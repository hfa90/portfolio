# -*- coding: utf-8 -*-
"""Ações na tela (modo frente): janelas, mouse, teclado, imagens, Chrome (CDP), aguardar carregamento e rolagem.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import re

try:
    from motor_util import (BTN_MAP, ImageChops, ImageGrab, ImageNotFound, KB, Parado, WIN, cursor_ocupado, jc,
                            json, melhor_correspondencia, nav, os, outro_programa, parse_teclas,
                            pixels_rolagem, pyautogui, time, xt, uia, ocr, Image)
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    pass


class TelaMixin:

    # ------------------------------------------------------------ ações na tela (modo frente)
    def _garantir_tela(self, s, cfg):
        """Antes de cada ação na tela: a janela certa (Chrome ou o programa gravado) maximizada e na frente."""
        if outro_programa(s):
            self._garantir_janela(s["janela"], cfg)
        else:
            self._garantir_chrome(cfg)

    def _garantir_janela(self, info, cfg):
        if not (cfg.get("max_chrome") and jc.WIN):
            return
        prog = info.get("processo", "")
        hwnd = jc.achar_janela(info)
        if not hwnd:
            if prog not in self._janelas_avisadas:
                self._janelas_avisadas.add(prog)
                self.log(f"Aviso: nenhuma janela do programa {prog} aberta — confira se ele está aberto.", "erro")
                self.avisos += 1
            return
        e = jc.estado(hwnd)
        if e and e["ok"] and jc.janela_em_foco() == hwnd:
            return
        hwnd, antes, corrigiu = jc.garantir_janela(info, frente=True)
        if corrigiu and antes:
            self.log(f"Janela do {prog} estava {antes['descricao']} → maximizada.", "ok")
        elif hwnd:
            self.log(f"Janela do {prog} trazida para a frente.")
        time.sleep(0.25)

    def _garantir_chrome(self, cfg):
        """Antes das ações que dependem da tela: Chrome maximizado, no monitor principal e na frente."""
        if not (cfg.get("max_chrome") and jc.WIN):
            return
        lista = jc.listar_chrome()
        if self._hwnd_chrome not in lista:
            self._hwnd_chrome = jc.chrome_principal()
        if not self._hwnd_chrome:
            if not self._aviso_sem_chrome:
                self.log("Aviso: nenhuma janela do Chrome encontrada para maximizar.", "erro")
                self._aviso_sem_chrome = True
            return
        em_foco = jc.janela_em_foco() in lista
        e = jc.estado(self._hwnd_chrome)
        if e["ok"] and em_foco:
            return
        hwnd, antes, corrigiu = jc.garantir_maximizado(self._hwnd_chrome, frente=True)
        if corrigiu:
            self.log(f"Chrome estava {antes['descricao']} → maximizado.", "ok")
        elif not em_foco:
            self.log("Chrome trazido para a frente.")
        time.sleep(0.2)

    def _mover(self, x, y, cfg):
        self.ui.desviar(x, y)  # a caixinha de status do bot não pode estar debaixo do clique
        if cfg["visual"]:
            dur = max(0.1, 0.7 / cfg["vel"])
            self.ui.marcador(x, y, ms=int((dur + 0.4 / cfg["vel"]) * 1000) + 150)
            pyautogui.moveTo(x, y, duration=dur, tween=pyautogui.easeInOutQuad)
            self._esperar(0.35 / cfg["vel"])
        else:
            pyautogui.moveTo(x, y)

    @staticmethod
    def _teclas_segurar(segurar):
        return [] if not segurar or segurar == "nenhuma" else parse_teclas(segurar)

    def _clicar(self, x, y, botao, cliques, cfg, segurar=None):
        self._mover(x, y, cfg)
        teclas = self._teclas_segurar(segurar)
        self.sending = True
        try:
            for t in teclas:  # Ctrl+clique / Shift+clique
                pyautogui.keyDown(t)
            pyautogui.click(x, y, clicks=int(cliques), interval=0.08, button=BTN_MAP.get(botao, "left"))
        finally:
            for t in reversed(teclas):
                pyautogui.keyUp(t)
            self.sending = False

    def _arrastar(self, x, y, x2, y2, botao, duracao, cfg, segurar=None):
        """Aperta em (x, y), leva até (x2, y2) e solta (selecionar intervalo, alça de preencher, mover...)."""
        self.ui.desviar(x2, y2)
        self._mover(x, y, cfg)
        teclas = self._teclas_segurar(segurar)
        botao = BTN_MAP.get(botao, "left")
        self.sending = True
        try:
            for t in teclas:
                pyautogui.keyDown(t)
            pyautogui.mouseDown(x, y, button=botao)
            time.sleep(0.12)
            pyautogui.moveTo(x2, y2, duration=max(0.2, float(duracao) / max(0.25, cfg["vel"])))
            time.sleep(0.12)
            pyautogui.mouseUp(x2, y2, button=botao)
        finally:
            for t in reversed(teclas):
                pyautogui.keyUp(t)
            self.sending = False
        if cfg["visual"]:
            self.ui.marcador(x2, y2, ms=500)

    def _posicao_uia(self, s, x, y):
        """Posição do elemento gravado (botão, campo...) na janela do programa AGORA; None = imagem/posição."""
        alvo = s["alvo_uia"]
        hwnd = jc.achar_janela(s["janela"]) if s.get("janela") and jc.WIN else None
        pos = uia.posicao_elemento(alvo, hwnd)
        nome = uia.descrever(alvo)
        if pos:
            if abs(pos[0] - x) > 3 or abs(pos[1] - y) > 3:
                self.log(f"Elemento {nome}: posição ajustada ({x}, {y}) -> {pos}")
            return pos
        if uia.HAS_UIA:
            self.log(f"Aviso: não achei o {nome} na janela; usando a imagem/posição gravada.")
        return None

    # ------------------------------------------------------------ texto da tela (OCR)
    def _regiao_ocr(self, s):
        r = s.get("regiao") or "janela da frente"
        if r.startswith("janela"):
            return "janela"
        if r.startswith("área"):
            return (int(s.get("x", 0)), int(s.get("y", 0)), int(s.get("largura") or 400), int(s.get("altura") or 120))
        if r.startswith("arquivo"):
            caminho = self.caminho(self._x(s.get("arquivo")))
            if not caminho or not os.path.isfile(caminho):
                raise FileNotFoundError(f"imagem não encontrada: {caminho or '(vazio)'}")
            return ("arquivo", caminho)
        return None

    def _ler_ocr(self, regiao, idioma):
        if isinstance(regiao, tuple) and regiao and regiao[0] == "arquivo":
            return "\n".join(l["texto"] for l in ocr.reconhecer(Image.open(regiao[1]), idioma))
        return ocr.ler(regiao, idioma)

    def _passo_ocr(self, s, cfg):
        idioma = s.get("idioma") or "pt-BR"
        regiao = self._regiao_ocr(s)
        if s["tipo"] == "ler_tela":
            padrao = s.get("regex") or ""
            limite = time.time() + max(0.0, float(s.get("timeout") or 0))
            while True:
                texto = self._ler_ocr(regiao, idioma)
                valor = texto
                if padrao:
                    m = re.search(padrao, texto, re.IGNORECASE)
                    valor = (m.group(1) if m and m.groups() else m.group(0)) if m else None
                if valor is not None or time.time() >= limite:
                    break
                self._esperar(0.6)
            if valor is None:
                raise RuntimeError(f"o padrão {padrao} não apareceu no texto da tela (lido: {texto[:120]!r})")
            nome = s.get("variavel") or "texto_tela"
            self.vars[nome] = valor.strip()
            self.log(f"Texto da tela → {{{nome}}} = {valor.strip()[:80]!r}")
            return
        texto = self._x(s.get("texto", ""))
        limite = time.time() + max(0.5, float(s.get("timeout") or 10))
        while True:
            pos = ocr.achar(texto, regiao, idioma, int(s.get("ocorrencia") or 1))
            if pos or time.time() >= limite:
                break
            self._esperar(0.6)
        if not pos:
            raise RuntimeError(f"o texto \"{texto}\" não apareceu na tela")
        x, y = pos[0] + int(s.get("offset_x") or 0), pos[1] + int(s.get("offset_y") or 0)
        self.log(f"Texto \"{texto}\" achado em ({x}, {y})")
        self._clicar(x, y, s.get("botao", "esquerdo"), s.get("cliques", 1), cfg)
        if s.get("aguardar"):
            self._aguardar_carregar({"metodo": "automático", "estavel": 1.2, "timeout": 60}, cfg)

    def _posicao_excel(self, alvo, x, y):
        """Posição da célula gravada (ex.: Dados!B5) na tela AGORA, conferida com o Excel; None = usar a gravada."""
        if not alvo:
            return None
        pos = xt.posicao_da_celula(alvo, log=self.log)
        nome = xt.texto_alvo(alvo)
        if pos:
            if abs(pos[0] - x) > 3 or abs(pos[1] - y) > 3:
                self.log(f"Célula {nome}: posição ajustada ({x}, {y}) -> {pos}")
            return pos
        self.log(f"Aviso: não consegui achar a célula {nome} pelo Excel; usando a posição gravada.", "erro")
        self.avisos += 1
        return None

    def _teclas(self, texto):
        partes = parse_teclas(texto)
        self.sending = True
        try:
            if len(partes) == 1:
                pyautogui.press(partes[0])
            else:
                pyautogui.hotkey(*partes, interval=0.05)
            time.sleep(0.12)
        finally:
            self.sending = False

    def _digitar(self, texto, cfg):
        intervalo = 0.055 / cfg["vel"] if cfg["visual"] else 0.004
        self.sending = True
        try:
            for ch in texto:
                if self.stop_event.is_set():
                    raise Parado()
                if KB is not None:
                    KB.type(ch)  # Unicode: acentos e qualquer layout de teclado (ABNT2)
                else:
                    pyautogui.write(ch)
                time.sleep(intervalo)
            time.sleep(0.12)
        finally:
            self.sending = False

    def _procurar(self, s, cfg):
        caminho = self.caminho(s["imagem"])
        if not os.path.exists(caminho):
            raise FileNotFoundError(f"imagem não encontrada no disco: {s['imagem']}")
        limite = time.time() + float(s.get("timeout", 10))
        while True:
            if self.stop_event.is_set():
                raise Parado()
            try:
                box = melhor_correspondencia(caminho)
                if box and box.score < float(s.get("confianca", 0.85)):
                    box = None
            except (ImageNotFound, OSError):
                box = None
            if box:
                if cfg["visual"]:
                    self.ui.marcador(int(box.left), int(box.top), int(box.width), int(box.height),
                                     cor="#00e5ff", ms=900)
                    self._esperar(0.5 / cfg["vel"])
                return box
            if time.time() >= limite:
                raise TimeoutError(f"'{os.path.basename(caminho)}' não apareceu na tela em {s.get('timeout')}s "
                                   f"(tente diminuir a precisão ou recapturar a imagem)")
            self._esperar(0.4)

    def _posicao_conferida(self, s, x, y):
        """Procura a imagem de referência perto do ponto gravado e corrige a posição se o elemento se moveu."""
        caminho = self.caminho(s["imagem"])
        if not os.path.exists(caminho):
            self.log(f"Aviso: imagem de referência sumiu ({s['imagem']}); usando posição gravada.", "erro")
            return x, y
        sw, sh = pyautogui.size()
        esp_x, esp_y = int(s.get("ref_x", x)), int(s.get("ref_y", y))  # onde o recorte estava na gravação
        raio = 350
        l, t = max(0, x - raio), max(0, y - raio)
        regiao = (l, t, min(sw, x + raio) - l, min(sh, y + raio) - t)
        box = None
        for reg in (regiao, None):  # 1º perto do ponto, depois a tela toda (aí só se for bem parecido e único)
            try:
                achado = melhor_correspondencia(caminho, reg)
            except Exception:
                achado = None
            if not achado:
                continue
            perto = abs(achado.left - esp_x) <= 40 and abs(achado.top - esp_y) <= 40
            if reg and achado.score >= 0.8 and (achado.unico or perto):
                box = achado
                break
            if not reg and achado.score >= 0.9 and achado.unico:
                box = achado
                break
        if not box:
            self.log(f"Aviso: referência não encontrada na tela; usando posição gravada ({x}, {y}).", "erro")
            return x, y
        if "ref_x" in s:
            nx, ny = int(box.left) + (x - esp_x), int(box.top) + (y - esp_y)
        else:
            nx, ny = int(box.left + box.width / 2), int(box.top + box.height / 2)
        if abs(nx - x) > 3 or abs(ny - y) > 3:
            self.log(f"Posição corrigida pela imagem: ({x}, {y}) -> ({nx}, {ny})")
        return nx, ny

    def _posicao_por_elemento(self, s):
        """Com o Chrome controlado: posição atual na tela do elemento que foi clicado na gravação."""
        if not (s.get("alvo") and jc.WIN and nav.cdp_disponivel()):
            return None
        try:
            n = self._conectar()
            obj = self._achar(s["alvo"], timeout=4)
            if not obj:
                return None
            l, t, r, b = n.caixa(obj)
            px, py = self._ponto_no_elemento(s["alvo"], l, t, r, b)
            hwnd = jc.chrome_principal()
            org = jc.origem_pagina(hwnd)
            if not org:
                return None
            dpr = float(n.avaliar("devicePixelRatio") or 1)
            return int(round(org[0] + px * dpr)), int(round(org[1] + py * dpr))
        except Exception:
            return None

    # ------------------------------------------------------------ Chrome (CDP)
    def _conectar(self):
        if self.nav and self.nav.vivo:
            return self.nav
        if not nav.cdp_disponivel():
            raise RuntimeError("o Chrome do bot (modo controlado) não está aberto. Comece o roteiro com o passo "
                               "'Abrir Chrome' com 'Modo controlado' marcado.")
        self.nav = nav.Navegador(ao_log=self.log)
        return self.nav

    def _achar(self, alvo, timeout=10.0):
        """Espera o elemento gravado aparecer na página (como uma pessoa esperaria a página montar)."""
        n = self._conectar()
        fim = time.time() + timeout
        while True:
            try:
                obj = n.achar(alvo)
                if obj:
                    return obj
            except Exception:
                pass
            if time.time() >= fim:
                return None
            self._esperar(0.3)

    @staticmethod
    def _ponto_no_elemento(alvo, l, t, r, b):
        """O mesmo ponto relativo dentro do elemento onde se clicou na gravação (ou o centro)."""
        w, h = r - l, b - t
        if alvo.get("w") and alvo.get("h") and alvo.get("ox") is not None:
            fx = min(max(alvo["ox"] / alvo["w"], 0.1), 0.9)
            fy = min(max(alvo["oy"] / alvo["h"], 0.1), 0.9)
            return l + w * fx, t + h * fy
        return l + w / 2, t + h / 2

    def _js(self, expr):
        """Avalia na página: na aba do bot (segundo plano) ou na aba ativa (modo frente)."""
        if self._bg:
            return self._conectar().avaliar_json(expr)
        return nav.cdp_json(expr)

    # ---- aguardar carregamento
    def _aguardar_carregar(self, s, cfg):
        metodo = s.get("metodo", "automático")
        estavel = max(0.3, float(s.get("estavel", 1.5)))
        limite = time.time() + float(s.get("timeout", 60))
        seletor = (s.get("seletor") or "").strip()
        self._esperar(0.4)  # dá tempo da navegação começar depois de um clique
        if self._bg:
            return self._aguardar_chrome(seletor, estavel, limite)
        if metodo in ("automático", "chrome"):
            if nav.cdp_disponivel():
                return self._aguardar_chrome(seletor, estavel, limite)
            if metodo == "chrome":
                raise RuntimeError("Chrome não está em modo controlado. Abra-o pelo passo 'Abrir Chrome' "
                                   "com 'Modo controlado' marcado" + ("" if nav.HAS_WS else
                                   " e instale websocket-client (pip install websocket-client)"))
            if seletor:
                self.log("Aviso: elemento CSS só funciona no modo chrome; usando detecção visual.", "erro")
        self._aguardar_visual(estavel, limite)

    def _aguardar_chrome(self, seletor, estavel, limite):
        assinatura, desde, ultimo = None, time.time(), {}
        base_desde = None  # desde quando o documento está pronto (e o elemento pedido apareceu)
        expr = nav.JS_ESTADO % json.dumps(seletor or "")
        while True:
            if self.stop_event.is_set():
                raise Parado()
            try:
                e = self._js(expr) or {}
            except Exception:
                e = {}  # aba trocando de página: tenta de novo
            base = e.get("rs") == "complete" and (not seletor or e.get("alvo"))
            base_desde = (base_desde or time.time()) if base else None
            # Sites como o Gmail ficam carregando imagens/fontes sem parar (fotos, ícones sob demanda): com o
            # documento pronto há uns segundos, isso não segura mais a execução.
            demorando = base_desde is not None and time.time() - base_desde >= max(8.0, estavel * 4)
            pronto = base and ((e.get("imgs") and e.get("fontes")) or demorando)
            sig = (e.get("url"), e.get("res") if not demorando else None)
            if not pronto or sig != assinatura:
                assinatura, desde = sig, time.time()
            elif time.time() - desde >= estavel:
                extra = "" if e.get("imgs") and e.get("fontes") else " (imagens ainda chegando: seguindo)"
                self.log(f"Página carregada: {e.get('url', '')[:80]}{extra}", "ok")
                return
            ultimo = e
            if time.time() >= limite:
                if base:  # só faltaram imagens/fontes ou a rede não parou: dá para continuar
                    self.log(f"Página pronta, mas ainda carregando imagens/dados: seguindo "
                             f"({ultimo.get('url', '')[:80]})")
                    return
                falta = []
                if ultimo.get("rs") != "complete":
                    falta.append(f"documento '{ultimo.get('rs')}'")
                if not ultimo.get("imgs"):
                    falta.append("imagens")
                if seletor and not ultimo.get("alvo"):
                    falta.append(f"elemento {seletor}")
                raise TimeoutError("a página não terminou de carregar" +
                                   (f" (faltou: {', '.join(falta)})" if falta else " (rede não ficou parada)"))
            self._esperar(0.25)

    def _aguardar_visual(self, estavel, limite):
        anterior, desde = None, time.time()
        while True:
            if self.stop_event.is_set():
                raise Parado()
            img = ImageGrab.grab().convert("L")
            w, h = img.size
            img.paste(0, (max(0, w - 440), 0, w, 170))  # ignora o painel de status do bot
            img = img.resize((max(1, w // 4), max(1, h // 4)))
            mudou = True
            if anterior is not None:
                diff = ImageChops.difference(img, anterior).point(lambda p: 255 if p > 24 else 0)
                fracao = diff.histogram()[255] / float(img.width * img.height)
                mudou = fracao > 0.002 or cursor_ocupado()  # 0,2%: ignora cursor piscando em campos
            if mudou:
                desde = time.time()
            elif time.time() - desde >= estavel:
                self.log("Tela estabilizada: página carregada.", "ok")
                return
            anterior = img
            if time.time() >= limite:
                raise TimeoutError("a tela não parou de mudar (página ainda carregando ou com animação)")
            self._esperar(0.25)

    # ---- rolagem
    def _rolar(self, s, cfg):
        x, y = int(s.get("x", 0)), int(s.get("y", 0))
        px = pixels_rolagem(s)
        alvo = s.get("alvo_y")
        if alvo not in (None, "") and (self._bg or nav.cdp_disponivel()):
            alvo, sel = int(float(alvo)), s.get("seletor") or ""
            ler = nav.JS_ROLAR_PARA % (json.dumps(sel), alvo, "null")
            r = None
            fim = time.time() + 8
            while time.time() < fim:  # espera o conteúdo carregar até dar altura para rolar
                try:
                    r = self._js(ler)
                except Exception:
                    r = None
                if r and r["max"] >= alvo - 3:
                    break
                self._esperar(0.3)
            if r:
                if r.get("via") == "maior_area":
                    self.log("Área rolável gravada não encontrada; usando a maior área rolável da página.")
                comp = "smooth" if cfg.get("visual") else "instant"
                self._js(nav.JS_ROLAR_PARA % (json.dumps(sel), alvo, json.dumps(comp)))
                fim = time.time() + 3
                while time.time() < fim:  # confere se a página chegou lá
                    self._esperar(0.2)
                    r = self._js(ler) or r
                    if abs(r["top"] - alvo) <= 3:
                        return
                falta = alvo - int(r["top"])
                self.log(f"Aviso: a página parou em {int(r['top'])} px (esperado {alvo}); "
                         f"completando com a roda do mouse.", "erro")
                if abs(falta) < 3:
                    return
                px = falta
            else:
                self.log("Aviso: não consegui ler a página; rolando pela roda do mouse.", "erro")
        if self._bg:
            n = self._conectar()
            if x or y:
                cx, cy = self._tela_para_pagina(s)
            else:
                cx, cy = n.avaliar_json("JSON.stringify([innerWidth / 2, innerHeight / 2])")
            for parte in range(0, abs(px), 100):
                n.roda(cx, cy, min(100, abs(px) - parte) * (1 if px > 0 else -1))
                self._esperar(0.05 if cfg["visual"] else 0.01)
            return
        if x or y:
            self._mover(x, y, cfg)
        if not WIN:
            n = max(1, round(abs(px) / 100))
            for _ in range(n):
                pyautogui.scroll(-1 if px > 0 else 1)
                self._esperar(0.12 / cfg["vel"] if cfg["visual"] else 0.02)
            return
        # Windows: giro bruto proporcional aos pixels (120 = 1 clique = linhas x 100/3 px no Chrome)
        total = int(round(abs(px) * 120 / (jc.linhas_por_clique() * 100 / 3.0)))
        pedaco = 40 if cfg["visual"] else 120
        sinal = -1 if px > 0 else 1
        while total > 0:
            parte = min(pedaco, total)
            pyautogui.scroll(sinal * parte)
            total -= parte
            self._esperar(0.03 / cfg["vel"] if cfg["visual"] else 0.01)
