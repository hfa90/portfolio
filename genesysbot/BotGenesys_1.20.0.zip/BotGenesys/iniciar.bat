@echo off
title Bot Genesys
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    echo Primeira vez neste computador: executando o instalador...
    call "%~dp0instalar.bat"
    exit /b
)
call .venv\Scripts\activate.bat
if not exist .venv\instalado_v5.ok (
    echo Instalando dependencias...
    pip install -r requirements.txt && echo ok> .venv\instalado_v5.ok
)
python bot_genesys.py
if errorlevel 1 pause
