# -*- coding: utf-8 -*-
"""Modo SEGUNDO PLANO: o bot trabalha numa janela própria do Chrome, sem usar o seu mouse e teclado.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
try:
    from motor_util import (BTN_MAP, Parado, expandir, jc, melhor_correspondencia, nav, os, parse_teclas, time)
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    pass


class FundoMixin:

    # ------------------------------------------------------------ SEGUNDO PLANO
    def _preparar_fundo(self, itens):
        """Liga a conexão com o Chrome do bot (se o roteiro não começar abrindo o Chrome)."""
        if itens and itens[0][1]["tipo"] == "abrir_chrome":
            return
        n = self._conectar()
        n.escolher_aba()
        self._janela_do_bot_atras(n, ajustar=False)
        n.emular_foco(True)

    def _janela_do_bot_atras(self, n, ajustar=True, foco_antes=None, janelas_antes=None):
        """Deixa a janela do bot do tamanho da tela, atrás das suas janelas, e devolve o foco para você."""
        if not jc.WIN:
            return
        try:
            hwnd = jc.aguardar_nova_janela(janelas_antes, 6) if janelas_antes is not None else None
            if ajustar:
                import ctypes as _c
                from ctypes import wintypes as _w
                r = _w.RECT()
                _c.windll.user32.SystemParametersInfoW(0x0030, 0, _c.byref(r), 0)
                n.ajustar_janela(r.left, r.top, r.right - r.left, r.bottom - r.top)
            for h in ([hwnd] if hwnd else jc.listar_chrome()[:1]):
                jc.restaurar_sem_ativar(h)
                jc.enviar_para_tras(h)
            if foco_antes:
                jc.trazer_para_frente(foco_antes)
        except Exception:
            pass

    def _tela_para_pagina(self, s):
        """Converte a posição gravada na tela para a posição dentro da página."""
        x, y = int(s.get("x", 0)), int(s.get("y", 0))
        vp = s.get("vp")
        if vp:
            return (x - vp[0]) / vp[2], (y - vp[1]) / vp[2]
        esc = jc.escala() if jc.WIN else 1.0
        topo = int(130 * esc)  # altura típica das abas + barra de endereço com o Chrome maximizado
        try:
            hwnd = jc.chrome_principal()
            org, ret = jc.origem_pagina(hwnd), jc.retangulo(hwnd)
            if org and ret:
                topo = org[1] - ret[1]
        except Exception:
            pass
        return x / esc, (y - topo) / esc

    def _passo_fundo(self, s, cfg):
        t = s["tipo"]
        botao = BTN_MAP.get(s.get("botao", "esquerdo"), "left")
        if t == "abrir_chrome":
            url = expandir(s.get("url", ""), self._valores())
            foco = jc.janela_em_foco() if jc.WIN else None
            antes = set(jc.listar_chrome()) if jc.WIN else set()
            vazias = []
            if not nav.cdp_disponivel():
                # abre o Chrome do bot vazio e depois cria a janela do sistema: assim o bot sabe
                # exatamente qual é a aba dele (mesmo que o Chrome reabra abas antigas)
                nav.abrir_chrome("about:blank", True, self.perfil)
                fim = time.time() + 25
                while not nav.cdp_disponivel():
                    if time.time() > fim:
                        raise RuntimeError("o Chrome do bot não abriu em modo controlado")
                    self._esperar(0.5)
                self._esperar(1.0)
                n = self._conectar()
                vazias = [t["targetId"] for t in n.paginas()
                          if t.get("url", "").startswith(("about:blank", "chrome://newtab", "chrome://new-tab"))]
            n = self._conectar()
            reaproveitou = bool(n.aba and n.aba in n.alvos and not vazias)
            if reaproveitou:
                # o bot já tem a janela dele (ex.: próximo chamado da planilha): reaproveita
                n.enviar("Page.navigate", {"url": url}, n.sessao())
            else:
                n.nova_janela(url, fundo=True)
            for tid in vazias:
                try:
                    n.enviar("Target.closeTarget", {"targetId": tid})
                except Exception:
                    pass
            self._esperar(float(s.get("espera", 1)))
            if reaproveitou:
                self.log("Usando a mesma janela do bot para o próximo chamado.")
            else:
                self._janela_do_bot_atras(n, ajustar=bool(s.get("maximizar", True)), foco_antes=foco,
                                          janelas_antes=antes)
                n.emular_foco(True)
                self.log("Chrome do bot aberto atrás das suas janelas.")
            if s.get("aguardar", True):
                self._aguardar_carregar({"estavel": 1.5, "timeout": 60}, cfg)
        elif t == "clique":
            n = self._conectar()
            feito = False
            if s.get("alvo"):
                obj = self._achar(s["alvo"], timeout=12)
                if obj:
                    l, tp, r, b = n.caixa(obj)
                    if cfg["visual"]:
                        n.destacar(obj, 600)
                        self._esperar(0.3 / cfg["vel"])
                    x, y = self._ponto_no_elemento(s["alvo"], l, tp, r, b)
                    n.clicar(x, y, botao, int(s.get("cliques", 1)), self._teclas_segurar(s.get("segurar")))
                    feito = True
                else:
                    self.log("Aviso: elemento gravado não apareceu na página; usando a posição gravada.", "erro")
            if not feito:
                x, y = self._tela_para_pagina(s)
                n.clicar(x, y, botao, int(s.get("cliques", 1)), self._teclas_segurar(s.get("segurar")))
            if s.get("aguardar"):
                self._aguardar_carregar({"estavel": 1.2, "timeout": 60}, cfg)
        elif t == "digitar":
            n = self._conectar()
            if s.get("limpar"):
                n.tecla("a", ("ctrl",))
                n.tecla("backspace")
            texto = expandir(s.get("texto", ""), self._valores())
            partes = texto.split("\n")
            for k, parte in enumerate(partes):
                if cfg["visual"]:
                    for ch in parte:
                        if self.stop_event.is_set():
                            raise Parado()
                        n.inserir_texto(ch)
                        time.sleep(0.03 / cfg["vel"])
                elif parte:
                    n.inserir_texto(parte)
                if k < len(partes) - 1:
                    n.tecla("enter")
            if s.get("enter"):
                n.tecla("enter")
        elif t == "tecla":
            n = self._conectar()
            partes = parse_teclas(s["teclas"])
            mods = tuple(p for p in partes if p in ("ctrl", "alt", "shift", "win"))
            principais = [p for p in partes if p not in mods]
            if "win" in mods or not principais:
                self.log(f"Aviso: o atalho '{s['teclas']}' é do Windows e não vale em segundo plano; pulado.",
                         "erro")
                return
            for _ in range(max(1, int(s.get("repetir", 1)))):
                n.tecla(principais[-1], mods)
                self._esperar(0.1 / cfg["vel"] if cfg["visual"] else 0.03)
        elif t == "esperar":
            self._esperar(float(s.get("segundos", 1)))
        elif t == "aguardar_carregar":
            self._aguardar_carregar(s, cfg)
        elif t in ("clicar_imagem", "esperar_imagem"):
            n = self._conectar()
            caminho = self.caminho(s["imagem"])
            limite = time.time() + float(s.get("timeout", 10))
            while True:
                img, dpr = n.captura()
                box = melhor_correspondencia(caminho, tela=img)
                if box and box.score >= float(s.get("confianca", 0.85)):
                    break
                if time.time() >= limite:
                    raise TimeoutError(f"'{os.path.basename(caminho)}' não apareceu na página em "
                                       f"{s.get('timeout')}s")
                self._esperar(0.5)
            if t == "clicar_imagem":
                x = (box.left + box.width / 2 + int(s.get("offset_x", 0))) / dpr
                y = (box.top + box.height / 2 + int(s.get("offset_y", 0))) / dpr
                n.clicar(x, y, botao, int(s.get("cliques", 1)))
                if s.get("aguardar"):
                    self._aguardar_carregar({"estavel": 1.2, "timeout": 60}, cfg)
        elif t == "rolar":
            self._rolar(s, cfg)
        else:
            raise ValueError(f"tipo de passo desconhecido: {t}")
