# -*- coding: utf-8 -*-
"""
Compatibilidade: o programa agora se chama Bot Genesys e o arquivo principal é bot_genesys.py.
Este arquivo só repassa para ele (agendamentos e atalhos antigos continuam funcionando).
"""
import os
import runpy
import sys

_principal = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_genesys.py")
sys.argv[0] = _principal
runpy.run_path(_principal, run_name="__main__")
