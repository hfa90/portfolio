# -*- coding: utf-8 -*-
"""
IA (Claude, da Anthropic) no Bot Genesys.

- gerar_passos(): "filtre as linhas de nota acima de 1.000 para uma aba nova" -> passos do roteiro (conferidos
  com o catálogo antes de entrar).
- perguntar(): pergunta sobre um texto, a tela ou uma imagem -> resposta (texto, número, sim/não ou JSON).
- localizar(): "o botão azul Salvar" -> posição na imagem da tela (visão computacional).
- explicar_erro(): lê o log, o passo que falhou e o print -> causa e o que mudar.

Precisa de uma chave da API da Anthropic (console.anthropic.com), guardada criptografada pelo Windows.
A chamada vai direto ao endereço da API (urllib): não depende de biblioteca extra.
"""
import base64
import io
import json
import os
import re
import time
import urllib.error
import urllib.request

URL_API = "https://api.anthropic.com/v1/messages"
VERSAO_API = "2023-06-01"
MODELOS = ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"]
MODELO_PADRAO = MODELOS[0]
FORMATOS_IA = ["texto", "número", "sim ou não", "JSON"]
INCLUIR = ["nada (só o texto)", "tela inteira", "janela da frente", "arquivo de imagem"]
MAX_LADO_IMAGEM = 1568  # maior lado enviado (a API reduz imagens maiores; mandar já reduzido é mais rápido)


class ErroIA(RuntimeError):
    pass


def limpar_chave(chave):
    """Tira espaços, quebras de linha e aspas que vêm junto ao copiar a chave."""
    return re.sub(r"\s+", "", str(chave or "")).strip("\"'“”‘’")


def formato_chave(chave):
    """None se parece uma chave da API; senão, o que está estranho."""
    c = limpar_chave(chave)
    if not c:
        return "a chave está vazia"
    if not c.startswith("sk-ant-"):
        return ("não começa com 'sk-ant-' — as chaves da API da Anthropic começam assim (crie em "
                "console.anthropic.com › API Keys; a assinatura do claude.ai não tem chave de API)")
    if c.startswith("sk-ant-admin"):
        return "é uma chave de ADMINISTRAÇÃO (sk-ant-admin…): crie uma chave de API normal"
    if len(c) < 60:
        return f"está curta ({len(c)} caracteres): parece copiada pela metade"
    return None


# --------------------------------------------------------------------------- chave e chamada
def chave_configurada(app_dir=None, abrir=None):
    """Chave da API: a guardada em IA › Configurar (config_app.json, criptografada) e, só se não houver, a
    variável de ambiente ANTHROPIC_API_KEY (que pode ter ficado com uma chave antiga de outra ferramenta)."""
    if app_dir and abrir:
        try:
            with open(os.path.join(app_dir, "config_app.json"), encoding="utf-8") as f:
                guardada = (json.load(f).get("ia") or {}).get("chave_protegida")
            if guardada:
                return limpar_chave(abrir(guardada))
        except (OSError, ValueError, KeyError):
            pass
        except Exception:
            raise ErroIA("não consegui abrir a chave da IA guardada (outro usuário do Windows?). "
                         "Configure de novo em IA › Configurar.") from None
    return limpar_chave(os.environ.get("ANTHROPIC_API_KEY", ""))


def modelo_configurado(app_dir=None):
    try:
        with open(os.path.join(app_dir, "config_app.json"), encoding="utf-8") as f:
            return (json.load(f).get("ia") or {}).get("modelo") or MODELO_PADRAO
    except (OSError, ValueError, TypeError):
        return MODELO_PADRAO


def imagem_bloco(img, max_lado=MAX_LADO_IMAGEM):
    """(bloco de imagem para a API, fator) — fator = quanto multiplicar as coordenadas da resposta."""
    fator = 1.0
    if max(img.size) > max_lado:
        fator = max(img.size) / max_lado
        img = img.resize((round(img.width / fator), round(img.height / fator)))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    dados = base64.b64encode(buf.getvalue()).decode("ascii")
    return {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": dados}}, fator, img.size


def chamar(chave, texto, sistema="", imagens=(), max_tokens=4096, modelo=None, timeout=180, tentativas=3):
    """Uma pergunta à IA. imagens = blocos de imagem_bloco(). Devolve o texto da resposta."""
    chave = limpar_chave(chave)
    if not chave:
        raise ErroIA("falta a chave da API da IA: menu IA › Configurar (crie em console.anthropic.com)")
    conteudo = list(imagens) + [{"type": "text", "text": texto}]
    corpo = {"model": modelo or MODELO_PADRAO, "max_tokens": int(max_tokens),
             "messages": [{"role": "user", "content": conteudo}]}
    if sistema:
        corpo["system"] = sistema
    dados = json.dumps(corpo).encode("utf-8")
    for n in range(tentativas):
        req = urllib.request.Request(URL_API, data=dados, method="POST", headers={
            "x-api-key": chave, "anthropic-version": VERSAO_API, "content-type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                resp = json.loads(r.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
            except Exception:
                msg = ""
            if e.code in (429, 500, 502, 503, 529) and n + 1 < tentativas:
                time.sleep(3 * (n + 1))
                continue
            raise ErroIA({401: "a chave da API foi recusada pela Anthropic — " + (
                              formato_chave(chave) or "ela não existe mais ou foi desativada no console "
                              "(console.anthropic.com › API Keys); crie uma nova") +
                          ". Cole a nova em IA › Configurar e use o botão Testar",
                          403: "a chave não tem permissão para isso",
                          404: f"modelo não encontrado ({corpo['model']}) — escolha outro em IA › Configurar",
                          429: "limite de uso da API atingido; espere um pouco",
                          529: "a IA está sobrecarregada agora; tente de novo em instantes"}.get(
                e.code, f"a API respondeu {e.code}") + (f": {msg}" if msg else "")) from None
        except urllib.error.URLError as e:
            if n + 1 < tentativas:
                time.sleep(2)
                continue
            raise ErroIA(f"sem conexão com a IA ({e.reason})") from None
    texto = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text").strip()
    if not texto:
        raise ErroIA(f"a IA não respondeu texto (motivo: {resp.get('stop_reason')})")
    return texto


def extrair_json(texto):
    """O primeiro objeto/lista JSON da resposta (aceita ```json ... ``` e texto em volta)."""
    m = re.search(r"```(?:json)?\s*(.+?)```", texto, re.S)
    candidatos = [m.group(1)] if m else []
    candidatos.append(texto)
    dec = json.JSONDecoder()
    for c in candidatos:
        for i, ch in enumerate(c):
            if ch in "{[":
                try:
                    return dec.raw_decode(c[i:])[0]
                except ValueError:
                    continue
    raise ErroIA("a resposta da IA não veio no formato combinado (JSON)")


# --------------------------------------------------------------------------- catálogo -> IA
def descrever_catalogo(cat):
    """Texto compacto com todos os tipos de passo e seus campos, para a IA montar roteiros."""
    linhas = []
    for p in cat.CATALOGO:
        campos = []
        for chave, rotulo, tipo, padrao, opcoes in p.campos:
            if tipo == "pos":
                campos.append('x,y: int (posição na tela)')
                continue
            if tipo == "segredo":
                continue  # senhas/tokens: a pessoa preenche no formulário
            t = {"str": "texto", "text": "texto longo", "int": "inteiro", "float": "número", "bool": "true/false",
                 "arq": "caminho", "img": "imagem png", "formula": "fórmula"}.get(tipo, tipo)
            if tipo == "choice":
                t = "um de " + json.dumps(opcoes, ensure_ascii=False)
            campos.append(f"{chave}: {t} — {rotulo} (padrão {json.dumps(padrao, ensure_ascii=False)})")
        dica = re.sub(r"\s+", " ", p.dica or "")[:420]
        linhas.append(f"### {p.tipo} = {p.nome}{'  [usa a tela]' if p.tela else ''}\n"
                      + ("".join(f"  - {c}\n" for c in campos) or "  (sem campos)\n") + (f"  Dica: {dica}\n" if dica else ""))
    return "\n".join(linhas)


BOAS_PRATICAS = """- Pense na CADEIA de eventos de cada ação e trate cada consequência com um passo: o que abre, o que pode
  aparecer, como saber que deu certo.
- Enviar/anexar arquivo num SITE (Gmail, portal, formulário): use chrome_anexar com o formulário já aberto — nunca
  clique no clipe/botão de upload nem digite caminho numa janela. Depois confira (conferir=true).
- Num PROGRAMA DESKTOP que abre a janela 'Abrir'/'Salvar como': o clique que a abre e logo depois
  win_escolher_arquivo (ele espera a janela aparecer). Nunca 'esperar' + 'digitar' às cegas.
- Avisos previsíveis (ex.: Gmail 'esqueceu de anexar?', 'deseja sair da página?', 'arquivo já existe, substituir?',
  'sessão expirada', cookies): coloque passos vigiar_popup no INÍCIO do roteiro dizendo o que responder. Use
  'parar o roteiro com erro' quando o aviso significa que algo deu errado (ex.: esqueceu o anexo → Cancelar e parar).
- Depois de ações que demoram, espere pelo RESULTADO (aguardar_carregar com seletor, se_pagina com texto, arq_esperar,
  se_janela) em vez de 'esperar' segundos fixos; use 'esperar' só como folga curta.
- Login: se_pagina verificando um elemento que só existe logado; se não estiver, aguardar_usuario com
  'aparecer na página do Chrome' (continua sozinho depois do login).
- Ao final de ações importantes (enviar, salvar, gravar), confirme com se_pagina/se_texto_tela/se_arquivo e
  notifique ou pare com erro se não confirmou.
- Gmail: compor pela URL https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=...&su={assunto_url}&body={corpo_url}
  (textos com definir_variavel 'codificar para link (URL)'), aguardar_carregar, chrome_anexar, tecla ctrl+enter, e
  se_pagina 'Mensagem enviada'. Vigie o aviso 'anexar' (Cancelar e parar)."""

SISTEMA_ROTEIRO = """Você monta roteiros do Bot Genesys, um robô de automação para Windows (Chrome, Excel, arquivos,
e-mail, programas desktop). Um roteiro é uma lista de passos executados em ordem. Responda SÓ com um JSON:
{"explicacao": "o que o roteiro faz, em 1-4 frases em português, e o que a pessoa precisa conferir",
 "passos": [ {"tipo": "...", "descricao": "frase curta", ...campos do tipo...}, ... ]}

Regras:
- Use apenas os tipos e campos do catálogo abaixo; valores de 'choice' exatamente como listados.
- Prefira passos que NÃO dependem de posição na tela: Excel (excel_*), arquivos (arq_*), Windows (win_*),
  e-mail, fluxo (se_*, repetir, tentar...), Chrome por seletor/texto. Cliques por posição (clique x,y) só se não houver
  alternativa — nesse caso diga na explicação que a pessoa deve gravar/ajustar esse clique.
- Para clicar em algo de um programa sem posição conhecida, use clicar_texto (texto visível) ou ia_clicar (descrição).
- Blocos: todo se_* termina com fim_se (senao opcional no meio); repetir termina com fim_repetir; tentar tem
  se_der_erro e termina com fim_tentar. Não deixe blocos abertos.
- Variáveis entre chaves: {data}, {hora}, colunas da planilha carregada, e as que passos anteriores guardam.
- Planilhas: use os passos excel_* com referências tipo Aba!A1 ou intervalos; filtros e cópias podem usar
  excel_escrever com fórmulas (ex.: FILTRO/FILTER) quando for o caminho mais simples.
- Não invente arquivos: se precisar de um caminho que a pessoa não deu, use um nome claro como
  C:\\caminho\\para\\planilha.xlsx e avise na explicação.
- Nunca coloque senhas ou tokens nos passos.
""" + "\n" + """BOAS PRÁTICAS (roteiro assertivo — não precisa ser rápido, precisa não falhar):""" + "\n" + """{boas}"""


def _converter(valor, tipo, padrao, opcoes):
    if tipo == "bool":
        return valor if isinstance(valor, bool) else str(valor).strip().casefold() in ("true", "1", "sim", "yes")
    if tipo == "int":
        return int(float(str(valor).replace(",", ".")))
    if tipo == "float":
        return float(str(valor).replace(",", "."))
    if tipo == "choice":
        if str(valor) in [str(o) for o in opcoes]:
            return int(valor) if isinstance(padrao, int) and not isinstance(padrao, bool) else str(valor)
        for o in opcoes:  # tolera maiúsculas/acentos diferentes
            if str(o).casefold() == str(valor).casefold():
                return o
        raise ValueError(f"'{valor}' não é uma opção ({', '.join(map(str, opcoes))})")
    return "" if valor is None else str(valor)


def normalizar_passos(lista, cat, ctx=None):
    """Confere os passos que a IA mandou: tipo conhecido, campos convertidos, padrões preenchidos, validação do
    formulário. Devolve (passos, avisos). Passos de tipo desconhecido são descartados (com aviso)."""
    if isinstance(lista, dict):
        lista = lista.get("passos") or []
    passos, avisos = [], []
    for n, bruto in enumerate(lista if isinstance(lista, list) else [], 1):
        if not isinstance(bruto, dict) or bruto.get("tipo") not in cat.TIPOS:
            avisos.append(f"passo {n}: tipo desconhecido '{bruto.get('tipo') if isinstance(bruto, dict) else bruto}'"
                          " — descartado")
            continue
        tipo = bruto["tipo"]
        p = {"tipo": tipo, "descricao": str(bruto.get("descricao") or "")[:120]}
        for chave, rotulo, kind, padrao, opcoes in cat.FIELDS[tipo]:
            if kind == "pos":
                for k in ("x", "y"):
                    try:
                        p[k] = int(float(bruto.get(k, 0)))
                    except (TypeError, ValueError):
                        p[k] = 0
                continue
            if kind == "segredo":
                p[chave] = ""
                continue
            if chave not in bruto:
                p[chave] = padrao
                continue
            try:
                p[chave] = _converter(bruto[chave], kind, padrao, opcoes)
            except (TypeError, ValueError) as e:
                p[chave] = padrao
                avisos.append(f"passo {len(passos) + 1} ({cat.TIPOS[tipo]}): campo '{rotulo}' — {e}; usei o padrão")
        if ctx is not None:
            try:
                erro = cat.validar(p, ctx)
            except Exception as e:
                erro = ("Valor inválido", str(e))
            if erro:
                avisos.append(f"passo {len(passos) + 1} ({cat.TIPOS[tipo]}): {erro[0]} — {erro[1]} (confira)")
        passos.append(p)
    return passos, avisos


def conferir_estrutura(passos, fx):
    try:
        fx.estrutura([p["tipo"] for p in passos])
        return None
    except fx.ErroEstrutura as e:
        return str(e)


def _sem_segredos(passos, cat):
    out = []
    for p in passos:
        p = {k: v for k, v in p.items() if not k.startswith("_") and not k.endswith("_protegido")
             and k not in ("janela", "alvo", "vp", "alvo_excel", "alvo_excel_fim", "alvo_uia", "ref_x", "ref_y")}
        for k in cat.CAMPOS_SEGREDO.get(p.get("tipo"), ()):
            p.pop(k, None)
        if p.get("tipo") == "digitar" and p.get("senha"):
            p["texto"] = "(senha oculta)"
        out.append(p)
    return out


SISTEMA_ROTEIRO = SISTEMA_ROTEIRO.replace("{boas}", BOAS_PRATICAS)


def gerar_passos(chave, pedido, cat, fx, atuais=(), colunas=(), substituir=False, ctx=None, modelo=None,
                 chamar_fn=None):
    """Pedido em português -> (passos, explicação, avisos). Uma rodada extra de correção se a estrutura vier
    quebrada."""
    chamar_fn = chamar_fn or chamar
    sistema = SISTEMA_ROTEIRO + "\n\nCATÁLOGO DE PASSOS:\n" + descrever_catalogo(cat)
    texto = f"Pedido: {pedido.strip()}\n"
    if colunas:
        texto += f"\nColunas da planilha carregada no bot (viram {{variáveis}}): {', '.join(map(str, colunas))}\n"
    if atuais:
        resumo = json.dumps(_sem_segredos(atuais, cat), ensure_ascii=False)[:30000]
        texto += (("\nRoteiro ATUAL (reescreva-o inteiro aplicando o pedido; mantenha o que não precisa mudar):\n"
                   if substituir else "\nRoteiro atual (só para contexto; devolva APENAS os passos NOVOS a "
                                      "acrescentar):\n") + resumo + "\n")
    resp = chamar_fn(chave, texto, sistema=sistema, max_tokens=16000, modelo=modelo)
    dados = extrair_json(resp)
    passos, avisos = normalizar_passos(dados, cat, ctx)
    erro = conferir_estrutura(passos, fx)
    if erro:  # uma chance de corrigir
        resp = chamar_fn(chave, texto + f"\nSua resposta anterior tinha este problema de blocos: {erro}\n"
                                        f"Resposta anterior:\n{json.dumps(dados, ensure_ascii=False)[:20000]}\n"
                                        "Corrija e responda o JSON completo de novo.",
                         sistema=sistema, max_tokens=16000, modelo=modelo)
        dados = extrair_json(resp)
        passos, avisos = normalizar_passos(dados, cat, ctx)
        erro = conferir_estrutura(passos, fx)
        if erro:
            avisos.insert(0, f"estrutura dos blocos: {erro} (ajuste antes de executar)")
    if not passos:
        raise ErroIA("a IA não devolveu nenhum passo válido" + (f" ({'; '.join(avisos[:3])})" if avisos else ""))
    explicacao = str(dados.get("explicacao") or "") if isinstance(dados, dict) else ""
    return passos, explicacao, avisos


# --------------------------------------------------------------------------- perguntar / localizar / explicar
def interpretar(resposta, formato):
    r = resposta.strip()
    if formato == "número":
        m = re.search(r"-?\d[\d.,]*", r)
        if not m:
            raise ErroIA(f"a IA não respondeu um número: {r[:120]!r}")
        n = m.group(0).rstrip(".,")
        if "," in n and "." in n:
            n = n.replace(".", "").replace(",", ".") if n.rfind(",") > n.rfind(".") else n.replace(",", "")
        elif "," in n:
            n = n.replace(",", ".")
        return n
    if formato == "sim ou não":
        t = r.casefold()
        if re.match(r"^\W*(sim|yes|verdadeiro|true)\b", t):
            return "sim"
        if re.match(r"^\W*(n[aã]o|no|falso|false)\b", t):
            return "não"
        raise ErroIA(f"a IA não respondeu sim ou não: {r[:120]!r}")
    if formato == "JSON":
        return json.dumps(extrair_json(r), ensure_ascii=False)
    return r


def perguntar(chave, pergunta, formato="texto", imagem=None, modelo=None, chamar_fn=None):
    chamar_fn = chamar_fn or chamar
    instr = {"texto": "Responda direto, sem introdução.",
             "número": "Responda SÓ com o número (sem unidade nem texto).",
             "sim ou não": "Responda SÓ 'sim' ou 'não'.",
             "JSON": "Responda SÓ com um JSON válido, sem texto em volta."}.get(formato, "")
    imgs = [imagem_bloco(imagem)[0]] if imagem is not None else []
    resp = chamar_fn(chave, f"{pergunta.strip()}\n\n{instr}", imagens=imgs, max_tokens=4000, modelo=modelo,
                     sistema="Você ajuda um robô de automação. Seja exato e curto.")
    return interpretar(resp, formato)


def localizar(chave, descricao, imagem, modelo=None, chamar_fn=None):
    """Centro (x, y), em pixels da imagem ORIGINAL, do elemento descrito; None se não estiver visível."""
    chamar_fn = chamar_fn or chamar
    bloco, fator, (w, h) = imagem_bloco(imagem)
    pedido = (f"A imagem é uma captura de tela de {w}x{h} pixels. Localize: \"{descricao}\".\n"
              "Responda SÓ com JSON: {\"encontrado\": true/false, \"x\": inteiro, \"y\": inteiro, "
              "\"o_que_achou\": \"descrição curta\"} — x,y = CENTRO do elemento, em pixels desta imagem "
              "(0,0 = canto superior esquerdo). Se não estiver visível, encontrado=false.")
    dados = extrair_json(chamar_fn(chave, pedido, imagens=[bloco], max_tokens=1000, modelo=modelo,
                                   sistema="Você localiza elementos de interface em capturas de tela com precisão."))
    if not isinstance(dados, dict) or not dados.get("encontrado"):
        return None
    try:
        x, y = float(dados["x"]), float(dados["y"])
    except (KeyError, TypeError, ValueError):
        return None
    if not (0 <= x <= w and 0 <= y <= h):
        return None
    return round(x * fator), round(y * fator), str(dados.get("o_que_achou") or "")


def explicar_erro(chave, erro, passo_txt, log_txt, imagem=None, modelo=None, chamar_fn=None):
    chamar_fn = chamar_fn or chamar
    imgs = [imagem_bloco(imagem)[0]] if imagem is not None else []
    pedido = (f"Um roteiro do Bot Genesys falhou.\n\nERRO: {erro}\n\nPASSO QUE FALHOU: {passo_txt}\n\n"
              f"ÚLTIMAS LINHAS DO LOG:\n{log_txt[-6000:]}\n\n"
              + ("A imagem é o print da tela no momento do erro.\n\n" if imgs else "")
              + "Explique em português simples: 1) o que provavelmente aconteceu; 2) o que mudar no roteiro "
                "(qual passo, qual campo, qual valor) ou no computador; 3) se valer, como evitar que aconteça de "
                "novo (ex.: aguardar carregar, Tentar/Se der erro, clicar pelo texto). Seja direto, no máximo "
                "12 linhas.")
    return chamar_fn(chave, pedido, imagens=imgs, max_tokens=2000, modelo=modelo,
                     sistema="Você é especialista no Bot Genesys e em automação de Windows, Chrome e Excel.")


# --------------------------------------------------------------------------- diagnosticar e corrigir (APLICAR SOLUÇÃO)
SISTEMA_DIAGNOSTICO = """Você é especialista no Bot Genesys (automação de Windows, Chrome e Excel) e corrige roteiros que
falharam. Você recebe o roteiro numerado, o passo que falhou, o erro, o log e (às vezes) o print da tela.
Responda SÓ com um JSON:
{"explicacao": "TEXTO SIMPLES (sem markdown, sem asteriscos): 1) o que aconteceu; 2) o que você vai mudar e por quê;
                3) o que a pessoa precisa fazer fora do roteiro, se houver",
 "alteracoes": [
   {"acao": "alterar", "passo": N, "campos": {"campo": novo_valor}},
   {"acao": "inserir_antes" | "inserir_depois", "passo": N, "passos": [ {passo completo do catálogo} ]},
   {"acao": "remover", "passo": N}
 ],
 "executar_de": N}
Regras: os números de passo são os do roteiro RECEBIDO (1 = primeiro). Mude o mínimo necessário. Use só tipos, campos e
opções do catálogo. Não quebre blocos (se_*/fim_se, repetir/fim_repetir, tentar/se_der_erro/fim_tentar). Leia o
roteiro inteiro antes de supor que algo está errado: passos podem ser de propósito. Se a causa não estiver no roteiro
(internet, senha, programa fechado), deixe "alteracoes" vazio e explique. "executar_de" = de qual passo vale executar
de novo depois de corrigir (o primeiro passo que precisa rodar outra vez).
Corrija a CAUSA e previna o próximo problema da mesma cadeia (ex.: se um clique abriu uma janela que o robô não
tratou, troque pela forma certa e vigie o aviso que viria depois). Boas práticas:
""" + BOAS_PRATICAS


def _numerado(passos, cat):
    linhas = []
    for n, p in enumerate(_sem_segredos(passos, cat), 1):
        linhas.append(f"{n}. " + json.dumps(p, ensure_ascii=False))
    return "\n".join(linhas)


def diagnosticar(chave, erro, i_passo, passos, log_txt, cat, imagem=None, modelo=None, chamar_fn=None):
    """Explicação + alterações que corrigem o roteiro. Devolve {'explicacao', 'alteracoes', 'executar_de'}."""
    chamar_fn = chamar_fn or chamar
    imgs = [imagem_bloco(imagem)[0]] if imagem is not None else []
    falhou = f"{i_passo + 1}" if i_passo is not None else "(não identificado)"
    texto = (f"ERRO: {erro}\nPASSO QUE FALHOU: {falhou}\n\nROTEIRO:\n{_numerado(passos, cat)[:60000]}\n\n"
             f"ÚLTIMAS LINHAS DO LOG:\n{log_txt[-6000:]}\n"
             + ("\nA imagem é o print da tela no momento do erro.\n" if imgs else ""))
    sistema = SISTEMA_DIAGNOSTICO + "\n\nCATÁLOGO DE PASSOS:\n" + descrever_catalogo(cat)
    dados = extrair_json(chamar_fn(chave, texto, sistema=sistema, imagens=imgs, max_tokens=8000, modelo=modelo))
    if not isinstance(dados, dict):
        raise ErroIA("a resposta da IA não veio no formato combinado")
    alts = dados.get("alteracoes") if isinstance(dados.get("alteracoes"), list) else []
    try:
        executar_de = int(dados.get("executar_de")) if dados.get("executar_de") not in (None, "") else None
    except (TypeError, ValueError):
        executar_de = None
    return {"explicacao": sem_markdown(str(dados.get("explicacao") or "")), "alteracoes": alts,
            "executar_de": executar_de}


def sem_markdown(t):
    t = re.sub(r"\*\*|__|`", "", t)
    return re.sub(r"^#+\s*", "", t, flags=re.M).strip()


def _rotulo(cat, tipo, chave):
    for c in cat.FIELDS.get(tipo, ()):
        if c[0] == chave:
            return c[1]
    return chave


def aplicar_alteracoes(passos, alteracoes, cat, fx, ctx=None, executar_de=None):
    """Aplica as alterações da IA numa CÓPIA do roteiro, conferindo tudo. Devolve (novos, descricoes, avisos, inicio)
    — inicio = índice (0-based) no roteiro novo de onde executar de novo. Erro se o resultado quebrar os blocos."""
    itens = [[i, dict(p)] for i, p in enumerate(passos)]  # [índice original ou None, passo]
    descricoes, avisos = [], []
    n_total = len(passos)

    def pos_de(n):  # posição atual do passo original n (1-based)
        for k, (orig, _) in enumerate(itens):
            if orig == n - 1:
                return k
        return None

    def ordem(a):  # do fim para o começo: os números originais continuam valendo
        try:
            n = int(a.get("passo"))
        except (TypeError, ValueError):
            n = -1
        return (-n, {"remover": 3, "inserir_depois": 0, "alterar": 1, "inserir_antes": 2}.get(a.get("acao"), 9))

    for a in sorted([a for a in alteracoes if isinstance(a, dict)], key=ordem):
        acao = a.get("acao")
        try:
            n = int(a.get("passo"))
        except (TypeError, ValueError):
            avisos.append(f"alteração sem número de passo válido: {a}")
            continue
        if not 1 <= n <= n_total:
            avisos.append(f"passo {n} não existe — ignorado")
            continue
        k = pos_de(n)
        if k is None:
            avisos.append(f"passo {n} já tinha sido removido — ignorado")
            continue
        atual = itens[k][1]
        nome = cat.TIPOS.get(atual["tipo"], atual["tipo"])
        if acao == "alterar":
            campos = a.get("campos") if isinstance(a.get("campos"), dict) else {}
            novo_tipo = campos.get("tipo", atual["tipo"])
            if novo_tipo not in cat.TIPOS:
                avisos.append(f"passo {n}: tipo '{novo_tipo}' desconhecido — ignorado")
                continue
            if novo_tipo != atual["tipo"]:  # troca de tipo: passo novo completo, com os campos dados
                base = {k2: v for k2, v in atual.items() if k2 in ("descricao", "ativo")}
                novo, av = normalizar_passos([dict(base, **campos, tipo=novo_tipo)], cat, ctx)
                avisos += [f"passo {n}: {x}" for x in av]
                itens[k][1] = novo[0]
                descricoes.append(f"Passo {n}: {nome} → {cat.TIPOS[novo_tipo]}")
                continue
            definicao = {c[0]: c for c in cat.FIELDS[atual["tipo"]]}
            mudou = []
            for chave_c, valor in campos.items():
                if chave_c == "tipo":
                    continue
                if chave_c in ("x", "y"):
                    try:
                        valor = int(float(valor))
                    except (TypeError, ValueError):
                        avisos.append(f"passo {n}: posição {chave_c} inválida")
                        continue
                elif chave_c == "descricao":
                    valor = str(valor)[:120]
                elif chave_c == "ativo":
                    valor = bool(valor)
                elif chave_c in definicao:
                    _, rotulo, kind, padrao, opcoes = definicao[chave_c]
                    if kind == "segredo":
                        avisos.append(f"passo {n}: a IA não altera senhas/tokens ('{rotulo}')")
                        continue
                    try:
                        valor = _converter(valor, kind, padrao, opcoes)
                    except (TypeError, ValueError) as e:
                        avisos.append(f"passo {n} ({nome}): '{rotulo}' — {e}")
                        continue
                else:
                    avisos.append(f"passo {n} ({nome}): campo '{chave_c}' não existe — ignorado")
                    continue
                if atual.get(chave_c) != valor:
                    mudou.append(f"{_rotulo(cat, atual['tipo'], chave_c)}: {atual.get(chave_c)!r} → {valor!r}")
                    atual[chave_c] = valor
            if mudou:
                if ctx is not None:
                    erro = cat.validar(atual, ctx)
                    if erro:
                        avisos.append(f"passo {n} ({nome}): {erro[0]} — {erro[1]}")
                descricoes.append(f"Passo {n} ({nome}): " + "; ".join(mudou))
        elif acao in ("inserir_antes", "inserir_depois"):
            novos, av = normalizar_passos(a.get("passos") or [], cat, ctx)
            avisos += [f"novo passo perto do {n}: {x}" for x in av]
            if not novos:
                continue
            onde = k if acao == "inserir_antes" else k + 1
            itens[onde:onde] = [[None, p] for p in novos]
            lado = "antes" if acao == "inserir_antes" else "depois"
            descricoes.append(f"Novo(s) {lado} do passo {n}: " + "; ".join(cat.TIPOS[p["tipo"]] for p in novos))
        elif acao == "remover":
            del itens[k]
            descricoes.append(f"Passo {n} ({nome}): removido")
        else:
            avisos.append(f"ação desconhecida '{acao}' — ignorada")
    novos_passos = [p for _, p in itens]
    erro = conferir_estrutura([p for p in novos_passos if p.get("ativo", True)], fx)
    if erro:
        raise ErroIA(f"a solução da IA quebraria os blocos do roteiro ({erro}); nada foi alterado")
    inicio = None
    if executar_de:
        k = pos_de(int(executar_de)) if 1 <= int(executar_de) <= n_total else None
        if k is None:  # o passo foi removido: começa onde ele estava
            antes = [kk for kk, (orig, _) in enumerate(itens) if orig is not None and orig < int(executar_de) - 1]
            k = (antes[-1] + 1) if antes else 0
        # se inseriram passos logo antes dele, começa por eles
        while k > 0 and itens[k - 1][0] is None:
            k -= 1
        inicio = k
    return novos_passos, descricoes, avisos, inicio
