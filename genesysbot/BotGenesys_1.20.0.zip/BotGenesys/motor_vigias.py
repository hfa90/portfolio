# -*- coding: utf-8 -*-
"""Pop-ups e anexos à prova de surpresa:
- vigias: regras 'Vigiar pop-up' conferidas antes/depois de cada passo e durante as esperas;
- aviso do Chrome (alert/confirm) sem regra: para com a mensagem dele, em vez de seguir às cegas;
- Chrome: anexar arquivo direto no campo de upload da página (sem a janela 'Abrir').

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import os
import sys
import time

try:
    import arquivos_win as aw
    import mensagens as mg
    from motor_util import nav
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    aw = mg = sys.modules[__name__]

INTERVALO_VIGIA = 0.8


class VigiasMixin:

    # ------------------------------------------------------------ regras
    def _registrar_vigia(self, s):
        regra = {"chrome": str(s.get("onde", "")).startswith("aviso"), "texto": self._x(s.get("texto")).strip(),
                 "acao": s.get("acao") or "OK / aceitar", "botao": self._x(s.get("botao")).strip(),
                 "parar": str(s.get("depois", "")).startswith("parar")}
        vigias = getattr(self, "_vigias", None)
        if vigias is None:
            vigias = self._vigias = []
        vigias.append(regra)
        self.log(f"Vigiando: {'aviso do Chrome' if regra['chrome'] else 'janela do Windows'} "
                 f"\"{regra['texto'] or 'qualquer'}\" → {regra['acao']}"
                 + (f" '{regra['botao']}'" if regra["acao"].startswith("clicar") else ""))
        if regra["chrome"]:
            try:
                if nav.cdp_disponivel():
                    self._conectar().dialogo_aberto()  # começa a ouvir a aba já
            except Exception:
                pass

    def _checar_vigias(self, forcar=False):
        """Confere os pop-ups. Chamado entre passos e durante as esperas (com intervalo mínimo)."""
        if getattr(self, "_vigiando", False):
            return
        agora = time.time()
        if not forcar and agora - getattr(self, "_t_vigia", 0) < INTERVALO_VIGIA:
            return
        self._t_vigia = agora
        vigias = getattr(self, "_vigias", None) or []
        self._vigiando = True
        try:
            self._vigiar_chrome([v for v in vigias if v["chrome"]])
            for v in vigias:
                if not v["chrome"] and v["texto"]:
                    self._vigiar_windows(v)
        finally:
            self._vigiando = False

    def _vigiar_chrome(self, regras):
        n = self.nav if (self.nav and self.nav.vivo) else None
        if n is None:
            if not regras:
                return
            try:
                if not nav.cdp_disponivel():
                    return
                n = self._conectar()
            except Exception:
                return
        tid, d = n.dialogo_aberto()
        if not d:
            return
        msg = str(d.get("message") or "").strip()
        tipo = d.get("type", "alert")
        for r in regras:
            if not r["texto"] or r["texto"].casefold() in msg.casefold():
                aceitar = not r["acao"].startswith(("Cancelar", "fechar")) and not (
                    r["acao"].startswith("clicar") and r["botao"].casefold() in ("cancelar", "cancel", "não", "no"))
                n.responder_dialogo(aceitar, tid=tid)
                self.log(f"Pop-up do Chrome ({tipo}): \"{msg[:120]}\" → {'OK' if aceitar else 'Cancelar'}", "ok")
                if r["parar"]:
                    raise RuntimeError(f"o site mostrou o aviso \"{msg[:160]}\" (regra 'Vigiar pop-up': parar)")
                return
        raise RuntimeError(f"o site abriu um aviso que trava o Chrome: \"{msg[:160]}\". Adicione um passo "
                           "'Vigiar pop-up' (aviso do Chrome) dizendo o que responder — ou responda e rode de novo")

    def _vigiar_windows(self, r):
        for hwnd, titulo in aw.win_janelas_com(r["texto"]):
            acao = ("ok" if r["acao"].startswith("OK") else "cancelar" if r["acao"].startswith("Cancelar")
                    else "fechar" if r["acao"].startswith("fechar") else "botao")
            try:
                feito = aw.win_responder(hwnd, acao, r["botao"])
            except Exception as e:
                self.log(f"Aviso: janela '{titulo}' apareceu mas não consegui responder: {e}", "erro")
                continue
            self.log(f"Janela do Windows '{titulo}': {feito}", "ok")
            if r["parar"]:
                raise RuntimeError(f"apareceu a janela '{titulo}' (regra 'Vigiar pop-up': parar)")

    # ------------------------------------------------------------ anexar no Chrome
    def _chrome_anexar(self, s):
        caminhos = mg.arquivos_anexos(self._x(s.get("arquivos")), self.base)
        n = self._conectar()
        espera = max(3.0, float(s.get("timeout") or 60))
        limite = time.time() + espera
        while True:
            try:
                qtd = n.anexar_arquivos(caminhos, self._x(s.get("seletor")).strip())
            except Exception as e:
                qtd, erro = 0, e
            else:
                erro = None
            if qtd:
                break
            if time.time() >= limite:
                raise RuntimeError("a página não tem campo para enviar arquivo" + (f" ({erro})" if erro else "")
                                   + " — abra antes a tela de anexar/escrever (ex.: Nova mensagem no Gmail)")
            self._esperar(0.5)
        nomes = [os.path.basename(c) for c in caminhos]
        self.log(f"Arquivo(s) entregue(s) à página: {', '.join(nomes)}")
        if not s.get("conferir", True):
            return
        while True:
            try:
                if all(self._pagina_tem(nome, "") for nome in nomes):
                    self._esperar(1.5)  # deixa o upload começar/terminar
                    self.log("Anexo confirmado na página.", "ok")
                    return
            except Exception:
                pass
            if time.time() >= limite:
                raise RuntimeError(f"o nome do anexo não apareceu na página em {espera:.0f} s "
                                   f"({', '.join(nomes)}) — o site recusou o arquivo?")
            self._esperar(0.6)
