# -*- coding: utf-8 -*-
"""
Bot Genesys - automação visual (mouse + teclado + imagem) com interface gráfica.

Atalhos globais (funcionam mesmo com o Chrome em foco):
    F4  -> inicia / para a GRAVAÇÃO (grava cliques, textos, teclas e rolagem)
    F8  -> captura a posição atual do mouse para o formulário
    F9  -> adiciona direto um passo de "Clique" na posição atual do mouse
    F2  -> pausa / continua a execução
    ESC -> para o bot durante a execução

Linha de comando (para o Agendador de Tarefas do Windows):
    python bot_genesys.py --executar roteiro.json [--csv dados.csv]
Segurança extra: jogar o mouse no canto SUPERIOR ESQUERDO da tela também para o bot.
"""
import interface.comum as _comum
from interface.comum import (APP_DIR, CONFIG_APP, IMG_DIR, LOG_DIR, TEMA_CLARO, diag, json, os, sys, tb)
from interface.janela import App

# Compatibilidade: tudo que antes era importado de bot_genesys (FIELDS, TEMA_CLARO, App...) continua aqui.
globals().update({k: v for k, v in vars(_comum).items() if not k.startswith("__")})


def main():
    args = sys.argv[1:]
    if "--diagnostico" in args:  # sem janela: imprime o relatório e salva na pasta de logs
        res = diag.executar(APP_DIR, LOG_DIR, IMG_DIR, ao_passo=lambda t: print(t, flush=True))
        print("\n" + diag.relatorio_texto(res))
        print("Relatório salvo em", diag.salvar_relatorio(res, LOG_DIR))
        sys.exit(1 if diag.resumo(res)[0] == diag.ERRO else 0)

    def arg(nome, caminho=True):
        if nome in args and args.index(nome) + 1 < len(args):
            v = args[args.index(nome) + 1]
            return os.path.abspath(v) if caminho else v
        return None

    try:
        with open(CONFIG_APP, encoding="utf-8") as f:
            tema = json.load(f).get("tema", TEMA_CLARO)
    except (OSError, ValueError):
        tema = TEMA_CLARO
    try:
        import diario
        diario.instalar_ganchos(LOG_DIR)  # erro ao abrir também fica no log (com pythonw não há console)
    except Exception:
        pass
    root = tb.Window(themename=tema)
    try:  # ícone do programa na janela e na barra de tarefas
        root.iconbitmap(default=os.path.join(APP_DIR, "instalador", "bot_genesys.ico"))
    except Exception:
        pass
    app = App(root, auto=arg("--executar"), csv_auto=arg("--csv"), agendamento=arg("--agendamento", False))
    root.mainloop()
    sys.exit(app.codigo_saida)


if __name__ == "__main__":
    main()
