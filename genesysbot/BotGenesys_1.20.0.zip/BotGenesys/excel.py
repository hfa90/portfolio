# -*- coding: utf-8 -*-
"""
Excel no Bot Genesys, sem mouse e sem teclado.

- No Windows com o Excel instalado: controla o PRÓPRIO Excel (pywin32), numa cópia invisível que não
  mexe nas planilhas que você estiver usando. Permite macros, atualizar dados, recalcular, PDF...
- Sem o Excel (ou fora do Windows): usa openpyxl para ler/escrever/copiar/salvar arquivos .xlsx.

Também lê uma planilha como lista de chamados e escreve o resultado de cada um na própria linha.
"""
import csv
import datetime
import zipfile
import os
import re
import sys
import threading

WIN = sys.platform == "win32"

try:
    import formulas_excel as fx
except ImportError:  # arquivo .py exportado: tudo está neste mesmo arquivo
    fx = sys.modules[__name__]
try:
    import openpyxl
    from openpyxl.utils import get_column_letter, column_index_from_string
    HAS_OPENPYXL = True
except Exception:
    HAS_OPENPYXL = False

try:
    import pythoncom
    import win32com.client as win32
    HAS_COM = WIN
except Exception:
    HAS_COM = False

FORMATOS = {"xlsx": 51, "xlsm": 52, "xls": 56, "csv": 6, "pdf": None}
TIPOS_GRAFICO = {"colunas": 51, "colunas empilhadas": 52, "barras": 57, "barras empilhadas": 58,
                 "linhas": 65, "pizza": 5, "rosca": -4120, "área": 1}


def erro_legivel(e):
    """Erros do Excel (COM) vêm como (-2147352567, 'Exceção.', (...)). Traduz para algo útil."""
    a = getattr(e, "args", ())
    if len(a) >= 2 and isinstance(a[0], int) and a[0] < 0:
        info = a[2] if len(a) > 2 and isinstance(a[2], tuple) else ()
        desc = (info[2] if len(info) > 2 and info[2] else None) or a[1] or "erro"
        cod = info[5] if len(info) > 5 and isinstance(info[5], int) and info[5] else a[0]
        dica = {-2147467259: "o Excel não conseguiu fazer isso agora (seleção, célula em edição ou objeto que "
                             "não aceita esse comando)",
                -2146827284: "referência, aba ou nome inválido",
                -2147418111: "o Excel estava ocupado (tem alguma caixa de diálogo aberta?)",
                -2147417848: "o Excel foi fechado durante a execução"}.get(cod, "")
        return f"o Excel recusou a operação: {desc}{' — ' + dica if dica else ''} (código {cod & 0xFFFFFFFF:#010x})"
    return str(e)


def tem_objetos(arquivo):
    """A planilha tem gráficos, tabelas dinâmicas ou imagens? (o openpyxl apagaria isso ao salvar)"""
    try:
        with zipfile.ZipFile(arquivo) as z:
            return any(n.startswith(("xl/charts/", "xl/pivotTables/", "xl/drawings/", "xl/media/"))
                       for n in z.namelist())
    except Exception:
        return False
PADRAO_REF = re.compile(r"^(?:'?(?P<aba>[^'!]+)'?!)?(?P<ini>\$?[A-Za-z]{1,3}\$?\d+)(?::(?P<fim>\$?[A-Za-z]{1,3}\$?\d+))?$")
_com_iniciado = threading.local()


def _iniciar_com():
    if HAS_COM and not getattr(_com_iniciado, "ok", False):
        pythoncom.CoInitialize()
        _com_iniciado.ok = True


def separar_ref(ref):
    """'Dados!A1:C5' -> ('Dados', 'A1', 'C5');  'B2' -> (None, 'B2', None)."""
    m = PADRAO_REF.match(str(ref).strip())
    if not m:
        raise ValueError(f"referência de célula inválida: '{ref}' (use B2, A1:C10 ou Aba!A1)")
    return m.group("aba"), m.group("ini").replace("$", "").upper(), (m.group("fim") or "").replace("$", "").upper() or None


# Fórmulas em português -> inglês (usado só quando NÃO há Excel instalado; com o Excel o próprio Excel traduz)
IDIOMAS = {"automático": None, "português": "pt", "inglês": "en", None: None, "": None, "pt": "pt", "en": "en"}


def formula_pt_para_en(f):
    """=SE(A2>0;"Sim";"Não") -> =IF(A2>0,"Sim","Não")  (nome mantido por compatibilidade; ver formulas_excel)."""
    return fx.para_ingles(f, "pt")


def idioma_da_formula(valor, idioma=None):
    """'pt', 'en' ou 'neutro'. idioma = escolha do passo ("automático", "português", "inglês")."""
    escolhido = IDIOMAS.get(idioma, None)
    return escolhido or fx.detectar_idioma(valor)


def _numero_se_possivel(v):
    if isinstance(v, str):
        t = v.strip()
        if re.fullmatch(r"-?\d+", t) and not (len(t) > 1 and t.startswith("0")) and len(t) < 15:
            return int(t)
        if re.fullmatch(r"-?\d+[.,]\d+", t):
            return float(t.replace(",", "."))
    return v


class Excel:
    """Uma pasta de trabalho aberta pelo bot."""

    def __init__(self, ao_log=None):
        self.ao_log = ao_log or (lambda m, t=None: None)
        self.app = self.wb = None
        self.arquivo = None
        self.modo = None
        self.aba_atual = None
        self.de_terceiros = False  # a pasta já estava aberta no Excel do usuário

    @property
    def aberto(self):
        return self.wb is not None

    # ------------------------------------------------------------ abrir / fechar
    def abrir(self, arquivo, aba=None, visivel=False, somente_leitura=False, usar_excel=True):
        arquivo = os.path.abspath(arquivo)
        if not os.path.exists(arquivo):
            raise FileNotFoundError(f"planilha não encontrada: {arquivo}")
        self.fechar(salvar=False)
        self.arquivo = arquivo
        if HAS_COM and usar_excel:
            _iniciar_com()
            self.wb = None
            try:  # já está aberta no Excel do usuário? então trabalha nela mesma (sem abrir nada novo)
                ativo = win32.GetActiveObject("Excel.Application")
                for wb in ativo.Workbooks:
                    if str(wb.FullName).lower() == arquivo.lower():
                        self.wb, self.app, self.de_terceiros = wb, ativo, True
                        self.ao_log("A planilha já estava aberta no seu Excel: o bot vai usar essa janela.")
                        break
            except Exception:
                self.wb = None
            if self.wb is None:
                self.app = win32.DispatchEx("Excel.Application")  # Excel separado, só do bot
                self.app.Visible = bool(visivel)
                self.app.DisplayAlerts = False
                self.app.ScreenUpdating = bool(visivel)
                self.app.AskToUpdateLinks = False
                self.wb = self.app.Workbooks.Open(arquivo, UpdateLinks=0, ReadOnly=bool(somente_leitura))
            self.modo = "excel"
        else:
            if not HAS_OPENPYXL:
                raise RuntimeError("instale o openpyxl (pip install openpyxl) ou use o Windows com o Excel")
            if arquivo.lower().endswith(".xls"):
                raise RuntimeError("arquivos .xls antigos precisam do Excel instalado (ou salve como .xlsx)")
            self.wb = openpyxl.load_workbook(arquivo, keep_vba=arquivo.lower().endswith(".xlsm"))
            self.modo = "openpyxl"
            self._protegida = tem_objetos(arquivo)
            if self._protegida:
                self.ao_log("Aviso: sem o Excel instalado, esta planilha (com gráficos/tabelas dinâmicas/imagens) "
                            "pode ser lida, mas não será salva por cima (poderia perder ou alterar esses objetos).", "erro")
        self.aba_atual = aba or None
        if aba:
            self._aba(aba)  # confere se existe
        return self

    def fechar(self, salvar=False):
        if not self.wb:
            return
        try:
            if self.modo == "excel":
                if salvar:
                    self.wb.Save()
                if not self.de_terceiros:
                    self.wb.Close(SaveChanges=False)
                    self.app.Quit()
            elif salvar:
                self.salvar()
        finally:
            self.wb = self.app = None
            self.modo = None
            self.de_terceiros = False

    # ------------------------------------------------------------ células
    def _ver(self, ws, endereco=None):
        """Com o Excel visível ("ver o processo"): mostra a aba e seleciona onde o bot está mexendo."""
        if self.modo != "excel" or not self.app or not getattr(self.app, "Visible", False):
            return
        try:
            ws.Activate()
            if endereco:
                ws.Range(endereco).Select()
        except Exception:
            pass

    def _aba(self, nome=None):
        nome = nome or self.aba_atual
        if self.modo == "excel":
            if not nome:
                return self.wb.ActiveSheet
            try:
                return self.wb.Worksheets(nome)
            except Exception:
                raise ValueError(f"a aba '{nome}' não existe nesta planilha")
        if not nome:
            return self.wb.active
        if nome not in self.wb.sheetnames:
            raise ValueError(f"a aba '{nome}' não existe nesta planilha")
        return self.wb[nome]

    def ler(self, ref):
        aba, ini, fim = separar_ref(ref)
        ws = self._aba(aba)
        if self.modo == "excel":
            self._ver(ws, f"{ini}:{fim}" if fim else ini)
            v = ws.Range(f"{ini}:{fim}" if fim else ini).Value
            if isinstance(v, tuple):
                return [list(l) for l in v]
            return v
        calc = self._valores_calculados(ws.title)
        if fim:
            return [[self._calculado(c, calc) for c in linha] for linha in ws[f"{ini}:{fim}"]]
        return self._calculado(ws[ini], calc)

    def _valores_calculados(self, aba):
        """openpyxl não calcula fórmulas: usa o último resultado que o Excel salvou no arquivo."""
        if not hasattr(self, "_cache_calc"):
            try:
                self._cache_calc = openpyxl.load_workbook(self.arquivo, data_only=True, read_only=True)
            except Exception:
                self._cache_calc = None
        try:
            return self._cache_calc[aba] if self._cache_calc else None
        except KeyError:
            return None

    @staticmethod
    def _calculado(celula, calc):
        v = celula.value
        if isinstance(v, str) and v.startswith("=") and calc is not None:
            try:
                return calc[celula.coordinate].value
            except Exception:
                return v
        return v

    def escrever(self, ref, valor, formula_pt=None, idioma=None):
        """Escreve um valor ou fórmula. Fórmula num intervalo (ex.: H2:H500) é preenchida para baixo,
        com as referências relativas ajustadas linha a linha (como arrastar no Excel).
        idioma: "automático" (padrão: detecta português ou inglês), "português" ou "inglês".
        formula_pt (antigo): True = português, False = inglês. Devolve o idioma usado ('pt'/'en'/'neutro')."""
        aba, ini, fim = separar_ref(ref)
        ws = self._aba(aba)
        formula = isinstance(valor, str) and valor.strip().startswith("=")
        valor = valor.strip() if formula else _numero_se_possivel(valor)
        if idioma is None and formula_pt is not None:
            idioma = "português" if formula_pt else "inglês"
        lingua = idioma_da_formula(valor, idioma) if formula else None
        if self.modo == "excel":
            rng = ws.Range(f"{ini}:{fim}" if fim else ini)
            self._ver(ws, f"{ini}:{fim}" if fim else ini)
            if not formula:
                rng.Value = valor
                return None
            em_ingles = valor if lingua == "en" else fx.para_ingles(valor, "pt")
            # Formula2 = como digitar no Excel atual (matrizes dinâmicas sem o "@"); Formula = Excel antigo.
            # Local = no idioma do Excel instalado. Tenta o jeito mais direto primeiro e cai para os outros.
            if lingua == "pt":
                tentativas = [("Formula2Local", valor), ("FormulaLocal", valor),
                              ("Formula2", em_ingles), ("Formula", em_ingles)]
            else:
                tentativas = [("Formula2", em_ingles), ("Formula", em_ingles),
                              ("Formula2Local", valor), ("FormulaLocal", valor)]
            erro = None
            for atributo, texto in tentativas:
                try:
                    setattr(rng, atributo, texto)
                    return lingua
                except Exception as e:
                    erro = erro or e
            raise erro
        if formula:
            valor = fx.para_arquivo(valor if lingua == "en" else fx.para_ingles(valor, "pt"))
        celulas = [c for linha in ws[f"{ini}:{fim}"] for c in linha] if fim else [ws[ini]]
        if formula and len(celulas) > 1:
            from openpyxl.formula.translate import Translator
            base = Translator(valor, origin=ini)
            for c in celulas:
                c.value = base.translate_formula(c.coordinate)
        else:
            for c in celulas:
                c.value = valor
        return lingua

    def idioma_do_excel(self):
        """Código do idioma da interface do Excel (1046 = português do Brasil, 1033 = inglês) ou None."""
        if self.modo != "excel":
            return None
        try:
            return int(self.app.LanguageSettings.LanguageID(2))  # msoLanguageIDUI
        except Exception:
            return None

    def ler_funcoes_do_excel(self, pasta, ao_progresso=None):
        """Pergunta ao PRÓPRIO Excel o nome local (no idioma dele) de cada função e salva em
        funcoes_excel_local.json. Assim o bot conhece todas as funções da sua versão do Excel."""
        self._precisa_excel("ler a lista de funções do Excel")
        try:
            from openpyxl.utils import FORMULAE as classicas
        except ImportError:
            classicas = set()
        nomes = sorted(set(classicas) | set(fx.EN_PARA_PT))
        wb = self.app.Workbooks.Add()
        cel = wb.Worksheets(1).Range("A1")
        achadas = {}
        try:
            for i, nome in enumerate(nomes):
                if ao_progresso and i % 20 == 0:
                    ao_progresso(i, len(nomes))
                for args in ("", "1", "1,1", "1,1,1", "1,1,1,1", "1,1,1,1,1", "1,1,1,1,1,1"):
                    try:
                        cel.Formula = f"={nome}({args})"
                    except Exception:
                        continue  # número de argumentos errado: tenta o próximo
                    local = str(cel.FormulaLocal)[1:]
                    nome_local = local.split("(", 1)[0].strip().upper()
                    if nome_local and not nome_local.startswith("_XL"):
                        achadas[nome.upper()] = nome_local
                    break
        finally:
            wb.Close(SaveChanges=False)
        dados = {"idioma": self.idioma_do_excel(), "versao_excel": str(self.app.Version),
                 "lido_em": datetime.datetime.now().isoformat(timespec="seconds"), "funcoes": achadas}
        import json
        with open(os.path.join(pasta, fx.ARQ_LOCAL), "w", encoding="utf-8") as f:
            json.dump(dados, f, ensure_ascii=False, indent=1)
        fx.carregar_lista_do_excel(pasta)
        return len(achadas), dados["idioma"]

    def ultima_linha(self, coluna="A", aba=None):
        """Número da última linha preenchida da coluna (0 se vazia)."""
        ws = self._aba(aba)
        if self.modo == "excel":
            col = ws.Range(f"{coluna}1").Column
            ultima = ws.Cells(ws.Rows.Count, col).End(-4162).Row  # xlUp
            return 0 if ultima == 1 and ws.Cells(1, col).Value in (None, "") else ultima
        col = column_index_from_string(coluna.upper())
        for n in range(ws.max_row, 0, -1):
            if ws.cell(row=n, column=col).value not in (None, ""):
                return n
        return 0

    def criar_dinamica(self, origem, destino, nome, linhas=(), colunas=(), valores=(), filtros=(), funcao="soma"):
        """Cria (ou recria com os dados atuais) uma tabela dinâmica. Precisa do Excel."""
        self._precisa_excel("criar tabela dinâmica")
        funcoes = {"soma": (-4157, "Soma"), "contagem": (-4112, "Contagem"), "média": (-4106, "Média"),
                   "máximo": (-4136, "Máx"), "mínimo": (-4139, "Mín")}
        cod, nome_func = funcoes.get(funcao, funcoes["soma"])
        aba_o, ini_o, fim_o = separar_ref(origem)
        wo = self._aba(aba_o)
        src = wo.Range(f"{ini_o}:{fim_o}") if fim_o else wo.Range(ini_o).CurrentRegion  # região dos dados
        aba_d, ini_d, _ = separar_ref(destino)
        if not aba_d:
            raise ValueError("informe a aba de destino da tabela dinâmica, ex.: Painel!A3")
        try:
            wd = self.wb.Worksheets(aba_d)
        except Exception:
            wd = self.wb.Worksheets.Add(After=self.wb.Worksheets(self.wb.Worksheets.Count))
            wd.Name = aba_d
        for ws in self.wb.Worksheets:  # já existe? apaga e cria de novo com os dados de agora
            try:
                ws.PivotTables(nome).TableRange2.Clear()
            except Exception:
                pass
        try:
            cache = self.wb.PivotCaches().Create(1, src)  # 1 = xlDatabase
        except Exception:
            ref = (f"'{wo.Name}'!R{src.Row}C{src.Column}:"
                   f"R{src.Row + src.Rows.Count - 1}C{src.Column + src.Columns.Count - 1}")
            cache = self.wb.PivotCaches().Create(1, ref)
        pt = cache.CreatePivotTable(wd.Range(ini_d), nome)
        existentes = [str(c.Value) for c in src.Rows(1).Cells]
        for campos, orientacao in ((filtros, 3), (linhas, 1), (colunas, 2)):  # filtro, linha, coluna
            for c in campos:
                if c not in existentes:
                    raise ValueError(f"a coluna '{c}' não existe nos dados ({', '.join(existentes)})")
                pt.PivotFields(c).Orientation = orientacao
        for v in valores:
            if v not in existentes:
                raise ValueError(f"a coluna '{v}' não existe nos dados ({', '.join(existentes)})")
            pt.AddDataField(pt.PivotFields(v), f"{nome_func} de {v}", cod)
        self._ver(wd)
        return str(pt.TableRange2.Address)

    def copiar(self, origem, destino, so_valores=True):
        aba_o, ini_o, fim_o = separar_ref(origem)
        aba_d, ini_d, _ = separar_ref(destino)
        wo, wd = self._aba(aba_o), self._aba(aba_d)
        if self.modo == "excel":
            src = wo.Range(f"{ini_o}:{fim_o}" if fim_o else ini_o)
            if so_valores:
                dst = wd.Range(ini_d).Resize(src.Rows.Count, src.Columns.Count)
                dst.Value = src.Value
            else:
                src.Copy(wd.Range(ini_d))
            try:
                self._ver(wd, wd.Range(ini_d).Resize(src.Rows.Count, src.Columns.Count).Address)
            except Exception:
                pass
            return
        valores = [[c.value for c in linha] for linha in wo[f"{ini_o}:{fim_o}" if fim_o else ini_o]] \
            if fim_o else [[wo[ini_o].value]]
        col0 = column_index_from_string(re.sub(r"\d", "", ini_d))
        lin0 = int(re.sub(r"\D", "", ini_d))
        c_o = column_index_from_string(re.sub(r"\d", "", ini_o))
        l_o = int(re.sub(r"\D", "", ini_o))
        from openpyxl.formula.translate import Translator
        for i, linha in enumerate(valores):
            for j, v in enumerate(linha):
                if not so_valores and isinstance(v, str) and v.startswith("="):  # fórmula: ajusta as referências
                    v = Translator(v, origin=f"{get_column_letter(c_o + j)}{l_o + i}").translate_formula(
                        f"{get_column_letter(col0 + j)}{lin0 + i}")
                wd.cell(row=lin0 + i, column=col0 + j, value=v)

    def criar_grafico(self, dados, destino, tipo="colunas", titulo="", nome="Grafico1", largura=480, altura=290):
        """Cria (ou recria) um gráfico. 'dados' = intervalo (1ª coluna = categorias, 1ª linha = séries)
        ou o NOME de uma tabela dinâmica (vira um gráfico dinâmico)."""
        aba_d, ini_d, _ = separar_ref(destino)
        if self.modo == "excel":
            try:
                wd = self.wb.Worksheets(aba_d) if aba_d else self.wb.ActiveSheet
            except Exception:
                wd = self.wb.Worksheets.Add(After=self.wb.Worksheets(self.wb.Worksheets.Count))
                wd.Name = aba_d
            fonte = None
            for ws in self.wb.Worksheets:  # é o nome de uma tabela dinâmica?
                try:
                    fonte = ws.PivotTables(dados).TableRange1
                    break
                except Exception:
                    pass
            if fonte is None:
                aba_o, ini_o, fim_o = separar_ref(dados)
                wo = self._aba(aba_o)
                fonte = wo.Range(f"{ini_o}:{fim_o}") if fim_o else wo.Range(ini_o).CurrentRegion
            graficos = wd.ChartObjects()
            for i in range(graficos.Count, 0, -1):  # já existe com esse nome? recria
                if str(graficos(i).Name) == nome:
                    graficos(i).Delete()
            cel = wd.Range(ini_d)
            codigo = TIPOS_GRAFICO.get(tipo, 51)
            # ChartObjects.Add cria o gráfico VAZIO. (Shapes.AddChart2 usa a SELEÇÃO atual como dados: com o
            # Excel visível e a seleção dentro de uma tabela dinâmica, ele virava gráfico dinâmico daquela
            # tabela e o SetSourceData com um intervalo comum falhava com "Exceção.")
            obj, grafico = self._novo_grafico(wd, cel, largura, altura, fonte, nome)
            grafico.ChartType = codigo
            try:
                grafico.ChartStyle = 201  # visual padrão do Excel atual (2013+)
                grafico.ClearToMatchStyle()
            except Exception:
                pass
            if titulo:
                grafico.HasTitle = True
                grafico.ChartTitle.Text = titulo
            self._ver(wd, ini_d)
            return f"{wd.Name}!{ini_d}"
        # sem Excel: openpyxl (só a partir de intervalo)
        from openpyxl.chart import AreaChart, BarChart, DoughnutChart, LineChart, PieChart, Reference
        from openpyxl.utils.cell import range_boundaries
        aba_o, ini_o, fim_o = separar_ref(dados)
        if not fim_o:
            raise RuntimeError("sem o Excel, informe o intervalo completo dos dados (ex.: Indicadores!A3:B8); "
                               "gráfico de tabela dinâmica precisa do Excel")
        wo = self._aba(aba_o)
        c1, l1, c2, l2 = range_boundaries(f"{ini_o}:{fim_o}")
        if tipo in ("pizza", "rosca"):
            g = PieChart() if tipo == "pizza" else DoughnutChart()
        elif tipo == "linhas":
            g = LineChart()
        elif tipo == "área":
            g = AreaChart()
        else:
            g = BarChart()
            g.type = "bar" if tipo.startswith("barras") else "col"
            if "empilhadas" in tipo:
                g.grouping, g.overlap = "stacked", 100
        g.add_data(Reference(wo, min_col=c1 + 1, min_row=l1, max_col=c2, max_row=l2), titles_from_data=True)
        g.set_categories(Reference(wo, min_col=c1, min_row=l1 + 1, max_row=l2))
        g.title = titulo or None
        g.width, g.height = largura / 37.8, altura / 37.8  # px -> cm
        wd = self._aba(aba_d) if aba_d in self.wb.sheetnames or not aba_d else self.wb.create_sheet(aba_d)
        wd._charts = [c for c in wd._charts if getattr(c, "_bot_nome", None) != nome]
        g._bot_nome = nome
        wd.add_chart(g, ini_d)
        return f"{wd.title}!{ini_d}"

    # ------------------------------------------------------------ só com o Excel
    def _selecionar(self, rng):
        try:
            rng.Worksheet.Activate()
            rng.Select()
            return True
        except Exception:
            return False

    def _novo_grafico(self, wd, cel, largura, altura, fonte, nome):
        """Cria o gráfico já com os dados certos.
        O Excel preenche um gráfico novo com o que estiver SELECIONADO (e, se a seleção estiver numa tabela
        dinâmica, ele vira gráfico dinâmico daquela tabela e recusa outro intervalo). Por isso o bot
        seleciona antes os próprios dados do gráfico; se ainda assim falhar, tenta de novo a partir de uma
        célula vazia."""
        ativa = None
        try:
            ativa = self.app.ActiveSheet
        except Exception:
            pass
        tentativas = [lambda: self._selecionar(fonte),
                      lambda: self._selecionar(wd.Cells(wd.Rows.Count, wd.Columns.Count))]  # célula vazia
        erro = None
        for preparar in tentativas:
            preparar()
            obj = wd.ChartObjects().Add(cel.Left, cel.Top, largura, altura)
            try:
                obj.Name = nome
                grafico = obj.Chart
                grafico.SetSourceData(fonte)
                if ativa is not None and not getattr(self.app, "Visible", False):
                    try:
                        ativa.Activate()
                    except Exception:
                        pass
                return obj, grafico
            except Exception as e:
                erro = e
                try:
                    obj.Delete()
                except Exception:
                    pass
        raise erro

    def _precisa_excel(self, o_que):
        if self.modo != "excel":
            raise RuntimeError(f"{o_que} precisa do Microsoft Excel instalado (Windows)")

    def macro(self, nome, argumentos=()):
        self._precisa_excel("rodar macro")
        alvo = nome if "!" in nome else f"'{self.wb.Name}'!{nome}"
        return self.app.Run(alvo, *[_numero_se_possivel(a) for a in argumentos])

    def atualizar_tudo(self):
        self._precisa_excel("atualizar dados")
        self.wb.RefreshAll()
        try:
            self.app.CalculateUntilAsyncQueriesDone()
        except Exception:
            pass

    def recalcular(self):
        if self.modo == "excel":
            self.app.CalculateFull()
        # openpyxl não calcula fórmulas (o Excel recalcula ao abrir)

    def salvar(self, arquivo=None, formato=None, aba=None):
        destino = os.path.abspath(arquivo) if arquivo else self.arquivo
        formato = (formato or os.path.splitext(destino)[1].lstrip(".") or "xlsx").lower()
        if destino != self.arquivo or formato == "pdf":
            os.makedirs(os.path.dirname(destino) or ".", exist_ok=True)
        if self.modo == "excel":
            if formato == "pdf":
                self._aba(aba).ExportAsFixedFormat(0, destino)  # a aba escolhida em PDF
            elif formato == "csv":  # cópia da aba em CSV (UTF-8), sem mudar a planilha aberta
                self._aba().Copy()
                novo = self.app.ActiveWorkbook
                novo.SaveAs(destino, 62)
                novo.Close(SaveChanges=False)
            elif destino.lower() == self.arquivo.lower():
                self.wb.Save()
            else:
                self.wb.SaveAs(destino, FORMATOS.get(formato, 51))
                self.arquivo = destino
            return destino
        if formato == "pdf":
            raise RuntimeError("salvar em PDF precisa do Microsoft Excel instalado (Windows)")
        if formato != "csv" and getattr(self, "_protegida", False):
            raise RuntimeError("sem o Microsoft Excel, salvar esta planilha poderia perder ou alterar os gráficos/"
                               "tabelas dinâmicas/imagens que ela tem. Rode no Windows com o Excel instalado")
        if formato == "csv":
            ws = self._aba(aba)
            with open(destino, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";")
                for linha in ws.iter_rows(values_only=True):
                    w.writerow(["" if v is None else v for v in linha])
            return destino
        self.wb.save(destino)
        self.arquivo = destino
        return destino


# --------------------------------------------------------------------------- #
# Planilha como lista de chamados
# --------------------------------------------------------------------------- #
def abas(arquivo):
    if arquivo.lower().endswith(".csv"):
        return []
    if not HAS_OPENPYXL:
        return []
    wb = openpyxl.load_workbook(arquivo, read_only=True)
    try:
        return list(wb.sheetnames)
    finally:
        wb.close()


def ler_planilha(arquivo, aba=None):
    """Lista de dicionários (1ª linha = nomes das colunas). Cada linha guarda '_linha' (nº na planilha)."""
    if arquivo.lower().endswith(".csv"):
        texto = None
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                with open(arquivo, encoding=enc, newline="") as f:
                    texto = f.read()
                break
            except UnicodeDecodeError:
                continue
        delim = ";" if texto.count(";") > texto.count(",") else ","
        linhas = []
        for n, r in enumerate(csv.DictReader(texto.splitlines(), delimiter=delim), start=2):
            d = {(k or "").strip(): (v or "").strip() for k, v in r.items()}
            if any(d.values()):
                d["_linha"] = n
                linhas.append(d)
        return linhas
    if not HAS_OPENPYXL:
        raise RuntimeError("para ler .xlsx instale o openpyxl (pip install openpyxl)")
    wb = openpyxl.load_workbook(arquivo, read_only=True, data_only=True)
    try:
        ws = wb[aba] if aba else wb.worksheets[0]
        it = ws.iter_rows(values_only=True)
        cab = [("" if c is None else str(c)).strip() for c in next(it, [])]
        linhas = []
        for n, valores in enumerate(it, start=2):
            d = {}
            for k, v in zip(cab, valores):
                if not k:
                    continue
                if isinstance(v, datetime.datetime):
                    v = v.strftime("%d/%m/%Y %H:%M") if (v.hour or v.minute) else v.strftime("%d/%m/%Y")
                elif isinstance(v, float) and v.is_integer():
                    v = int(v)
                d[k] = "" if v is None else str(v).strip()
            if any(d.values()):
                d["_linha"] = n
                linhas.append(d)
        return linhas
    finally:
        wb.close()


class Registro:
    """Escreve o resultado de cada chamado na própria linha da planilha (coluna de status + variáveis)."""

    def __init__(self, arquivo, aba=None, coluna_status="Status", ao_log=None):
        self.arquivo, self.aba, self.coluna = os.path.abspath(arquivo), aba, coluna_status or "Status"
        self.ao_log = ao_log or (lambda m, t=None: None)
        self.csv = arquivo.lower().endswith(".csv")
        self.xl = None
        self.cab = None

    def _abrir(self):
        if self.xl is None:
            self.xl = Excel(self.ao_log).abrir(self.arquivo, self.aba)
            self._ler_cabecalho()

    def _ler_cabecalho(self):
        primeira = self.xl.ler("A1:ZZ1")[0]
        self.cab = [("" if c is None else str(c)).strip() for c in primeira]
        while self.cab and not self.cab[-1]:
            self.cab.pop()

    def _coluna(self, nome, criar):
        if nome in self.cab:
            return self.cab.index(nome) + 1
        if not criar:
            return None
        self.cab.append(nome)
        n = len(self.cab)
        self.xl.escrever(f"{get_column_letter(n)}1", nome)
        return n

    def registrar(self, linha_num, status, valores=None):
        if self.csv:
            return self._registrar_csv(linha_num, status, valores)
        try:
            self._abrir()
            col = self._coluna(self.coluna, criar=True)
            self.xl.escrever(f"{get_column_letter(col)}{linha_num}", status)
            for nome, valor in (valores or {}).items():
                c = self._coluna(nome, criar=False)  # só preenche colunas que já existem
                if c:
                    self.xl.escrever(f"{get_column_letter(c)}{linha_num}", valor)
            self.xl.salvar()
        except (PermissionError, RuntimeError) as e:
            self.ao_log(f"Aviso: não deu para escrever na planilha ({e}); resultado guardado em resultados_*.csv.",
                        "erro")
            self._registrar_csv(linha_num, status, valores)

    def _registrar_csv(self, linha_num, status, valores):
        destino = os.path.join(os.path.dirname(self.arquivo), "resultados_" + os.path.splitext(
            os.path.basename(self.arquivo))[0] + ".csv")
        novo = not os.path.exists(destino)
        with open(destino, "a", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            if novo:
                w.writerow(["linha", self.coluna] + list((valores or {}).keys()))
            w.writerow([linha_num, status] + list((valores or {}).values()))

    def fechar(self):
        if self.xl:
            try:
                self.xl.fechar(salvar=self.xl.modo == "excel")
            finally:
                self.xl = None
