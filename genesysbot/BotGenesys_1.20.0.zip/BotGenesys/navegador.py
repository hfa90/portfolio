# -*- coding: utf-8 -*-
"""
Conversa com o Chrome em "modo controlado" pelo Chrome DevTools Protocol (CDP).

Permite:
  - saber quando a página terminou de carregar, ler/rolar a página;
  - gravar QUAL ELEMENTO foi clicado (não só a posição na tela);
  - executar em SEGUNDO PLANO: cliques, teclas e texto vão direto para a página,
    sem usar o mouse e o teclado do Windows (você continua usando o computador).
"""
import base64
import io
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

try:
    import websocket  # pacote websocket-client
    HAS_WS = True
except Exception:
    HAS_WS = False

CDP_PORTA = 9222
# Sem "--remote-allow-origins=*": o bot conecta sem cabeçalho Origin (suppress_origin), então não precisa dela —
# e sem ela nenhuma página aberta em outro navegador consegue se conectar ao Chrome do bot.
FLAGS_CONTROLE = ["--no-first-run", "--no-default-browser-check",
                  "--hide-crash-restore-bubble",
                  # continua desenhando/rodando mesmo atrás de outras janelas (segundo plano)
                  "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
                  "--disable-background-timer-throttling"]


def caminho_chrome():
    for c in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
              os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
              "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser"):
        if os.path.exists(c):
            return c
    return None


def abrir_chrome(url, controle=False, perfil=None):
    """Abre uma nova janela do Chrome. Com controle=True usa o perfil do bot e liga o modo controlado."""
    exe = caminho_chrome()
    if not exe:
        webbrowser.open(url)
        return
    args = [exe]
    if controle:
        args += [f"--remote-debugging-port={CDP_PORTA}"] + FLAGS_CONTROLE
        if perfil:
            args.append(f"--user-data-dir={perfil}")
        if not sys.platform.startswith("win"):
            args.append("--no-sandbox")
    subprocess.Popen(args + ["--new-window", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# --------------------------------------------------------------------------- #
# Acesso simples (uma conexão por pergunta) - usado na execução normal e na gravação
# --------------------------------------------------------------------------- #
JS_ESTADO = """(() => {
  const sel = %s; let alvo = null;
  if (sel) { const el = document.querySelector(sel);
             alvo = !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }
  return JSON.stringify({rs: document.readyState, vs: document.visibilityState, url: location.href,
    imgs: Array.from(document.images).every(i => i.complete),
    fontes: !document.fonts || document.fonts.status === 'loaded',
    res: performance.getEntriesByType('resource').length, alvo: alvo});
})()"""

CDP_PREFERIDA = {"id": None}  # aba aberta pelo bot (passo "Abrir Chrome" ou início da gravação)


def cdp_disponivel():
    if not HAS_WS:
        return False
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{CDP_PORTA}/json/version", timeout=1).read()
        return True
    except Exception:
        return False


def _cdp_avaliar(ws_url, expr):
    ws = websocket.create_connection(ws_url, timeout=4, suppress_origin=True)
    try:
        ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                            "params": {"expression": expr, "returnByValue": True}}))
        while True:
            msg = json.loads(ws.recv())
            if msg.get("id") == 1:
                return msg.get("result", {}).get("result", {}).get("value")
    finally:
        ws.close()


def cdp_abas():
    abas = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{CDP_PORTA}/json", timeout=2).read())
    return [a for a in abas if a.get("type") == "page" and "webSocketDebuggerUrl" in a
            and not a.get("url", "").startswith("devtools")]


def cdp_ids():
    try:
        return {a["id"] for a in cdp_abas()}
    except Exception:
        return set()


def marcar_aba_nova(ids_antes, timeout=8.0, url=None):
    """Guarda qual aba o bot abriu, para agir na página certa mesmo com outras janelas abertas.
    Se o Chrome reabrir abas antigas, prefere a aba do mesmo site da URL pedida."""
    from urllib.parse import urlparse
    host = urlparse(url).netloc if url else ""
    inicio = time.time()
    while time.time() - inicio < timeout:
        try:
            novas = [a for a in cdp_abas() if a["id"] not in ids_antes]
        except Exception:
            novas = []
        if novas:
            mesmo_site = [a for a in novas if host and urlparse(a.get("url", "")).netloc == host]
            if mesmo_site or not host or time.time() - inicio > timeout / 2:
                CDP_PREFERIDA["id"] = (mesmo_site or novas)[0]["id"]
                return CDP_PREFERIDA["id"]
        time.sleep(0.3)
    return None


def cdp_aba_visivel():
    """Aba em que se está agindo: 1º a que tem o foco, 2º a aberta pelo bot, 3º uma visível."""
    abas = cdp_abas()
    visiveis = []
    for aba in abas:
        try:
            e = json.loads(_cdp_avaliar(aba["webSocketDebuggerUrl"],
                                        "JSON.stringify({f: document.hasFocus(), v: document.visibilityState})"))
        except Exception:
            continue
        if e.get("f"):
            return aba["webSocketDebuggerUrl"]
        if e.get("v") == "visible":
            visiveis.append(aba)
    for aba in abas:
        if aba.get("id") == CDP_PREFERIDA["id"]:
            return aba["webSocketDebuggerUrl"]
    lista = visiveis or abas
    return lista[0]["webSocketDebuggerUrl"] if lista else None


def cdp_json(expr):
    """Avalia na aba ativa uma expressão que devolve JSON.stringify(...)."""
    ws_url = cdp_aba_visivel()
    if not ws_url:
        return None
    valor = _cdp_avaliar(ws_url, expr)
    return json.loads(valor) if valor else None


def cdp_estado(seletor=""):
    return cdp_json(JS_ESTADO % json.dumps(seletor or ""))


# Observa a rolagem da página (janela ou área rolável interna) durante a gravação.
JS_ROLAGEM = """(() => {
  if (!window.__botRol) {
    const caminho = el => {
      const partes = [];
      while (el && el.nodeType === 1 && el !== document.body && el !== document.documentElement) {
        if (el.id) { partes.unshift('#' + CSS.escape(el.id)); return partes.join(' > '); }
        let i = 1, s = el;
        while ((s = s.previousElementSibling)) if (s.tagName === el.tagName) i++;
        partes.unshift(el.tagName.toLowerCase() + ':nth-of-type(' + i + ')');
        el = el.parentElement;
      }
      partes.unshift('body');
      return partes.join(' > ');
    };
    window.__botRol = {sel: '', top: scrollY};
    document.addEventListener('scroll', e => {
      const t = e.target;
      if (t === document || t === document.documentElement || t === document.body)
        window.__botRol = {sel: '', top: scrollY};
      else
        window.__botRol = {sel: caminho(t), top: t.scrollTop};
    }, true);
  }
  return JSON.stringify({url: location.href, y: scrollY, sel: window.__botRol.sel,
                         top: window.__botRol.sel ? window.__botRol.top : scrollY});
})()"""

# Leva a página (ou a área rolável) para uma posição exata.
JS_ROLAR_PARA = """(() => {
  const sel = %s, alvo = %d, comp = %s;
  const rolavel = el => el && el.scrollHeight - el.clientHeight > 2 &&
                        /(auto|scroll|overlay)/.test(getComputedStyle(el).overflowY);
  let el = sel ? document.querySelector(sel) : null, via = sel ? 'area' : 'janela';
  if (sel && !rolavel(el)) {        // a página foi montada de outro jeito: usa a maior área rolável
    el = null; via = 'janela'; let melhor = 0;
    for (const c of document.querySelectorAll('div, section, main, article, form, ul, table, tbody')) {
      if (c.scrollHeight - c.clientHeight > 2 && c.clientHeight * c.clientWidth > melhor && rolavel(c)) {
        melhor = c.clientHeight * c.clientWidth; el = c; via = 'maior_area';
      }
    }
  }
  const max = el ? el.scrollHeight - el.clientHeight : document.documentElement.scrollHeight - innerHeight;
  if (comp) (el || window).scrollTo({top: alvo, behavior: comp});
  return JSON.stringify({top: el ? el.scrollTop : scrollY, max: max, via: via});
})()"""

# Instalado em todas as páginas durante a gravação: avisa QUAL elemento foi clicado.
JS_GRAVAR = r"""(() => {
  if (window.__botGravando) return; window.__botGravando = true;
  const INTER = 'a,button,input,select,textarea,label,summary,option,[role=button],[role=link],[role=option],' +
                '[role=menuitem],[role=tab],[role=checkbox],[role=radio],[role=combobox],[role=switch],[onclick]';
  const unico = s => { try { return document.querySelectorAll(s).length === 1; } catch (e) { return false; } };
  const idBom = id => id && !/\d{4,}|[0-9a-f]{12,}|^ember|^ext-gen|^react|:/.test(id);
  const css = el => {
    const tag = el.tagName.toLowerCase();
    if (idBom(el.id) && unico('#' + CSS.escape(el.id))) return '#' + CSS.escape(el.id);
    for (const a of ['name', 'aria-label', 'placeholder', 'data-testid', 'data-id', 'title', 'for', 'value', 'href']) {
      const v = el.getAttribute(a);
      if (v && v.length < 120) { const s = tag + '[' + a + '=' + JSON.stringify(v) + ']'; if (unico(s)) return s; }
    }
    const partes = []; let e = el;
    while (e && e.nodeType === 1 && e !== document.documentElement) {
      if (e !== el && idBom(e.id) && unico('#' + CSS.escape(e.id))) { partes.unshift('#' + CSS.escape(e.id)); break; }
      if (e === document.body) { partes.unshift('body'); break; }
      let i = 1, s = e; while ((s = s.previousElementSibling)) if (s.tagName === e.tagName) i++;
      partes.unshift(e.tagName.toLowerCase() + ':nth-of-type(' + i + ')');
      e = e.parentElement;
    }
    return partes.join(' > ');
  };
  const xpath = el => {
    const partes = [];
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
      if (idBom(e.id)) { partes.unshift('//*[@id="' + e.id + '"]'); return partes.join('/'); }
      let i = 1, s = e; while ((s = s.previousElementSibling)) if (s.tagName === e.tagName) i++;
      partes.unshift(e.tagName.toLowerCase() + '[' + i + ']');
    }
    return '/' + partes.join('/');
  };
  document.addEventListener('mousedown', ev => {
    try {
      let el = ev.target.closest ? (ev.target.closest(INTER) || ev.target) : ev.target;
      if (el === document.body || el === document.documentElement) el = ev.target;
      const r = el.getBoundingClientRect();
      const txt = (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ');
      window.__botEvento(JSON.stringify({
        ev: 'clique', botao: ev.button, sel: css(el), xpath: xpath(el), texto: txt.slice(0, 80),
        tag: el.tagName.toLowerCase(), tipo: el.getAttribute('type') || '', nome: el.getAttribute('name') || '',
        rotulo: el.getAttribute('aria-label') || el.getAttribute('placeholder') || '',
        cx: ev.clientX, cy: ev.clientY, ox: ev.clientX - r.left, oy: ev.clientY - r.top, w: r.width, h: r.height,
        sx: ev.screenX, sy: ev.screenY, dpr: devicePixelRatio,
        frame: window === top ? '' : location.href, url: location.href}));
    } catch (e) {}
  }, true);
})()"""

# Encontra o elemento gravado (vários jeitos, do mais preciso para o mais tolerante).
JS_ACHAR = r"""((a) => {
  const vis = el => el && el.isConnected && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const um = lista => { const v = [...lista].filter(vis); return v.length === 1 ? v[0] : null; };
  const porCss = s => { try { return s ? um(document.querySelectorAll(s)) : null; } catch (e) { return null; } };
  const porXpath = x => {
    try { const r = document.evaluate(x, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
          const l = []; for (let i = 0; i < r.snapshotLength; i++) l.push(r.snapshotItem(i)); return um(l);
    } catch (e) { return null; } };
  const limpo = el => (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  let el = porCss(a.sel) || porXpath(a.xpath);
  if (!el && a.texto && a.tag) el = um([...document.getElementsByTagName(a.tag)].filter(e => limpo(e) === a.texto));
  if (!el && a.nome && a.tag) el = porCss(a.tag + '[name=' + JSON.stringify(a.nome) + ']');
  if (!el && a.rotulo && a.tag) el = porCss(a.tag + '[aria-label=' + JSON.stringify(a.rotulo) + ']') ||
                                     porCss(a.tag + '[placeholder=' + JSON.stringify(a.rotulo) + ']');
  return el || null;
})(%s)"""

JS_DESTACAR = """function(ms) { const o = this.style.outline, f = this.style.outlineOffset;
  this.style.outline = '3px solid #ff3b30'; this.style.outlineOffset = '2px';
  setTimeout(() => { this.style.outline = o; this.style.outlineOffset = f; }, ms); }"""

# key, code, windowsVirtualKeyCode, texto
TECLAS_CDP = {
    "enter": ("Enter", "Enter", 13, "\r"), "return": ("Enter", "Enter", 13, "\r"),
    "tab": ("Tab", "Tab", 9, None), "esc": ("Escape", "Escape", 27, None), "escape": ("Escape", "Escape", 27, None),
    "backspace": ("Backspace", "Backspace", 8, None), "delete": ("Delete", "Delete", 46, None),
    "del": ("Delete", "Delete", 46, None), "space": (" ", "Space", 32, " "), "insert": ("Insert", "Insert", 45, None),
    "up": ("ArrowUp", "ArrowUp", 38, None), "down": ("ArrowDown", "ArrowDown", 40, None),
    "left": ("ArrowLeft", "ArrowLeft", 37, None), "right": ("ArrowRight", "ArrowRight", 39, None),
    "home": ("Home", "Home", 36, None), "end": ("End", "End", 35, None),
    "pageup": ("PageUp", "PageUp", 33, None), "pagedown": ("PageDown", "PageDown", 34, None),
}
for _i in range(1, 13):
    TECLAS_CDP[f"f{_i}"] = (f"F{_i}", f"F{_i}", 111 + _i, None)
MODIFICADORES = {"alt": 1, "ctrl": 2, "win": 4, "shift": 8}
COMANDOS = {"a": "selectAll", "c": "copy", "v": "paste", "x": "cut", "z": "undo", "y": "redo"}


class Navegador:
    """Conexão permanente com o Chrome controlado (nível do navegador, todas as abas)."""

    def __init__(self, porta=CDP_PORTA, ao_log=None):
        info = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{porta}/json/version", timeout=3).read())
        self.ws = websocket.create_connection(info["webSocketDebuggerUrl"], timeout=10, suppress_origin=True,
                                              enable_multithread=True)
        self.ws.settimeout(None)
        self.ao_log = ao_log or (lambda m: None)
        self._n = 0
        self._lock = threading.Lock()
        self._pend = {}
        self.alvos = {}      # targetId -> info
        self.sessoes = {}    # targetId -> sessionId
        self._alvo_da_sessao = {}
        self.ouvintes = []
        self.vivo = True
        self.aba = None      # aba que o bot está controlando
        self.seguir_novas = True
        self.dialogos = {}   # targetId -> aviso da página aberto (alert/confirm/prompt/beforeunload)
        threading.Thread(target=self._ler, daemon=True).start()
        self.enviar("Target.setDiscoverTargets", {"discover": True})
        for t in self.enviar("Target.getTargets").get("targetInfos", []):
            self.alvos[t["targetId"]] = t

    # ---- protocolo
    def _ler(self):
        while self.vivo:
            try:
                msg = json.loads(self.ws.recv())
            except Exception:
                self.vivo = False
                for ev in list(self._pend.values()):
                    ev[0].set()
                break
            if "id" in msg:
                ev = self._pend.pop(msg["id"], None)
                if ev:
                    ev[1] = msg
                    ev[0].set()
                continue
            metodo, p, sid = msg.get("method"), msg.get("params", {}), msg.get("sessionId")
            if metodo == "Page.javascriptDialogOpening":
                self.dialogos[self._alvo_da_sessao.get(sid) or sid] = dict(p, desde=time.time())
            elif metodo == "Page.javascriptDialogClosed":
                self.dialogos.pop(self._alvo_da_sessao.get(sid) or sid, None)
            if metodo in ("Target.targetCreated", "Target.targetInfoChanged"):
                t = p["targetInfo"]
                novo = t["targetId"] not in self.alvos
                self.alvos[t["targetId"]] = t
                if (novo and self.seguir_novas and t.get("type") == "page" and self.aba
                        and t.get("openerId") == self.aba):
                    self.aba = t["targetId"]  # a página abriu uma nova aba: o bot passa a agir nela
                    self.ao_log("A página abriu uma nova aba; o bot continua nela.")
            elif metodo == "Target.targetDestroyed":
                self.alvos.pop(p["targetId"], None)
                self.sessoes.pop(p["targetId"], None)
                if self.aba == p["targetId"]:
                    self.aba = None
            elif metodo == "Target.detachedFromTarget":
                tid = self._alvo_da_sessao.pop(p.get("sessionId"), None)
                if tid:
                    self.sessoes.pop(tid, None)
            for cb in list(self.ouvintes):
                try:
                    cb(metodo, p, self._alvo_da_sessao.get(sid))
                except Exception:
                    pass

    def enviar(self, metodo, params=None, sessao=None, timeout=20):
        if not self.vivo:
            raise RuntimeError("conexão com o Chrome foi perdida (o Chrome foi fechado?)")
        with self._lock:
            self._n += 1
            i = self._n
        ev = [threading.Event(), None]
        self._pend[i] = ev
        msg = {"id": i, "method": metodo, "params": params or {}}
        if sessao:
            msg["sessionId"] = sessao
        self.ws.send(json.dumps(msg))
        if not ev[0].wait(timeout) or ev[1] is None:
            self._pend.pop(i, None)
            raise TimeoutError(f"o Chrome não respondeu ({metodo})")
        r = ev[1]
        if "error" in r:
            raise RuntimeError(r["error"].get("message", str(r["error"])))
        return r.get("result", {})

    def fechar(self):
        self.vivo = False
        try:
            self.ws.close()
        except Exception:
            pass

    # ---- abas
    def paginas(self):
        return [t for t in self.alvos.values() if t.get("type") == "page"
                and not t.get("url", "").startswith(("devtools", "chrome-extension"))]

    def sessao(self, tid=None):
        tid = tid or self.escolher_aba()
        if tid not in self.sessoes:
            sid = self.enviar("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]
            self.sessoes[tid] = sid
            self._alvo_da_sessao[sid] = tid
            for m in ("Page.enable", "Runtime.enable", "DOM.enable"):
                try:
                    self.enviar(m, sessao=sid)
                except Exception:
                    pass
        return self.sessoes[tid]

    def escolher_aba(self):
        ids = {t["targetId"] for t in self.paginas()}
        if self.aba in ids:
            return self.aba
        if CDP_PREFERIDA["id"] in ids:
            self.aba = CDP_PREFERIDA["id"]
            return self.aba
        for t in self.paginas():  # a que tem o foco
            try:
                if self.avaliar("document.hasFocus()", t["targetId"]):
                    self.aba = t["targetId"]
                    return self.aba
            except Exception:
                pass
        pags = [t for t in self.paginas() if not t.get("url", "").startswith(("chrome://", "about:"))] or self.paginas()
        if not pags:
            raise RuntimeError("nenhuma aba aberta no Chrome do bot")
        self.aba = pags[0]["targetId"]
        return self.aba

    def nova_janela(self, url, fundo=True):
        """Abre uma janela nova (sem tirar o foco de quem está usando o computador)."""
        r = self.enviar("Target.createTarget", {"url": url, "newWindow": True, "background": fundo})
        self.aba = CDP_PREFERIDA["id"] = r["targetId"]
        return self.aba

    def ajustar_janela(self, esquerda, topo, largura, altura):
        """Deixa a janela do bot do tamanho da área de trabalho, sem ativá-la."""
        try:
            jid = self.enviar("Browser.getWindowForTarget", {"targetId": self.escolher_aba()})["windowId"]
            self.enviar("Browser.setWindowBounds", {"windowId": jid, "bounds": {"windowState": "normal"}})
            self.enviar("Browser.setWindowBounds", {"windowId": jid, "bounds": {
                "left": int(esquerda), "top": int(topo), "width": int(largura), "height": int(altura)}})
        except Exception:
            pass

    def emular_foco(self, ligado=True):
        """A página se comporta como se estivesse em foco, mesmo atrás de outras janelas."""
        try:
            self.enviar("Emulation.setFocusEmulationEnabled", {"enabled": ligado}, self.sessao())
        except Exception:
            pass

    # ---- JavaScript
    def avaliar(self, expr, tid=None, valor=True):
        r = self.enviar("Runtime.evaluate", {"expression": expr, "returnByValue": valor, "awaitPromise": False},
                        self.sessao(tid))
        if r.get("exceptionDetails"):
            raise RuntimeError(r["exceptionDetails"].get("exception", {}).get("description", "erro de JavaScript"))
        res = r.get("result", {})
        if valor:
            return res.get("value")
        return res.get("objectId")

    # ---- avisos da página (alert / confirm / prompt / "sair desta página?")
    def dialogo_aberto(self):
        """(targetId, {'message', 'type', 'url'}) do aviso aberto na aba do bot, ou (None, None)."""
        try:
            tid = self.escolher_aba()
        except Exception:
            return None, None
        if tid not in self.sessoes:
            try:
                self.sessao(tid)  # começa a ouvir a aba (os avisos que abrirem daqui em diante chegam)
            except Exception:
                return None, None
        d = self.dialogos.get(tid)
        return (tid, d) if d else (None, None)

    def responder_dialogo(self, aceitar=True, texto=None, tid=None):
        tid = tid or self.escolher_aba()
        params = {"accept": bool(aceitar)}
        if texto is not None:
            params["promptText"] = str(texto)
        self.enviar("Page.handleJavaScriptDialog", params, self.sessao(tid), timeout=8)
        self.dialogos.pop(tid, None)

    # ---- enviar arquivo para a página (sem a janela "Abrir" do Windows)
    JS_MARCAR_UPLOAD = r"""((sel) => {
        const todos = [...document.querySelectorAll(sel || 'input[type=file]')].filter(i => i.type === 'file');
        if (!todos.length) return JSON.stringify({n: 0});
        const nota = i => (i.multiple ? 2 : 0) + (!i.accept || !/^image\//.test(i.accept) ? 3 : 0)
                         + (i.name === 'Filedata' ? 4 : 0) + (i.disabled ? -9 : 0);
        todos.sort((a, b) => nota(b) - nota(a));
        document.querySelectorAll('[data-bot-anexo]').forEach(e => e.removeAttribute('data-bot-anexo'));
        todos[0].setAttribute('data-bot-anexo', '1');
        return JSON.stringify({n: todos.length, multiplo: todos[0].multiple});
    })(%s)"""

    def anexar_arquivos(self, caminhos, seletor="", tid=None):
        """Entrega os arquivos ao campo de upload da página (o mesmo que escolher na janela Abrir). Devolve quantos
        campos de upload a página tinha (0 = nenhum ainda)."""
        tid = tid or self.escolher_aba()
        info = self.avaliar_json(self.JS_MARCAR_UPLOAD % json.dumps(seletor or ""), tid) or {}
        if not info.get("n"):
            return 0
        sid = self.sessao(tid)
        raiz = self.enviar("DOM.getDocument", {"depth": 0}, sid)["root"]["nodeId"]
        no = self.enviar("DOM.querySelector", {"nodeId": raiz, "selector": "[data-bot-anexo]"}, sid).get("nodeId")
        if not no:
            return 0
        arquivos = list(caminhos) if info.get("multiplo") else list(caminhos)[:1]
        self.enviar("DOM.setFileInputFiles", {"files": arquivos, "nodeId": no}, sid)
        return info["n"]

    def avaliar_json(self, expr, tid=None):
        v = self.avaliar(expr, tid)
        return json.loads(v) if v else None

    def chamar(self, objeto, funcao, *args):
        return self.enviar("Runtime.callFunctionOn", {
            "objectId": objeto, "functionDeclaration": funcao, "returnByValue": True,
            "arguments": [{"value": a} for a in args]}, self.sessao()).get("result", {}).get("value")

    # ---- elementos
    def achar(self, alvo):
        return self.avaliar(JS_ACHAR % json.dumps(alvo), valor=False)

    def caixa(self, objeto):
        """(esquerda, topo, direita, baixo) do elemento, em pixels da página visível."""
        try:
            self.enviar("DOM.scrollIntoViewIfNeeded", {"objectId": objeto}, self.sessao())
        except Exception:
            self.chamar(objeto, "function() { this.scrollIntoView({block: 'center', inline: 'center'}); }")
        q = self.enviar("DOM.getBoxModel", {"objectId": objeto}, self.sessao())["model"]["border"]
        xs, ys = q[0::2], q[1::2]
        return min(xs), min(ys), max(xs), max(ys)

    def destacar(self, objeto, ms=700):
        try:
            self.chamar(objeto, JS_DESTACAR, ms)
        except Exception:
            pass

    # ---- entrada direta na página
    def mouse(self, tipo, x, y, botao="left", cliques=0, mods=()):
        self.enviar("Input.dispatchMouseEvent", {"type": tipo, "x": x, "y": y, "button": botao,
                                                 "clickCount": cliques,
                                                 "modifiers": sum(MODIFICADORES.get(m, 0) for m in mods),
                                                 "buttons": 0 if tipo == "mouseReleased" else (1 if botao == "left" else 2)},
                    self.sessao())

    def clicar(self, x, y, botao="left", cliques=1, mods=()):
        """mods: ("ctrl",), ("shift",)... para Ctrl+clique / Shift+clique."""
        self.mouse("mouseMoved", x, y, "none", 0, mods)
        for n in range(1, int(cliques) + 1):
            self.mouse("mousePressed", x, y, botao, n, mods)
            self.mouse("mouseReleased", x, y, botao, n, mods)

    def roda(self, x, y, dy):
        self.enviar("Input.dispatchMouseEvent", {"type": "mouseWheel", "x": x, "y": y, "deltaX": 0, "deltaY": dy},
                    self.sessao())

    def inserir_texto(self, texto):
        self.enviar("Input.insertText", {"text": texto}, self.sessao())

    def tecla(self, nome, mods=()):
        """Aperta uma tecla dentro da página (ex.: 'tab', 'enter', 'a' com ('ctrl',))."""
        nome = nome.lower()
        if nome in TECLAS_CDP:
            key, code, vk, texto = TECLAS_CDP[nome]
        elif len(nome) == 1 and nome.isalnum():
            key, code, vk, texto = nome, ("Key" + nome.upper()) if nome.isalpha() else ("Digit" + nome), ord(nome.upper()), nome
        else:
            raise ValueError(f"tecla '{nome}' não pode ser enviada em segundo plano")
        m = sum(MODIFICADORES.get(x, 0) for x in mods)
        if m & 0b0111:  # ctrl/alt/win: sem texto
            texto = None
        base = {"key": key, "code": code, "windowsVirtualKeyCode": vk, "nativeVirtualKeyCode": vk, "modifiers": m}
        down = dict(base, type="keyDown" if texto else "rawKeyDown")
        if texto:
            down.update(text=texto, unmodifiedText=texto)
        if m & 2 and nome in COMANDOS:
            down["commands"] = [COMANDOS[nome]]
        self.enviar("Input.dispatchKeyEvent", down, self.sessao())
        self.enviar("Input.dispatchKeyEvent", dict(base, type="keyUp"), self.sessao())

    # ---- imagem da página
    def captura(self):
        """Imagem da página (mesmo atrás de outras janelas) e o devicePixelRatio."""
        from PIL import Image
        dados = self.enviar("Page.captureScreenshot", {"format": "png", "fromSurface": True}, self.sessao(),
                            timeout=20)["data"]
        dpr = float(self.avaliar("devicePixelRatio") or 1)
        return Image.open(io.BytesIO(base64.b64decode(dados))).convert("RGB"), dpr

    # ---- gravação: avisa qual elemento foi clicado em qualquer aba/página
    def gravar(self, ao_clique):
        def instalar(tid):
            try:
                sid = self.sessao(tid)
                self.enviar("Runtime.addBinding", {"name": "__botEvento"}, sid)
                self.enviar("Page.addScriptToEvaluateOnNewDocument", {"source": JS_GRAVAR}, sid)
                self.enviar("Runtime.evaluate", {"expression": JS_GRAVAR}, sid)
            except Exception:
                pass

        def ouvinte(metodo, p, tid):
            if metodo == "Runtime.bindingCalled" and p.get("name") == "__botEvento":
                try:
                    dados = json.loads(p.get("payload", "{}"))
                    dados["aba"] = tid
                    ao_clique(dados, time.time())
                except Exception:
                    pass
            elif metodo == "Target.targetCreated" and p["targetInfo"].get("type") == "page":
                threading.Thread(target=instalar, args=(p["targetInfo"]["targetId"],), daemon=True).start()

        self.ouvintes.append(ouvinte)
        for t in self.paginas():
            instalar(t["targetId"])
