# -*- coding: utf-8 -*-
"""
Fórmulas do Excel em PORTUGUÊS e INGLÊS.

- FUNCOES: ~250 funções (nome em inglês e em português do Brasil, categoria, argumentos e descrição).
- detectar_idioma(formula): "pt", "en" ou "neutro" (sem funções/sinais que indiquem o idioma).
- para_ingles(formula) / para_portugues(formula): converte nomes de funções, separadores (; ↔ ,),
  decimais (0,5 ↔ 0.5), VERDADEIRO/FALSO e valores de erro (#N/D ↔ #N/A). Textos entre aspas,
  nomes de abas entre apóstrofos e colunas de tabela [entre colchetes] nunca são alterados.
- Lista completa: com o Excel instalado, o bot pode ler do PRÓPRIO Excel a tradução de todas as funções
  (excel.Excel.ler_funcoes_do_excel) e guardar em funcoes_excel_local.json; ela completa o dicionário.
"""
import json
import os
import re

# EN | PT | categoria | argumentos (em português) | descrição
_TABELA = r"""
SUM|SOMA|Matemática|núm1; [núm2]; ...|Soma os números
SUMIF|SOMASE|Matemática|intervalo; critério; [intervalo_soma]|Soma as células que atendem a um critério
SUMIFS|SOMASES|Matemática|intervalo_soma; intervalo1; critério1; ...|Soma com vários critérios
SUMPRODUCT|SOMARPRODUTO|Matemática|matriz1; [matriz2]; ...|Soma dos produtos das matrizes
SUMSQ|SOMAQUAD|Matemática|núm1; [núm2]; ...|Soma dos quadrados
PRODUCT|MULT|Matemática|núm1; [núm2]; ...|Multiplica os números
ROUND|ARRED|Matemática|núm; casas|Arredonda
ROUNDUP|ARREDONDAR.PARA.CIMA|Matemática|núm; casas|Arredonda para cima
ROUNDDOWN|ARREDONDAR.PARA.BAIXO|Matemática|núm; casas|Arredonda para baixo
MROUND|MARRED|Matemática|núm; múltiplo|Arredonda para o múltiplo mais próximo
CEILING|TETO|Matemática|núm; significância|Arredonda para cima até o múltiplo
CEILING.MATH|TETO.MAT|Matemática|núm; [significância]; [modo]|Arredonda para cima até o múltiplo
FLOOR|ARREDMULTB|Matemática|núm; significância|Arredonda para baixo até o múltiplo
FLOOR.MATH|ARREDMULTB.MAT|Matemática|núm; [significância]; [modo]|Arredonda para baixo até o múltiplo
INT|INT|Matemática|núm|Parte inteira (para baixo)
TRUNC|TRUNCAR|Matemática|núm; [casas]|Corta as casas decimais
ABS|ABS|Matemática|núm|Valor absoluto
MOD|MOD|Matemática|núm; divisor|Resto da divisão
QUOTIENT|QUOCIENTE|Matemática|numerador; denominador|Parte inteira da divisão
POWER|POTÊNCIA|Matemática|núm; potência|Eleva à potência
SQRT|RAIZ|Matemática|núm|Raiz quadrada
EXP|EXP|Matemática|núm|e elevado ao número
LN|LN|Matemática|núm|Logaritmo natural
LOG|LOG|Matemática|núm; [base]|Logaritmo
LOG10|LOG10|Matemática|núm|Logaritmo na base 10
PI|PI|Matemática||O número pi
SIGN|SINAL|Matemática|núm|Sinal do número (1, 0 ou -1)
EVEN|PAR|Matemática|núm|Arredonda para o próximo par
ODD|ÍMPAR|Matemática|núm|Arredonda para o próximo ímpar
FACT|FATORIAL|Matemática|núm|Fatorial
COMBIN|COMBIN|Matemática|núm; escolhidos|Combinações
PERMUT|PERMUT|Matemática|núm; escolhidos|Permutações
GCD|MDC|Matemática|núm1; [núm2]; ...|Máximo divisor comum
LCM|MMC|Matemática|núm1; [núm2]; ...|Mínimo múltiplo comum
RAND|ALEATÓRIO|Matemática||Número aleatório entre 0 e 1
RANDBETWEEN|ALEATÓRIOENTRE|Matemática|inferior; superior|Inteiro aleatório entre dois números
RANDARRAY|MATRIZALEATÓRIA|Matemática|[linhas]; [colunas]; [mín]; [máx]; [inteiro]|Matriz de números aleatórios
SEQUENCE|SEQUÊNCIA|Matemática|linhas; [colunas]; [início]; [passo]|Lista de números em sequência
SUBTOTAL|SUBTOTAL|Matemática|núm_função; ref1; ...|Subtotal (ignora linhas filtradas com 101-111)
AGGREGATE|AGREGAR|Matemática|núm_função; opções; ref1; ...|Agregação ignorando erros/ocultos
ROMAN|ROMANO|Matemática|núm; [forma]|Número em algarismos romanos
SIN|SEN|Matemática|núm|Seno
COS|COS|Matemática|núm|Cosseno
TAN|TAN|Matemática|núm|Tangente
ASIN|ASEN|Matemática|núm|Arco seno
ACOS|ACOS|Matemática|núm|Arco cosseno
ATAN|ATAN|Matemática|núm|Arco tangente
ATAN2|ATAN2|Matemática|x; y|Arco tangente de x e y
RADIANS|RADIANOS|Matemática|ângulo|Graus para radianos
DEGREES|GRAUS|Matemática|ângulo|Radianos para graus
MMULT|MATRIZ.MULT|Matemática|matriz1; matriz2|Produto de matrizes
MDETERM|MATRIZ.DETERM|Matemática|matriz|Determinante
MINVERSE|MATRIZ.INVERSO|Matemática|matriz|Matriz inversa
IF|SE|Lógica|teste; [se_verdadeiro]; [se_falso]|Escolhe um valor conforme o teste
IFS|SES|Lógica|teste1; valor1; [teste2; valor2]; ...|Vários testes em sequência
IFERROR|SEERRO|Lógica|valor; valor_se_erro|Troca erros por outro valor
IFNA|SENÃODISP|Lógica|valor; valor_se_nd|Troca #N/D por outro valor
AND|E|Lógica|lógico1; [lógico2]; ...|VERDADEIRO se todos forem verdadeiros
OR|OU|Lógica|lógico1; [lógico2]; ...|VERDADEIRO se algum for verdadeiro
NOT|NÃO|Lógica|lógico|Inverte VERDADEIRO/FALSO
XOR|OUEXCL|Lógica|lógico1; [lógico2]; ...|Ou exclusivo
SWITCH|PARÂMETRO|Lógica|expressão; valor1; resultado1; ...; [padrão]|Escolhe o resultado pelo valor
TRUE|VERDADEIRO|Lógica||Valor lógico VERDADEIRO
FALSE|FALSO|Lógica||Valor lógico FALSO
LET|LET|Lógica|nome1; valor1; cálculo|Dá nomes a cálculos dentro da fórmula
LAMBDA|LAMBDA|Lógica|[parâmetro1]; ...; cálculo|Cria uma função personalizada
VLOOKUP|PROCV|Pesquisa|valor; tabela; núm_coluna; [procurar_intervalo]|Procura na 1ª coluna e devolve outra coluna
HLOOKUP|PROCH|Pesquisa|valor; tabela; núm_linha; [procurar_intervalo]|Procura na 1ª linha e devolve outra linha
XLOOKUP|PROCX|Pesquisa|valor; matriz_procura; matriz_retorno; [se_não_encontrado]; [modo]; [busca]|Procura moderna (substitui PROCV)
LOOKUP|PROC|Pesquisa|valor; vetor_procura; [vetor_resultado]|Procura num vetor
INDEX|ÍNDICE|Pesquisa|matriz; núm_linha; [núm_coluna]|Valor numa posição da tabela
MATCH|CORRESP|Pesquisa|valor; matriz; [tipo]|Posição do valor na lista
XMATCH|CORRESPX|Pesquisa|valor; matriz; [modo]; [busca]|Posição do valor (moderna)
CHOOSE|ESCOLHER|Pesquisa|índice; valor1; [valor2]; ...|Escolhe um valor pela posição
OFFSET|DESLOC|Pesquisa|ref; linhas; colunas; [altura]; [largura]|Referência deslocada
INDIRECT|INDIRETO|Pesquisa|texto_ref; [a1]|Referência a partir de um texto
ADDRESS|ENDEREÇO|Pesquisa|linha; coluna; [abs]; [a1]; [planilha]|Endereço da célula como texto
ROW|LIN|Pesquisa|[ref]|Número da linha
ROWS|LINS|Pesquisa|matriz|Quantidade de linhas
COLUMN|COL|Pesquisa|[ref]|Número da coluna
COLUMNS|COLS|Pesquisa|matriz|Quantidade de colunas
AREAS|ÁREAS|Pesquisa|ref|Quantidade de áreas da referência
TRANSPOSE|TRANSPOR|Pesquisa|matriz|Troca linhas por colunas
FILTER|FILTRO|Pesquisa|matriz; incluir; [se_vazio]|Filtra uma tabela por condição
SORT|CLASSIFICAR|Pesquisa|matriz; [índice]; [ordem]; [por_coluna]|Ordena uma tabela
SORTBY|CLASSIFICARPOR|Pesquisa|matriz; por_matriz1; [ordem1]; ...|Ordena por outra coluna
UNIQUE|ÚNICO|Pesquisa|matriz; [por_coluna]; [exatamente_uma_vez]|Valores sem repetição
CHOOSECOLS|ESCOLHERCOLS|Pesquisa|matriz; núm_col1; ...|Escolhe colunas
CHOOSEROWS|ESCOLHERLINS|Pesquisa|matriz; núm_lin1; ...|Escolhe linhas
VSTACK|EMPILHARV|Pesquisa|matriz1; [matriz2]; ...|Empilha tabelas uma embaixo da outra
HSTACK|EMPILHARH|Pesquisa|matriz1; [matriz2]; ...|Junta tabelas lado a lado
TOCOL|PARACOL|Pesquisa|matriz; [ignorar]; [por_coluna]|Transforma em uma coluna
TOROW|PARALIN|Pesquisa|matriz; [ignorar]; [por_coluna]|Transforma em uma linha
HYPERLINK|HIPERLINK|Pesquisa|local; [nome]|Cria um link
GETPIVOTDATA|INFODADOSTABELADINÂMICA|Pesquisa|campo_dados; tabela_dinâmica; [campo1; item1]; ...|Valor de uma tabela dinâmica
FORMULATEXT|FÓRMULATEXTO|Pesquisa|ref|Texto da fórmula da célula
CONCATENATE|CONCATENAR|Texto|texto1; [texto2]; ...|Junta textos
CONCAT|CONCAT|Texto|texto1; [texto2]; ...|Junta textos e intervalos
TEXTJOIN|UNIRTEXTO|Texto|delimitador; ignorar_vazio; texto1; ...|Junta textos com separador
LEFT|ESQUERDA|Texto|texto; [núm_caract]|Primeiros caracteres
RIGHT|DIREITA|Texto|texto; [núm_caract]|Últimos caracteres
MID|EXT.TEXTO|Texto|texto; início; núm_caract|Trecho do meio
LEN|NÚM.CARACT|Texto|texto|Quantidade de caracteres
FIND|PROCURAR|Texto|procurar; no_texto; [início]|Posição de um texto (diferencia maiúsculas)
SEARCH|LOCALIZAR|Texto|procurar; no_texto; [início]|Posição de um texto (aceita curingas)
REPLACE|MUDAR|Texto|texto_antigo; início; núm_caract; texto_novo|Troca caracteres por posição
SUBSTITUTE|SUBSTITUIR|Texto|texto; texto_antigo; texto_novo; [ocorrência]|Troca um texto por outro
UPPER|MAIÚSCULA|Texto|texto|Tudo em maiúsculas
LOWER|MINÚSCULA|Texto|texto|Tudo em minúsculas
PROPER|PRI.MAIÚSCULA|Texto|texto|Primeira letra de cada palavra maiúscula
TRIM|ARRUMAR|Texto|texto|Tira espaços extras
CLEAN|TIRAR|Texto|texto|Tira caracteres não imprimíveis
TEXT|TEXTO|Texto|valor; formato|Número/data como texto formatado
VALUE|VALOR|Texto|texto|Texto para número
NUMBERVALUE|VALORNUMÉRICO|Texto|texto; [sep_decimal]; [sep_grupo]|Texto para número com separadores
REPT|REPT|Texto|texto; vezes|Repete o texto
EXACT|EXATO|Texto|texto1; texto2|Textos idênticos?
CHAR|CARACT|Texto|núm|Caractere pelo código
CODE|CÓDIGO|Texto|texto|Código do primeiro caractere
UNICHAR|CARACTUNICODE|Texto|núm|Caractere Unicode
UNICODE|UNICODE|Texto|texto|Código Unicode
FIXED|DEF.NÚM.DEC|Texto|núm; [decimais]; [sem_separador]|Número como texto com decimais fixos
DOLLAR|MOEDA|Texto|núm; [decimais]|Número como texto em moeda
T|T|Texto|valor|Devolve o texto (ou vazio)
TEXTBEFORE|TEXTOANTES|Texto|texto; delimitador; [ocorrência]; ...|Texto antes do delimitador
TEXTAFTER|TEXTODEPOIS|Texto|texto; delimitador; [ocorrência]; ...|Texto depois do delimitador
TEXTSPLIT|DIVIDIRTEXTO|Texto|texto; delim_coluna; [delim_linha]; ...|Divide o texto em células
TODAY|HOJE|Data e hora||Data de hoje
NOW|AGORA|Data e hora||Data e hora atuais
DATE|DATA|Data e hora|ano; mês; dia|Monta uma data
TIME|TEMPO|Data e hora|hora; minuto; segundo|Monta um horário
YEAR|ANO|Data e hora|data|Ano da data
MONTH|MÊS|Data e hora|data|Mês da data
DAY|DIA|Data e hora|data|Dia da data
HOUR|HORA|Data e hora|hora|Hora
MINUTE|MINUTO|Data e hora|hora|Minuto
SECOND|SEGUNDO|Data e hora|hora|Segundo
WEEKDAY|DIA.DA.SEMANA|Data e hora|data; [tipo]|Dia da semana (número)
WEEKNUM|NÚMSEMANA|Data e hora|data; [tipo]|Número da semana no ano
ISOWEEKNUM|NÚMSEMANAISO|Data e hora|data|Semana ISO do ano
EDATE|DATAM|Data e hora|data; meses|Data somando meses
EOMONTH|FIMMÊS|Data e hora|data; meses|Último dia do mês
NETWORKDAYS|DIATRABALHOTOTAL|Data e hora|início; fim; [feriados]|Dias úteis entre datas
NETWORKDAYS.INTL|DIATRABALHOTOTAL.INTL|Data e hora|início; fim; [fim_de_semana]; [feriados]|Dias úteis (fim de semana escolhido)
WORKDAY|DIATRABALHO|Data e hora|início; dias; [feriados]|Data após N dias úteis
WORKDAY.INTL|DIATRABALHO.INTL|Data e hora|início; dias; [fim_de_semana]; [feriados]|Data após N dias úteis (fim de semana escolhido)
DATEDIF|DATADIF|Data e hora|início; fim; unidade|Diferença entre datas ("d", "m", "y")
DATEVALUE|DATA.VALOR|Data e hora|texto_data|Texto para data
TIMEVALUE|VALOR.TEMPO|Data e hora|texto_hora|Texto para hora
DAYS|DIAS|Data e hora|fim; início|Dias entre duas datas
DAYS360|DIAS360|Data e hora|início; fim; [método]|Dias entre datas (ano de 360 dias)
YEARFRAC|FRAÇÃOANO|Data e hora|início; fim; [base]|Fração do ano entre datas
AVERAGE|MÉDIA|Estatística|núm1; [núm2]; ...|Média
AVERAGEA|MÉDIAA|Estatística|valor1; [valor2]; ...|Média contando textos/lógicos
AVERAGEIF|MÉDIASE|Estatística|intervalo; critério; [intervalo_média]|Média com critério
AVERAGEIFS|MÉDIASES|Estatística|intervalo_média; intervalo1; critério1; ...|Média com vários critérios
COUNT|CONT.NÚM|Estatística|valor1; [valor2]; ...|Conta células com números
COUNTA|CONT.VALORES|Estatística|valor1; [valor2]; ...|Conta células não vazias
COUNTBLANK|CONTAR.VAZIO|Estatística|intervalo|Conta células vazias
COUNTIF|CONT.SE|Estatística|intervalo; critério|Conta com critério
COUNTIFS|CONT.SES|Estatística|intervalo1; critério1; ...|Conta com vários critérios
MAX|MÁXIMO|Estatística|núm1; [núm2]; ...|Maior valor
MAXA|MÁXIMOA|Estatística|valor1; [valor2]; ...|Maior valor contando lógicos
MAXIFS|MÁXIMOSES|Estatística|intervalo_máx; intervalo1; critério1; ...|Maior valor com critérios
MIN|MÍNIMO|Estatística|núm1; [núm2]; ...|Menor valor
MINA|MÍNIMOA|Estatística|valor1; [valor2]; ...|Menor valor contando lógicos
MINIFS|MÍNIMOSES|Estatística|intervalo_mín; intervalo1; critério1; ...|Menor valor com critérios
LARGE|MAIOR|Estatística|matriz; k|k-ésimo maior valor
SMALL|MENOR|Estatística|matriz; k|k-ésimo menor valor
MEDIAN|MED|Estatística|núm1; [núm2]; ...|Mediana
MODE|MODO|Estatística|núm1; [núm2]; ...|Valor mais frequente
MODE.SNGL|MODO.ÚNICO|Estatística|núm1; [núm2]; ...|Valor mais frequente
MODE.MULT|MODO.MULT|Estatística|núm1; [núm2]; ...|Valores mais frequentes
RANK|ORDEM|Estatística|núm; ref; [ordem]|Posição no ranking
RANK.EQ|ORDEM.EQ|Estatística|núm; ref; [ordem]|Posição no ranking
RANK.AVG|ORDEM.MÉD|Estatística|núm; ref; [ordem]|Posição no ranking (média em empates)
PERCENTILE|PERCENTIL|Estatística|matriz; k|Percentil
PERCENTILE.INC|PERCENTIL.INC|Estatística|matriz; k|Percentil (inclusivo)
PERCENTILE.EXC|PERCENTIL.EXC|Estatística|matriz; k|Percentil (exclusivo)
QUARTILE|QUARTIL|Estatística|matriz; quarto|Quartil
QUARTILE.INC|QUARTIL.INC|Estatística|matriz; quarto|Quartil (inclusivo)
QUARTILE.EXC|QUARTIL.EXC|Estatística|matriz; quarto|Quartil (exclusivo)
STDEV|DESVPAD|Estatística|núm1; [núm2]; ...|Desvio padrão (amostra)
STDEV.S|DESVPAD.A|Estatística|núm1; [núm2]; ...|Desvio padrão (amostra)
STDEV.P|DESVPAD.P|Estatística|núm1; [núm2]; ...|Desvio padrão (população)
STDEVA|DESVPADA|Estatística|valor1; [valor2]; ...|Desvio padrão contando lógicos
STDEVP|DESVPADP|Estatística|núm1; [núm2]; ...|Desvio padrão (população)
VAR|VAR|Estatística|núm1; [núm2]; ...|Variância (amostra)
VAR.S|VAR.A|Estatística|núm1; [núm2]; ...|Variância (amostra)
VAR.P|VAR.P|Estatística|núm1; [núm2]; ...|Variância (população)
VARP|VARP|Estatística|núm1; [núm2]; ...|Variância (população)
AVEDEV|DESV.MÉDIO|Estatística|núm1; [núm2]; ...|Desvio médio
GEOMEAN|MÉDIA.GEOMÉTRICA|Estatística|núm1; [núm2]; ...|Média geométrica
HARMEAN|MÉDIA.HARMÔNICA|Estatística|núm1; [núm2]; ...|Média harmônica
TRIMMEAN|MÉDIA.INTERNA|Estatística|matriz; porcentagem|Média sem os extremos
CORREL|CORREL|Estatística|matriz1; matriz2|Correlação
PEARSON|PEARSON|Estatística|matriz1; matriz2|Correlação de Pearson
RSQ|RQUAD|Estatística|y_conhecidos; x_conhecidos|R ao quadrado
SLOPE|INCLINAÇÃO|Estatística|y_conhecidos; x_conhecidos|Inclinação da reta
INTERCEPT|INTERCEPÇÃO|Estatística|y_conhecidos; x_conhecidos|Intercepto da reta
FORECAST|PREVISÃO|Estatística|x; y_conhecidos; x_conhecidos|Previsão linear
FORECAST.LINEAR|PREVISÃO.LINEAR|Estatística|x; y_conhecidos; x_conhecidos|Previsão linear
TREND|TENDÊNCIA|Estatística|y_conhecidos; [x_conhecidos]; [novos_x]; [const]|Valores da tendência linear
GROWTH|CRESCIMENTO|Estatística|y_conhecidos; [x_conhecidos]; [novos_x]; [const]|Valores do crescimento exponencial
STANDARDIZE|PADRONIZAR|Estatística|x; média; desv_padrão|Valor normalizado
NORM.DIST|DIST.NORM.N|Estatística|x; média; desv_padrão; cumulativo|Distribuição normal
NORM.INV|INV.NORM.N|Estatística|probabilidade; média; desv_padrão|Inverso da normal
NORM.S.DIST|DIST.NORMP.N|Estatística|z; cumulativo|Distribuição normal padrão
CONFIDENCE|INT.CONFIANÇA|Estatística|alfa; desv_padrão; tamanho|Intervalo de confiança
COVARIANCE.S|COVARIAÇÃO.S|Estatística|matriz1; matriz2|Covariância (amostra)
COVARIANCE.P|COVARIAÇÃO.P|Estatística|matriz1; matriz2|Covariância (população)
SKEW|DISTORÇÃO|Estatística|núm1; [núm2]; ...|Assimetria
KURT|CURT|Estatística|núm1; [núm2]; ...|Curtose
ISBLANK|ÉCÉL.VAZIA|Informação|valor|A célula está vazia?
ISERROR|ÉERROS|Informação|valor|É qualquer erro?
ISERR|ÉERRO|Informação|valor|É erro (menos #N/D)?
ISNA|É.NÃO.DISP|Informação|valor|É #N/D?
ISNUMBER|ÉNÚM|Informação|valor|É número?
ISTEXT|ÉTEXTO|Informação|valor|É texto?
ISNONTEXT|É.NÃO.TEXTO|Informação|valor|Não é texto?
ISLOGICAL|ÉLÓGICO|Informação|valor|É VERDADEIRO/FALSO?
ISREF|ÉREF|Informação|valor|É referência?
ISEVEN|ÉPAR|Informação|núm|É par?
ISODD|ÉIMPAR|Informação|núm|É ímpar?
ISFORMULA|ÉFÓRMULA|Informação|ref|A célula tem fórmula?
NA|NÃO.DISP|Informação||Devolve #N/D
N|N|Informação|valor|Valor como número
TYPE|TIPO|Informação|valor|Tipo do valor
ERROR.TYPE|TIPO.ERRO|Informação|valor_erro|Número do tipo de erro
CELL|CÉL|Informação|tipo_info; [ref]|Informações sobre a célula
INFO|INFORMAÇÃO|Informação|tipo|Informações do ambiente
SHEET|PLAN|Informação|[valor]|Número da planilha
SHEETS|PLANS|Informação|[ref]|Quantidade de planilhas
PMT|PGTO|Financeira|taxa; nper; vp; [vf]; [tipo]|Valor da prestação
PV|VP|Financeira|taxa; nper; pgto; [vf]; [tipo]|Valor presente
FV|VF|Financeira|taxa; nper; pgto; [vp]; [tipo]|Valor futuro
NPV|VPL|Financeira|taxa; valor1; [valor2]; ...|Valor presente líquido
IRR|TIR|Financeira|valores; [estimativa]|Taxa interna de retorno
MIRR|MTIR|Financeira|valores; taxa_financ; taxa_reinvest|TIR modificada
XNPV|XVPL|Financeira|taxa; valores; datas|VPL com datas
XIRR|XTIR|Financeira|valores; datas; [estimativa]|TIR com datas
RATE|TAXA|Financeira|nper; pgto; vp; [vf]; [tipo]; [estimativa]|Taxa de juros por período
NPER|NPER|Financeira|taxa; pgto; vp; [vf]; [tipo]|Número de períodos
IPMT|IPGTO|Financeira|taxa; per; nper; vp; [vf]; [tipo]|Juros de uma prestação
PPMT|PPGTO|Financeira|taxa; per; nper; vp; [vf]; [tipo]|Amortização de uma prestação
SLN|DPD|Financeira|custo; recuperação; vida_útil|Depreciação linear
DB|BD|Financeira|custo; recuperação; vida_útil; período; [mês]|Depreciação (saldo decrescente)
DDB|BDD|Financeira|custo; recuperação; vida_útil; período; [fator]|Depreciação (saldo duplamente decrescente)
EFFECT|EFETIVA|Financeira|taxa_nominal; nper_ano|Taxa efetiva anual
NOMINAL|NOMINAL|Financeira|taxa_efetiva; nper_ano|Taxa nominal anual
DSUM|BDSOMA|Banco de dados|banco; campo; critérios|Soma com critérios (banco de dados)
DAVERAGE|BDMÉDIA|Banco de dados|banco; campo; critérios|Média com critérios (banco de dados)
DCOUNT|BDCONTAR|Banco de dados|banco; campo; critérios|Conta números com critérios
DCOUNTA|BDCONTARA|Banco de dados|banco; campo; critérios|Conta não vazias com critérios
DMAX|BDMÁX|Banco de dados|banco; campo; critérios|Máximo com critérios
DMIN|BDMÍN|Banco de dados|banco; campo; critérios|Mínimo com critérios
DGET|BDEXTRAIR|Banco de dados|banco; campo; critérios|Extrai um único valor
CONVERT|CONVERTER|Engenharia|núm; de_unidade; para_unidade|Converte unidades
DEC2BIN|DECABIN|Engenharia|núm; [casas]|Decimal para binário
BIN2DEC|BINADEC|Engenharia|núm|Binário para decimal
DEC2HEX|DECAHEX|Engenharia|núm; [casas]|Decimal para hexadecimal
HEX2DEC|HEXADEC|Engenharia|núm|Hexadecimal para decimal
DELTA|DELTA|Engenharia|núm1; [núm2]|Números iguais? (1 ou 0)
ENCODEURL|CODIFURL|Web|texto|Codifica um texto para URL
FILTERXML|FILTROXML|Web|xml; xpath|Lê dados de um XML
"""

ERROS = {"#N/A": "#N/D", "#NAME?": "#NOME?", "#VALUE!": "#VALOR!", "#NUM!": "#NÚM!", "#NULL!": "#NULO!",
         "#REF!": "#REF!", "#DIV/0!": "#DIV/0!", "#SPILL!": "#DESPEJAR!", "#CALC!": "#CALC!"}
LOGICOS = {"TRUE": "VERDADEIRO", "FALSE": "FALSO"}
# precisam do prefixo _xlfn. num arquivo salvo sem o Excel (funções novas, 2010 em diante)
_XLWS = {"FILTER", "SORT"}

FUNCOES = []
for _l in _TABELA.strip().splitlines():
    _en, _pt, _cat, _args, _desc = _l.split("|")
    FUNCOES.append({"en": _en, "pt": _pt, "categoria": _cat, "args": _args, "descricao": _desc})

EN_PARA_PT = {f["en"]: f["pt"] for f in FUNCOES if f["en"] not in LOGICOS}
PT_PARA_EN = {v: k for k, v in EN_PARA_PT.items()}
CATEGORIAS = sorted({f["categoria"] for f in FUNCOES})
ARQ_LOCAL = "funcoes_excel_local.json"


def carregar_lista_do_excel(pasta):
    """Completa o dicionário com a lista lida do próprio Excel (funcoes_excel_local.json), se existir
    e se o Excel for em português do Brasil."""
    try:
        with open(os.path.join(pasta, ARQ_LOCAL), encoding="utf-8") as f:
            dados = json.load(f)
    except (OSError, ValueError):
        return 0
    if str(dados.get("idioma")) != "1046":  # 1046 = português (Brasil)
        return 0
    novos = 0
    for en, pt in dados.get("funcoes", {}).items():
        en, pt = en.upper(), pt.upper()
        if en not in EN_PARA_PT and pt and pt not in PT_PARA_EN and en not in LOGICOS:
            EN_PARA_PT[en], PT_PARA_EN[pt] = pt, en
            FUNCOES.append({"en": en, "pt": pt, "categoria": "Outras (lidas do seu Excel)", "args": "",
                            "descricao": ""})
            novos += 1
    return novos


# --------------------------------------------------------------------------- #
# Leitura da fórmula em pedaços: textos "..." / abas '...' / colunas [..] ficam intactos
# --------------------------------------------------------------------------- #
_PEDACOS = re.compile(r'("(?:[^"]|"")*"|\'(?:[^\']|\'\')*\'|\[[^\]]*\])')
_NOME_FUNCAO = re.compile(r"(?<![\w.$#])([A-Za-zÀ-ÿ_][\w.À-ÿ]*)(?=\s*\()")
_LOGICO = re.compile(r"(?<![\w.$#])(TRUE|FALSE|VERDADEIRO|FALSO)(?![\w.(])", re.IGNORECASE)


def _partes(formula):
    """[(texto, protegido?)] — protegido = entre aspas, apóstrofos ou colchetes."""
    out = []
    for i, p in enumerate(_PEDACOS.split(formula)):
        if p:
            out.append((p, i % 2 == 1))
    return out


def funcoes_usadas(formula):
    nomes = []
    for p, protegido in _partes(formula):
        if not protegido:
            nomes += [m.upper() for m in _NOME_FUNCAO.findall(p)]
    return nomes


def detectar_idioma(formula):
    """'pt', 'en' ou 'neutro'. Olha os nomes das funções e, se não decidir, os separadores."""
    if not isinstance(formula, str) or not formula.strip().startswith("="):
        return "neutro"
    pt = en = 0
    for n in funcoes_usadas(formula):
        n = n.removeprefix("_XLFN.").removeprefix("_XLWS.")
        e_pt, e_en = n in PT_PARA_EN, n in EN_PARA_PT
        if e_pt and not e_en:
            pt += 1
        elif e_en and not e_pt:
            en += 1
    for p, protegido in _partes(formula):
        if not protegido:
            for v in _LOGICO.findall(p):
                if v.upper() in ("VERDADEIRO", "FALSO"):
                    pt += 1
                else:
                    en += 1
    if pt != en:
        return "pt" if pt > en else "en"
    livre = "".join(p for p, protegido in _partes(formula) if not protegido)
    if ";" in livre or re.search(r"\d,\d", livre):
        return "pt"
    if re.search(r"\w\s*\(.*,", livre) or re.search(r"\d\.\d", livre):
        return "en"
    return "neutro"


def _trocar_nomes(p, dic):
    return _NOME_FUNCAO.sub(lambda m: dic.get(m.group(1).upper(), m.group(1)), p)


def para_ingles(formula, idioma=None):
    """Fórmula (PT ou EN) -> inglês, como o Excel guarda internamente (Range.Formula / openpyxl)."""
    if not isinstance(formula, str) or not formula.strip().startswith("="):
        return formula
    idioma = idioma or detectar_idioma(formula)
    if idioma == "en":
        return formula
    out = []
    for p, protegido in _partes(formula):
        if not protegido:
            p = re.sub(r"(?<=\d),(?=\d)", ".", p)      # 0,5 -> 0.5
            p = p.replace(";", ",")
            p = _trocar_nomes(p, PT_PARA_EN)
            p = _LOGICO.sub(lambda m: {"VERDADEIRO": "TRUE", "FALSO": "FALSE"}.get(m.group(1).upper(),
                                                                                  m.group(1).upper()), p)
            for en, pt in ERROS.items():
                p = p.replace(pt, en)
        out.append(p)
    return "".join(out)


def para_portugues(formula, idioma=None):
    """Fórmula (EN ou PT) -> português (como se digita no Excel em português)."""
    if not isinstance(formula, str) or not formula.strip().startswith("="):
        return formula
    idioma = idioma or detectar_idioma(formula)
    if idioma == "pt":
        return formula
    out = []
    for p, protegido in _partes(formula):
        if not protegido:
            p = p.replace(",", ";")
            p = re.sub(r"(?<=\d)\.(?=\d)", ",", p)      # 0.5 -> 0,5
            p = _trocar_nomes(p, EN_PARA_PT)
            p = _LOGICO.sub(lambda m: {"TRUE": "VERDADEIRO", "FALSE": "FALSO"}.get(m.group(1).upper(),
                                                                                m.group(1).upper()), p)
            for en, pt in ERROS.items():
                p = p.replace(en, pt)
        out.append(p)
    return "".join(out)


def para_arquivo(formula_en, conhecidas=None):
    """Fórmula em inglês pronta para salvar SEM o Excel (openpyxl): funções novas ganham o prefixo
    _xlfn. (senão o Excel mostra #NOME? ao abrir). 'conhecidas' = funções clássicas (sem prefixo)."""
    if conhecidas is None:
        try:
            from openpyxl.utils import FORMULAE as conhecidas
        except ImportError:
            return formula_en
    out = []
    for p, protegido in _partes(formula_en):
        if not protegido:
            def troca(m):
                n = m.group(1).upper()
                if n.startswith("_XL") or n in conhecidas or n not in EN_PARA_PT:
                    return m.group(1)
                return ("_xlfn._xlws." if n in _XLWS else "_xlfn.") + n
            p = _NOME_FUNCAO.sub(troca, p)
        out.append(p)
    return "".join(out)


def sintaxe(funcao, idioma="pt"):
    """Ex.: PROCV(valor; tabela; núm_coluna; [procurar_intervalo])"""
    if idioma == "pt":
        return f"{funcao['pt']}({funcao['args']})"
    return f"{funcao['en']}({funcao['args'].replace('; ', ', ').replace(';', ',')})"


def procurar(texto="", categoria=None):
    """Busca por nome (PT ou EN) ou descrição."""
    t = texto.strip().upper()
    res = []
    for f in FUNCOES:
        if categoria and f["categoria"] != categoria:
            continue
        if not t or t in f["pt"] or t in f["en"] or t in f["descricao"].upper():
            res.append(f)
    return sorted(res, key=lambda f: (not (f["pt"].startswith(t) or f["en"].startswith(t)),
                                      f["en"] not in POPULARES, f["pt"]))


# aparecem primeiro na busca
POPULARES = {"SUM", "IF", "VLOOKUP", "XLOOKUP", "SUMIF", "SUMIFS", "COUNTIF", "COUNTIFS", "IFERROR", "INDEX",
             "MATCH", "AVERAGE", "TODAY", "NOW", "TEXT", "CONCAT", "LEFT", "RIGHT", "MID", "ROUND", "MAX", "MIN",
             "COUNTA", "TRIM", "FILTER", "UNIQUE", "DATE", "NETWORKDAYS"}


# completa com a lista lida do Excel do usuário (se já foi lida alguma vez)
carregar_lista_do_excel(os.path.dirname(os.path.abspath(__file__)))
