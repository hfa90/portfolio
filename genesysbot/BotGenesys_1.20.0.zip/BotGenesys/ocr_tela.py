# -*- coding: utf-8 -*-
"""
LER TEXTO DA TELA (OCR) com o leitor de texto que JÁ VEM no Windows 10/11 (Windows.Media.Ocr) — sem instalar
programa nem baixar modelo. É chamado pelo Windows PowerShell (que sabe usar esse recurso do Windows).

- ler(regiao): texto da tela inteira, da janela da frente ou de uma área.
- achar(texto, regiao): onde está um texto na tela (para clicar nele) — ex.: um botão de um sistema antigo.
Cada leitura leva ~1 a 3 segundos.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import unicodedata

from PIL import ImageGrab

try:
    import janelas as jc
except ImportError:  # arquivo .py exportado
    jc = sys.modules[__name__]

WIN_OCR = sys.platform == "win32"
REGIOES = ["tela inteira", "janela da frente", "área (posição + largura e altura)", "arquivo de imagem"]

_SCRIPT = r'''
param([string]$Caminho, [string]$Idioma = "pt-BR")
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
    function Esperar($op, $tipo) { $t = $asTask.MakeGenericMethod($tipo).Invoke($null, @($op)); $t.Wait(-1) | Out-Null; $t.Result }
    $arq = Esperar ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Caminho)) ([Windows.Storage.StorageFile])
    $fluxo = Esperar ($arq.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $dec = Esperar ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($fluxo)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bmp = Esperar ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $lingua = New-Object Windows.Globalization.Language $Idioma
    if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lingua)) {
        $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lingua)
    } else { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
    if ($null -eq $motor) { throw "nenhum idioma de OCR instalado no Windows" }
    $res = Esperar ($motor.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
    $linhas = @(foreach ($l in $res.Lines) {
        @{ texto = $l.Text; palavras = @(foreach ($w in $l.Words) {
            $r = $w.BoundingRect; @{ t = $w.Text; x = $r.X; y = $r.Y; w = $r.Width; h = $r.Height } }) } })
    $fluxo.Dispose()
    @{ idioma = $motor.RecognizerLanguage.LanguageTag; linhas = $linhas } | ConvertTo-Json -Depth 6 -Compress
} catch { @{ erro = $_.Exception.Message } | ConvertTo-Json -Compress }
'''
_script_salvo = {}


def disponivel():
    return WIN_OCR


def _arquivo_script():
    if "p" not in _script_salvo or not os.path.exists(_script_salvo["p"]):
        p = os.path.join(tempfile.gettempdir(), "botgenesys_ocr.ps1")
        with open(p, "w", encoding="utf-8-sig") as f:  # com BOM: o PowerShell 5.1 lê os acentos certo
            f.write(_SCRIPT)
        _script_salvo["p"] = p
    return _script_salvo["p"]


def reconhecer(img, idioma="pt-BR"):
    """OCR de uma imagem (PIL). Devolve [{'texto', 'palavras': [{'t', 'x', 'y', 'w', 'h'}]}] em pixels da imagem."""
    if not WIN_OCR:
        raise RuntimeError("a leitura de texto da tela (OCR) usa o leitor do Windows: só funciona no Windows")
    fator = 2 if img.width < 1400 else 1  # texto pequeno de tela: ampliar ajuda muito o OCR
    if fator > 1:
        img = img.resize((img.width * fator, img.height * fator))
    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    tmp.close()
    try:
        img.convert("RGB").save(tmp.name)
        r = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", _arquivo_script(),
                            "-Caminho", tmp.name, "-Idioma", idioma or "pt-BR"],
                           capture_output=True, timeout=60, creationflags=0x08000000)
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass
    saida = r.stdout.decode("utf-8", errors="replace").strip()
    try:
        dados = json.loads(saida[saida.find("{"):]) if "{" in saida else {}
    except ValueError:
        raise RuntimeError(f"o OCR do Windows não respondeu direito: {saida[:200] or r.stderr[:200]!r}")
    if dados.get("erro"):
        raise RuntimeError(f"OCR do Windows: {dados['erro']}")
    linhas = dados.get("linhas") or []
    if isinstance(linhas, dict):  # o PowerShell desembrulha listas de um item só
        linhas = [linhas]
    out = []
    for l in linhas:
        pal = l.get("palavras") or []
        if isinstance(pal, dict):
            pal = [pal]
        out.append({"texto": l.get("texto", ""),
                    "palavras": [{"t": p["t"], "x": p["x"] / fator, "y": p["y"] / fator, "w": p["w"] / fator,
                                  "h": p["h"] / fator} for p in pal]})
    return out


def capturar_regiao(regiao=None):
    """Imagem da tela + canto (x, y) dela. regiao = (x, y, largura, altura), 'janela' ou None (tela inteira)."""
    if regiao == "janela":
        r = None
        try:
            r = jc.retangulo(jc.janela_em_foco()) if jc.WIN else None
        except Exception:
            r = None
        if r:
            caixa = (int(r[0]), int(r[1]), int(r[2]), int(r[3])) if isinstance(r, tuple) else \
                (int(r.left), int(r.top), int(r.right), int(r.bottom))
            return ImageGrab.grab(bbox=caixa), (caixa[0], caixa[1])
        regiao = None
    if regiao:
        x, y, w, h = (int(v) for v in regiao)
        return ImageGrab.grab(bbox=(x, y, x + max(1, w), y + max(1, h))), (x, y)
    return ImageGrab.grab(), (0, 0)


def ler(regiao=None, idioma="pt-BR"):
    """Texto (linhas separadas por quebra de linha) da região."""
    img, _ = capturar_regiao(regiao)
    return "\n".join(l["texto"] for l in reconhecer(img, idioma))


def normalizar(t):
    t = unicodedata.normalize("NFKD", str(t)).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", t).strip().casefold()


def procurar_nas_linhas(linhas, texto, ocorrencia=1):
    """Caixa (x, y, w, h) da n-ésima ocorrência do texto (pode ter várias palavras), na ordem de leitura."""
    alvo = normalizar(texto)
    if not alvo:
        return None
    achadas = []
    for l in sorted(linhas, key=lambda l: (min((p["y"] for p in l["palavras"]), default=0),
                                          min((p["x"] for p in l["palavras"]), default=0))):
        pal = l["palavras"]
        norm = [normalizar(p["t"]) for p in pal]
        i = 0
        while i < len(pal):
            junto = ""
            for j in range(i, len(pal)):
                junto = (junto + " " + norm[j]).strip()
                if alvo in junto:
                    if j > i and alvo in " ".join(norm[i + 1:j + 1]):
                        break  # não precisa da palavra i: o achado começa mais adiante
                    grupo = pal[i:j + 1]
                    x1 = min(p["x"] for p in grupo)
                    y1 = min(p["y"] for p in grupo)
                    x2 = max(p["x"] + p["w"] for p in grupo)
                    y2 = max(p["y"] + p["h"] for p in grupo)
                    achadas.append((x1, y1, x2 - x1, y2 - y1))
                    i = j  # não conta a mesma palavra duas vezes
                    break
                if len(junto) > len(alvo) + 40:
                    break
            i += 1
    n = max(1, int(ocorrencia or 1))
    return achadas[n - 1] if len(achadas) >= n else None


def achar(texto, regiao=None, idioma="pt-BR", ocorrencia=1):
    """Centro (x, y) do texto na tela, ou None."""
    img, (ox, oy) = capturar_regiao(regiao)
    caixa = procurar_nas_linhas(reconhecer(img, idioma), texto, ocorrencia)
    if not caixa:
        return None
    x, y, w, h = caixa
    return int(ox + x + w / 2), int(oy + y + h / 2)


def autoteste_ocr():
    """Desenha um texto numa imagem e lê com o OCR do Windows. Devolve (ok, texto)."""
    if not WIN_OCR:
        return None, "só no Windows"
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (900, 200), "white")
    d = ImageDraw.Draw(img)
    try:
        fonte = ImageFont.truetype("arial.ttf", 48)
    except OSError:
        fonte = ImageFont.load_default()
    d.text((30, 60), "Chamado 4521 aberto com sucesso", fill="black", font=fonte)
    try:
        linhas = reconhecer(img)
    except Exception as e:
        return False, str(e)
    lido = " ".join(l["texto"] for l in linhas)
    caixa = procurar_nas_linhas(linhas, "aberto com")
    if "4521" in lido and caixa and 250 < caixa[0] + caixa[2] / 2 < 800:
        return True, f"leu: \"{lido}\""
    return False, f"leu: \"{lido}\" (esperado 'Chamado 4521 aberto com sucesso')"
