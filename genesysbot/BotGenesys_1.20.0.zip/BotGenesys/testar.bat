@echo off
title Bot Genesys - testes
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -c "import pytest" 2>nul || pip install pytest
python -m pytest testes -q -p no:cacheprovider %*
pause
