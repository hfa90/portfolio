@echo off
title Bot Genesys - diagnostico
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python bot_genesys.py --diagnostico
pause
