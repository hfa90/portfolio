# -*- coding: utf-8 -*-
"""Execução com FLUXO: o laço dos passos (com Se / Senão, Repetir, Tentar / Se der erro, Sair da repetição,
Parar o roteiro, Definir variável e Executar outro roteiro) e a avaliação das condições.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import json
import os
import sys
import time
import urllib.parse

try:
    from motor_util import (PRECISA_TELA, RETENTAVEIS, TIPOS, Parado, jc, ocr, pyautogui, resumo, xlm)
    import fluxo as fx
    import arquivos_win as aw
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    fx = aw = sys.modules[__name__]

LIMITE_SUB_ROTEIROS = 5


class FluxoMixin:

    # ------------------------------------------------------------ o laço dos passos
    def _rodar_passos(self, passos, itens, cfg, rot, feitos, total_passos, nivel=0):
        """Executa os passos ativos (itens = [(índice, passo)]) seguindo os blocos. Devolve 'feitos'."""
        est = fx.estrutura([s["tipo"] for _, s in itens], [i + 1 for i, _ in itens])
        lacos = []  # repetições em andamento: {"k", "fim", "volta", "itens", "modo"}
        k = 0
        while k < len(itens):
            i, s = itens[k]
            t = s["tipo"]
            if self.stop_event.is_set():
                raise Parado()
            while self.pausado:
                self._esperar(0.2)
            self.ui.status(f"Passo {i + 1}/{len(passos)}{rot}\n{TIPOS[t]}: {resumo(s)}")
            self.ui.progresso(min(feitos, total_passos), total_passos, f"Passo {i + 1} de {len(passos)}{rot}")
            self.ui.destacar(i)
            try:
                if t in fx.CONTROLE:
                    k = self._passo_controle(k, s, est, lacos, passos, itens, cfg, rot, nivel, i)
                    feitos += 1
                    continue
                if not self._bg and (t in PRECISA_TELA or (t == "aguardar_carregar" and s.get("metodo") == "visual")):
                    self._garantir_tela(s, cfg)
                if t != "vigiar_popup":  # pop-up aberto antes do passo? (responde ou para com a mensagem)
                    self._checar_vigias(forcar=True)
                self.log(f"Passo {i + 1}: {TIPOS[t]} - {resumo(s)}")
                self._passo_atual = i
                self._executar_com_tentativas(s, i, cfg, rot)
                self._checar_vigias(forcar=True)
            except (Parado, pyautogui.FailSafeException, fx.PararRoteiro):
                raise
            except Exception as e:
                tentar = est[k].get("tentar")
                if tentar is None:
                    raise
                # dentro de um "Tentar": guarda o erro em {erro} e vai para "Se der erro" (ou para depois do bloco)
                msg = str(e)
                self.vars["erro"] = msg
                destino = est[tentar].get("erro")
                lacos[:] = [l for l in lacos if l["k"] < tentar]  # repetições abertas dentro do Tentar acabam
                self.log(f"Erro tratado pelo 'Tentar' do passo {itens[tentar][0] + 1}: {msg}", "erro")
                self._detalhe_tecnico(f"erro tratado pelo 'Tentar' do passo {itens[tentar][0] + 1}", e)
                self.avisos += 1
                k = (destino if destino is not None else est[tentar]["fim"]) + 1
                continue
            feitos += 1
            pausa = float(cfg["pausa"])
            if cfg.get("excel_visivel") and t.startswith("excel_"):
                pausa = max(pausa, 0.6)  # dá tempo de acompanhar o que o bot faz no Excel
            self._esperar(pausa)
            k += 1
        return feitos

    def _executar_com_tentativas(self, s, i, cfg, rot):
        tentativas = int(cfg["tent"]) if s["tipo"] in RETENTAVEIS else 1
        for tentativa in range(1, tentativas + 1):
            try:
                self.executar_passo(s, cfg)
                return
            except (Parado, pyautogui.FailSafeException):
                raise
            except Exception as e:
                if tentativa >= tentativas:
                    raise RuntimeError(f"Passo {i + 1} ({TIPOS[s['tipo']]}){rot}: {xlm.erro_legivel(e)}") from e
                self.log(f"Passo {i + 1} falhou ({xlm.erro_legivel(e)}). Nova tentativa {tentativa + 1}/{tentativas}...",
                         "erro")
                self._esperar(1.5)

    # ------------------------------------------------------------ passos de controle
    def _passo_controle(self, k, s, est, lacos, passos, itens, cfg, rot, nivel, i):
        """Executa um passo de controle e devolve a próxima posição."""
        t, e = s["tipo"], est[k]
        if t in fx.SE_TIPOS:
            ok = self._avaliar(s, cfg)
            self.log(f"Passo {i + 1}: {TIPOS[t]} - {resumo(s)}  →  {'SIM' if ok else 'NÃO'}")
            if ok:
                return k + 1
            return (e["senao"] if e.get("senao") is not None else e["fim"]) + 1
        if t == "senao":  # chegou aqui vindo do "sim": pula o "senão"
            return e["fim"] + 1
        if t in ("fim_se", "fim_tentar", "tentar"):
            return k + 1
        if t == "se_der_erro":  # chegou aqui sem erro: pula o tratamento
            return e["fim"] + 1
        if t == "repetir":
            laco = {"k": k, "fim": e["fim"], "volta": 1, "modo": s.get("modo") or "vezes"}
            if laco["modo"] == "para cada item da lista":
                laco["itens"] = fx.dividir_lista(self._x(s.get("lista")), s.get("separador") or ";")
            if not self._continuar_laco(s, laco, i):
                self.log(f"Passo {i + 1}: Repetir — nenhuma volta ({resumo(s)}).")
                return e["fim"] + 1
            lacos.append(laco)
            return k + 1
        if t == "fim_repetir":
            laco = lacos[-1] if lacos and lacos[-1]["k"] == e["inicio"] else None
            if laco is None:
                return k + 1
            s_rep = itens[laco["k"]][1]
            laco["volta"] += 1
            maximo = int(s_rep.get("maximo") or 1000)
            if laco["volta"] > maximo:
                raise RuntimeError(f"o 'Repetir' do passo {itens[laco['k']][0] + 1} passou de {maximo} voltas "
                                   "(limite de segurança). Confira a condição ou aumente o máximo.")
            if self._continuar_laco(s_rep, laco, itens[laco["k"]][0]):
                return laco["k"] + 1
            lacos.pop()
            self.log(f"Repetição do passo {itens[laco['k']][0] + 1} terminou ({laco['volta'] - 1} volta(s)).")
            return k + 1
        if t == "sair_repeticao":
            alvo = e["laco"]
            while lacos and lacos[-1]["k"] >= alvo:
                lacos.pop()
            self.log(f"Passo {i + 1}: saindo da repetição do passo {itens[alvo][0] + 1}.")
            return est[alvo]["fim"] + 1
        if t == "parar_roteiro":
            msg = self._x(s.get("mensagem")) or "parado pelo roteiro"
            sucesso = (s.get("resultado") or "sucesso") == "sucesso"
            self.log(f"Passo {i + 1}: Parar o roteiro ({'sucesso' if sucesso else 'erro'}): {msg}",
                     "ok" if sucesso else "erro")
            raise fx.PararRoteiro(msg, sucesso)
        if t == "definir_variavel":
            self._definir_variavel(s, i)
            return k + 1
        if t == "executar_roteiro":
            self._executar_sub_roteiro(s, i, cfg, rot, nivel)
            return k + 1
        raise ValueError(f"passo de controle desconhecido: {t}")

    def _continuar_laco(self, s, laco, i):
        """Prepara a volta atual (variáveis) e diz se ela acontece."""
        modo, n = laco["modo"], laco["volta"]
        var = (str(s.get("variavel") or "").strip().strip("{}")) or "volta"
        if modo == "para cada item da lista":
            if n > len(laco["itens"]):
                return False
            self.vars["item"] = laco["itens"][n - 1]
        elif modo == "enquanto (comparar valores)":
            if not fx.comparar(self._x(s.get("valor1")), s.get("operador"), self._x(s.get("valor2"))):
                return False
        elif n > int(float(self._x(s.get("vezes")) or 0)):
            return False
        self.vars[var] = str(n)
        extra = f", {{item}} = {self.vars['item'][:60]!r}" if modo == "para cada item da lista" else ""
        self.log(f"Repetir (passo {i + 1}): volta {n}{extra}")
        return True

    def _definir_variavel(self, s, i):
        nome = (str(s.get("nome") or "").strip().strip("{}")) or "valor"
        op, valor = s.get("operacao") or "definir", self._x(s.get("valor"))
        atual = self.vars.get(nome, self._valores().get(nome, ""))
        if op in ("somar", "subtrair"):
            a, b = fx.numero(atual) or 0.0, fx.numero(valor)
            if b is None:
                raise ValueError(f"'{valor}' não é um número para {op}")
            novo = fx.formatar_numero(a + b if op == "somar" else a - b)
        elif op == "juntar ao texto":
            novo = f"{atual}{valor}"
        elif op.startswith("codificar"):
            novo = urllib.parse.quote(valor, safe="")
        else:
            novo = valor
        self.vars[nome] = novo
        self.log(f"Passo {i + 1}: {{{nome}}} = {novo[:80]!r}")

    def _executar_sub_roteiro(self, s, i, cfg, rot, nivel):
        if nivel >= LIMITE_SUB_ROTEIROS:
            raise RuntimeError(f"roteiros chamando roteiros passaram de {LIMITE_SUB_ROTEIROS} níveis "
                               "(um roteiro chama a si mesmo?)")
        caminho = aw.arq_caminho(self._x(s.get("arquivo")), self.base)
        with open(caminho, encoding="utf-8") as f:
            dados = json.load(f)
        passos = dados.get("passos", dados) if isinstance(dados, dict) else dados
        itens = [(j, p) for j, p in enumerate(passos) if p.get("ativo", True)]
        novos = sorted({p.get("tipo", "?") for _, p in itens if p.get("tipo") not in TIPOS})
        if novos:
            raise RuntimeError(f"o roteiro {os.path.basename(caminho)} usa passo(s) desconhecido(s): {', '.join(novos)}")
        nome = os.path.basename(caminho)
        self.log(f"Passo {i + 1}: executando o roteiro {nome} ({len(itens)} passos)...", "ok")
        self._rodar_passos(passos, itens, cfg, f"{rot}  |  {nome}", 0, max(1, len(itens)), nivel + 1)
        self.log(f"Roteiro {nome} terminou; voltando ao principal.", "ok")

    # ------------------------------------------------------------ condições
    def _avaliar(self, s, cfg):
        t = s["tipo"]
        if t == "se_valor":
            return fx.comparar(self._x(s.get("valor1")), s.get("operador"), self._x(s.get("valor2")))
        espera = max(0.0, float(s.get("espera") or 0))
        if t == "se_arquivo":
            r = self._esperar_ate(lambda: bool(aw.arq_encontrar(self._x(s.get("padrao")), self.base)), espera)
        elif t == "se_janela":
            texto = self._x(s.get("titulo")).casefold()
            r = self._esperar_ate(lambda: any(texto in tit.casefold() for tit in jc.titulos_janelas()), espera)
        elif t == "se_texto_tela":
            texto = self._x(s.get("texto"))
            regiao = "janela" if str(s.get("regiao", "janela")).startswith("janela") else None
            r = self._esperar_ate(lambda: ocr.achar(texto, regiao, s.get("idioma") or "pt-BR") is not None,
                                  max(espera, 0.1))
        elif t == "se_pagina":
            r = self._esperar_ate(lambda: self._pagina_tem(self._x(s.get("texto")), self._x(s.get("seletor"))),
                                  espera)
        elif t == "se_imagem":
            imagem = self.caminho(s.get("imagem"))
            if not imagem or not os.path.exists(imagem):
                raise FileNotFoundError(f"imagem da condição não encontrada: {s.get('imagem')}")
            teste = {"tipo": "esperar_imagem", "imagem": s.get("imagem"), "confianca": s.get("confianca", 0.85),
                     "timeout": max(0.5, espera)}
            try:
                self.executar_passo(teste, cfg)
                r = True
            except (Parado, pyautogui.FailSafeException):
                raise
            except Exception:
                r = False
        else:
            raise ValueError(f"condição desconhecida: {t}")
        return (not r) if s.get("negar") else r

    # ------------------------------------------------------------ pausa para a pessoa
    def _aguardar_usuario(self, s):
        msg = self._x(s.get("mensagem")).strip() or "Faça o que precisa e clique em Continuar."
        modo = s.get("continuar") or "eu"
        texto, seletor = self._x(s.get("texto")).strip(), self._x(s.get("seletor")).strip()
        espera = float(s.get("timeout") or 0)
        limite = time.time() + espera if espera > 0 else None
        self.log(f"Esperando você: {msg}")
        self.pausado = True
        self.ui.aguardar_usuario(msg)
        try:
            while self.pausado:
                pronto = False
                try:
                    if modo.startswith("aparecer na página") and (texto or seletor):
                        pronto = self._pagina_tem(texto, seletor)
                    elif modo.startswith("aparecer na tela") and texto:
                        pronto = ocr.achar(texto, None) is not None
                except (Parado, pyautogui.FailSafeException):
                    raise
                except Exception:
                    pronto = False
                if pronto:
                    self.log("Apareceu o que o robô esperava: continuando.", "ok")
                    break
                if limite and time.time() >= limite:
                    if s.get("se_acabar", "dar erro") == "dar erro":
                        raise RuntimeError(f"o tempo de espera ({espera:.0f} s) acabou: {msg[:80]}")
                    self.log("O tempo de espera acabou; seguindo.")
                    break
                self._esperar(1.5)
            else:
                self.log("Continuando (você clicou em Continuar).")
        finally:
            self.pausado = False
            self.ui.fim_aguardar()

    def _esperar_ate(self, teste, segundos):
        limite = time.time() + segundos
        while True:
            try:
                if teste():
                    return True
            except (Parado, pyautogui.FailSafeException):
                raise
            except Exception:
                pass
            if time.time() >= limite:
                return False
            self._esperar(0.4)

    def _pagina_tem(self, texto, seletor):
        expr = (r"""((sel, txt) => { const el = sel ? document.querySelector(sel) : document.body;
                  if (!el) return JSON.stringify({ok: false});
                  const v = (el.innerText || el.textContent || el.value || '').toLowerCase();
                  return JSON.stringify({ok: !txt || v.includes(txt.toLowerCase())}); })"""
                + f"({json.dumps(seletor)}, {json.dumps(texto)})")
        return bool((self._js(expr) or {}).get("ok"))
