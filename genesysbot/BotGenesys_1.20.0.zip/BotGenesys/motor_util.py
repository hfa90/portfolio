# -*- coding: utf-8 -*-
"""
Utilidades do motor do Bot Genesys: imports, constantes, procurar imagem na tela, variáveis {...},
teclas, criptografia de senhas e a interface UiBase (quem mostra o andamento)."""
import base64
import ctypes
import datetime
import json
import os
import sys
import threading
import time

WIN = sys.platform == "win32"

import pyautogui
from PIL import Image, ImageChops, ImageGrab

try:
    import janelas as jc
    import navegador as nav
    import excel as xlm
    import passos as cat
    import excel_tela as xt
    import janelas_uia as uia
    import ocr_tela as ocr
except ImportError:  # arquivo exportado: tudo está neste mesmo arquivo
    jc = nav = xlm = cat = xt = uia = ocr = sys.modules[__name__]

try:
    from pynput import keyboard as _pkb
    KB = _pkb.Controller()
except Exception:
    KB = None

try:
    import cv2
    import numpy as np
    HAS_CV = True
except Exception:
    HAS_CV = False

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0
ImageNotFound = getattr(pyautogui, "ImageNotFoundException", Exception)

# Tipos de passo: definidos no catálogo (passos.py)
TIPOS = cat.TIPOS
RETENTAVEIS = cat.RETENTAVEIS
PRECISA_TELA = cat.PRECISA_TELA
NAVEGADORES = cat.NAVEGADORES
outro_programa = cat.outro_programa
pixels_rolagem = cat.pixels_rolagem
resumo = cat.resumo
BTN_MAP = {"esquerdo": "left", "direito": "right", "meio": "middle"}
ALIASES = {
    "control": "ctrl", "espaco": "space", "espaço": "space", "cima": "up",
    "baixo": "down", "esquerda": "left", "direita": "right", "apagar": "backspace",
    "del": "delete", "return": "enter", "windows": "win", "escape": "esc",
}
CFG_PADRAO = {"visual": True, "vel": 1.0, "pausa": 0.5, "rep": 1, "contagem": 3, "tent": 2, "so_um": False,
              "max_chrome": True, "segundo_plano": False,
              # planilha como lista de chamados
              "planilha_arquivo": None, "planilha_aba": None, "coluna_status": "Status",
              "escrever_resultado": True, "pular_ok": True, "continuar_erro": False}


class Parado(Exception):
    pass


# --------------------------------------------------------------------------- #
# Utilidades
# --------------------------------------------------------------------------- #
class Achado:
    def __init__(self, left, top, width, height, score=1.0, segunda=0.0):
        self.left, self.top, self.width, self.height, self.score = left, top, width, height, score
        self.segunda = segunda  # nota do 2º lugar mais parecido (se for quase igual, a imagem não é única)

    @property
    def unico(self):
        return self.score - self.segunda >= 0.06


def melhor_correspondencia(caminho, regiao=None, tela=None):
    """Procura a imagem na tela (ou numa região, ou numa imagem dada) e devolve a MELHOR correspondência."""
    if tela is None:
        tela = pyautogui.screenshot(region=regiao) if regiao else pyautogui.screenshot()
        ox, oy = (regiao[0], regiao[1]) if regiao else (0, 0)
    else:
        ox = oy = 0
    agulha = Image.open(caminho).convert("RGB")
    if agulha.width > tela.width or agulha.height > tela.height:
        return None
    if HAS_CV:
        hay_rgb, nee_rgb = np.array(tela.convert("RGB")), np.array(agulha)
        hay = cv2.cvtColor(hay_rgb, cv2.COLOR_RGB2GRAY)
        nee = cv2.cvtColor(nee_rgb, cv2.COLOR_RGB2GRAY)
        mapa = cv2.matchTemplate(hay, nee, cv2.TM_CCOEFF_NORMED)
        w, h = agulha.width, agulha.height
        for _ in range(8):  # melhores candidatos, conferindo também a COR (forma igual com cor diferente não vale)
            _, nota, _, (x, y) = cv2.minMaxLoc(mapa)
            if nota < 0.5:
                break
            dif = np.abs(hay_rgb[y:y + h, x:x + w].astype(np.int16) - nee_rgb.astype(np.int16)).mean()
            if dif <= 45:
                resto = mapa.copy()
                resto[max(0, y - h // 2):y + h // 2 + 1, max(0, x - w // 2):x + w // 2 + 1] = -1
                segunda = float(cv2.minMaxLoc(resto)[1])
                return Achado(x + ox, y + oy, w, h, float(nota), segunda)
            mapa[max(0, y - h // 2):y + h // 2 + 1, max(0, x - w // 2):x + w // 2 + 1] = -1
        return None
    try:
        box = pyautogui.locate(agulha, tela)
    except Exception:
        box = None
    return Achado(box.left + ox, box.top + oy, box.width, box.height) if box else None


def deslocamento_vertical(antes, depois):
    """Quanto o conteúdo deslizou entre duas imagens (cinza, float32). Retorna (dx, dy, confiança)."""
    janela = cv2.createHanningWindow((antes.shape[1], antes.shape[0]), cv2.CV_32F)
    (dx, dy), resp = cv2.phaseCorrelate(antes, depois, janela)
    return dx, dy, resp


def expandir(texto, dados=None):
    for chave, valor in (dados or {}).items():
        texto = texto.replace("{" + chave + "}", "" if valor is None else str(valor))
    agora = datetime.datetime.now()
    texto = (texto.replace("{data_arquivo}", agora.strftime("%Y-%m-%d"))
                  .replace("{hora_arquivo}", agora.strftime("%H-%M")))
    return (texto.replace("{datahora}", agora.strftime("%d/%m/%Y %H:%M"))
                 .replace("{data}", agora.strftime("%d/%m/%Y"))
                 .replace("{hora}", agora.strftime("%H:%M")))


def parse_teclas(texto):
    partes = [ALIASES.get(p.strip().lower(), p.strip().lower()) for p in texto.split("+") if p.strip()]
    if not partes:
        raise ValueError("Informe uma tecla.")
    for p in partes:
        if p not in pyautogui.KEYBOARD_KEYS:
            raise ValueError(f"Tecla desconhecida: '{p}'")
    return partes


if WIN:
    from ctypes import wintypes as _wt

    class _CURSORINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("flags", ctypes.c_uint),
                    ("hCursor", ctypes.c_void_p), ("pt", _wt.POINT)]

    ctypes.windll.user32.LoadCursorW.restype = ctypes.c_void_p
    _CURSORES_OCUPADO = {ctypes.windll.user32.LoadCursorW(None, 32514),   # ampulheta
                         ctypes.windll.user32.LoadCursorW(None, 32650)}   # seta + ampulheta


def cursor_ocupado():
    if not WIN:
        return False
    try:
        ci = _CURSORINFO()
        ci.cbSize = ctypes.sizeof(ci)
        ctypes.windll.user32.GetCursorInfo(ctypes.byref(ci))
        return ci.hCursor in _CURSORES_OCUPADO
    except Exception:
        return False


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(dados, proteger):
    """Criptografia do próprio Windows (DPAPI): só o seu usuário, neste computador, consegue abrir."""
    entrada = _BLOB(len(dados), ctypes.cast(ctypes.create_string_buffer(dados, len(dados)),
                                            ctypes.POINTER(ctypes.c_char)))
    saida = _BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if proteger else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(entrada), None, None, None, None, 0x1, ctypes.byref(saida)):
        raise OSError("falha na criptografia do Windows")
    try:
        return ctypes.string_at(saida.pbData, saida.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(saida.pbData)


def proteger_texto(texto):
    if WIN:
        return "dpapi:" + base64.b64encode(_dpapi(texto.encode("utf-8"), True)).decode()
    return "b64:" + base64.b64encode(texto.encode("utf-8")).decode()


def abrir_texto(guardado):
    tipo, _, conteudo = guardado.partition(":")
    bruto = base64.b64decode(conteudo)
    return (_dpapi(bruto, False) if tipo == "dpapi" else bruto).decode("utf-8")


# --------------------------------------------------------------------------- #
# Interface com quem mostra o andamento (app, painel do arquivo exportado...)
# --------------------------------------------------------------------------- #
class UiBase:
    """Tudo aqui pode ser chamado de outra thread; quem implementa cuida de repassar para a tela."""

    def log(self, msg, tag=None):
        print(f"[{datetime.datetime.now():%H:%M:%S}] {msg}", flush=True)

    def status(self, texto, cor=None):
        pass

    def progresso(self, feito, total, texto=None):
        pass

    def destacar(self, i):
        pass

    def marcador(self, x, y, w=0, h=0, cor="#ff1744", ms=700):
        pass

    def desviar(self, x, y):
        """O bot vai usar o mouse em (x, y): tirar da frente o que for do próprio bot (a caixinha de status)."""
        pass

    def aguardar_usuario(self, msg):
        """O robô pausou esperando a pessoa (passo 'Pausar: esperar você')."""
        print(f"[{datetime.datetime.now():%H:%M:%S}] >>> ESPERANDO VOCÊ: {msg}", flush=True)

    def fim_aguardar(self):
        pass

    def detalhe(self, titulo, texto):
        """Caminho técnico de um erro (traceback): o app grava no log do dia."""
        pass

# O que as partes do motor importam daqui
__all__ = ['xt', 'uia', 'ocr', 'ALIASES', 'Achado', 'BTN_MAP', 'CFG_PADRAO', 'HAS_CV', 'Image',
           'ImageChops', 'ImageGrab', 'ImageNotFound', 'KB', 'NAVEGADORES', 'PRECISA_TELA',
           'Parado', 'RETENTAVEIS', 'TIPOS', 'UiBase', 'WIN', '_BLOB',
           '_CURSORES_OCUPADO', '_dpapi', '_pkb', '_wt', 'abrir_texto', 'base64',
           'cat', 'ctypes', 'cursor_ocupado', 'cv2', 'datetime', 'deslocamento_vertical',
           'expandir', 'jc', 'json', 'melhor_correspondencia', 'nav', 'np',
           'os', 'outro_programa', 'parse_teclas', 'pixels_rolagem', 'proteger_texto', 'pyautogui',
           'resumo', 'sys', 'threading', 'time', 'xlm']
