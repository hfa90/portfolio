# -*- coding: utf-8 -*-
"""Passos de E-MAIL e NOTIFICAÇÃO. Não usam mouse nem teclado: funcionam igual na tela e em segundo plano.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import datetime
import os
import sys

try:
    import mensagens as mg
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    mg = sys.modules[__name__]


class MensagensMixin:

    def _passo_mensagens(self, s, cfg):
        t = s["tipo"]
        if t == "email_enviar":
            return self._email_enviar(s)
        if t == "email_esperar":
            return self._email_esperar(s)
        if t == "notificar":
            return self._notificar(s)
        raise ValueError(f"passo de mensagem desconhecido: {t}")

    def _caminho_base(self, c):
        c = os.path.expandvars(os.path.expanduser(c))
        return c if not c or os.path.isabs(c) else os.path.join(self.base, c)

    # ------------------------------------------------------------ enviar
    def _email_enviar(self, s):
        x = self._x
        para, cc, cco = mg.enderecos(x(s.get("para"))), mg.enderecos(x(s.get("cc"))), mg.enderecos(x(s.get("cco")))
        assunto, corpo = x(s.get("assunto")), x(s.get("corpo"))
        anexos = mg.arquivos_anexos(x(s.get("anexos")), self.base)
        destino = ", ".join(para + cc + cco) or "(sem destinatário)"
        if str(s.get("via", "")).startswith("SMTP"):
            senha = s.get("smtp_senha") or ""
            mg.enviar_smtp(x(s.get("smtp_servidor")).strip(), s.get("smtp_porta") or 587, x(s.get("smtp_usuario")).strip(),
                           senha, para, assunto, corpo, cc, cco, anexos, bool(s.get("html")),
                           s.get("smtp_seguranca") or mg.SEGURANCAS[0])
            self.log(f"E-mail enviado por SMTP para {destino}: \"{assunto}\""
                     + (f" ({len(anexos)} anexo(s))" if anexos else ""), "ok")
        else:
            acao = mg.enviar_outlook(para, assunto, corpo, cc, cco, anexos, bool(s.get("html")),
                                     s.get("acao") or mg.ACOES_OUTLOOK[0], x(s.get("conta")).strip())
            feito = {"enviar": "enviado", "abrir para eu revisar": "aberto para revisão",
                     "salvar como rascunho": "salvo nos Rascunhos"}.get(acao, acao)
            self.log(f"E-mail {feito} pelo Outlook para {destino}: \"{assunto}\""
                     + (f" ({len(anexos)} anexo(s))" if anexos else ""), "ok")

    # ------------------------------------------------------------ esperar / ler
    def _email_esperar(self, s):
        x = self._x
        pre = (str(s.get("variavel") or "").strip().strip("{}")) or "email"
        quais = s.get("quais") or mg.QUAIS[0]
        desde = datetime.datetime.now().replace(microsecond=0) - datetime.timedelta(seconds=5)
        filtros = dict(pasta=x(s.get("pasta")), remetente=x(s.get("remetente")), assunto=x(s.get("assunto")),
                       contem=x(s.get("contem")), com_anexo=bool(s.get("com_anexo")), quais=quais, desde=desde)
        app = mg._outlook()
        espera = float(s.get("timeout") or 0)
        partes = [f"de {filtros['remetente']}" if filtros["remetente"] else "",
                  f"assunto \"{filtros['assunto']}\"" if filtros["assunto"] else ""]
        self.log(f"Procurando e-mail no Outlook {' '.join(p for p in partes if p)} "
                 f"({quais}{f', até {espera:.0f} s' if espera else ''})...")
        item = mg.esperar(lambda: mg.procurar_outlook(app=app, **filtros), espera, dormir=self._esperar)
        nomes = ("assunto", "remetente", "remetente_nome", "corpo", "data", "qtd_anexos", "anexos")
        if item is None:
            if str(s.get("se_nao_achar", "")).startswith("seguir"):
                for n in nomes:
                    self.vars[f"{pre}_{n}"] = ""
                self.log("Nenhum e-mail encontrado; seguindo com as variáveis vazias.")
                return
            raise RuntimeError("nenhum e-mail encontrado com esses filtros"
                               + (f" em {espera:.0f} s" if espera else ""))
        dados = mg.dados_do_email(item)
        salvos = []
        if s.get("salvar_anexos"):
            salvos = mg.salvar_anexos(item, self._caminho_base(x(s.get("salvar_anexos"))), x(s.get("filtro_anexos")))
        dados["anexos"] = ";".join(salvos)
        for n in nomes:
            self.vars[f"{pre}_{n}"] = dados.get(n, "")
        if s.get("marcar_lido", True):
            try:
                item.UnRead = False
                item.Save()
            except Exception:
                pass
        if s.get("mover_para"):
            mg.mover_outlook(item, app, x(s.get("mover_para")))
        self.log(f"E-mail de {dados['remetente_nome'] or dados['remetente']} ({dados['data']}): "
                 f"\"{dados['assunto'][:60]}\"" + (f" — {len(salvos)} anexo(s) salvo(s)" if salvos else ""), "ok")

    # ------------------------------------------------------------ notificar
    def _notificar(self, s):
        canal = s.get("canal") or mg.CANAIS[0]
        titulo, msg = self._x(s.get("titulo")), self._x(s.get("mensagem"))
        try:
            mg.notificar(canal, titulo, msg, (s.get("chave") or "").strip(), self._x(s.get("chat_id")).strip())
            self.log(f"Notificação enviada ({canal}).", "ok")
        except Exception as e:
            if s.get("falhar"):
                raise
            self.log(f"Aviso: a notificação ({canal}) não foi enviada: {e}", "erro")
            self.avisos += 1
