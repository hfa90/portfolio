# -*- coding: utf-8 -*-
"""
Exporta um roteiro do Bot Genesys para UM arquivo Python que roda sozinho, com:
  - o mesmo motor de execução do app (modo na tela e em segundo plano, correção por elemento/imagem,
    espera de carregamento, rolagem exata, senha criptografada, tentativas, planilha CSV, logs);
  - os passos gravados, legíveis e editáveis;
  - as imagens de referência embutidas no próprio arquivo.
"""
import base64
import datetime
import json
import os
import pprint

PASTA = os.path.dirname(os.path.abspath(__file__))
MODULOS = ["janelas.py", "navegador.py", "formulas_excel.py", "excel.py", "excel_tela.py", "janelas_uia.py", "ocr_tela.py",
           "passos.py",
           "arquivos_win.py", "motor_util.py", "motor_dados.py", "motor_tela.py", "motor_fundo.py",
           "motor_arquivos.py", "mensagens.py", "motor_mensagens.py", "ia.py", "motor_ia.py", "motor_vigias.py", "fluxo.py", "motor_fluxo.py", "motor.py", "painel.py"]
ORDEM_CHAVES = ["tipo", "descricao", "ativo", "url", "x", "y", "botao", "cliques", "texto", "texto_protegido",
                "senha", "limpar", "enter", "teclas", "repetir", "segundos", "metodo", "seletor", "estavel",
                "timeout", "pixels", "alvo_y", "imagem", "confianca", "offset_x", "offset_y", "conferir",
                "ref_x", "ref_y", "aguardar", "maximizar", "controle", "espera", "origem", "alvo", "vp"]

CABECALHO = '''# -*- coding: utf-8 -*-
"""
{titulo}
Exportado pelo {programa} em {data} — {n} passos.

COMO USAR
  1) Instale as dependências (uma vez):
         pip install pyautogui pynput pillow opencv-python websocket-client openpyxl pywin32
  2) Rode:
         python {arquivo}                      (na tela, como foi configurado)
         python {arquivo} --segundo-plano      (sem usar seu mouse/teclado; precisa do Chrome controlado)
         python {arquivo} --na-tela            (força usar o mouse e o teclado de verdade)
         python {arquivo} --rapido             (sem animações)
         python {arquivo} --planilha chamados.xlsx [--aba Dados]   (um chamado por linha; {{Coluna}} nos textos)
         python {arquivo} --repeticoes 3 --velocidade 1.5 --sem-painel
     Na tela: ESC para parar, F2 pausa. Em segundo plano: botões Pausar/Parar no cartão do canto da tela.

ONDE MEXER
  - CONFIG: opções de execução.
  - PASSOS: a lista do que o bot faz, na ordem. Cada passo tem todos os detalhes gravados.
  - Imagens de referência ficam embutidas no fim do arquivo (IMAGENS) e são extraídas para
    "{pasta_dados}" ao rodar; os logs e prints de erro também ficam lá.
{aviso_senha}"""
'''

AVISO_SENHA = '''
SENHAS
  Os passos marcados como senha estão criptografados com a proteção do Windows (DPAPI): só funcionam
  no mesmo usuário do Windows e no mesmo computador onde o roteiro foi gravado.
'''

PRINCIPAL = r'''

# =============================================================================================== #
#  EXECUÇÃO
# =============================================================================================== #
def _pasta_dados():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), NOME + "_arquivos")


def _extrair_imagens(pasta):
    os.makedirs(os.path.join(pasta, "imagens"), exist_ok=True)
    for nome, dados in IMAGENS.items():
        destino = os.path.join(pasta, "imagens", nome)
        if not os.path.exists(destino):
            with open(destino, "wb") as f:
                f.write(base64.b64decode(dados))


def _preparar(passos):
    prontos = []
    for p in passos:
        p = dict(p)
        if p.get("texto_protegido"):
            p["texto"] = abrir_texto(p.pop("texto_protegido"))
        abrir_segredos(p, abrir_texto)
        prontos.append(p)
    return prontos




class UiScript(UiBase):
    """Mostra o andamento no terminal, no arquivo de log e no painel da tela."""

    def __init__(self, fila, arquivo_log):
        self.fila, self.arquivo_log = fila, arquivo_log

    def log(self, msg, tag=None):
        linha = f"[{datetime.datetime.now():%H:%M:%S}] {msg}"
        print(linha, flush=True)
        try:
            with open(self.arquivo_log, "a", encoding="utf-8") as f:
                f.write(linha + "\n")
        except OSError:
            pass

    def detalhe(self, titulo, texto):
        try:
            with open(self.arquivo_log, "a", encoding="utf-8") as f:
                f.write(f"DETALHE TÉCNICO — {titulo}:\n{texto}\n")
        except OSError:
            pass

    def status(self, texto, cor=None):
        if self.fila:
            self.fila.put(("texto", texto, cor))

    def progresso(self, feito, total, texto=None):
        if self.fila:
            self.fila.put(("progresso", 0 if not total else feito / total))

    def marcador(self, x, y, w=0, h=0, cor="#ff1744", ms=700):
        if self.fila:
            self.fila.put(("marcador", x, y, w, h, cor, ms))


def executar(passos=None, config=None, dados=None, painel=True):
    import queue
    import tkinter as tk
    cfg = dict(CONFIG, **(config or {}))
    pasta = _pasta_dados()
    _extrair_imagens(pasta)
    os.makedirs(os.path.join(pasta, "logs"), exist_ok=True)
    arquivo_log = os.path.join(pasta, "logs", f"execucao_{datetime.date.today():%Y%m%d}.log")
    fila = queue.Queue() if painel else None
    motor = Motor(ui=UiScript(fila, arquivo_log), base=pasta, perfil_chrome=PERFIL_CHROME,
                  log_dir=os.path.join(pasta, "logs"))
    passos = _preparar(passos or PASSOS)
    resultado = {}

    # atalhos (só no modo na tela): ESC para, F2 pausa
    if not cfg.get("segundo_plano"):
        try:
            from pynput import keyboard

            def tecla(k, *_):
                if motor.sending:
                    return
                if k == keyboard.Key.esc:
                    motor.parar()
                elif k == keyboard.Key.f2:
                    motor.pausado = not motor.pausado
                    if fila:
                        fila.put(("pausa", motor.pausado))
            ouvinte = keyboard.Listener(on_press=tecla)
            ouvinte.daemon = True
            ouvinte.start()
        except Exception:
            pass

    def trabalhar():
        resultado["codigo"], resultado["erro"] = motor.rodar(passos, cfg=cfg, dados=dados)
        if fila:
            fila.put(("fim",))

    if not painel:
        trabalhar()
    else:
        root = tk.Tk()
        root.withdraw()
        p = Painel(root)

        def pausar():
            motor.pausado = not motor.pausado
            p.pausado(motor.pausado)

        fundo = bool(cfg.get("segundo_plano"))
        p.mostrar("fundo" if fundo else "frente", NOME.upper()[:40],
                  "você pode continuar usando o computador" if fundo else "ESC = parar     F2 = pausar",
                  ao_pausar=pausar, ao_parar=motor.parar)

        def ver_log():
            if sys.platform == "win32":
                os.startfile(arquivo_log)

        def tique():
            try:
                while True:
                    m = fila.get_nowait()
                    if m[0] == "texto":
                        p.texto(m[1], m[2])
                    elif m[0] == "progresso":
                        p.progresso(m[1])
                    elif m[0] == "marcador":
                        p.marcador(*m[1:])
                    elif m[0] == "pausa":
                        p.pausado(m[1])
                    elif m[0] == "fim":
                        cod = resultado.get("codigo", 1)
                        res = {0: "aviso" if motor.avisos else "ok", 2: "parado"}.get(cod, "erro")
                        msg = {"ok": f"{NOME}: todos os passos executados.", "parado": f"{NOME}: interrompido.",
                               "aviso": f"{NOME}: concluído com {motor.avisos} aviso(s) — veja o log.",
                               "erro": f"{NOME}: {resultado.get('erro')}"}[res]
                        p.final(res, msg, ao_ver_log=ver_log, fechar_em=8000 if res == "ok" else 30000)
                        root.after(8500 if res == "ok" else 30500, root.destroy)
                        return
            except queue.Empty:
                pass
            root.after(80, tique)

        threading.Thread(target=trabalhar, daemon=True).start()
        root.after(80, tique)
        root.mainloop()
    return resultado.get("codigo", 1)


def main():
    import argparse
    ap = argparse.ArgumentParser(description=f"Executa o bot '{NOME}'.")
    ap.add_argument("--segundo-plano", action="store_true", help="não usa o mouse/teclado (Chrome controlado)")
    ap.add_argument("--na-tela", action="store_true", help="usa o mouse e o teclado de verdade")
    ap.add_argument("--rapido", action="store_true", help="sem animações")
    ap.add_argument("--velocidade", type=float, help="0.25 a 3 (modo visual)")
    ap.add_argument("--repeticoes", type=int)
    ap.add_argument("--planilha", "--csv", dest="planilha", help="planilha Excel/CSV: um chamado por linha")
    ap.add_argument("--aba", help="aba da planilha")
    ap.add_argument("--sem-painel", action="store_true", help="sem cartão na tela (só terminal e log)")
    a = ap.parse_args()
    cfg = {}
    if a.segundo_plano:
        cfg["segundo_plano"] = True
    if a.na_tela:
        cfg["segundo_plano"] = False
    if a.rapido:
        cfg["visual"] = False
    if a.velocidade:
        cfg["vel"] = a.velocidade
    if a.repeticoes:
        cfg["rep"] = a.repeticoes
    planilha = a.planilha or (PLANILHA if PLANILHA and os.path.exists(PLANILHA) else None)
    dados = None
    if planilha:
        cfg["planilha_arquivo"] = os.path.abspath(planilha)
        if a.aba:
            cfg["planilha_aba"] = a.aba
        dados = ler_planilha(planilha, cfg.get("planilha_aba") or CONFIG.get("planilha_aba"))
    sys.exit(executar(config=cfg, dados=dados, painel=not a.sem_painel))
'''


def _ler_modulo(nome):
    with open(os.path.join(PASTA, nome), encoding="utf-8") as f:
        linhas = f.read().splitlines()
    if linhas and linhas[0].startswith("# -*- coding"):
        linhas = linhas[1:]
    return "\n".join(linhas).strip("\n")


def _valor(v, recuo=9):
    if isinstance(v, (dict, list)):
        txt = repr(v)
        if len(txt) <= 100:
            return txt
        return pprint.pformat(v, width=100, sort_dicts=False).replace("\n", "\n" + " " * (recuo + 1))
    return repr(v)


def _formatar_passo(i, p, tipos):
    from motor import resumo
    comentario = f"    # {i}. {tipos.get(p['tipo'], p['tipo'])} — {resumo(p)}".replace("\n", " ")
    chaves = [k for k in ORDEM_CHAVES if k in p] + [k for k in p if k not in ORDEM_CHAVES]
    itens = [(k, p[k]) for k in chaves if not k.startswith("_")]
    if all(k.isidentifier() for k, _ in itens):
        partes = [f"{k}={_valor(v, 9 + len(k))}" for k, v in itens]
        linhas, atual = [], "    dict("
        for parte in partes:
            if len(atual) + len(parte) + 2 > 112 and atual.strip() != "dict(":
                linhas.append(atual.rstrip() + ",")
                atual = "         "
            elif not atual.endswith("(") and atual.strip():
                atual += ", "
            atual += parte
        linhas.append(atual + "),")
        return comentario + "\n" + "\n".join(linhas)
    return comentario + "\n    " + _valor(dict(itens)) + ","


def exportar(passos, cfg, destino, base, perfil=None, planilha=None):
    """Gera o arquivo. Devolve um resumo {'passos', 'imagens', 'tamanho'}."""
    from motor import TIPOS, proteger_texto
    from passos import guardar_segredos
    nome = os.path.splitext(os.path.basename(destino))[0]
    imagens, saida = {}, []
    for p in passos:
        p = {k: v for k, v in p.items() if not k.startswith("_")}
        if p.get("tipo") == "digitar" and p.get("senha") and p.get("texto"):
            p["texto_protegido"] = proteger_texto(p.pop("texto"))
        p = guardar_segredos(p, proteger_texto)
        if p.get("imagem"):
            origem = p["imagem"] if os.path.isabs(p["imagem"]) else os.path.join(base, p["imagem"])
            if os.path.exists(origem):
                chave = os.path.basename(origem)
                if chave in imagens and imagens[chave][0] != origem:
                    chave = f"{len(imagens)}_{chave}"
                with open(origem, "rb") as f:
                    imagens[chave] = (origem, base64.b64encode(f.read()).decode())
                p["imagem"] = "imagens/" + chave
        saida.append(p)

    cfg = {k: cfg[k] for k in ("visual", "vel", "pausa", "rep", "contagem", "tent", "max_chrome", "segundo_plano",
                               "planilha_aba", "coluna_status", "escrever_resultado", "pular_ok", "continuar_erro")
           if k in cfg}
    tem_senha = any(k.endswith("_protegido") for p in saida for k in p)
    from versao import NOME as PROGRAMA, VERSAO
    partes = [CABECALHO.format(titulo=f"Bot: {nome}", programa=f"{PROGRAMA} v{VERSAO}", data=f"{datetime.datetime.now():%d/%m/%Y %H:%M}",
                               n=len(saida), arquivo=os.path.basename(destino), pasta_dados=nome + "_arquivos",
                               aviso_senha=AVISO_SENHA if tem_senha else "")]
    partes.append("import sys\n\nif sys.platform == \"win32\":  # usa os pixels reais da tela (escala 125%/150%)\n"
                  "    import ctypes as _ct\n    try:\n        _ct.windll.shcore.SetProcessDpiAwareness(2)\n"
                  "    except Exception:\n        try:\n            _ct.windll.user32.SetProcessDPIAware()\n"
                  "        except Exception:\n            pass\n")
    for m in MODULOS:
        partes.append(f"\n# {'=' * 95} #\n#  Biblioteca interna: {m} (igual à do app)\n# {'=' * 95} #\n")
        partes.append(_ler_modulo(m))
    partes.append(f"\n\n# {'=' * 95} #\n#  ROTEIRO\n# {'=' * 95} #\n")
    partes.append(f"NOME = {nome!r}\n")
    partes.append(f"PERFIL_CHROME = {os.path.abspath(perfil)!r}  # perfil do Chrome controlado (login salvo)\n"
                  if perfil else "PERFIL_CHROME = None\n")
    partes.append(f"PLANILHA = {os.path.abspath(planilha)!r}  # planilha padrão (ou use --csv)\n"
                  if planilha else "PLANILHA = None  # use --planilha chamados.xlsx para vários chamados\n")
    partes.append("CONFIG = " + pprint.pformat(cfg, sort_dicts=False) + "\n")
    partes.append("\nPASSOS = [\n" + "\n".join(_formatar_passo(i + 1, p, TIPOS) for i, p in enumerate(saida))
                  + "\n]\n")
    partes.append(PRINCIPAL)
    partes.append(f"\n\n# {'=' * 95} #\n#  IMAGENS DE REFERÊNCIA (embutidas, em base64)\n# {'=' * 95} #\n")
    partes.append("IMAGENS = {\n" + "".join(f"    {k!r}: {v[1]!r},\n" for k, v in imagens.items()) + "}\n")
    partes.append("\n\nif __name__ == \"__main__\":\n    main()\n")
    codigo = "\n".join(partes)
    compile(codigo, destino, "exec")  # garante que o arquivo gerado é Python válido
    with open(destino, "w", encoding="utf-8") as f:
        f.write(codigo)
    return {"passos": len(saida), "imagens": len(imagens), "tamanho": len(codigo.encode("utf-8"))}


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("uso: python exportar.py roteiro.json destino.py")
        sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        dados = json.load(f)
    cfg = dados.get("config", {})
    cfg = {"visual": cfg.get("visual", True), "vel": float(cfg.get("velocidade", 1.0)),
           "pausa": float(cfg.get("pausa", 0.5)), "rep": int(cfg.get("repeticoes", 1)),
           "contagem": int(cfg.get("contagem", 3)), "tent": int(cfg.get("tentativas", 2)),
           "max_chrome": cfg.get("maximizar_chrome", True), "segundo_plano": cfg.get("segundo_plano", False)}
    base = os.path.dirname(os.path.abspath(sys.argv[1]))
    print(exportar(dados["passos"], cfg, sys.argv[2], base, os.path.join(base, "chrome_perfil_bot")))
