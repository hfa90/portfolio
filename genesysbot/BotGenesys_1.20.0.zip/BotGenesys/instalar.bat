@echo off
title Bot Genesys - instalador
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\instalar.ps1" %*
if errorlevel 1 pause
