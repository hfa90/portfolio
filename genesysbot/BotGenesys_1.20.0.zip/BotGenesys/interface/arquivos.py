# -*- coding: utf-8 -*-
"""Arquivos: planilha da execução e abrir/salvar/exportar roteiros.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import diario
from interface.comum import (APP_DIR, LOG_DIR, NOME, TIPOS_PLANILHA, VERSAO, WIN, abrir_texto, agm, cat, datetime,
                             caminho_abs, caminho_rel, filedialog, json, messagebox, os, pixels_rolagem,
                             proteger_texto, xlm)


class ArquivosMixin:

    # --------------------------------------------------------- planilha CSV --
    def escolher_csv(self):
        p = filedialog.askopenfilename(initialdir=APP_DIR, filetypes=TIPOS_PLANILHA)
        if p:
            self._carregar_csv(p)
            self.dirty = True
            self._titulo()

    def _carregar_csv(self, p, aba=None):
        """Carrega a lista de chamados de uma planilha Excel (.xlsx/.xlsm) ou CSV."""
        try:
            nomes = xlm.abas(p)
            if nomes and aba not in nomes:
                aba = nomes[0]
            linhas = xlm.ler_planilha(p, aba)
        except Exception as e:
            messagebox.showerror("Planilha", f"Não foi possível ler a planilha:\n{e}")
            return
        if not linhas:
            messagebox.showerror("Planilha", "A planilha não tem linhas de dados (a 1ª linha deve ter os nomes "
                                             "das colunas).")
            return
        self.dados, self.dados_arquivo = linhas, p
        self.cb_aba.config(values=nomes, state="readonly" if nomes else "disabled")
        self.v_aba.set(aba or "")
        cols = [c for c in linhas[0].keys() if not c.startswith("_")]
        col = self.v_col_status.get().strip() or "Status"
        ok = sum(1 for l in linhas if str(l.get(col, "")).upper().startswith("OK"))
        txt_cols = ", ".join("{" + c + "}" for c in cols)
        self.lbl_csv.config(text=f"{os.path.basename(p)}{' [' + aba + ']' if aba else ''}  ·  {len(linhas)} linhas"
                                 f"{f' ({ok} já OK)' if ok else ''}\nUse nos textos: {txt_cols[:160]}",
                            bootstyle="success")
        self.log(f"Planilha carregada: {len(linhas)} linhas{' da aba ' + aba if aba else ''}. Colunas: {txt_cols}")

    def remover_csv(self):
        self.dados = self.dados_arquivo = None
        self.cb_aba.config(values=[], state="disabled")
        self.v_aba.set("")
        self.lbl_csv.config(text="Nenhuma planilha: o roteiro roda pelo nº de repetições.", bootstyle="secondary")
        self.dirty = True
        self._titulo()

    def _abrir_logs(self):
        os.makedirs(LOG_DIR, exist_ok=True)
        if not WIN:
            messagebox.showinfo("Logs", LOG_DIR)
        if WIN:
            os.startfile(LOG_DIR)

    # ------------------------------------------------------------- arquivos --
    def _titulo(self):
        nome = os.path.basename(self.arquivo) if self.arquivo else "sem título"
        self.root.title(f"{NOME} {VERSAO} — {nome}{' *' if self.dirty else ''}")
        self.lbl_arquivo.config(text=f"{nome}{'   ● não salvo' if self.dirty else ''}")

    def _confirmar_descartar(self):
        if not self.dirty:
            return True
        r = messagebox.askyesnocancel("Salvar?", "Há alterações não salvas. Deseja salvar?")
        if r is None:
            return False
        if r:
            return self.salvar()
        return True

    def novo(self):
        if self._confirmar_descartar():
            self._solucao_ia_pendente = False
            self.steps, self.arquivo, self.dirty = [], None, False
            self._refresh()

    def abrir(self):
        if not self._confirmar_descartar():
            return
        p = filedialog.askopenfilename(initialdir=APP_DIR, filetypes=[("Roteiro", "*.json")])
        if p:
            self._carregar(p)

    def _carregar(self, p):
        self._solucao_ia_pendente = False
        try:
            with open(p, encoding="utf-8") as f:
                dados = json.load(f)
            self.steps = dados["passos"] if isinstance(dados, dict) else dados
            for passo in self.steps:
                if passo.get("texto_protegido"):
                    try:
                        passo["texto"] = abrir_texto(passo.pop("texto_protegido"))
                    except Exception:
                        passo["texto"] = ""
                        self.log("Aviso: não foi possível abrir uma senha salva (outro usuário/computador?). "
                                 "Digite-a de novo no passo.", "erro")
                if cat.abrir_segredos(passo, abrir_texto):
                    self.log("Aviso: não foi possível abrir uma senha/token salvo (outro usuário/computador?). "
                             "Digite de novo no passo.", "erro")
                if passo.get("tipo") == "rolar" and passo.get("pixels") in (None, ""):
                    passo["pixels"] = pixels_rolagem(passo)
                    passo.pop("quantidade", None)
            for k, v in dados.get("config", {}).items() if isinstance(dados, dict) else []:
                var = {"visual": self.v_visual, "minimizar": self.v_min, "velocidade": self.v_vel,
                       "pausa": self.v_pausa, "repeticoes": self.v_rep, "contagem": self.v_cont,
                       "tentativas": self.v_tent, "maximizar_chrome": self.v_max_chrome,
                       "segundo_plano": self.v_fundo, "coluna_status": self.v_col_status,
                       "escrever_resultado": self.v_escrever, "pular_ok": self.v_pular_ok,
                       "continuar_erro": self.v_continuar}.get(k)
                if var is not None:
                    var.set(v)
            self.lbl_vel.config(text=f"{self.v_vel.get():.2f}x")
            self._mudou_fundo()
            conf = dados.get("config", {}) if isinstance(dados, dict) else {}
            planilha = conf.get("planilha")
            if planilha and os.path.exists(caminho_abs(planilha)):
                self._carregar_csv(caminho_abs(planilha), conf.get("planilha_aba"))
            self.undo = []
            self.arquivo, self.dirty = p, False
            self._refresh()
            if not self.auto:
                self._atualizar_recentes(p)
            self.log(f"Roteiro carregado: {os.path.basename(p)} ({len(self.steps)} passos)")
        except Exception as e:
            messagebox.showerror("Erro ao abrir", str(e))

    def salvar(self):
        if not self.arquivo:
            return self.salvar_como()
        passos = []
        for passo in self.steps:
            if passo.get("tipo") == "digitar" and passo.get("senha") and passo.get("texto"):
                passo = dict(passo)
                passo["texto_protegido"] = proteger_texto(passo.pop("texto"))
            passos.append(cat.guardar_segredos(passo, proteger_texto))
        dados = {"versao": 1, "passos": passos, "config": {
            "visual": self.v_visual.get(), "minimizar": self.v_min.get(),
            "velocidade": round(self.v_vel.get(), 2), "pausa": self.v_pausa.get(),
            "repeticoes": self.v_rep.get(), "contagem": self.v_cont.get(), "tentativas": self.v_tent.get(),
            "planilha": caminho_rel(self.dados_arquivo) if self.dados_arquivo else None,
            "maximizar_chrome": self.v_max_chrome.get(), "segundo_plano": self.v_fundo.get(),
            "planilha_aba": self.v_aba.get() or None, "coluna_status": self.v_col_status.get(),
            "escrever_resultado": self.v_escrever.get(), "pular_ok": self.v_pular_ok.get(),
            "continuar_erro": self.v_continuar.get()}}
        try:
            diario.salvar_json(self.arquivo, dados)  # se falhar no meio, o roteiro anterior continua inteiro
        except Exception as e:
            messagebox.showerror("Erro ao salvar", str(e))
            return False
        self.dirty = False
        self._titulo()
        self._atualizar_recentes(self.arquivo)
        self.log(f"Salvo em {os.path.basename(self.arquivo)}")
        self.lbl_sb.config(text=f"Salvo em {os.path.basename(self.arquivo)}")
        return True

    def _salvar_solucao_que_deu_certo(self):
        """Depois de 'Aplicar solução' da IA, a execução terminou sem nenhuma falha: salva o roteiro corrigido por
        cima do anterior (com uma cópia do anterior na pasta de logs) e só avisa."""
        self._solucao_ia_pendente = False
        if not self.arquivo:
            self._toast("A correção da IA deu certo", "Execução sem falhas. Salve o roteiro (Ctrl+S) para manter.")
            return
        try:
            import shutil
            pasta = os.path.join(LOG_DIR, "roteiros_antes_da_ia")
            os.makedirs(pasta, exist_ok=True)
            if os.path.exists(self.arquivo):
                raiz, ext = os.path.splitext(os.path.basename(self.arquivo))
                shutil.copy2(self.arquivo, os.path.join(pasta, f"{raiz}_{datetime.datetime.now():%Y%m%d_%H%M%S}{ext}"))
        except Exception:
            pass
        if self.salvar():
            nome = os.path.basename(self.arquivo)
            self.log(f"A correção da IA deu certo: '{nome}' foi salvo com ela (a versão com falha ficou em "
                     f"logs\\roteiros_antes_da_ia).", "ok")
            self._toast("Correção salva", f"Deu certo sem falhas: '{nome}' foi atualizado com a correção da IA.")

    def salvar_como(self):
        p = filedialog.asksaveasfilename(initialdir=APP_DIR, initialfile="roteiro.json",
                                         defaultextension=".json", filetypes=[("Roteiro", "*.json")])
        if not p:
            return False
        self.arquivo = p
        return self.salvar()

    def _ao_fechar(self):
        if any(p.poll() is None for p in self.filhos.values()):
            if not messagebox.askyesno("Execução agendada", "Há uma execução agendada em andamento. Fechar mesmo assim?"
                                       "\n(ela continua rodando)"):
                return
        if any(a.get("modo") == "app" and a.get("ativo", True) and agm.proxima(a) for a in self.agendas):
            if not messagebox.askyesno("Agendamentos", "Existem agendamentos 'pelo app': com o app fechado eles "
                                                       "não vão rodar. Fechar mesmo assim?"):
                return
        if self.gravando:
            self.parar_gravacao()
        if self.running:
            self.parar()
        if self._confirmar_descartar():
            self.root.destroy()
