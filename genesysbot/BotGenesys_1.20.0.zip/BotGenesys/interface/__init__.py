# -*- coding: utf-8 -*-
"""Interface (janela) do Bot Genesys, dividida por assunto. Ponto de entrada: bot_genesys.py"""
