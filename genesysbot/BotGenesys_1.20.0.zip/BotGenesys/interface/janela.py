# -*- coding: utf-8 -*-
"""Janela principal do Bot Genesys: a classe App (construção da tela e aparência).
Os demais comportamentos vêm das partes (mixins) importadas abaixo.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import diario
from interface.comum import (APP_DIR, CONFIG_APP, DEFAULT_FILE, HAS_CV, IMG_DIR, LOG_DIR, Motor, NOME,
                             PERFIL_CHROME, Painel, TEMA_CLARO, TEMA_ESCURO, TIPOS, TIPO_POR_NOME, VERSAO,
                             _UiApp, json, misturar, os, queue, tb, threading, tk)
from interface.ajuda import AjudaMixin
from interface.editor import EditorMixin
from interface.arquivos import ArquivosMixin
from interface.infra import InfraMixin
from interface.agenda import AgendaMixin
from interface.gravador import GravadorMixin
from interface.execucao import ExecucaoMixin
from interface.funcoes import FuncoesMixin
from interface.gravador_mouse import GravadorMouseMixin
from interface.ia_janela import IAJanelaMixin


class App(AjudaMixin, EditorMixin, ArquivosMixin, InfraMixin, AgendaMixin, GravadorMixin, ExecucaoMixin, FuncoesMixin,
          GravadorMouseMixin, IAJanelaMixin):
    def __init__(self, root, auto=None, csv_auto=None, agendamento=None):
        self.root = root
        self.steps = []
        self.arquivo = None
        self.dirty = False
        self.fvars = {}
        self.tipo_atual = "clique"
        self.uiq = queue.Queue()
        self.running = False
        self.sending = False
        self.overlay = None
        self._preview = None
        self._shot_tk = None
        self.undo = []
        self.gravando = False
        self.dados = None
        self.dados_arquivo = None
        self.linha = {}
        self._refs = {}
        self._rec = None
        self._ultima_url = ""
        self.mouse_listener = None
        self.auto = auto
        self.agendamento = agendamento
        self.codigo_saida = 0
        self.agendas = []
        self._agenda_mtime = 0
        self.filhos = {}
        self._drag = None
        self._neutros = []
        self._hwnd_chrome = None
        self._aviso_sem_chrome = False
        self.style = tb.Style()
        self.motor = Motor(ui=_UiApp(self), base=APP_DIR, perfil_chrome=PERFIL_CHROME, log_dir=LOG_DIR)
        self.painel = Painel(root)
        self._fundo_atual = False
        self._rec_nav = None
        os.makedirs(LOG_DIR, exist_ok=True)
        diario.instalar_ganchos(LOG_DIR)  # erro que escapar vai para o log do dia (não some)
        root.report_callback_exception = self._erro_interface
        try:
            with open(CONFIG_APP, encoding="utf-8") as f:
                self.app_cfg = json.load(f)
        except (OSError, ValueError):
            self.app_cfg = {}
        self.app_cfg.setdefault("recentes", [])
        self.app_cfg.setdefault("dias_logs", 30)
        self.painel.posicoes = self.app_cfg.setdefault("painel_pos", {})  # onde você deixou cada caixinha
        self.painel.ao_mover = self._salvar_app_cfg

        root.title(f"{NOME} {VERSAO}")
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w, h = min(int(sw * 0.84), 1700), min(int(sh * 0.86), 1050)
        root.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 20)}")
        root.minsize(min(1100, sw - 40), min(680, sh - 60))

        self._build_ui()
        self._aplicar_cores()
        self._set_tipo("clique")
        self._poll()
        self._track_mouse()
        self._tick_chrome()
        threading.Thread(target=self._manutencao_logs, daemon=True).start()
        self._start_hotkeys()
        os.makedirs(IMG_DIR, exist_ok=True)
        inicial = auto or (DEFAULT_FILE if os.path.exists(DEFAULT_FILE) else None)
        if not inicial and self.app_cfg["recentes"] and os.path.exists(self.app_cfg["recentes"][0]):
            inicial = self.app_cfg["recentes"][0]
        if inicial:
            self._carregar(inicial)
        else:
            self._titulo()
        if csv_auto:
            self._carregar_csv(csv_auto)
        if auto:
            root.withdraw()
            root.after(700, lambda: self.executar(0))
        else:
            self._agenda_carregar()
            root.after(3000, self._agenda_tick)
        if not HAS_CV:
            self.log("Aviso: opencv-python não instalado - a busca por imagem fica menos precisa.", "erro")
        self.log(f"{NOME} v{VERSAO} iniciado.")
        self.log("Pronto. F4 = gravar | F8 = capturar posição | F9 = adicionar clique | F2 = pausar | ESC = parar")
        root.protocol("WM_DELETE_WINDOW", self._ao_fechar)
        for seq, fn in (("<Control-s>", self.salvar), ("<Control-z>", self.desfazer), ("<Control-n>", self.novo),
                        ("<Control-o>", self.abrir), ("<Control-d>", self.duplicar), ("<Control-i>", self.criar_com_ia),
                        ("<F5>", lambda: self.executar(0))):
            root.bind(seq, lambda e, fn=fn: fn())

    # ------------------------------------------------------------------ UI --
    def _build_ui(self):
        r = self.root
        self._build_menu()

        # ---- cabeçalho
        head = tb.Frame(r, bootstyle="primary", padding=(18, 10))
        head.pack(fill="x")
        tb.Label(head, text=f"◆  {NOME}", font=("Segoe UI", 15, "bold"),
                 bootstyle="inverse-primary").pack(side="left")
        tb.Label(head, text=f"v{VERSAO}", font=("Segoe UI", 9), bootstyle="inverse-primary").pack(
            side="left", padx=(8, 0), pady=(6, 0))
        self.lbl_arquivo = tb.Label(head, text="", font=("Segoe UI", 10), bootstyle="inverse-primary")
        self.lbl_arquivo.pack(side="left", padx=(16, 0), pady=(4, 0))
        self.btn_tema = tb.Button(head, text="◐  Tema", bootstyle="light", command=self.alternar_tema)
        self.btn_tema.pack(side="right")
        self.lbl_estado = tb.Label(head, text="PRONTO", font=("Segoe UI", 9, "bold"),
                                   bootstyle="inverse-success", padding=(12, 5))
        self.lbl_estado.pack(side="right", padx=14)

        # ---- barra de ações
        bar = tb.Frame(r, padding=(14, 12, 14, 8))
        bar.pack(fill="x")
        self.btn_rec = tb.Button(bar, text="●  Gravar processo", bootstyle="danger", padding=(16, 9),
                                 command=self.alternar_gravacao)
        self.btn_run = tb.Button(bar, text="▶  Executar", bootstyle="success", padding=(16, 9),
                                 command=lambda: self.executar(0))
        self.btn_run_sel = tb.Button(bar, text="▶  Do selecionado", bootstyle="success-outline", padding=(12, 9),
                                     command=self.executar_do_selecionado)
        self.btn_pause = tb.Button(bar, text="❚❚  Pausar", bootstyle="warning-outline", padding=(12, 9),
                                   command=self.pausar, state="disabled")
        self.btn_stop = tb.Button(bar, text="■  Parar", bootstyle="secondary-outline", padding=(12, 9),
                                  command=self.parar, state="disabled")
        self.btn_agendar = tb.Button(bar, text="⏰  Agendar", bootstyle="info", padding=(16, 9),
                                     command=self.novo_agendamento)
        for wdg, pad in ((self.btn_rec, (0, 12)), (self.btn_run, (0, 6)), (self.btn_run_sel, (0, 6)),
                         (self.btn_pause, (0, 6)), (self.btn_stop, (0, 12)), (self.btn_agendar, (0, 0))):
            wdg.pack(side="left", padx=pad)
        for txt, cmd, dica in (("⇩ Exportar .py", self.exportar_python, "Gera um arquivo Python que roda sozinho, "
                                                                        "com todos os detalhes gravados"),
                               ("Salvar", self.salvar, "Salvar roteiro (Ctrl+S)"),
                               ("Abrir", self.abrir, "Abrir roteiro (Ctrl+O)"),
                               ("Novo", self.novo, "Novo roteiro (Ctrl+N)")):
            b = self._neutro(tb.Button(bar, text=txt, padding=(10, 9), command=cmd))
            b.pack(side="right", padx=(6, 0))
            self._dica(b, dica)
        self._dica(self.btn_rec, "Grava cada clique, texto, tecla e rolagem que você fizer no Chrome (F4)")
        self._dica(self.btn_run, "Executa o roteiro inteiro (F5)")
        self._dica(self.btn_run_sel, "Executa a partir do passo selecionado")
        self._dica(self.btn_pause, "Pausa / continua a execução (F2)")
        self._dica(self.btn_stop, "Para a execução (ESC)")
        self._dica(self.btn_agendar, "Programa a execução para uma data/hora, todo dia, dias úteis...")

        # ---- barra de status e log (embaixo)
        status = tb.Frame(r, padding=(14, 5))
        status.pack(side="bottom", fill="x")
        self.lbl_sb = tb.Label(status, text="Pronto", font=("Segoe UI", 9))
        self.lbl_sb.pack(side="left")
        self.prog = tb.Progressbar(status, length=220, bootstyle="success-striped", mode="determinate")
        self.prog.pack(side="left", padx=12)
        self.lbl_sb_agenda = tb.Label(status, text="", font=("Segoe UI", 9), bootstyle="info")
        self.lbl_sb_agenda.pack(side="right")
        self.lbl_sb_chrome = tb.Label(status, text="", font=("Segoe UI", 9))
        self.lbl_sb_chrome.pack(side="right", padx=18)
        self.lbl_sb_mouse = tb.Label(status, text="", font=("Consolas", 9), bootstyle="secondary")
        self.lbl_sb_mouse.pack(side="right")

        logf = tb.Labelframe(r, text=" Log ", padding=(8, 4))
        logf.pack(side="bottom", fill="x", padx=14, pady=(6, 2))
        self.txt_log = tk.Text(logf, height=6, font=("Consolas", 9), state="disabled", relief="flat",
                               borderwidth=0, bg="#1e1f24", fg="#d4d4d4", padx=6, pady=4)
        sb2 = tb.Scrollbar(logf, command=self.txt_log.yview, bootstyle="round")
        self.txt_log.configure(yscrollcommand=sb2.set)
        self.txt_log.pack(side="left", fill="both", expand=True)
        sb2.pack(side="right", fill="y")
        self.txt_log.tag_configure("erro", foreground="#ff7b72")
        self.txt_log.tag_configure("ok", foreground="#7ee787")
        self.txt_log.tag_configure("hora", foreground="#7d8590")

        # ---- corpo
        corpo = tb.Panedwindow(r, orient="horizontal")
        corpo.pack(fill="both", expand=True, padx=14, pady=(2, 0))
        esq = tb.Frame(corpo)
        dir_ = tb.Frame(corpo, padding=(10, 0, 0, 0))
        corpo.add(esq, weight=3)
        corpo.add(dir_, weight=2)
        self._build_lista(esq)

        self.nb = tb.Notebook(dir_, bootstyle="primary")
        self.nb.pack(fill="both", expand=True)
        tab_passo, tab_exec, tab_ag = (tb.Frame(self.nb, padding=12) for _ in range(3))
        self.nb.add(tab_passo, text="   Passo   ")
        self.nb.add(tab_exec, text="   Execução   ")
        self.nb.add(tab_ag, text="   Agendamentos   ")
        self._build_tab_passo(tab_passo)
        self._build_tab_execucao(self._rolavel(tab_exec))
        self._build_tab_agenda(tab_ag)

    def _estilo_neutro(self):
        return "light-outline" if self.style.theme_use() == TEMA_ESCURO else "secondary-outline"

    def _neutro(self, botao):
        botao.config(bootstyle=self._estilo_neutro())
        self._neutros.append(botao)
        return botao

    def _rolavel(self, pai):
        """Área com barra de rolagem (para telas menores ou com escala 125%/150%)."""
        try:
            sf = tb.ScrolledFrame(pai, auto_hide=True, padding=(0, 0, 10, 0))
            sf.pack(fill="both", expand=True)
            return sf
        except Exception:
            return pai

    def _dica(self, widget, texto):
        try:
            tb.ToolTip(widget, text=texto, delay=400)
        except Exception:
            pass

    def _build_menu(self):
        m = tk.Menu(self.root)
        arq = tk.Menu(m, tearoff=0)
        arq.add_command(label="Novo", accelerator="Ctrl+N", command=self.novo)
        arq.add_command(label="Abrir...", accelerator="Ctrl+O", command=self.abrir)
        self.menu_recentes = tk.Menu(arq, tearoff=0)
        arq.add_cascade(label="Abrir recente", menu=self.menu_recentes)
        arq.add_separator()
        arq.add_command(label="Salvar", accelerator="Ctrl+S", command=self.salvar)
        arq.add_command(label="Salvar como...", command=self.salvar_como)
        arq.add_command(label="Exportar para Python (.py)...", command=self.exportar_python)
        arq.add_separator()
        arq.add_command(label="Abrir pasta de logs", command=self._abrir_logs)
        arq.add_separator()
        arq.add_command(label="Sair", command=self._ao_fechar)
        m.add_cascade(label="Arquivo", menu=arq)
        ed = tk.Menu(m, tearoff=0)
        ed.add_command(label="Desfazer", accelerator="Ctrl+Z", command=self.desfazer)
        ed.add_command(label="Duplicar passo", accelerator="Ctrl+D", command=self.duplicar)
        ed.add_command(label="Ativar / desativar passo", accelerator="Espaço", command=self.alternar_ativo)
        ed.add_command(label="Remover passo", accelerator="Delete", command=self.remover)
        ed.add_separator()
        ed.add_command(label="Limpar todos os passos", command=self.limpar)
        m.add_cascade(label="Editar", menu=ed)
        ex = tk.Menu(m, tearoff=0)
        ex.add_command(label="Gravar processo", accelerator="F4", command=self.alternar_gravacao)
        ex.add_separator()
        ex.add_command(label="Executar tudo", accelerator="F5", command=lambda: self.executar(0))
        ex.add_command(label="Executar a partir do selecionado", command=self.executar_do_selecionado)
        ex.add_command(label="Testar só o passo selecionado", command=self.testar_passo)
        ex.add_separator()
        ex.add_command(label="Maximizar o Chrome agora", command=self.maximizar_chrome_agora)
        ex.add_command(label="Agendar execução...", command=self.novo_agendamento)
        m.add_cascade(label="Executar", menu=ex)
        mia = tk.Menu(m, tearoff=0)
        mia.add_command(label="✦  Criar ou alterar o roteiro descrevendo...", accelerator="Ctrl+I",
                        command=self.criar_com_ia)
        mia.add_command(label="Explicar o último erro", command=self.explicar_erro_ia)
        mia.add_separator()
        mia.add_command(label="Configurar (chave da API)...", command=self.configurar_ia)
        m.add_cascade(label="IA", menu=mia)
        aj = tk.Menu(m, tearoff=0)
        aj.add_command(label="Verificar sistema (diagnóstico)...", command=self.diagnostico)
        aj.add_command(label="Histórico de execuções...", command=self.historico_execucoes)
        aj.add_separator()
        aj.add_command(label="Voltar para uma versão anterior...", command=self.voltar_versao)
        aj.add_separator()
        aj.add_command(label="Atalhos de teclado", command=self._mostrar_atalhos)
        aj.add_command(label="Alternar tema claro / escuro", command=self.alternar_tema)
        aj.add_separator()
        aj.add_command(label=f"Sobre o {NOME}", command=self._sobre)
        m.add_cascade(label="Ajuda", menu=aj)
        self.root.config(menu=m)
        self._atualizar_recentes()

    def _build_lista(self, esq):
        cab = tb.Frame(esq)
        cab.pack(fill="x", pady=(0, 8))
        self.lbl_qtd = tb.Label(cab, text="Passos do roteiro", font=("Segoe UI", 12, "bold"))
        self.lbl_qtd.pack(side="left")
        self.v_filtro = tk.StringVar()
        ent = tb.Entry(cab, textvariable=self.v_filtro, width=26)
        ent.pack(side="right")
        tb.Label(cab, text="Filtrar", bootstyle="secondary").pack(side="right", padx=6)
        self.v_filtro.trace_add("write", lambda *a: self._refresh(self._sel()))

        caixa = tb.Frame(esq)
        caixa.pack(fill="both", expand=True)
        self.tree = tb.Treeview(caixa, columns=("n", "tipo", "det"), show="headings", selectmode="browse",
                                bootstyle="primary")
        self.tree.heading("n", text="#")
        self.tree.heading("tipo", text="Ação")
        self.tree.heading("det", text="Detalhes")
        self.tree.column("n", width=56, anchor="center", stretch=False)
        self.tree.column("tipo", width=210, stretch=False)
        self.tree.column("det", width=440)
        sb = tb.Scrollbar(caixa, orient="vertical", command=self.tree.yview, bootstyle="round")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.lbl_vazio = tb.Label(caixa, justify="center", font=("Segoe UI", 11), bootstyle="secondary",
                                  text="Nenhum passo ainda.\n\nClique em  ●  Gravar processo  (F4)\n"
                                       "e faça o chamado normalmente no Chrome.")
        for tag in ("impar", "par", "inativo", "rodando"):
            self.tree.tag_configure(tag)
        self.tree.bind("<<TreeviewSelect>>", self._ao_selecionar)
        self.tree.bind("<Delete>", lambda e: self.remover())
        self.tree.bind("<space>", lambda e: self.alternar_ativo())
        self.tree.bind("<Double-1>", lambda e: self.nb.select(0))
        self.tree.bind("<Button-3>", self._menu_contexto)
        self.tree.bind("<ButtonPress-1>", self._drag_ini, add="+")
        self.tree.bind("<B1-Motion>", self._drag_mov, add="+")
        self.tree.bind("<ButtonRelease-1>", self._drag_fim, add="+")

        acoes = tb.Frame(esq, padding=(0, 8, 0, 0))
        acoes.pack(fill="x")
        for txt, cmd, dica in (("↑", lambda: self.mover(-1), "Subir (ou arraste o passo na lista)"),
                               ("↓", lambda: self.mover(1), "Descer"),
                               ("⧉  Duplicar", self.duplicar, "Duplicar (Ctrl+D)"),
                               ("⊘  Ativar/Desativar", self.alternar_ativo, "Desativados são pulados (Espaço)"),
                               ("✕  Remover", self.remover, "Remover (Delete)"),
                               ("↶  Desfazer", self.desfazer, "Desfazer (Ctrl+Z)")):
            b = self._neutro(tb.Button(acoes, text=txt, command=cmd, padding=(9, 5)))
            b.pack(side="left", padx=(0, 5))
            self._dica(b, dica)
        b = tb.Button(acoes, text="▷  Testar passo", bootstyle="info-outline", command=self.testar_passo,
                      padding=(9, 5))
        b.pack(side="right")
        self._dica(b, "Executa só o passo selecionado, para conferir")

        self.menu_ctx = tk.Menu(self.root, tearoff=0)
        self.menu_ctx.add_command(label="▷  Testar este passo", command=self.testar_passo)
        self.menu_ctx.add_command(label="▶  Executar a partir daqui", command=self.executar_do_selecionado)
        self.menu_ctx.add_separator()
        self.menu_ctx.add_command(label="⧉  Duplicar", command=self.duplicar)
        self.menu_ctx.add_command(label="⊘  Ativar / desativar", command=self.alternar_ativo)
        self.menu_ctx.add_command(label="↑  Subir", command=lambda: self.mover(-1))
        self.menu_ctx.add_command(label="↓  Descer", command=lambda: self.mover(1))
        self.menu_ctx.add_separator()
        self.menu_ctx.add_command(label="✕  Remover", command=self.remover)

    def _build_tab_passo(self, tab):
        card = tb.Labelframe(tab, text=" Posição do mouse ", padding=(12, 8), bootstyle="info")
        card.pack(fill="x")
        linha = tb.Frame(card)
        linha.pack(fill="x")
        self.lbl_pos = tb.Label(linha, text="X 0   Y 0", font=("Consolas", 22, "bold"), bootstyle="info")
        self.lbl_pos.pack(side="left")
        self.lbl_chrome = tb.Label(linha, text="", font=("Segoe UI", 9, "bold"))
        self.lbl_chrome.pack(side="right", anchor="n")
        tb.Label(card, text="F8 captura a posição   •   F9 adiciona um clique   •   F4 grava o processo",
                 bootstyle="secondary", font=("Segoe UI", 9)).pack(anchor="w")
        self.lbl_status = tb.Label(card, text="", bootstyle="warning", font=("Segoe UI", 9, "bold"))
        self.lbl_status.pack(anchor="w")

        ed = tb.Labelframe(tab, text=" Editar passo ", padding=12)
        ed.pack(fill="both", expand=True, pady=(12, 0))
        linha = tb.Frame(ed)
        linha.pack(fill="x")
        tb.Label(linha, text="Ação", width=11).pack(side="left")
        self.v_tipo = tk.StringVar()
        cb = tb.Combobox(linha, textvariable=self.v_tipo, values=list(TIPOS.values()), state="readonly", width=30)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._set_tipo(TIPO_POR_NOME[self.v_tipo.get()], manter=True))
        linha2 = tb.Frame(ed)
        linha2.pack(fill="x", pady=(8, 6))
        tb.Label(linha2, text="Descrição", width=11).pack(side="left")
        self.v_desc = tk.StringVar()
        tb.Entry(linha2, textvariable=self.v_desc).pack(side="left", fill="x", expand=True)
        bb = tb.Frame(ed)
        bb.pack(fill="x", pady=(2, 0))
        tb.Button(bb, text="✓  Salvar no selecionado", bootstyle="success", command=self.atualizar,
                  padding=(12, 6)).pack(side="left")
        tb.Button(bb, text="✚  Adicionar como novo", bootstyle="info-outline", command=self.adicionar,
                  padding=(12, 6)).pack(side="left", padx=8)
        tb.Separator(ed).pack(fill="x", pady=(10, 6))
        self.form = tb.Frame(ed)
        self.form.pack(fill="x", pady=4)
        self.lbl_dica = tb.Label(ed, text="", wraplength=440, justify="left", bootstyle="secondary",
                                 font=("Segoe UI", 9))
        self.lbl_dica.pack(fill="x", pady=6)

    def _build_tab_execucao(self, tab):
        self.v_visual = tk.BooleanVar(value=True)
        self.v_min = tk.BooleanVar(value=True)
        self.v_topo = tk.BooleanVar(value=False)
        self.v_max_chrome = tk.BooleanVar(value=True)
        self.v_fundo = tk.BooleanVar(value=False)
        self.v_vel = tk.DoubleVar(value=1.0)
        self.v_pausa = tk.StringVar(value="0.5")
        self.v_rep = tk.StringVar(value="1")
        self.v_cont = tk.StringVar(value="3")
        self.v_tent = tk.StringVar(value="2")

        f0 = tb.Labelframe(tab, text=" Segundo plano ", padding=12, bootstyle="info")
        f0.pack(fill="x", pady=(0, 12))
        tb.Checkbutton(f0, text="Rodar em segundo plano (continuo usando o computador)", variable=self.v_fundo,
                       bootstyle="info-round-toggle", command=self._mudou_fundo).pack(anchor="w")
        self.lbl_fundo = tb.Label(f0, bootstyle="secondary", wraplength=440, justify="left", font=("Segoe UI", 9),
                                  text="O bot age direto dentro do Chrome controlado, sem usar o seu mouse e teclado. "
                                       "Um cartão no canto da tela mostra o andamento, erros e a conclusão.")
        self.lbl_fundo.pack(anchor="w", pady=(4, 0))

        f1 = tb.Labelframe(tab, text=" Como executar ", padding=12)
        f1.pack(fill="x")
        for txt, var, cmd in (("Ver o bot executando (mouse devagar, marcações na tela)", self.v_visual, None),
                              ("Garantir a janela maximizada — Chrome, Excel ou o programa gravado (confere antes de cada ação)", self.v_max_chrome, None),
                              ("Minimizar o app durante a execução", self.v_min, None),
                              ("Manter o app sempre no topo", self.v_topo,
                               lambda: self.root.attributes("-topmost", self.v_topo.get()))):
            tb.Checkbutton(f1, text=txt, variable=var, bootstyle="success-round-toggle",
                           command=cmd).pack(anchor="w", pady=3)
        lv = tb.Frame(f1)
        lv.pack(fill="x", pady=(10, 2))
        tb.Label(lv, text="Velocidade", width=11).pack(side="left")
        tb.Scale(lv, from_=0.25, to=3.0, variable=self.v_vel, bootstyle="success",
                 command=lambda v: self.lbl_vel.config(text=f"{float(v):.2f}x")).pack(side="left", fill="x",
                                                                                     expand=True)
        self.lbl_vel = tb.Label(lv, text="1.00x", width=6, font=("Segoe UI", 10, "bold"))
        self.lbl_vel.pack(side="left", padx=(8, 0))
        grade = tb.Frame(f1)
        grade.pack(fill="x", pady=(10, 0))
        for i, (txt, var, a, b, inc) in enumerate((("Pausa entre passos (s)", self.v_pausa, 0, 30, 0.1),
                                                   ("Repetições", self.v_rep, 1, 999, 1),
                                                   ("Contagem inicial (s)", self.v_cont, 0, 60, 1),
                                                   ("Tentativas (imagem/carregamento)", self.v_tent, 1, 10, 1))):
            tb.Label(grade, text=txt).grid(row=i // 2, column=(i % 2) * 2, sticky="w", pady=4, padx=(0, 6))
            tb.Spinbox(grade, from_=a, to=b, increment=inc, textvariable=var, width=6).grid(
                row=i // 2, column=(i % 2) * 2 + 1, sticky="w", padx=(0, 22))

        f2 = tb.Labelframe(tab, text=" Vários chamados de uma vez (planilha Excel ou CSV) ", padding=12)
        f2.pack(fill="x", pady=(12, 0))
        self.v_aba = tk.StringVar()
        self.v_col_status = tk.StringVar(value="Status")
        self.v_escrever = tk.BooleanVar(value=True)
        self.v_pular_ok = tk.BooleanVar(value=True)
        self.v_continuar = tk.BooleanVar(value=False)
        self.lbl_csv = tb.Label(f2, text="Nenhuma planilha: o roteiro roda pelo nº de repetições.",
                                bootstyle="secondary", wraplength=440, justify="left")
        self.lbl_csv.pack(anchor="w")
        lb = tb.Frame(f2)
        lb.pack(fill="x", pady=(8, 0))
        tb.Button(lb, text="Escolher planilha...", bootstyle="primary-outline", command=self.escolher_csv).pack(
            side="left")
        tb.Button(lb, text="Remover", bootstyle="secondary-link", command=self.remover_csv).pack(side="left", padx=6)
        la = tb.Frame(f2)
        la.pack(fill="x", pady=(8, 0))
        tb.Label(la, text="Aba").pack(side="left")
        self.cb_aba = tb.Combobox(la, textvariable=self.v_aba, state="disabled", width=18)
        self.cb_aba.pack(side="left", padx=(6, 16))
        self.cb_aba.bind("<<ComboboxSelected>>", lambda e: self._carregar_csv(self.dados_arquivo, self.v_aba.get()))
        tb.Label(la, text="Coluna de status").pack(side="left")
        tb.Entry(la, textvariable=self.v_col_status, width=12).pack(side="left", padx=6)
        for txt, var in (("Escrever o resultado de cada chamado na planilha (OK/erro, data e valores lidos)",
                          self.v_escrever),
                         ("Pular linhas que já estão com status OK (continua de onde parou)", self.v_pular_ok),
                         ("Se um chamado der erro, seguir para o próximo", self.v_continuar)):
            tb.Checkbutton(f2, text=txt, variable=var, bootstyle="success-round-toggle").pack(anchor="w", pady=2)

        f3 = tb.Labelframe(tab, text=" Janela do Chrome ", padding=12)
        f3.pack(fill="x", pady=(12, 0))
        self.lbl_chrome2 = tb.Label(f3, text="", font=("Segoe UI", 10, "bold"))
        self.lbl_chrome2.pack(anchor="w")
        tb.Label(f3, bootstyle="secondary", wraplength=440, justify="left", font=("Segoe UI", 9),
                 text="As posições gravadas valem para o Chrome maximizado no monitor principal. "
                      "Se ele estiver minimizado, pela metade, em tela cheia ou em outro monitor, "
                      "o bot corrige sozinho antes de agir.").pack(anchor="w", pady=(4, 8))
        tb.Button(f3, text="Maximizar agora", bootstyle="primary-outline",
                  command=self.maximizar_chrome_agora).pack(anchor="w")

    def _mudou_fundo(self):
        if self.v_fundo.get():
            self.log("Segundo plano ligado: o roteiro precisa usar o Chrome controlado (passo 'Abrir Chrome' com "
                     "modo controlado). Passos gravados com o Chrome controlado clicam pelo elemento da página.")
        self.btn_run.config(text="▶  Executar (2º plano)" if self.v_fundo.get() else "▶  Executar")

    def _build_tab_agenda(self, tab):
        cab = tb.Frame(tab)
        cab.pack(fill="x")
        tb.Label(cab, text="Execuções agendadas", font=("Segoe UI", 12, "bold")).pack(side="left")
        tb.Button(cab, text="✚  Novo agendamento", bootstyle="info", command=self.novo_agendamento,
                  padding=(10, 6)).pack(side="right")
        caixa = tb.Frame(tab, padding=(0, 10, 0, 0))
        caixa.pack(fill="both", expand=True)
        cols = ("nome", "quando", "proxima", "modo", "resultado")
        self.tree_ag = tb.Treeview(caixa, columns=cols, show="headings", selectmode="browse",
                                   bootstyle="info", height=8)
        for c, t, w in (("nome", "Nome", 130), ("quando", "Repetição", 150), ("proxima", "Próxima", 110),
                        ("modo", "Por", 70), ("resultado", "Último resultado", 160)):
            self.tree_ag.heading(c, text=t)
            self.tree_ag.column(c, width=w, stretch=c in ("nome", "resultado"))
        self.tree_ag.pack(fill="both", expand=True)
        self.tree_ag.tag_configure("pausado")
        self.tree_ag.bind("<Double-1>", lambda e: self.editar_agendamento())
        bts = tb.Frame(tab, padding=(0, 8, 0, 0))
        bts.pack(fill="x")
        for txt, cmd, est in (("Editar", self.editar_agendamento, None),
                              ("▶  Rodar agora", self.rodar_agendamento_agora, "success-outline"),
                              ("Ativar / Pausar", self.alternar_agendamento, "warning-outline"),
                              ("Excluir", self.excluir_agendamento, "danger-outline")):
            b = tb.Button(bts, text=txt, bootstyle=est or "secondary-outline", command=cmd, padding=(9, 5))
            b.pack(side="left", padx=(0, 5))
            if not est:
                self._neutro(b)
        tb.Label(tab, bootstyle="secondary", wraplength=440, justify="left", font=("Segoe UI", 9),
                 text="Pelo app: dispara enquanto o app estiver aberto (pode ficar minimizado).\n"
                      "Pelo Windows: usa o Agendador de Tarefas e roda mesmo com o app fechado.\n"
                      "Nos dois casos o computador precisa estar ligado e desbloqueado, "
                      "pois o bot usa o mouse e o teclado de verdade.").pack(anchor="w", pady=(10, 0))

    # ------------------------------------------------------------ aparência --
    def _aplicar_cores(self):
        c = self.style.colors
        escuro = self.style.theme_use() == TEMA_ESCURO
        self.style.configure("Treeview", rowheight=30, font=("Segoe UI", 10))
        self.style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        for arv in (self.tree, getattr(self, "tree_ag", None)):
            if not arv:
                continue
            arv.tag_configure("impar", background=c.bg)
            arv.tag_configure("par", background=misturar(c.bg, c.fg, 0.05 if escuro else 0.035))
            arv.tag_configure("inativo", foreground=misturar(c.fg, c.bg, 0.55))
            arv.tag_configure("rodando", background=misturar(c.bg, c.warning, 0.45))
            arv.tag_configure("pausado", foreground=misturar(c.fg, c.bg, 0.55))
        self.btn_tema.config(text="☀  Tema claro" if escuro else "◐  Tema escuro")
        for b in self._neutros:
            try:
                b.config(bootstyle=self._estilo_neutro())
            except tk.TclError:
                pass
        if hasattr(self, "fvars"):
            self._set_tipo(self.tipo_atual, self._ler_form_silencioso(), manter=True)

    def alternar_tema(self):
        novo = TEMA_CLARO if self.style.theme_use() == TEMA_ESCURO else TEMA_ESCURO
        self.style.theme_use(novo)
        self.app_cfg["tema"] = novo
        self._salvar_app_cfg()
        self._aplicar_cores()
        self._refresh(self._sel())

    def _salvar_app_cfg(self):
        try:
            diario.salvar_json(CONFIG_APP, self.app_cfg)
        except (OSError, TypeError, ValueError):
            pass

    def _set_estado(self, texto, estilo):
        self.lbl_estado.config(text=texto, bootstyle=f"inverse-{estilo}")

    def _toast(self, titulo, msg, estilo="success", ms=4000):
        if self.auto:
            return
        try:
            tb.ToastNotification(title=titulo, message=msg, duration=ms, bootstyle=estilo).show_toast()
        except Exception:
            pass
