# -*- coding: utf-8 -*-
"""Janela "Funções do Excel" (botão ƒx do passo Excel: escrever célula): procurar, ver a sintaxe em português
ou inglês, inserir na fórmula, converter a fórmula de idioma e ler a lista completa do seu Excel.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
from interface.comum import APP_DIR, messagebox, tb, threading, tk, xlm
import formulas_excel as fx


class FuncoesMixin:

    def escolher_funcao(self, var, entrada):
        win = tb.Toplevel(title="Funções do Excel")
        win.transient(self.root)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h = min(900, sw - 80), min(600, sh - 100)
        win.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 30)}")
        atual = var.get()
        v_busca = tk.StringVar()
        v_cat = tk.StringVar(value="Todas")
        v_idioma = tk.StringVar(value="en" if fx.detectar_idioma(atual) == "en" else "pt")
        topo = tb.Frame(win, padding=(14, 12, 14, 4))
        topo.pack(fill="x")
        tb.Label(topo, text="Procurar:").pack(side="left")
        busca = tb.Entry(topo, textvariable=v_busca, width=28)
        busca.pack(side="left", padx=(4, 10))
        tb.Combobox(topo, textvariable=v_cat, values=["Todas"] + fx.CATEGORIAS, state="readonly",
                    width=22).pack(side="left")
        for txt, val in (("Português", "pt"), ("English", "en")):
            tb.Radiobutton(topo, text=txt, variable=v_idioma, value=val, bootstyle="info-toolbutton",
                           command=lambda: preencher()).pack(side="right", padx=2)
        meio = tb.Frame(win, padding=(14, 4))
        meio.pack(fill="both", expand=True)
        tv = tb.Treeview(meio, columns=("func", "cat", "desc"), show="headings", bootstyle="info")
        for col, txt, larg in (("func", "Função", 200), ("cat", "Categoria", 130), ("desc", "O que faz", 480)):
            tv.heading(col, text=txt)
            tv.column(col, width=larg, stretch=col == "desc")
        sb = tb.Scrollbar(meio, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        v_sintaxe = tk.StringVar(value="Escolha uma função.")
        tb.Label(win, textvariable=v_sintaxe, font=("Consolas", 11), padding=(14, 6),
                 bootstyle="info").pack(fill="x")
        v_info = tk.StringVar()
        baixo = tb.Frame(win, padding=(14, 4, 14, 12))
        baixo.pack(fill="x")
        achadas = {}

        def preencher(*_):
            tv.delete(*tv.get_children())
            achadas.clear()
            cat = None if v_cat.get() == "Todas" else v_cat.get()
            idi = v_idioma.get()
            for i, f in enumerate(fx.procurar(v_busca.get(), cat)):
                iid = str(i)
                achadas[iid] = f
                nome = f[idi] + ("" if f[idi] == f["en" if idi == "pt" else "pt"] else
                                 f"   ({f['en' if idi == 'pt' else 'pt']})")
                tv.insert("", "end", iid=iid, values=(nome, f["categoria"], f["descricao"]))
            v_info.set(f"{len(achadas)} de {len(fx.FUNCOES)} funções")
            if achadas:
                tv.selection_set("0")

        def selecionada():
            sel = tv.selection()
            return achadas.get(sel[0]) if sel else None

        def mostrar(*_):
            f = selecionada()
            if f:
                v_sintaxe.set("=" + fx.sintaxe(f, v_idioma.get()))

        def inserir(*_):
            f = selecionada()
            if not f:
                return
            texto = var.get()
            pos = entrada.index("insert") if entrada.winfo_exists() else len(texto)
            nome = f[v_idioma.get()] + "("
            if not texto.strip():
                texto, pos = "=", 1
            var.set(texto[:pos] + nome + texto[pos:])
            if entrada.winfo_exists():
                entrada.icursor(pos + len(nome))
            win.destroy()

        def converter(lingua):
            texto = var.get()
            if not texto.strip().startswith("="):
                messagebox.showinfo("Converter", "O campo não tem uma fórmula (começa com =).", parent=win)
                return
            var.set(fx.para_portugues(texto) if lingua == "pt" else fx.para_ingles(texto))
            v_idioma.set(lingua)
            preencher()

        def ler_do_excel():
            if not xlm.HAS_COM:
                messagebox.showinfo("Funções do Excel", "Precisa do Microsoft Excel instalado (Windows).", parent=win)
                return
            b_ler.configure(state="disabled")
            v_info.set("Lendo do seu Excel... (leva cerca de 1 minuto)")

            def trabalho():
                xl = xlm.Excel()
                try:
                    import os
                    import openpyxl
                    import tempfile
                    tmp = os.path.join(tempfile.mkdtemp(), "funcoes.xlsx")
                    openpyxl.Workbook().save(tmp)
                    xl.abrir(tmp)
                    n, idioma = xl.ler_funcoes_do_excel(
                        APP_DIR, lambda i, t: self.post(lambda: win.winfo_exists() and v_info.set(
                            f"Lendo do seu Excel... {i} de {t}")))
                    msg = (f"{n} funções lidas do seu Excel (idioma {idioma}). "
                           + ("Elas completam a lista." if idioma == 1046 else
                              "Seu Excel não está em português do Brasil: a lista em português continua a do bot."))
                except Exception as e:
                    msg = f"Não deu para ler: {xlm.erro_legivel(e)}"
                finally:
                    try:
                        xl.fechar()
                    except Exception:
                        pass

                def fim():
                    if win.winfo_exists():
                        b_ler.configure(state="normal")
                        preencher()
                        messagebox.showinfo("Funções do Excel", msg, parent=win)
                self.post(fim)
            threading.Thread(target=trabalho, daemon=True).start()

        tb.Button(baixo, text="Inserir na fórmula", bootstyle="primary", command=inserir).pack(side="left")
        tb.Button(baixo, text="Fórmula → português", bootstyle="secondary-outline",
                  command=lambda: converter("pt")).pack(side="left", padx=(8, 0))
        tb.Button(baixo, text="Fórmula → inglês", bootstyle="secondary-outline",
                  command=lambda: converter("en")).pack(side="left", padx=(8, 0))
        b_ler = tb.Button(baixo, text="Ler a lista completa do meu Excel", bootstyle="info-outline",
                          command=ler_do_excel)
        b_ler.pack(side="left", padx=(8, 0))
        tb.Label(baixo, textvariable=v_info, bootstyle="secondary").pack(side="left", padx=10)
        tb.Button(baixo, text="Fechar", bootstyle="secondary", command=win.destroy).pack(side="right")
        v_busca.trace_add("write", preencher)
        v_cat.trace_add("write", preencher)
        tv.bind("<<TreeviewSelect>>", mostrar)
        tv.bind("<Double-1>", inserir)
        busca.bind("<Return>", inserir)
        busca.bind("<Down>", lambda e: (tv.focus_set(), tv.focus(tv.selection()[0] if tv.selection() else "")))
        win.bind("<Escape>", lambda e: win.destroy())
        preencher()
        busca.focus_set()
