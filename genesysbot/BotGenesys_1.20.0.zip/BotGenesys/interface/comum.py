# -*- coding: utf-8 -*-
"""
Base comum da janela do Bot Genesys: imports, constantes (pastas, temas), utilidades e a trava
que impede duas execuções ao mesmo tempo. Usada por todos os arquivos de interface/."""
import ctypes
import datetime
import json
import os
import queue
import subprocess
import sys
import threading
import time
import unicodedata
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

WIN = sys.platform == "win32"

# Faz Tkinter, pyautogui e prints de tela usarem os MESMOS pixels reais
# (sem isso, com escala de 125%/150% no Windows as posições ficam erradas).
if WIN:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

try:
    import pyautogui
    import ttkbootstrap as tb
    from PIL import Image, ImageStat, ImageTk, ImageGrab
except ImportError:
    print("Dependências faltando. Rode: pip install -r requirements.txt")
    raise

import agendador as agm
import diario
from versao import NOME, VERSAO, DATA_VERSAO, HISTORICO
import exportar as exportador
import excel as xlm
import janelas as jc
import diagnostico as diag
import versoes
import navegador as navm
from motor import (Motor, UiBase, HAS_CV, TIPOS, PRECISA_TELA, resumo, pixels_rolagem, parse_teclas, proteger_texto, abrir_texto,
                   deslocamento_vertical)
import passos as cat
from passos import FIELDS, DICAS, ICONES, TIPO_POR_NOME
from navegador import (cdp_disponivel, cdp_json, cdp_ids, marcar_aba_nova, JS_ROLAGEM, Navegador)
from painel import Painel

try:
    from pynput import keyboard as pkb, mouse as pms
except Exception:
    pkb = pms = None

import numpy as np

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # pasta do programa
IMG_DIR = os.path.join(APP_DIR, "imagens")
DEFAULT_FILE = os.path.join(APP_DIR, "roteiro.json")
PERFIL_CHROME = os.path.join(APP_DIR, "chrome_perfil_bot")
LOG_DIR = os.path.join(APP_DIR, "logs")
AGENDA_FILE = os.path.join(APP_DIR, "agendamentos.json")
CONFIG_APP = os.path.join(APP_DIR, "config_app.json")
LOCK_FILE = os.path.join(LOG_DIR, ".executando")
SCRIPT = os.path.join(APP_DIR, "bot_genesys.py")
TEMA_CLARO, TEMA_ESCURO = "flatly", "darkly"
FONT = ("Segoe UI", 10)

# --------------------------------------------------------------------------- #
# Tipos de passo (campos, dicas, ícones): catálogo em passos.py
# --------------------------------------------------------------------------- #
TIPOS_PLANILHA = [("Planilhas", "*.xlsx *.xlsm *.xls *.csv"), ("Excel", "*.xlsx *.xlsm *.xls"), ("CSV", "*.csv"),
                  ("Todos", "*.*")]

def caminho_abs(p):
    if not p:
        return p
    return p if os.path.isabs(p) else os.path.join(APP_DIR, p)


def caminho_rel(p):
    try:
        rel = os.path.relpath(p, APP_DIR)
        if not rel.startswith(".."):
            return rel.replace("\\", "/")
    except ValueError:
        pass
    return p


def expandir_teste(texto):
    """Troca {variáveis} por valores de exemplo, só para validar referências de célula no formulário."""
    import re as _re
    return _re.sub(r"\{[^}]+\}", "2", texto)


class _CtxValidar:
    """O que as validações do catálogo (passos.py) precisam da tela/programa."""
    existe = staticmethod(lambda p: os.path.exists(caminho_abs(p)))
    parse_teclas = staticmethod(lambda t: parse_teclas(t))
    separar_ref = staticmethod(lambda r: xlm.separar_ref(r))
    expandir_teste = staticmethod(lambda t: expandir_teste(t))


_CTX_VALIDAR = _CtxValidar()


def abrir_chrome(url, controle=False):
    navm.abrir_chrome(url, controle, PERFIL_CHROME)


class _UiApp(UiBase):
    """Liga o motor de execução à tela do app (tudo repassado para a thread da interface)."""

    def __init__(self, app):
        self.app = app

    def log(self, msg, tag=None):
        self.app.log(msg, tag)

    def status(self, texto, cor=None):
        self.app.post(lambda: self.app.painel.texto(texto, cor))

    def progresso(self, feito, total, texto=None):
        self.app.post(lambda: self.app._progresso(feito, total, texto))

    def destacar(self, i):
        self.app._destacar(i)

    def marcador(self, x, y, w=0, h=0, cor="#ff1744", ms=700):
        self.app.post(lambda: self.app.painel.marcador(x, y, w, h, cor, ms))

    def desviar(self, x, y):
        if self.app.painel.contem(x, y):  # leitura rápida; só espera quando precisa mover
            self.app.post(lambda: self.app.painel.desviar(x, y))
            time.sleep(0.3)

    def aguardar_usuario(self, msg):
        self.app.post(lambda: self.app._cartao_aguardar(msg))

    def detalhe(self, titulo, texto):
        diario.detalhe(LOG_DIR, titulo, texto)  # só no arquivo de log

    def fim_aguardar(self):
        self.app.post(self.app._fim_cartao_aguardar)


def misturar(c1, c2, t):
    """Mistura duas cores hex (t=0 -> c1, t=1 -> c2)."""
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(a, b))


def processo_vivo(pid):
    if not WIN:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
    if not h:
        return False
    try:
        codigo = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(codigo))
        return codigo.value == 259  # STILL_ACTIVE
    finally:
        ctypes.windll.kernel32.CloseHandle(h)


_MUTEX = None  # trava do próprio Windows (some sozinha se o processo morrer)


def _pegar_mutex():
    """Trava pelo Windows: True = é nossa; False = outro processo do bot está executando;
    None = não deu para usar (aí vale só a trava por arquivo, como antes)."""
    global _MUTEX
    if not WIN:
        return None
    if _MUTEX:
        return True
    try:
        import hashlib
        nome = "Local\\BotGenesys_" + hashlib.sha1(os.path.abspath(LOCK_FILE).lower().encode("utf-8")).hexdigest()[:16]
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateMutexW.restype = ctypes.c_void_p
        k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        ctypes.set_last_error(0)
        h = k.CreateMutexW(None, 0, nome)
        erro = ctypes.get_last_error()
        if not h:
            return None
        if erro == 183:  # ERROR_ALREADY_EXISTS: outro processo já tem a trava
            k.CloseHandle(h)
            return False
        _MUTEX = h
        return True
    except Exception:
        return None


def _soltar_mutex():
    global _MUTEX
    h, _MUTEX = _MUTEX, None
    if h:
        try:
            k = ctypes.WinDLL("kernel32")
            k.CloseHandle.argtypes = [ctypes.c_void_p]
            k.CloseHandle(h)
        except Exception:
            pass


def pegar_trava():
    """Evita duas execuções ao mesmo tempo (ex.: agendamento + execução manual).
    No Windows quem decide é uma trava do próprio sistema: não tem como dois processos pegarem juntos, e ela some
    sozinha se o bot fechar de repente. O arquivo .executando fica como informação (e como trava fora do Windows)."""
    mutex = _pegar_mutex()
    if mutex is False:
        return False
    if mutex is None:  # sem a trava do Windows: confere pelo arquivo
        try:
            with open(LOCK_FILE, encoding="utf-8") as f:
                info = json.load(f)
            if processo_vivo(info["pid"]) and time.time() - info["t"] < 3 * 3600 and info["pid"] != os.getpid():
                return False
        except (OSError, ValueError, KeyError, TypeError):
            pass
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "t": time.time()}, f)
    except OSError:
        if mutex is None:
            raise
    return True


def soltar_trava():
    _soltar_mutex()
    try:
        with open(LOCK_FILE, encoding="utf-8") as f:
            nosso = json.load(f).get("pid") == os.getpid()
        if nosso:  # só depois de fechar: o Windows não apaga um arquivo que ainda está aberto
            os.remove(LOCK_FILE)
    except (OSError, ValueError, AttributeError):
        pass

# Tudo o que as partes da janela importam daqui
__all__ = ['AGENDA_FILE', 'APP_DIR', 'CONFIG_APP', 'DATA_VERSAO', 'DEFAULT_FILE', 'DICAS',
           'FIELDS', 'FONT', 'HAS_CV', 'HISTORICO', 'ICONES', 'IMG_DIR',
           'Image', 'ImageGrab', 'ImageStat', 'ImageTk', 'JS_ROLAGEM', 'LOCK_FILE',
           'LOG_DIR', 'Motor', 'NOME', 'Navegador', 'PERFIL_CHROME', 'PRECISA_TELA',
           'Painel', 'SCRIPT', 'TEMA_CLARO', 'TEMA_ESCURO', 'TIPOS', 'TIPOS_PLANILHA',
           'TIPO_POR_NOME', 'UiBase', 'VERSAO', 'WIN', '_CTX_VALIDAR', '_CtxValidar',
           '_UiApp', 'abrir_chrome', 'abrir_texto', 'agm', 'caminho_abs', 'caminho_rel',
           'cat', 'cdp_disponivel', 'cdp_ids', 'cdp_json', 'ctypes', 'datetime',
           'deslocamento_vertical', 'diag', 'expandir_teste', 'exportador', 'filedialog', 'jc',
           'json', 'marcar_aba_nova', 'messagebox', 'misturar', 'navm', 'np',
           'os', 'parse_teclas', 'pegar_trava', 'pixels_rolagem', 'pkb', 'pms',
           'processo_vivo', 'proteger_texto', 'pyautogui', 'queue', 'resumo', 'soltar_trava',
           'subprocess', 'sys', 'tb', 'threading', 'time', 'tk',
           'ttk', 'unicodedata', 'versoes', 'xlm']
