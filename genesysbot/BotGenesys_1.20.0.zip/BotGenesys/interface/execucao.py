# -*- coding: utf-8 -*-
"""Execução: pergunta do Excel, rodar o roteiro, pausar/parar e o final.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
from painel import _estilo_janela, arrastavel
from interface.comum import (AGENDA_FILE, APP_DIR, LOG_DIR, PERFIL_CHROME, PRECISA_TELA, WIN, agm, datetime,
                             exportador, filedialog, messagebox, os, pegar_trava, soltar_trava, tb, threading,
                             time, tk, xlm)
import diario
from versao import VERSAO


class ExecucaoMixin:

    # ------------------------------------------------------------ execução --
    def _cfg(self):
        def num(var, padrao, tipo=float):
            try:
                return tipo(str(var.get()).replace(",", "."))
            except ValueError:
                return padrao
        return {"visual": self.v_visual.get(), "vel": max(0.1, self.v_vel.get()),
                "pausa": max(0.0, num(self.v_pausa, 0.5)), "rep": max(1, num(self.v_rep, 1, int)),
                "contagem": max(0, num(self.v_cont, 3, int)), "minimizar": self.v_min.get(),
                "tent": max(1, num(self.v_tent, 2, int)), "so_um": False, "max_chrome": self.v_max_chrome.get(),
                "segundo_plano": self.v_fundo.get(),
                "planilha_arquivo": os.path.abspath(self.dados_arquivo) if self.dados_arquivo else None,
                "planilha_aba": self.v_aba.get() or None, "coluna_status": self.v_col_status.get().strip() or "Status",
                "escrever_resultado": self.v_escrever.get(), "pular_ok": self.v_pular_ok.get(),
                "continuar_erro": self.v_continuar.get()}

    def executar(self, inicio=0, so_um=False):
        if self.running or self.gravando:
            return
        if not self.steps:
            if self.auto:
                self.codigo_saida = 1
                self._fim("roteiro vazio")
            else:
                messagebox.showinfo("Executar", "Adicione passos ao roteiro primeiro (ou grave o processo com F4).")
            return
        cfg = self._cfg()
        itens = list(enumerate(self.steps))[inicio:]
        if so_um:
            itens = [(inicio, dict(self.steps[inicio], ativo=True))]
        ativos = [s for _, s in itens if s.get("ativo", True)]
        if not self.auto and any(s["tipo"].startswith("excel_") for s in ativos):
            modo = self._perguntar_modo_excel()
            if modo is None:
                return
            cfg["excel_visivel"] = modo == "ver"
            if not any(s["tipo"] in PRECISA_TELA or s["tipo"] in ("abrir_chrome", "aguardar_carregar", "ler_pagina")
                       for s in ativos):  # roteiro só de Excel: nada usa mouse/teclado
                cfg["segundo_plano"], cfg["contagem"] = modo == "fundo", 0
                cfg["minimizar"] = cfg["minimizar"] and modo == "ver"
        if any(p.poll() is None for p in self.filhos.values()) or not pegar_trava():
            msg = "Já existe outra execução do bot em andamento."
            if self.auto:
                self.codigo_saida = 3
                self._fim(msg)
            else:
                messagebox.showwarning("Executar", msg)
            return
        if so_um:
            cfg["rep"], cfg["contagem"], cfg["so_um"] = 1, min(cfg["contagem"], 2), True
        self.running = True
        self._t_execucao = time.time()
        self._fundo_atual = cfg["segundo_plano"]
        self._execucao_parcial = so_um  # 'testar só este passo' não conta como execução que deu certo
        for b in (self.btn_run, self.btn_run_sel, self.btn_rec, self.btn_agendar):
            b.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.btn_pause.config(state="normal", text="❚❚  Pausar")
        self._set_estado("▶ EM SEGUNDO PLANO" if self._fundo_atual else "▶ EXECUTANDO", "info")
        self._progresso(0, 1, "Preparando...")
        if cfg["minimizar"] and not self.auto and not self._fundo_atual:
            self.root.iconify()
        nome = f"AGENDADO · {self._nome_agendamento()}" if self.agendamento else ""
        if self._fundo_atual:
            self._overlay_mostrar("você pode continuar usando o computador", nome or "BOT GENESYS · SEGUNDO PLANO",
                                  modo="fundo")
        else:
            self._overlay_mostrar(titulo=nome or "BOT GENESYS · EXECUTANDO")
        threading.Thread(target=self._rodar, args=(itens, cfg), daemon=True).start()

    def _perguntar_modo_excel(self):
        """Antes de rodar um roteiro com passos de Excel: segundo plano (invisível) ou ver o processo?
        Devolve 'fundo', 'ver' ou None (cancelou)."""
        win = tb.Toplevel(title="Executar no Excel")
        win.transient(self.root)
        win.resizable(False, False)
        escolha = {"v": None}
        corpo = tb.Frame(win, padding=22)
        corpo.pack(fill="both", expand=True)
        tb.Label(corpo, text="▦  Este roteiro trabalha no Excel", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        tb.Label(corpo, text="Como você quer rodar?", bootstyle="secondary").pack(anchor="w", pady=(2, 14))

        def opcao(valor, titulo, texto, estilo):
            def esc():
                escolha["v"] = valor
                win.destroy()
            b = tb.Button(corpo, text=titulo, bootstyle=estilo, command=esc, width=40)
            b.pack(fill="x", ipady=6)
            tb.Label(corpo, text=texto, bootstyle="secondary", wraplength=380, justify="left").pack(anchor="w",
                                                                                                   pady=(3, 12))
            return b
        b1 = opcao("fundo", "◐  Em segundo plano (Excel invisível)",
                   "Mais rápido. O Excel trabalha escondido e você pode continuar usando o computador.", "primary")
        opcao("ver", "👁  Quero ver o processo (Excel visível)",
              "O Excel abre maximizado e você acompanha cada célula, tabela e gráfico sendo feito. "
              "Evite mexer na planilha enquanto ele trabalha.", "info-outline")
        tb.Button(corpo, text="Cancelar", bootstyle="secondary-link", command=win.destroy).pack(anchor="e")
        win.bind("<Escape>", lambda e: win.destroy())
        win.bind("<Return>", lambda e: b1.invoke())
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_height()) // 3
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
        win.grab_set()
        b1.focus_set()
        self.root.wait_window(win)
        return escolha["v"]

    def _nome_agendamento(self):
        for a in agm.carregar(AGENDA_FILE):
            if a.get("id") == self.agendamento:
                return a.get("nome", "")
        return ""

    def executar_do_selecionado(self):
        i = self._sel()
        self.executar(i if i is not None else 0)

    def testar_passo(self):
        i = self._sel()
        if i is None:
            messagebox.showinfo("Testar", "Selecione um passo na lista.")
            return
        self.executar(i, so_um=True)

    def parar(self):
        self.motor.parar()

    def pausar(self):
        if not self.running:
            return
        m = self.motor
        m.pausado = not m.pausado
        self.btn_pause.config(text="▶  Continuar" if m.pausado else "❚❚  Pausar")
        self._set_estado("❚❚ PAUSADO" if m.pausado else "▶ EXECUTANDO", "warning" if m.pausado else "info")
        self.log("Pausado." if m.pausado else "Continuando...")
        self.painel.pausado(m.pausado)
        if m.pausado:
            self._overlay_texto("Pausado — clique em Continuar" if self._fundo_atual else
                                "PAUSADO\nF2 para continuar  ·  ESC para parar", "#ffb300")

    # ------------------------------------------------------------ passo 'Pausar: esperar você'
    def _mostrar_pausa(self, sim):
        self.btn_pause.config(text="▶  Continuar" if sim else "❚❚  Pausar")
        self._set_estado("❚❚ ESPERANDO VOCÊ" if sim else "▶ EXECUTANDO", "warning" if sim else "info")
        self.painel.pausado(sim)

    def _cartao_aguardar(self, msg):
        self._fim_cartao_aguardar(so_fechar=True)
        if not self.running:
            return
        self._mostrar_pausa(True)
        c = tk.Toplevel(self.root)
        c.overrideredirect(True)
        c.attributes("-topmost", True)
        c.configure(bg="#1f2229", highlightthickness=2, highlightbackground="#ffb300")
        tk.Label(c, text="arraste para mover  ✥", fg="#868e96", bg="#1f2229", font=("Segoe UI", 7),
                 anchor="e").pack(fill="x", padx=8, pady=(4, 0))
        tk.Label(c, text="✋  O ROBÔ ESTÁ ESPERANDO VOCÊ", fg="#ffb300", bg="#1f2229",
                 font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=14, pady=(10, 4))
        tk.Label(c, text=msg, fg="#f1f3f5", bg="#1f2229", font=("Segoe UI", 10), justify="left", wraplength=380,
                 anchor="w").pack(fill="x", padx=14)
        base = tk.Frame(c, bg="#1f2229")
        base.pack(fill="x", padx=14, pady=(10, 12))
        for texto, acao, cor in (("▶  Continuar", self._continuar_aguardo, "#40c057"), ("■  Parar", self.parar, "#fa5252")):
            b = tk.Label(base, text=texto, fg="#1f2229", bg=cor, font=("Segoe UI", 9, "bold"), padx=12, pady=4,
                         cursor="hand2")
            b.bind("<Button-1>", lambda e, a=acao: a())
            b.pack(side="left", padx=(0, 8))
        c.update_idletasks()
        x = self.root.winfo_screenwidth() - c.winfo_reqwidth() - 24
        self.painel._posicionar(c, "esperando", max(0, x), 120)
        _estilo_janela(c, atravessar_cliques=False)  # não rouba o foco da página do login
        arrastavel(c, self.painel._lembrar("esperando"))
        self._cartao = c
        try:
            self.root.bell()
        except tk.TclError:
            pass

    def _continuar_aguardo(self):
        self.motor.pausado = False
        self._fim_cartao_aguardar()

    def _fim_cartao_aguardar(self, so_fechar=False):
        c = getattr(self, "_cartao", None)
        self._cartao = None
        if c is not None:
            try:
                c.destroy()
            except tk.TclError:
                pass
        if not so_fechar and self.running:
            self._mostrar_pausa(False)

    def _destacar(self, i):
        def _d():
            for iid in self.tree.get_children():
                tags = [t for t in self.tree.item(iid, "tags") if t != "rodando"]
                if iid == str(i):
                    tags.append("rodando")
                    self.tree.see(iid)
                self.tree.item(iid, tags=tags)
        self.post(_d)

    def _rodar(self, itens, cfg):
        dados = self.dados
        if self.dados_arquivo and not cfg.get("so_um"):
            try:  # lê de novo: a planilha pode ter mudado (status OK de execuções anteriores)
                dados = xlm.ler_planilha(self.dados_arquivo, cfg.get("planilha_aba"))
            except Exception as e:
                self.log(f"Aviso: não consegui reler a planilha ({e}); usando a versão carregada.", "erro")
        codigo, erro = self.motor.rodar(self.steps, itens, cfg, dados)
        self.codigo_saida = codigo
        self.post(lambda: self._fim(erro))

    def _fim(self, erro):
        self.running = False
        soltar_trava()
        self._destacar(None)
        for b in (self.btn_run, self.btn_run_sel, self.btn_rec, self.btn_agendar):
            b.config(state="normal")
        self.btn_stop.config(state="disabled")
        self.btn_pause.config(state="disabled", text="❚❚  Pausar")
        self._set_estado("PRONTO", "success")
        n = sum(1 for s in self.steps if s.get("ativo", True))
        if self.codigo_saida == 0 and self.motor.avisos:
            res, msg = "aviso", (f"{n} passos executados, com {self.motor.avisos} aviso(s) — veja o log "
                                 "(ex.: elemento não encontrado, usou a posição gravada).")
        elif self.codigo_saida == 0:
            res, msg = "ok", f"{n} passos executados{' em segundo plano' if self._fundo_atual else ''}."
        elif self.codigo_saida == 2:
            res, msg = "parado", "Execução interrompida."
        else:
            res, msg = "erro", (erro or "erro desconhecido")[:300] + "\nO print do momento do erro está na pasta logs."
            if not self.auto:
                self.log("Dica: menu IA › Explicar o último erro — a IA lê o log e o print e diz o que mudar.")
        self._registrar_no_historico(res, erro)
        if self.agendamento:
            agora = datetime.datetime.now().strftime("%d/%m %H:%M")
            r = {0: f"✓ ok ({agora})", 2: f"■ interrompido ({agora})", 3: f"⚠ pulado: outra execução ({agora})"}.get(
                self.codigo_saida, f"✗ erro ({agora}): {(erro or '')[:80]}")
            try:
                agm.registrar_resultado(AGENDA_FILE, self.agendamento, r)
            except Exception:
                pass
        if self.auto:
            if self.codigo_saida in (0, 1, 2):
                self.painel.final(res, (f"Agendamento: {self._nome_agendamento()}\n" if self.agendamento else "")
                                  + msg, ao_ver_log=self._abrir_log_hoje,
                                  fechar_em=6000 if res == "ok" else 30000)
            self.root.after(6500 if res == "ok" else 30500, self.root.destroy)
            return
        self.painel.final(res, msg, ao_ver_log=self._abrir_log_hoje)
        if not self._fundo_atual:
            self.root.deiconify()
            self.root.lift()
        self._progresso(1 if res in ("ok", "aviso") else 0, 1,
                        {"ok": "Concluído", "aviso": "Concluído com avisos", "parado": "Interrompido",
                         "erro": "Erro na execução"}[res])
        if res == "ok" and getattr(self, "_solucao_ia_pendente", False) and not getattr(self, "_execucao_parcial", False):
            self._salvar_solucao_que_deu_certo()  # avisa por conta própria
        elif res == "ok":
            self._toast("Execução concluída", msg)
        self.codigo_saida = 0
        self._fundo_atual = False

    def _registrar_no_historico(self, res, erro):
        """Uma linha por execução em logs/execucoes.jsonl (Ajuda → Histórico de execuções)."""
        try:
            inicio, self._t_execucao = getattr(self, "_t_execucao", None), None
            falhou = (self.motor.ultimo_erro or {}).get("passo") if res == "erro" else None
            diario.registrar_execucao(LOG_DIR, {
                "roteiro": os.path.basename(self.arquivo) if self.arquivo else "(sem nome)", "resultado": res,
                "duracao_s": round(time.time() - inicio) if inicio else 0,
                "passos": sum(1 for s in self.steps if s.get("ativo", True)), "avisos": self.motor.avisos,
                "erro": (erro or "")[:300] if res == "erro" else "",
                "passo_falhou": falhou + 1 if isinstance(falhou, int) else None,
                "modo": "segundo plano" if self._fundo_atual else "tela",
                "agendamento": self._nome_agendamento() if self.agendamento else "",
                "parcial": bool(getattr(self, "_execucao_parcial", False)), "versao": VERSAO})
        except Exception as e:
            diario.detalhe(LOG_DIR, "não consegui registrar a execução no histórico", diario.texto_erro(e))

    def exportar_python(self):
        if not self.steps:
            messagebox.showinfo("Exportar", "Grave ou monte o roteiro antes de exportar.")
            return
        base = os.path.splitext(os.path.basename(self.arquivo or "roteiro"))[0]
        destino = filedialog.asksaveasfilename(initialdir=APP_DIR, initialfile=f"bot_{base}.py",
                                               defaultextension=".py", filetypes=[("Python", "*.py")],
                                               title="Exportar o bot como arquivo Python")
        if not destino:
            return
        try:
            info = exportador.exportar(self.steps, self._cfg(), destino, APP_DIR, PERFIL_CHROME, self.dados_arquivo)
        except Exception as e:
            messagebox.showerror("Exportar", f"Não foi possível exportar:\n{e}")
            return
        self.log(f"Exportado para {destino}: {info['passos']} passos, {info['imagens']} imagens embutidas "
                 f"({info['tamanho'] // 1024} KB).", "ok")
        if messagebox.askyesno("Exportado",
                               f"Arquivo criado:\n{destino}\n\n{info['passos']} passos e {info['imagens']} imagens "
                               "embutidas. Para rodar: python " + os.path.basename(destino) +
                               "\n(opções: --segundo-plano, --rapido, --csv planilha.csv)\n\nAbrir a pasta?"):
            if WIN:
                os.startfile(os.path.dirname(destino))

    def _abrir_log_hoje(self):
        caminho = os.path.join(LOG_DIR, f"bot_{datetime.date.today():%Y%m%d}.log")
        if WIN and os.path.exists(caminho):
            os.startfile(caminho)
        elif WIN:
            os.startfile(LOG_DIR)
