# -*- coding: utf-8 -*-
"""Gravação do processo (F4): cliques, digitação, teclas e rolagem.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
from interface.comum import (HAS_CV, IMG_DIR, ImageGrab, ImageStat, JS_ROLAGEM, Navegador, PRECISA_TELA, TIPOS,
                             WIN, abrir_chrome, caminho_rel, cdp_disponivel, cdp_ids, cdp_json, ctypes,
                             datetime, deslocamento_vertical, jc, marcar_aba_nova, messagebox, np, os,
                             pixels_rolagem, pkb, pms, pyautogui, resumo, tb, threading, time, tk, ttk,
                             unicodedata)


class GravadorMixin:

    # ------------------------------------------------------------ gravação --
    ACENTOS = {"´": "́", "`": "̀", "~": "̃", "^": "̂", "¨": "̈"}
    ACENTO_SOLTO = {"́": "´", "̀": "`", "̃": "~", "̂": "^", "̈": "¨"}

    def alternar_gravacao(self):
        if self.gravando:
            self.parar_gravacao()
        elif not self.running:
            self._dialogo_gravacao()

    def _dialogo_gravacao(self):
        if not pkb or not pms:
            messagebox.showerror("Gravação", "Instale o pynput (pip install pynput) para gravar.")
            return
        self.root.deiconify()
        d = tb.Toplevel(title="Gravar processo", transient=self.root)
        d.resizable(False, False)
        d.attributes("-topmost", True)
        f = ttk.Frame(d, padding=16)
        f.pack()
        tb.Label(f, justify="left", font=("Segoe UI", 10),
                 text="Faça o processo normalmente no Chrome: cada clique, texto digitado, tecla e\n"
                      "rolagem vira um passo do roteiro, com a posição exata do mouse.\n\n"
                      "F4 = parar a gravação      F9 = marcar um ponto sem clicar").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        sel = self._sel()
        v_abrir = tk.BooleanVar(value=not self.steps)
        v_url = tk.StringVar(value=self._ultima_url or "https://")
        v_rec = tk.BooleanVar(value=True)
        v_esp = tk.BooleanVar(value=True)
        v_lim = tk.StringVar(value="2")
        v_onde = tk.BooleanVar(value=sel is not None)
        ttk.Checkbutton(f, text="Começar abrindo o Chrome nesta URL (modo controlado):",
                        variable=v_abrir).grid(row=1, column=0, columnspan=2, sticky="w")
        ttk.Entry(f, textvariable=v_url, width=60).grid(row=2, column=0, columnspan=2, sticky="we", pady=(2, 10))
        ttk.Checkbutton(f, text="Guardar recorte da imagem de cada clique (corrige a posição se a tela mudar)",
                        variable=v_rec).grid(row=3, column=0, columnspan=2, sticky="w")
        fr = ttk.Frame(f)
        fr.grid(row=4, column=0, columnspan=2, sticky="w")
        ttk.Checkbutton(fr, text="Depois de um clique, pausas maiores que", variable=v_esp).pack(side="left")
        ttk.Entry(fr, textvariable=v_lim, width=4).pack(side="left", padx=4)
        ttk.Label(fr, text="s viram 'aguardar página carregar'").pack(side="left")
        if sel is not None:
            ttk.Checkbutton(f, text=f"Inserir depois do passo selecionado (#{sel + 1}) em vez do final",
                            variable=v_onde).grid(row=5, column=0, columnspan=2, sticky="w")

        def comecar():
            try:
                lim = max(0.5, float(v_lim.get().replace(",", ".")))
            except ValueError:
                lim = 2.0
            url = v_url.get().strip()
            cfg = {"abrir": v_abrir.get() and url not in ("", "https://", "http://"), "url": url,
                   "recorte": v_rec.get(), "esperas": v_esp.get(), "limite": lim,
                   "pos": (sel + 1) if (sel is not None and v_onde.get()) else len(self.steps)}
            d.destroy()
            self._comecar_gravacao(cfg)

        bb = ttk.Frame(f)
        bb.grid(row=6, column=0, columnspan=2, sticky="e", pady=(14, 0))
        tb.Button(bb, text="●  Começar a gravar", bootstyle="danger", command=comecar, padding=(12, 7)).pack(
            side="left", padx=4)
        tb.Button(bb, text="Cancelar", bootstyle="secondary-outline", command=d.destroy, padding=(12, 7)).pack(
            side="left")
        d.bind("<Return>", lambda e: comecar())
        d.bind("<Escape>", lambda e: d.destroy())
        d.grab_set()
        d.focus_force()

    def _comecar_gravacao(self, cfg):
        self._snap()
        self.gravando = True
        self._rec = {"cfg": cfg, "pos": cfg["pos"], "texto_idx": None, "mods": set(), "ultimo_t": time.time(),
                     "n": 0, "acento": None, "t_tecla": 0.0, "t_rolar": 0.0}
        self._t_roda, self._rol_cdp = 0.0, False
        self._rec_ult_thread = None
        self._rec_tela, self._rec_pag = [], []
        threading.Thread(target=self._rec_conectar_pagina, daemon=True).start()
        if cfg["abrir"]:
            self._ultima_url = cfg["url"]
            self._rec_add({"tipo": "abrir_chrome", "descricao": "Abrir sistema de chamados", "url": cfg["url"],
                           "maximizar": True, "controle": True, "aguardar": True, "espera": 1.0})
            antes, ids_antes = set(jc.listar_chrome()), cdp_ids()
            abrir_chrome(cfg["url"], True)
            threading.Thread(target=lambda: marcar_aba_nova(ids_antes, 15, cfg["url"]), daemon=True).start()
            if jc.WIN:
                threading.Thread(target=lambda: jc.garantir_maximizado(jc.aguardar_nova_janela(antes, 15)),
                                 daemon=True).start()
            else:
                self.root.after(2500, lambda: self._sem_gravar(lambda: pyautogui.hotkey("win", "up")))
        elif self.v_max_chrome.get() and jc.WIN:
            hwnd, antes, corrigiu = jc.garantir_maximizado(frente=True)
            if corrigiu:
                self.log(f"Chrome estava {antes['descricao']} → maximizado antes de gravar.", "ok")
        self._set_estado("● GRAVANDO", "danger")
        self.btn_rec.config(text="■  Parar gravação")
        for b in (self.btn_run, self.btn_run_sel):
            b.config(state="disabled")
        self.root.iconify()
        self._overlay_mostrar("F4 = parar gravação     F9 = marcar ponto sem clicar", "● GRAVANDO", "#ff6b6b")
        self._rec_overlay("pode começar")
        extra = {"win32_event_filter": self._rec_filtro_win} if WIN else {}
        self.mouse_listener = pms.Listener(on_click=self._rec_on_click, on_scroll=self._rec_on_scroll, **extra)
        self.mouse_listener.daemon = True
        self.mouse_listener.start()
        self._t_roda = 0.0
        self._rol_cdp = False
        threading.Thread(target=self._monitor_rolagem, daemon=True).start()
        self.log("● Gravação iniciada. Aperte F4 para parar.", "ok")

    def parar_gravacao(self):
        if not self.gravando:
            return
        self.gravando = False
        if self.mouse_listener:
            self.mouse_listener.stop()
            self.mouse_listener = None
        if self._rec_nav:
            self._rec_nav.fechar()
            self._rec_nav = None
        # remove textos vazios (ex.: digitou e apagou tudo)
        antes = len(self.steps)
        self.steps = [p for p in self.steps if not (p["tipo"] == "digitar" and not p.get("texto"))
                      and not (p["tipo"] == "rolar" and abs(pixels_rolagem(p)) < 3)]
        for p in self.steps:
            p.pop("_px", None)
            p.pop("_tk", None)
        n = self._rec["n"] - (antes - len(self.steps))
        self._overlay_esconder()
        self._set_estado("PRONTO", "success")
        self.btn_rec.config(text="●  Gravar processo")
        for b in (self.btn_run, self.btn_run_sel):
            b.config(state="normal")
        self.root.deiconify()
        self.root.lift()
        self._refresh(min(self._rec["pos"], len(self.steps)) - 1)
        self.log(f"■ Gravação concluída: {n} passos. Revise (descrições, esperas) e salve com Ctrl+S.", "ok")
        self._toast("Gravação concluída", f"{n} passos gravados. Revise e salve com Ctrl+S.")

    def _rec_conectar_pagina(self):
        """Com o Chrome controlado, grava também QUAL elemento foi clicado (para o segundo plano e mais precisão)."""
        while self.gravando and not self._rec_nav:
            if cdp_disponivel():
                try:
                    self._rec_nav = Navegador()
                    self._rec_nav.gravar(lambda dados, t: self.post(lambda: self._rec_casar(dados, t)))
                    self.log("Gravando também o elemento clicado em cada página (Chrome controlado).")
                    return
                except Exception:
                    self._rec_nav = None
            time.sleep(1.0)

    def _rec_casar(self, dados=None, t=None):
        """Junta o clique visto na tela (posição) com o clique visto na página (elemento)."""
        if dados is not None:
            self._rec_pag.append((t, dados))
        agora = time.time()
        self._rec_tela = [(tt, p) for tt, p in self._rec_tela if agora - tt < 4]
        self._rec_pag = [(tt, d) for tt, d in self._rec_pag if agora - tt < 4]
        botoes = {0: "esquerdo", 1: "meio", 2: "direito"}
        mudou = False
        for tp, d in list(self._rec_pag):
            for tt, passo in list(self._rec_tela):
                if abs(tt - tp) <= 1.5 and passo.get("botao") == botoes.get(d.get("botao"), "esquerdo"):
                    passo["alvo"] = {k: d.get(k) for k in ("sel", "xpath", "texto", "tag", "tipo", "nome", "rotulo",
                                                            "ox", "oy", "w", "h", "frame")}
                    if not d.get("frame") and d.get("dpr"):
                        dpr = float(d["dpr"])
                        passo["vp"] = [round(passo["x"] - d["cx"] * dpr, 1), round(passo["y"] - d["cy"] * dpr, 1),
                                       dpr]
                    self._rec_tela.remove((tt, passo))
                    self._rec_pag.remove((tp, d))
                    mudou = True
                    break
        if mudou and self.gravando:
            self._rec_atualizado()

    def _sem_gravar(self, fn):
        self.sending = True
        try:
            fn()
        finally:
            self.root.after(300, lambda: setattr(self, "sending", False))

    def _rec_overlay(self, ultimo):
        self._overlay_texto(f"{self._rec['n']} passos gravados\núltimo: {ultimo[:70]}")

    def _rec_anterior(self):
        p = self._rec["pos"]
        return self.steps[p - 1] if 0 < p <= len(self.steps) else None

    def _rec_add(self, passo):
        if jc.WIN and passo.get("tipo") in PRECISA_TELA and "janela" not in passo:
            try:  # em qual programa foi a ação (Chrome, Excel, sistema desktop...)
                h = jc.janela_no_ponto(passo["x"], passo["y"]) if "x" in passo else jc.janela_em_foco()
                j = jc.info_janela(h)
                if j:
                    passo["janela"] = j
            except Exception:
                pass
        self.steps.insert(self._rec["pos"], passo)
        self._rec["pos"] += 1
        self._rec["n"] += 1
        self.dirty = True
        self._rec_atualizado()

    def _rec_atualizado(self):
        self._refresh(self._rec["pos"] - 1)
        ant = self._rec_anterior()
        if ant:
            self._rec_overlay(f"{TIPOS[ant['tipo']]}: {resumo(ant)}")

    def _rec_pausa(self, agora):
        """Se o usuário ficou esperando depois de um clique, o clique ganha 'aguardar carregar'."""
        cfg, gap = self._rec["cfg"], agora - self._rec["ultimo_t"]
        self._rec["ultimo_t"] = agora
        ant = self._rec_anterior()
        if cfg["esperas"] and ant and gap >= cfg["limite"] and ant["tipo"] in ("clique", "clicar_imagem"):
            ant["aguardar"] = True

    def _dentro_da_janela(self, x, y):
        try:
            if self.root.state() == "iconic":
                return False
            rx, ry = self.root.winfo_rootx(), self.root.winfo_rooty()
            return rx <= x <= rx + self.root.winfo_width() and ry <= y <= ry + self.root.winfo_height()
        except Exception:
            return False

    # -- chamados na thread do pynput (só coletam dados e mandam para a interface)
    def _rec_on_click(self, x, y, button, pressed):
        if not self.gravando or self.sending:
            return
        if self.painel.contem(x, y, margem=0):
            return  # clique/arrasto na caixinha de status do bot: não é parte do processo
        botao = {pms.Button.left: "esquerdo", pms.Button.right: "direito", pms.Button.middle: "meio"}.get(button)
        if not botao:
            return
        x, y, agora = int(x), int(y), time.time()
        if not pressed:
            self._rec_soltou(x, y, botao, agora)
            return
        if jc.WIN and self.v_max_chrome.get() and self._rec_maximizar_no_clique(x, y):
            return
        segurar = self._rec_segurar_agora()  # Ctrl/Shift lidos agora, no instante do clique
        token = self._rec_novo_token()
        self._rec_apertou = {"x": x, "y": y, "botao": botao, "t": agora, "token": token}
        u = self._rec_ult_thread
        duplo = bool(u and u[2] == botao and agora - u[3] < 0.45 and abs(u[0] - x) <= 6 and abs(u[1] - y) <= 6)
        self._rec_ult_thread = (x, y, botao, agora)
        img = None
        if not duplo and self._rec["cfg"]["recorte"]:
            try:
                sw, sh = pyautogui.size()
                l, t = max(0, x - 60), max(0, y - 22)
                recorte = ImageGrab.grab(bbox=(l, t, min(sw, x + 60), min(sh, y + 22)))
                if ImageStat.Stat(recorte.convert("L")).stddev[0] >= 12:  # recorte "liso" não serve de referência
                    os.makedirs(IMG_DIR, exist_ok=True)
                    caminho = os.path.join(IMG_DIR, datetime.datetime.now().strftime("rec_%Y%m%d_%H%M%S_%f.png"))
                    recorte.save(caminho)
                    img = (caminho_rel(caminho), l, t)
            except Exception:
                img = None
        if not duplo:
            self._rec_pedir_celula(token, "alvo_excel", x, y)
        self.post(lambda: self._rec_clique(x, y, botao, duplo, img, agora, segurar, token))

    def _rec_maximizar_no_clique(self, x, y):
        """Clique numa janela minimizada pela metade/solta: maximiza e NÃO grava esse clique
        (a posição só vale com a janela maximizada, igual vai estar na execução)."""
        try:
            h = jc.janela_no_ponto(x, y)
            info = jc.info_janela(h)
            if not info or not jc.maximizavel(h):
                return False
            e = jc.estado(h)
            if not e or e["ok"]:
                return False
            jc.garantir_maximizado(h, frente=True)
        except Exception:
            return False
        prog = info["processo"].removesuffix(".exe").upper()
        msg = f"Janela do {prog} estava {e['descricao']} → maximizada. Clique de novo (esse clique não foi gravado)."

        def _avisar():
            self.log(msg, "ok")
            self._overlay_texto(f"⤢ {prog} maximizado — clique de novo", "#ffb300")
        self.post(_avisar)
        return True

    def _rec_on_scroll(self, x, y, dx, dy):
        # No Windows a roda é lida em _rec_filtro_win (valor bruto, sem perder rolagens "suaves").
        if WIN or not self.gravando or self.sending or not dy:
            return
        self._t_roda = time.time()
        if not self._rol_cdp:
            self.post(lambda: self._rec_rolar_px(int(x), int(y), -dy * 100, "roda"))

    def _rec_filtro_win(self, msg, data):
        """Recebe cada evento de mouse do Windows; pega o giro bruto da roda (120 = 1 'clique')."""
        if msg == 0x020A and self.gravando and not self.sending:  # WM_MOUSEWHEEL
            delta = ctypes.c_short((data.mouseData >> 16) & 0xFFFF).value
            if delta:
                self._t_roda = time.time()
                if not self._rol_cdp:  # com o Chrome controlado a rolagem é lida direto da página
                    px = -delta / 120.0 * jc.linhas_por_clique() * 100 / 3.0
                    x, y = int(data.pt.x), int(data.pt.y)
                    self.post(lambda: self._rec_rolar_px(x, y, px, "roda"))
        return True

    def _regiao_pagina(self):
        """Área do conteúdo da página (sem abas/barra de endereço), para detectar rolagem pela tela."""
        sw, sh = pyautogui.size()
        esc = 1.0
        reg = (0, 0, sw, sh)
        if jc.WIN:
            hwnd = jc.chrome_principal()
            if hwnd:
                reg = jc.retangulo(hwnd) or reg
                esc = jc.escala(hwnd)
        l, t, r, b = reg
        t += int(130 * esc)  # abas + barra de endereço
        larg = r - l
        l, r = l + int(larg * 0.2), r - int(larg * 0.2)
        return (l, t, r, b), esc

    def _monitor_rolagem(self):
        """Durante a gravação: lê a rolagem real da página (Chrome controlado) ou detecta pela tela (touchpad)."""
        ultimo, url, anterior, t_cdp, tem_cdp = {}, None, None, 0.0, False
        while self.gravando:
            try:
                if time.time() - t_cdp > 2:
                    tem_cdp, t_cdp = cdp_disponivel(), time.time()
                    if tem_cdp != self._rol_cdp:
                        self._rol_cdp = tem_cdp
                        self.log("Rolagem: lida direto da página (exata)." if tem_cdp else
                                 "Rolagem: pela roda do mouse e pela tela (touchpad).")
                if tem_cdp:
                    e = cdp_json(JS_ROLAGEM)
                    if e:
                        if e["url"] != url:
                            url, ultimo = e["url"], {"": e["y"]}
                        chave = e["sel"]
                        antes = ultimo.get(chave, 0 if chave else e["y"])
                        if abs(e["top"] - antes) >= 3 and self.gravando:
                            mx, my = pyautogui.position()
                            d, alvo = int(round(e["top"] - antes)), int(round(e["top"]))
                            self.post(lambda d=d, a=alvo, sel=chave, mx=mx, my=my:
                                      self._rec_rolar_cdp(mx, my, d, a, sel))
                        ultimo[chave] = e["top"]
                elif HAS_CV and time.time() - self._t_roda > 0.6:
                    (l, t, r, b), esc = self._regiao_pagina()
                    if r - l > 100 and b - t > 100:
                        img = ImageGrab.grab(bbox=(l, t, r, b)).convert("L")
                        img = img.resize((img.width // 2, img.height // 2))
                        atual = np.asarray(img, dtype=np.float32)
                        if anterior is not None and anterior.shape == atual.shape:
                            dx, dy, conf = deslocamento_vertical(anterior, atual)
                            if conf > 0.25 and abs(dy) >= 1.5 and abs(dx) < 1.5 and time.time() - self._t_roda > 0.6:
                                px = -dy * 2 / esc  # conteúdo subiu na tela = página desceu
                                mx, my = pyautogui.position()
                                self.post(lambda px=px, mx=mx, my=my: self._rec_rolar_px(mx, my, px, "touchpad"))
                        anterior = atual
                else:
                    anterior = None
            except Exception:
                anterior = None
            # pela tela, leituras frequentes = deslocamentos pequenos entre uma imagem e outra (medição confiável)
            time.sleep(0.2 if tem_cdp else 0.07)

    # -- lógica da gravação (thread da interface)
    def _rec_clique(self, x, y, botao, duplo, img, agora, segurar="nenhuma", token=None):
        if not self.gravando or self._dentro_da_janela(x, y):
            return
        ant = self._rec_anterior()
        if duplo and ant and ant["tipo"] == "clique" and ant.get("botao") == botao:
            ant["cliques"] = min(3, int(ant.get("cliques", 1)) + 1)
            self._rec_atualizado()
            return
        self._rec_pausa(agora)
        self._rec["texto_idx"] = None
        self._rec["menu_ate"] = 0  # um clique encerra o "modo menu" do Alt
        passo = {"tipo": "clique", "descricao": "", "x": x, "y": y, "botao": botao, "cliques": 1, "aguardar": False,
                 "_tk": token}
        if segurar and segurar != "nenhuma":
            passo["segurar"] = segurar
        if img:
            passo.update(imagem=img[0], ref_x=img[1], ref_y=img[2], conferir=True)
            self._refs[img[0]] = (img[1], img[2])
        self._rec_add(passo)
        self._rec_tela.append((agora, passo))
        self._rec_casar()
        self._marcador(x, y, cor="#00c853", ms=350)

    def _rec_marcar_ponto(self):
        x, y = pyautogui.position()
        self._rec_pausa(time.time())
        self._rec["texto_idx"] = None
        self._rec_add({"tipo": "clique", "descricao": "ponto marcado (F9)", "x": x, "y": y,
                       "botao": "esquerdo", "cliques": 1, "aguardar": False})
        self._marcador(x, y, cor="#2979ff", ms=500)

    def _rec_rolar_px(self, x, y, px, origem):
        """Rolagem pela roda do mouse ou detectada pela tela (px: + desce)."""
        if not self.gravando or self._dentro_da_janela(x, y):
            return
        agora, ant = time.time(), self._rec_anterior()
        if (ant and ant["tipo"] == "rolar" and ant.get("origem") == origem and agora - self._rec["t_rolar"] < 1.5
                and (pixels_rolagem(ant) > 0) == (px > 0)):
            ant["_px"] = ant.get("_px", ant["pixels"]) + px
            ant["pixels"] = int(round(ant["_px"]))
            self._rec_atualizado()
        else:
            self._rec_pausa(agora)
            self._rec["texto_idx"] = None
            self._rec_add({"tipo": "rolar", "descricao": "", "pixels": int(round(px)), "_px": px,
                           "x": x, "y": y, "origem": origem})
        self._rec["t_rolar"] = agora

    def _rec_rolar_cdp(self, x, y, delta, alvo, seletor):
        """Rolagem lida da própria página: guarda a posição exata (vale para touchpad, roda ou barra)."""
        if not self.gravando:
            return
        agora, ant = time.time(), self._rec_anterior()
        if (ant and ant["tipo"] == "rolar" and ant.get("origem") == "pagina" and ant.get("seletor", "") == seletor
                and agora - self._rec["t_rolar"] < 1.5):
            ant["pixels"] = int(ant.get("pixels", 0)) + delta
            ant["alvo_y"] = alvo
            self._rec_atualizado()
        else:
            self._rec_pausa(agora)
            self._rec["texto_idx"] = None
            self._rec_add({"tipo": "rolar", "descricao": "", "pixels": delta, "alvo_y": alvo, "seletor": seletor,
                           "x": x, "y": y, "origem": "pagina"})
        self._rec["t_rolar"] = agora

    @staticmethod
    def _nome_mod(key):
        nome = getattr(key, "name", None) if isinstance(key, pkb.Key) else None
        if not nome:
            return None
        for prefixo, mod in (("ctrl", "ctrl"), ("alt", "alt"), ("shift", "shift"), ("cmd", "win")):
            if nome.startswith(prefixo):
                return mod
        return None

    PONTUACAO_US = {186: ";", 187: "=", 188: ",", 189: "-", 190: ".", 191: "/", 192: "`", 219: "[", 220: "\\",
                    221: "]", 222: "'"}  # reserva, se o Windows não disser o caractere da tecla
    TECLADO_NUMERICO = {106: "multiply", 107: "add", 108: "separator", 109: "subtract", 110: "decimal",
                        111: "divide"}

    @staticmethod
    def _nome_tecla(key):
        if isinstance(key, pkb.Key):
            nome = {"page_up": "pageup", "page_down": "pagedown", "print_screen": "printscreen"}.get(key.name, key.name)
            return nome if nome in pyautogui.KEYBOARD_KEYS else None
        vk = getattr(key, "vk", None)
        if vk is not None:
            if 65 <= vk <= 90 or 48 <= vk <= 57:
                return chr(vk).lower()
            if 96 <= vk <= 105:
                return str(vk - 96)
            if vk in GravadorMixin.TECLADO_NUMERICO:
                return GravadorMixin.TECLADO_NUMERICO[vk]
            if WIN:  # pontuação (; - = , . / ...): o caractere da tecla no SEU teclado (ABNT2, US...)
                try:
                    c = ctypes.windll.user32.MapVirtualKeyW(vk, 2) & 0x7FFF
                    if c and chr(c).lower() in pyautogui.KEYBOARD_KEYS:
                        return chr(c).lower()
                except Exception:
                    pass
            if vk in GravadorMixin.PONTUACAO_US:
                return GravadorMixin.PONTUACAO_US[vk]
        ch = getattr(key, "char", None)
        return ch.lower() if ch and ch.isprintable() and ch.lower() in pyautogui.KEYBOARD_KEYS else None

    def _rec_tecla(self, key, pressionou, mods_reais=None):
        """mods_reais: Ctrl/Alt/Shift/Win lidos do Windows no instante da tecla (mais confiável que contar
        os eventos). Sem eles (fora do Windows), usa a contagem dos eventos."""
        if not self.gravando:
            return
        agora = time.time()
        if mods_reais is not None:
            self._rec["mods"] = set(mods_reais)
        mods = self._rec["mods"]
        mod = self._nome_mod(key)
        if mod:
            if pressionou:
                outros = (mods_reais if mods_reais is not None else mods) - {mod}
                sozinho = self._rec.get("mod_sozinho")
                if not outros and not (sozinho and sozinho[0] == mod):  # (a repetição automática não reinicia)
                    self._rec["mod_sozinho"] = (mod, agora)
                mods.add(mod)
            else:
                mods.discard(mod)
                sozinho, self._rec["mod_sozinho"] = self._rec.get("mod_sozinho"), None
                # Alt (ou Win) apertado e solto SOZINHO: no Excel abre as dicas de tecla da faixa (Alt, H, O, I)
                if sozinho and sozinho[0] == mod and mod in ("alt", "win") and agora - sozinho[1] < 1.5:
                    self._rec_pausa(agora)
                    self._rec_registrar_tecla(mod, agora)
                    self._rec["menu_ate"] = agora + 5 if mod == "alt" else 0
            return
        if not pressionou:
            return
        self._rec["mod_sozinho"] = None
        ch = getattr(key, "char", None)
        combo = mods & {"ctrl", "alt", "win"}
        texto_livre = not combo or combo == {"ctrl", "alt"}  # AltGr = ctrl+alt e gera caracteres (/, ?, °)
        if self._rec.get("menu_ate", 0) > agora and not combo:  # depois de um Alt sozinho: teclas do menu
            nome = self._nome_tecla(key)
            if nome:
                self._rec_pausa(agora)
                self._rec["texto_idx"] = None
                self._rec_registrar_tecla(nome, agora)
                self._rec["menu_ate"] = agora + 5 if len(nome) == 1 and nome.isalnum() else 0
            return
        if ch and texto_livre and (getattr(key, "is_dead", False) or unicodedata.combining(ch)):
            self._rec["acento"] = self.ACENTOS.get(ch, ch if unicodedata.combining(ch) else None)
            return
        if ch and ch.isprintable() and texto_livre:
            self._rec_pausa(agora)
            self._rec_texto(ch)
            return
        if key == pkb.Key.space and not combo:
            self._rec_pausa(agora)
            self._rec_texto(" ")
            return
        nome = self._nome_tecla(key)
        if not nome:
            return
        if combo or ("shift" in mods and len(nome) > 1):
            nome = "+".join([m for m in ("ctrl", "alt", "shift", "win") if m in mods] + [nome])
        self._rec_pausa(agora)
        idx = self._rec["texto_idx"]
        if idx is not None and nome in ("backspace", "enter"):
            passo = self.steps[idx]
            if nome == "backspace" and passo["texto"]:
                passo["texto"] = passo["texto"][:-1]
                self._rec_atualizado()
                return
            if nome == "enter":
                passo["enter"] = True
                self._rec["texto_idx"] = None
                self._rec_atualizado()
                return
        self._rec["texto_idx"] = None
        self._rec_registrar_tecla(nome, agora)

    def _rec_registrar_tecla(self, nome, agora):
        ant = self._rec_anterior()
        if ant and ant["tipo"] == "tecla" and ant["teclas"] == nome and agora - self._rec.get("t_tecla", 0) < 3:
            ant["repetir"] = int(ant.get("repetir", 1)) + 1
            self._rec_atualizado()
        else:
            self._rec_add({"tipo": "tecla", "descricao": "", "teclas": nome, "repetir": 1})
        self._rec["t_tecla"] = agora

    def _rec_texto(self, ch):
        idx = self._rec["texto_idx"]
        if idx is None:
            senha = False
            if self._rol_cdp:
                try:
                    senha = cdp_json("JSON.stringify({t: (document.activeElement || {}).type || ''})")["t"] == "password"
                except Exception:
                    pass
            self._rec_add({"tipo": "digitar", "descricao": "senha" if senha else "", "texto": "", "senha": senha,
                           "limpar": False, "enter": False})
            idx = self._rec["texto_idx"] = self._rec["pos"] - 1
        passo = self.steps[idx]
        texto = passo["texto"]
        marca, self._rec["acento"] = self._rec["acento"], None
        if marca is None and texto and texto[-1] in self.ACENTOS:  # acento veio como caractere comum
            marca, texto = self.ACENTOS[texto[-1]], texto[:-1]
        if marca:
            if ch.isalpha() and len(unicodedata.normalize("NFD", ch)) == 1:
                composto = unicodedata.normalize("NFC", ch + marca)
                ch = composto if len(composto) == 1 else self.ACENTO_SOLTO.get(marca, "") + ch
            elif ch == " ":
                ch = self.ACENTO_SOLTO.get(marca, "")
            elif not ch.isalpha():
                ch = self.ACENTO_SOLTO.get(marca, "") + ch
        passo["texto"] = texto + ch
        self._rec_atualizado()
