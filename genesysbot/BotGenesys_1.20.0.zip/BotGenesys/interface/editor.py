# -*- coding: utf-8 -*-
"""Editor de passos: lista de passos, formulário, captura de posição/imagem e Chrome.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import fluxo
from interface.comum import (APP_DIR, DICAS, FIELDS, FONT, ICONES, IMG_DIR, Image, ImageGrab, ImageTk, TIPOS,
                             TIPOS_PLANILHA, _CTX_VALIDAR, caminho_abs, caminho_rel, cat, datetime, filedialog,
                             jc, json, messagebox, os, pyautogui, resumo, tb, tk, ttk)


class EditorMixin:

    # ---- interação com a lista
    def _menu_contexto(self, e):
        row = self.tree.identify_row(e.y)
        if row:
            self.tree.selection_set(row)
            self.menu_ctx.tk_popup(e.x_root, e.y_root)

    def _drag_ini(self, e):
        row = self.tree.identify_row(e.y)
        self._drag = row if (row and not self.v_filtro.get().strip() and not self.running and not self.gravando) else None
        self._drag_moveu = False

    def _drag_mov(self, e):
        if not self._drag:
            return
        alvo = self.tree.identify_row(e.y)
        if alvo and alvo != self._drag:
            self.tree.move(self._drag, "", self.tree.index(alvo))
            self._drag_moveu = True
            self.tree.configure(cursor="fleur")

    def _drag_fim(self, e):
        self.tree.configure(cursor="")
        if self._drag and self._drag_moveu:
            ordem = [int(i) for i in self.tree.get_children()]
            if ordem != list(range(len(self.steps))):
                self._snap()
                nova = ordem.index(int(self._drag))
                self.steps = [self.steps[i] for i in ordem]
                self.dirty = True
                self._refresh(nova)
        self._drag = None

    # ---- Chrome
    def _tick_chrome(self):
        if not self.auto:
            texto, estilo = self._texto_chrome()
            for lbl in (self.lbl_chrome, self.lbl_chrome2, self.lbl_sb_chrome):
                lbl.config(text=texto, bootstyle=estilo)
        self.root.after(1200, self._tick_chrome)

    def _texto_chrome(self):
        if not jc.WIN:
            return "Chrome: detecção só no Windows", "secondary"
        try:
            hwnd = jc.chrome_principal()
            if not hwnd:
                return "Chrome: ○ não está aberto", "secondary"
            e = jc.estado(hwnd)
            if e["ok"]:
                return "Chrome: ● maximizado", "success"
            return f"Chrome: ● {e['descricao']}", "warning"
        except Exception:
            return "Chrome: ?", "secondary"

    def maximizar_chrome_agora(self):
        if not jc.WIN:
            messagebox.showinfo("Chrome", "Disponível apenas no Windows.")
            return
        hwnd, antes, corrigiu = jc.garantir_maximizado(frente=True)
        if not hwnd:
            self._toast("Chrome", "Nenhuma janela do Chrome aberta.", "warning")
        elif corrigiu:
            self.log(f"Chrome estava {antes['descricao']} → maximizado.", "ok")
        else:
            self.log("Chrome já estava maximizado.")

    # ------------------------------------------------------------ formulário --
    def _set_tipo(self, tipo, step=None, manter=False):
        self.tipo_atual = tipo
        self.v_tipo.set(TIPOS[tipo])
        if step is not None:
            self.v_desc.set(step.get("descricao", ""))
        elif not manter:
            self.v_desc.set("")
        for w in self.form.winfo_children():
            w.destroy()
        self.fvars = {}
        self._preview = None
        row = 0
        for key, label, kind, default, opcoes in FIELDS[tipo]:
            if kind == "pos":
                val = (step.get("x", 0), step.get("y", 0)) if step else default
            else:
                val = step.get(key, default) if step else default
            ttk.Label(self.form, text=label).grid(row=row, column=0, sticky="nw", pady=3, padx=(0, 8))
            if kind == "bool":
                v = tk.BooleanVar(value=bool(val))
                tb.Checkbutton(self.form, variable=v, bootstyle="round-toggle").grid(row=row, column=1, sticky="w")
            elif kind == "choice":
                v = tk.StringVar(value=str(val))
                ttk.Combobox(self.form, textvariable=v, values=opcoes, state="readonly",
                             width=min(32, max(12, max(len(str(o)) for o in opcoes) + 2))).grid(
                    row=row, column=1, sticky="w")
            elif kind == "text":
                v = tb.Text(self.form, height=6, width=40, wrap="word", font=FONT)
                v.insert("1.0", val)
                v.grid(row=row, column=1, sticky="we")
            elif kind == "pos":
                fr = ttk.Frame(self.form)
                fr.grid(row=row, column=1, sticky="w")
                vx, vy = tk.StringVar(value=str(val[0])), tk.StringVar(value=str(val[1]))
                ttk.Label(fr, text="X").pack(side="left")
                ttk.Entry(fr, textvariable=vx, width=6).pack(side="left", padx=(2, 6))
                ttk.Label(fr, text="Y").pack(side="left")
                ttk.Entry(fr, textvariable=vy, width=6).pack(side="left", padx=(2, 6))
                tb.Button(fr, text="Capturar em 3s", bootstyle="info-outline", padding=(6, 3),
                          command=lambda: self._contagem_captura(3)).pack(side="left", padx=2)
                tb.Button(fr, text="Mostrar ponto", bootstyle=self._estilo_neutro(), padding=(6, 3),
                          command=self._mostrar_ponto).pack(side="left", padx=2)
                v = (vx, vy)
            elif kind == "img":
                fr = ttk.Frame(self.form)
                fr.grid(row=row, column=1, sticky="we")
                v = tk.StringVar(value=val)
                ttk.Entry(fr, textvariable=v, width=26).pack(side="left", fill="x", expand=True)
                tb.Button(fr, text="Capturar da tela", bootstyle="info-outline", padding=(6, 3),
                          command=self.capturar_regiao).pack(side="left", padx=2)
                tb.Button(fr, text="Arquivo...", bootstyle=self._estilo_neutro(), padding=(6, 3),
                          command=self._escolher_img).pack(side="left")
                row += 1
                self.lbl_prev = ttk.Label(self.form, text="(sem imagem)", relief="groove", padding=4)
                self.lbl_prev.grid(row=row, column=1, sticky="w", pady=4)
                v.trace_add("write", lambda *a: self._atualizar_preview())
                self._img_var = v
            elif kind == "formula":
                fr = ttk.Frame(self.form)
                fr.grid(row=row, column=1, sticky="we")
                v = tk.StringVar(value=str(val))
                ent = ttk.Entry(fr, textvariable=v, width=34)
                ent.pack(side="left", fill="x", expand=True)
                tb.Button(fr, text="ƒx Funções", bootstyle="info-outline", padding=(6, 3),
                          command=lambda v=v, e=ent: self.escolher_funcao(v, e)).pack(side="left", padx=(4, 0))
            elif kind == "segredo":
                fr = ttk.Frame(self.form)
                fr.grid(row=row, column=1, sticky="w")
                v = tk.StringVar(value=str(val))
                ent = ttk.Entry(fr, textvariable=v, width=34, show="•")
                ent.pack(side="left")
                ver = tk.BooleanVar(value=False)
                ttk.Checkbutton(fr, text="mostrar", variable=ver,
                                command=lambda e=ent, b=ver: e.config(show="" if b.get() else "•")).pack(
                    side="left", padx=(6, 0))
            elif kind == "arq":
                fr = ttk.Frame(self.form)
                fr.grid(row=row, column=1, sticky="we")
                v = tk.StringVar(value=val)
                ttk.Entry(fr, textvariable=v, width=34).pack(side="left", fill="x", expand=True)
                tb.Button(fr, text="...", bootstyle=self._estilo_neutro(), padding=(6, 3), width=3,
                          command=lambda v=v: self._escolher_arquivo(v)).pack(side="left", padx=(4, 0))
            else:
                v = tk.StringVar(value=str(val))
                ttk.Entry(self.form, textvariable=v, width=40 if kind == "str" else 10).grid(
                    row=row, column=1, sticky="w")
            self.fvars[key] = (kind, v)
            row += 1
        self.form.columnconfigure(1, weight=1)
        self.lbl_dica.config(text=DICAS.get(tipo, ""))
        if "imagem" in self.fvars:
            self._atualizar_preview()

    def _ler_form(self):
        d = {"tipo": self.tipo_atual, "descricao": self.v_desc.get().strip()}
        try:
            for key, (kind, v) in self.fvars.items():
                if kind == "pos":
                    d["x"], d["y"] = int(float(v[0].get())), int(float(v[1].get()))
                elif kind == "bool":
                    d[key] = bool(v.get())
                elif kind == "text":
                    d[key] = v.get("1.0", "end-1c")
                elif kind == "int":
                    d[key] = int(float(v.get().replace(",", ".")))
                elif kind == "float":
                    d[key] = float(v.get().replace(",", "."))
                elif kind == "choice":
                    d[key] = int(v.get()) if key == "cliques" else v.get()
                else:
                    d[key] = v.get().strip()
        except ValueError:
            messagebox.showerror("Valor inválido", f"Confira o campo '{key}': precisa ser um número.")
            return None
        erro = cat.validar(d, _CTX_VALIDAR)
        if erro:
            messagebox.showerror(*erro)
            return None
        if d.get("imagem") and d["imagem"] in self._refs:
            d["ref_x"], d["ref_y"] = self._refs[d["imagem"]]
        return d

    def _ler_form_silencioso(self):
        try:
            d = {"tipo": self.tipo_atual, "descricao": self.v_desc.get()}
            for key, (kind, v) in self.fvars.items():
                if kind == "pos":
                    d["x"], d["y"] = v[0].get(), v[1].get()
                elif kind == "text":
                    d[key] = v.get("1.0", "end-1c")
                else:
                    d[key] = v.get()
            return d
        except Exception:
            return None

    def _atualizar_preview(self):
        p = caminho_abs(self._img_var.get()) if "imagem" in self.fvars else ""
        try:
            if p and os.path.exists(p):
                im = Image.open(p)
                info = f"{im.width}x{im.height}px"
                im.thumbnail((260, 110))
                self._preview = ImageTk.PhotoImage(im)
                self.lbl_prev.config(image=self._preview, text=info, compound="top")
                return
        except Exception:
            pass
        self._preview = None
        self.lbl_prev.config(image="", text="(sem imagem)")

    def _escolher_arquivo(self, var):
        salvar = self.tipo_atual == "excel_salvar"
        f = filedialog.asksaveasfilename if salvar else filedialog.askopenfilename
        p = f(initialdir=APP_DIR, filetypes=TIPOS_PLANILHA if not salvar else
              [("Excel", "*.xlsx *.xlsm"), ("PDF", "*.pdf"), ("CSV", "*.csv"), ("Todos", "*.*")])
        if p:
            var.set(caminho_rel(p))

    def _escolher_img(self):
        p = filedialog.askopenfilename(initialdir=IMG_DIR, filetypes=[("Imagens", "*.png *.jpg *.bmp")])
        if p:
            self._img_var.set(caminho_rel(p))

    # ---------------------------------------------------- captura de posição --
    def capturar_pos(self):
        x, y = pyautogui.position()
        if "pos" not in self.fvars:
            self._set_tipo("clique", manter=True)
        vx, vy = self.fvars["pos"][1]
        vx.set(str(x))
        vy.set(str(y))
        self._marcador(x, y, cor="#00c853", ms=600)
        self.lbl_status.config(text=f"Posição capturada: ({x}, {y})")
        self.log(f"Posição capturada: ({x}, {y})")

    def adicionar_clique_rapido(self):
        x, y = pyautogui.position()
        passo = {"tipo": "clique", "descricao": "", "x": x, "y": y, "botao": "esquerdo", "cliques": 1}
        self._inserir(passo)
        self._marcador(x, y, cor="#2979ff", ms=600)
        self.log(f"Clique adicionado em ({x}, {y})")

    def _contagem_captura(self, n):
        if n <= 0:
            self.lbl_status.config(text="")
            self.capturar_pos()
            return
        self.lbl_status.config(text=f"Coloque o mouse no ponto... capturando em {n}")
        self.root.after(1000, lambda: self._contagem_captura(n - 1))

    def _mostrar_ponto(self):
        try:
            vx, vy = self.fvars["pos"][1]
            x, y = int(float(vx.get())), int(float(vy.get()))
        except (KeyError, ValueError):
            return
        for i in range(3):
            self.root.after(i * 450, lambda: self._marcador(x, y, ms=380))

    # ---------------------------------------------------- captura de imagem --
    def capturar_regiao(self):
        self.root.withdraw()
        self.root.after(400, self._abrir_seletor)

    def _abrir_seletor(self):
        shot = ImageGrab.grab()
        top = tk.Toplevel(self.root)
        top.overrideredirect(True)
        top.geometry(f"{shot.width}x{shot.height}+0+0")
        top.attributes("-topmost", True)
        cv = tk.Canvas(top, cursor="crosshair", highlightthickness=0, width=shot.width, height=shot.height)
        cv.pack(fill="both", expand=True)
        escura = Image.blend(shot.convert("RGB"), Image.new("RGB", shot.size, (0, 0, 0)), 0.35)
        self._shot_tk = ImageTk.PhotoImage(escura)
        self._shot_claro = shot
        cv.create_image(0, 0, anchor="nw", image=self._shot_tk)
        cv.create_text(shot.width // 2, 40, fill="#ffeb3b", font=("Segoe UI", 16, "bold"),
                       text="Arraste para recortar o botão / campo / ícone.   ESC cancela")
        st = {"x0": 0, "y0": 0, "rect": None, "crop": None}

        def press(e):
            st["x0"], st["y0"] = e.x, e.y
            st["rect"] = cv.create_rectangle(e.x, e.y, e.x, e.y, outline="#ff1744", width=2)

        def drag(e):
            if st["rect"]:
                cv.coords(st["rect"], st["x0"], st["y0"], e.x, e.y)

        def fechar(salvar_box=None):
            top.destroy()
            self._shot_tk = None
            self.root.deiconify()
            self.root.lift()
            if salvar_box:
                x0, y0, x1, y1 = salvar_box
                os.makedirs(IMG_DIR, exist_ok=True)
                nome = datetime.datetime.now().strftime("img_%Y%m%d_%H%M%S.png")
                caminho = os.path.join(IMG_DIR, nome)
                self._shot_claro.crop((x0, y0, x1, y1)).save(caminho)
                self._refs[caminho_rel(caminho)] = (x0, y0)
                if "imagem" not in self.fvars:
                    self._set_tipo("clicar_imagem", manter=True)
                self._img_var.set(caminho_rel(caminho))
                self.log(f"Imagem capturada: {nome} ({x1 - x0}x{y1 - y0}px) na posição ({x0}, {y0})")
            self._shot_claro = None

        def release(e):
            x0, x1 = sorted((st["x0"], e.x))
            y0, y1 = sorted((st["y0"], e.y))
            if x1 - x0 < 6 or y1 - y0 < 6:
                if st["rect"]:
                    cv.delete(st["rect"])
                st["rect"] = None
                return
            fechar((x0, y0, x1, y1))

        cv.bind("<ButtonPress-1>", press)
        cv.bind("<B1-Motion>", drag)
        cv.bind("<ButtonRelease-1>", release)
        top.bind("<Escape>", lambda e: fechar())
        top.focus_force()

    # --------------------------------------------------------- lista/passos --
    def _refresh(self, sel=None):
        filtro = self.v_filtro.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        n = 0
        recuo = fluxo.profundidades([p["tipo"] for p in self.steps])  # passos dentro de Se/Repetir/Tentar
        for i, s in enumerate(self.steps):
            if s.get("imagem") and "ref_x" in s:
                self._refs[s["imagem"]] = (s["ref_x"], s["ref_y"])
            ativo = s.get("ativo", True)
            tipo = f"{'      ' * recuo[i]}{ICONES.get(s['tipo'], '•')}   {TIPOS.get(s['tipo'], s['tipo'])}"
            det = resumo(s)
            if filtro and filtro not in f"{tipo} {det}".lower():
                continue
            tags = ["par" if n % 2 else "impar"] + ([] if ativo else ["inativo"])
            self.tree.insert("", "end", iid=str(i), tags=tags, values=(i + 1 if ativo else f"⊘ {i + 1}", tipo, det))
            n += 1
        if sel is not None and self.tree.exists(str(sel)):
            self.tree.selection_set(str(sel))
            self.tree.see(str(sel))
        ativos = sum(1 for s in self.steps if s.get("ativo", True))
        extra = f"  ·  {len(self.steps) - ativos} desativado(s)" if ativos != len(self.steps) else ""
        try:  # avisa na hora se um bloco ficou aberto/fora de ordem
            fluxo.estrutura([p["tipo"] for p in self.steps if p.get("ativo", True)],
                            [k + 1 for k, p in enumerate(self.steps) if p.get("ativo", True)])
        except fluxo.ErroEstrutura as e:
            extra += f"  ·  ⚠ {e}"
        self.lbl_qtd.config(text=f"Passos do roteiro  ({len(self.steps)}){extra}")
        if self.steps:
            self.lbl_vazio.place_forget()
        else:
            self.lbl_vazio.place(relx=0.5, rely=0.42, anchor="center")
        self._titulo()

    def _sel(self):
        s = self.tree.selection()
        return int(s[0]) if s else None

    def _ao_selecionar(self, _e=None):
        i = self._sel()
        if i is not None and not self.running and not self.gravando:
            self._set_tipo(self.steps[i]["tipo"], self.steps[i])

    def _snap(self):
        self.undo.append(json.dumps(self.steps))
        del self.undo[:-60]

    def desfazer(self):
        if self.running or self.gravando or not self.undo:
            return
        self.steps = json.loads(self.undo.pop())
        self.dirty = True
        self._refresh(self._sel())
        self.log("Desfeito.")

    def _inserir(self, passo):
        self._snap()
        i = self._sel()
        pos = len(self.steps) if i is None else i + 1
        self.steps.insert(pos, passo)
        self.dirty = True
        self._refresh(pos)

    def adicionar(self):
        d = self._ler_form()
        if d:
            self._inserir(d)
            fim = fluxo.FECHAMENTO.get(d["tipo"])
            if fim:  # Se / Repetir / Tentar: cria o fechamento junto (os passos novos entram entre os dois)
                i = self._sel()
                extras = [{"tipo": "se_der_erro", "descricao": ""}] if d["tipo"] == "tentar" else []
                for k, p in enumerate(extras + [{"tipo": fim, "descricao": ""}]):
                    self.steps.insert(i + 1 + k, p)
                self._refresh(i)
                self.log(f"Bloco criado: adicione os passos dentro dele (com '{TIPOS[d['tipo']]}' selecionado, "
                         f"o próximo passo entra logo abaixo).")

    def atualizar(self):
        i = self._sel()
        if i is None:
            messagebox.showinfo("Atualizar", "Selecione um passo na lista primeiro.")
            return
        d = self._ler_form()
        if d:
            self._snap()
            if not self.steps[i].get("ativo", True):
                d["ativo"] = False
            self._manter_extras(self.steps[i], d)
            self.steps[i] = d
            self.dirty = True
            self._refresh(i)

    EXTRAS_GRAVACAO = ("janela", "alvo", "vp", "alvo_excel", "alvo_excel_fim", "alvo_uia")

    @classmethod
    def _manter_extras(cls, antigo, novo):
        """O formulário não mostra o que a gravação guardou além dos campos (elemento da página, célula do Excel,
        programa da janela). Ao atualizar o passo isso é mantido — menos quando a posição foi mudada à mão
        (aí vale a posição nova)."""
        if antigo.get("tipo") != novo.get("tipo"):
            return
        mudou = any(antigo.get(k) != novo.get(k) for k in ("x", "y", "x2", "y2") if k in novo)
        for k in cls.EXTRAS_GRAVACAO:
            if k in antigo and k not in novo and (k == "janela" or not mudou):
                novo[k] = antigo[k]

    def alternar_ativo(self):
        i = self._sel()
        if i is None:
            return
        self._snap()
        self.steps[i]["ativo"] = not self.steps[i].get("ativo", True)
        self.dirty = True
        self._refresh(i)

    def mover(self, delta):
        i = self._sel()
        if i is None:
            return
        j = i + delta
        if 0 <= j < len(self.steps):
            self._snap()
            self.steps[i], self.steps[j] = self.steps[j], self.steps[i]
            self.dirty = True
            self._refresh(j)

    def duplicar(self):
        i = self._sel()
        if i is not None:
            self._snap()
            self.steps.insert(i + 1, json.loads(json.dumps(self.steps[i])))
            self.dirty = True
            self._refresh(i + 1)

    def remover(self):
        i = self._sel()
        if i is not None:
            self._snap()
            del self.steps[i]
            self.dirty = True
            self._refresh(min(i, len(self.steps) - 1))

    def limpar(self):
        if self.steps and messagebox.askyesno("Limpar", "Remover todos os passos? (dá para desfazer com Ctrl+Z)"):
            self._snap()
            self.steps = []
            self.dirty = True
            self._refresh()
