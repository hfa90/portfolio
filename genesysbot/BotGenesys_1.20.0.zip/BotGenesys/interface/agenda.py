# -*- coding: utf-8 -*-
"""Agendamentos: aba Agendamentos, timer do app e tarefas do Windows.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
from interface.comum import (AGENDA_FILE, APP_DIR, SCRIPT, TIPOS_PLANILHA, WIN, agm, datetime, filedialog,
                             messagebox, os, subprocess, tb, threading, tk)


class AgendaMixin:

    # --------------------------------------------------------- agendamentos --
    def _agenda_carregar(self):
        self.agendas = agm.carregar(AGENDA_FILE)
        try:
            self._agenda_mtime = os.path.getmtime(AGENDA_FILE)
        except OSError:
            self._agenda_mtime = 0
        self._agenda_refresh()

    def _agenda_salvar(self):
        try:
            agm.mesclar(self.agendas, agm.carregar(AGENDA_FILE))
            agm.salvar(AGENDA_FILE, self.agendas)
            self._agenda_mtime = os.path.getmtime(AGENDA_FILE)
        except OSError as e:
            messagebox.showerror("Agendamentos", f"Não foi possível salvar: {e}")
        self._agenda_refresh()

    def _agenda_sel(self):
        s = self.tree_ag.selection()
        return next((a for a in self.agendas if a["id"] == s[0]), None) if s else None

    def _agenda_refresh(self):
        sel = self.tree_ag.selection()
        self.tree_ag.delete(*self.tree_ag.get_children())
        proximas = []
        for n, a in enumerate(self.agendas):
            p = agm.proxima(a)
            if a["id"] in self.filhos and self.filhos[a["id"]].poll() is None:
                prox = "▶ rodando"
            elif not a.get("ativo", True):
                prox = "pausado"
            elif p is None:
                prox = "concluído"
            else:
                prox = p.strftime("%d/%m %H:%M")
                proximas.append((p, a))
            tags = ["par" if n % 2 else "impar"] + ([] if a.get("ativo", True) else ["pausado"])
            self.tree_ag.insert("", "end", iid=a["id"], tags=tags, values=(
                a.get("nome", ""), agm.descrever(a), prox, "Windows" if a.get("modo") == "windows" else "App",
                a.get("resultado") or "—"))
        if sel and self.tree_ag.exists(sel[0]):
            self.tree_ag.selection_set(sel[0])
        if proximas:
            p, a = min(proximas, key=lambda x: x[0])
            self.lbl_sb_agenda.config(text=f"⏰ Próxima: {agm.DIAS[p.weekday()]} {p:%d/%m %H:%M} · {a['nome']}")
        else:
            self.lbl_sb_agenda.config(text="")

    def _agenda_tick(self):
        try:
            mt = os.path.getmtime(AGENDA_FILE) if os.path.exists(AGENDA_FILE) else 0
            if mt != self._agenda_mtime:
                self._agenda_carregar()
            agora = datetime.datetime.now()
            mudou = False
            for a in self.agendas:
                if a.get("modo") != "app":
                    continue
                p = agm.proxima(a, agora)
                if not p or p > agora:
                    continue
                if (agora - p).total_seconds() > agm.TOLERANCIA_MIN * 60:
                    a["ultima"] = agora.strftime(agm.FORMATO)
                    a["resultado"] = f"⚠ perdida ({p:%d/%m %H:%M}): app fechado ou ocupado"
                    self.log(f"Agendamento '{a['nome']}' de {p:%d/%m %H:%M} não rodou a tempo.", "erro")
                    mudou = True
                    continue
                if self.running or self.gravando or any(f.poll() is None for f in self.filhos.values()):
                    continue  # ocupado: tenta de novo no próximo ciclo (até a tolerância)
                a["ultima"] = agora.strftime(agm.FORMATO)
                mudou = True
                self._disparar(a)
            if mudou:
                self._agenda_salvar()
            else:
                self._agenda_refresh()
        except Exception as e:
            self.log(f"Erro no agendador: {e}", "erro")
        self.root.after(20000, self._agenda_tick)

    def _disparar(self, a):
        if not os.path.exists(a["roteiro"]):
            a["resultado"] = "✗ roteiro não encontrado"
            self.log(f"Agendamento '{a['nome']}': roteiro não encontrado ({a['roteiro']}).", "erro")
            return
        exe, _ = agm.comando(a, SCRIPT)
        cmd = [exe, SCRIPT, "--executar", a["roteiro"], "--agendamento", a["id"]]
        if a.get("planilha"):
            cmd += ["--csv", a["planilha"]]
        try:
            proc = subprocess.Popen(cmd, cwd=APP_DIR, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:
            a["resultado"] = f"✗ não iniciou: {e}"
            return
        self.filhos[a["id"]] = proc
        self.log(f"⏰ Iniciando agendamento '{a['nome']}' (ESC para parar).", "ok")
        self._set_estado("⏰ AGENDADO RODANDO", "info")
        self._toast("Execução agendada", f"Iniciando '{a['nome']}'. ESC para parar.", "info", 3000)
        for b in (self.btn_run, self.btn_run_sel, self.btn_rec):
            b.config(state="disabled")
        if self.v_min.get():
            self.root.iconify()
        threading.Thread(target=lambda: self.post(lambda rc=proc.wait(): self._filho_fim(a["id"], rc)),
                         daemon=True).start()
        self._agenda_refresh()

    def _filho_fim(self, ag_id, rc):
        self.filhos.pop(ag_id, None)
        self._agenda_carregar()
        a = next((x for x in self.agendas if x["id"] == ag_id), None)
        nome = a["nome"] if a else ag_id
        if a and rc not in (0, 1, 2, 3):
            a["resultado"] = f"✗ falhou (código {rc})"
            self._agenda_salvar()
        if not self.running and not self.gravando:
            self._set_estado("PRONTO", "success")
            for b in (self.btn_run, self.btn_run_sel, self.btn_rec):
                b.config(state="normal")
        if rc == 0:
            self.log(f"⏰ Agendamento '{nome}' concluído com sucesso.", "ok")
            self._toast("Agendamento concluído", f"'{nome}' executado com sucesso.")
        else:
            self.log(f"⏰ Agendamento '{nome}' terminou com problema: {a.get('resultado') if a else rc}. "
                     "Detalhes no arquivo de log (Arquivo > Abrir pasta de logs).", "erro")
            self._toast("Agendamento", f"'{nome}' terminou com problema. Veja o log.", "danger", 6000)

    def editar_agendamento(self):
        a = self._agenda_sel()
        if a:
            self.novo_agendamento(a)
        else:
            messagebox.showinfo("Agendamentos", "Selecione um agendamento na lista.")

    def rodar_agendamento_agora(self):
        a = self._agenda_sel()
        if not a:
            messagebox.showinfo("Agendamentos", "Selecione um agendamento na lista.")
            return
        if self.running or self.gravando or any(f.poll() is None for f in self.filhos.values()):
            messagebox.showwarning("Agendamentos", "Já existe uma execução ou gravação em andamento.")
            return
        if messagebox.askyesno("Rodar agora", f"Executar '{a['nome']}' agora?"):
            self._disparar(a)

    def alternar_agendamento(self):
        a = self._agenda_sel()
        if not a:
            return
        a["ativo"] = not a.get("ativo", True)
        if a["ativo"]:
            a["criado"] = datetime.datetime.now().strftime(agm.FORMATO)  # não "recupera" horários perdidos
        if a.get("modo") == "windows":
            ok, msg = agm.ativar_windows(a, a["ativo"])
            if not ok:
                messagebox.showerror("Agendador do Windows", msg)
        self._agenda_salvar()
        self.log(f"Agendamento '{a['nome']}' {'ativado' if a['ativo'] else 'pausado'}.")

    def excluir_agendamento(self):
        a = self._agenda_sel()
        if not a or not messagebox.askyesno("Excluir", f"Excluir o agendamento '{a['nome']}'?"):
            return
        if a.get("modo") == "windows":
            agm.remover_windows(a)
        self.agendas.remove(a)
        self._agenda_salvar()

    def novo_agendamento(self, ag=None):
        if self.running or self.gravando:
            return
        if ag is None:
            if not self.steps:
                messagebox.showinfo("Agendar", "Grave ou monte o roteiro antes de agendar.")
                return
            if self.dirty or not self.arquivo:
                if not messagebox.askyesno("Agendar", "O agendamento executa o roteiro salvo em arquivo.\n"
                                                      "Salvar o roteiro agora?"):
                    return
                if not self.salvar():
                    return
        agora = datetime.datetime.now()
        if ag:
            base = agm._dt(ag["quando"])
        else:
            base = (agora + datetime.timedelta(minutes=10)).replace(second=0, microsecond=0)
            base = base.replace(minute=(base.minute // 5) * 5)
        d = tb.Toplevel(title="Editar agendamento" if ag else "Agendar execução", transient=self.root,
                        resizable=(False, False))
        f = tb.Frame(d, padding=20)
        f.pack(fill="both", expand=True)
        tb.Label(f, text="⏰  " + ("Editar agendamento" if ag else "Agendar execução do bot"),
                 font=("Segoe UI", 14, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 14))

        nome_padrao = os.path.splitext(os.path.basename(self.arquivo or "roteiro"))[0].replace("_", " ").capitalize()
        v_nome = tk.StringVar(value=ag["nome"] if ag else nome_padrao)
        v_rot = tk.StringVar(value=ag["roteiro"] if ag else os.path.abspath(self.arquivo))
        v_csv = tk.StringVar(value=(ag.get("planilha") or "") if ag else
                             (os.path.abspath(self.dados_arquivo) if self.dados_arquivo else ""))
        v_h, v_m = tk.StringVar(value=f"{base.hour:02d}"), tk.StringVar(value=f"{base.minute:02d}")
        rep_nomes = list(agm.REPETICOES.values())
        v_rep = tk.StringVar(value=agm.REPETICOES[ag["repetir"]] if ag else rep_nomes[0])
        v_int = tk.StringVar(value=str(ag.get("intervalo", 60)) if ag else "60")
        v_modo = tk.StringVar(value=ag.get("modo", "app") if ag else ("windows" if WIN else "app"))
        v_dias = [tk.BooleanVar(value=(i in (ag.get("dias") or [])) if ag else i < 5) for i in range(7)]

        def linha(r, rotulo, widget, botao=None):
            tb.Label(f, text=rotulo).grid(row=r, column=0, sticky="w", pady=5, padx=(0, 12))
            widget.grid(row=r, column=1, sticky="we", pady=5)
            if botao:
                botao.grid(row=r, column=2, sticky="w", padx=(6, 0))

        def escolher(var, tipos):
            p = filedialog.askopenfilename(parent=d, initialdir=APP_DIR, filetypes=tipos)
            if p:
                var.set(os.path.abspath(p))

        linha(1, "Nome", tb.Entry(f, textvariable=v_nome, width=44))
        linha(2, "Roteiro", tb.Entry(f, textvariable=v_rot, width=44),
              tb.Button(f, text="...", bootstyle="secondary-outline", width=3,
                        command=lambda: escolher(v_rot, [("Roteiro", "*.json")])))
        linha(3, "Planilha (opcional)", tb.Entry(f, textvariable=v_csv, width=44),
              tb.Button(f, text="...", bootstyle="secondary-outline", width=3,
                        command=lambda: escolher(v_csv, TIPOS_PLANILHA)))
        tb.Separator(f).grid(row=4, column=0, columnspan=3, sticky="we", pady=10)
        linha(5, "Repetir", tb.Combobox(f, textvariable=v_rep, values=rep_nomes, state="readonly", width=30))
        de = tb.DateEntry(f, date_format="%d/%m/%Y", start_date=base, popup_title="Escolha a data",
                          first_weekday=0, bootstyle="info")
        self._lbl_data = tb.Label(f, text="Data")
        self._lbl_data.grid(row=6, column=0, sticky="w", pady=5)
        de.grid(row=6, column=1, sticky="w", pady=5)
        fh = tb.Frame(f)
        tb.Spinbox(fh, from_=0, to=23, textvariable=v_h, width=4, format="%02.0f", wrap=True).pack(side="left")
        tb.Label(fh, text=" : ", font=("Segoe UI", 11, "bold")).pack(side="left")
        tb.Spinbox(fh, from_=0, to=59, textvariable=v_m, width=4, format="%02.0f", wrap=True).pack(side="left")

        def ajustar(delta_min=None, amanha_8=False):
            n = datetime.datetime.now().replace(second=0, microsecond=0)
            alvo = (n + datetime.timedelta(days=1)).replace(hour=8, minute=0) if amanha_8 else \
                n + datetime.timedelta(minutes=delta_min)
            de.entry.delete(0, "end")
            de.entry.insert(0, alvo.strftime("%d/%m/%Y"))
            v_h.set(f"{alvo.hour:02d}")
            v_m.set(f"{alvo.minute:02d}")

        for txt, kw in (("daqui 5 min", {"delta_min": 5}), ("daqui 1 h", {"delta_min": 60}),
                        ("amanhã 08:00", {"amanha_8": True})):
            tb.Button(fh, text=txt, bootstyle="info-link", padding=(4, 0),
                      command=lambda kw=kw: ajustar(**kw)).pack(side="left", padx=(8, 0))
        linha(7, "Hora", fh)
        fd = tb.Frame(f)
        for i, nome_dia in enumerate(agm.DIAS):
            tb.Checkbutton(fd, text=nome_dia, variable=v_dias[i], bootstyle="info-toolbutton",
                           padding=(8, 4)).pack(side="left", padx=(0, 3))
        lbl_dias = tb.Label(f, text="Dias")
        fi = tb.Frame(f)
        tb.Spinbox(fi, from_=1, to=1440, textvariable=v_int, width=6).pack(side="left")
        tb.Label(fi, text=" minutos").pack(side="left")
        lbl_int = tb.Label(f, text="Intervalo")
        fm = tb.Frame(f)
        tb.Radiobutton(fm, text="Pelo app  (o app precisa estar aberto; pode ficar minimizado)", value="app",
                       variable=v_modo).pack(anchor="w", pady=2)
        rb = tb.Radiobutton(fm, text="Pelo Windows  (roda mesmo com o app fechado)", value="windows",
                            variable=v_modo)
        rb.pack(anchor="w", pady=2)
        if not WIN:
            rb.config(state="disabled")
        linha(10, "Executar", fm)
        resumo_lbl = tb.Label(f, text="", font=("Segoe UI", 10, "bold"), bootstyle="info")
        resumo_lbl.grid(row=11, column=0, columnspan=3, sticky="w", pady=(14, 0))

        def montar(validar=False):
            try:
                data = datetime.datetime.strptime(de.entry.get().strip(), "%d/%m/%Y").date()
                quando = datetime.datetime.combine(data, datetime.time(int(float(v_h.get())), int(float(v_m.get()))))
            except ValueError:
                raise ValueError("Data ou hora inválida (use dd/mm/aaaa e hora 0-23, minuto 0-59).")
            rep = {v: k for k, v in agm.REPETICOES.items()}[v_rep.get()]
            dias = [i for i, v in enumerate(v_dias) if v.get()]
            try:
                intervalo = max(1, int(float(v_int.get())))
            except ValueError:
                raise ValueError("Intervalo inválido.")
            novo = agm.novo(v_nome.get().strip() or "Execução", v_rot.get().strip(), quando, rep, dias, intervalo,
                            v_modo.get(), v_csv.get().strip() or None)
            if validar:
                if rep == "semanal" and not dias:
                    raise ValueError("Escolha pelo menos um dia da semana.")
                if rep == "uma_vez" and quando <= datetime.datetime.now():
                    raise ValueError("Escolha uma data/hora no futuro.")
                if not os.path.exists(novo["roteiro"]):
                    raise ValueError("Arquivo de roteiro não encontrado.")
                if novo["planilha"] and not os.path.exists(novo["planilha"]):
                    raise ValueError("Planilha não encontrada.")
            return novo

        def atualizar_tela():
            if not d.winfo_exists():
                return
            rep = {v: k for k, v in agm.REPETICOES.items()}.get(v_rep.get(), "uma_vez")
            self._lbl_data.config(text="Data" if rep == "uma_vez" else "A partir de")
            for w, cond, r in ((lbl_dias, rep == "semanal", 8), (fd, rep == "semanal", 8),
                               (lbl_int, rep == "intervalo", 9), (fi, rep == "intervalo", 9)):
                if cond:
                    w.grid(row=r, column=0 if w in (lbl_dias, lbl_int) else 1, sticky="w", pady=5)
                else:
                    w.grid_remove()
            try:
                p = agm.proxima(montar())
                if p is None or (rep == "uma_vez" and p <= datetime.datetime.now()):
                    resumo_lbl.config(text="⚠  Esse horário já passou.", bootstyle="warning")
                else:
                    falta = p - datetime.datetime.now()
                    h, m = int(falta.total_seconds() // 3600), int(falta.total_seconds() % 3600 // 60)
                    em = f"daqui {h // 24} dia(s)" if h >= 48 else (f"daqui {h}h{m:02d}" if h else f"daqui {m} min")
                    resumo_lbl.config(text=f"Próxima execução: {agm.DIAS[p.weekday()]} {p:%d/%m/%Y} às "
                                           f"{p:%H:%M}  ({em})", bootstyle="info")
            except ValueError as e:
                resumo_lbl.config(text=f"⚠  {e}", bootstyle="warning")
            d.after(400, atualizar_tela)

        def confirmar():
            try:
                novo = montar(validar=True)
            except ValueError as e:
                messagebox.showerror("Agendamento", str(e), parent=d)
                return
            if ag:
                novo["id"], novo["resultado"], novo["ativo"] = ag["id"], ag.get("resultado", ""), ag.get("ativo", True)
            d.config(cursor="watch")
            d.update()
            if ag and ag.get("modo") == "windows":
                agm.remover_windows(ag)
            if novo["modo"] == "windows":
                ok, msg = agm.registrar_windows(novo, SCRIPT, APP_DIR)
                if not ok:
                    d.config(cursor="")
                    messagebox.showerror("Agendador do Windows",
                                         f"Não foi possível registrar no Agendador do Windows:\n{msg}\n\n"
                                         "Você pode escolher 'Pelo app'.", parent=d)
                    return
            if ag:
                self.agendas[self.agendas.index(ag)] = novo
            else:
                self.agendas.append(novo)
            self._agenda_salvar()
            d.destroy()
            p = agm.proxima(novo)
            self.nb.select(2)
            self.log(f"⏰ Agendado '{novo['nome']}': {agm.descrever(novo)} "
                     f"({'Agendador do Windows' if novo['modo'] == 'windows' else 'pelo app'}).", "ok")
            self._toast("Agendado", f"'{novo['nome']}' — próxima: {p:%d/%m %H:%M}" if p else novo["nome"], "info")

        bb = tb.Frame(f)
        bb.grid(row=12, column=0, columnspan=3, sticky="e", pady=(18, 0))
        tb.Button(bb, text="⏰  " + ("Salvar" if ag else "Agendar"), bootstyle="info", padding=(16, 8),
                  command=confirmar).pack(side="left", padx=6)
        tb.Button(bb, text="Cancelar", bootstyle="secondary-outline", padding=(12, 8),
                  command=d.destroy).pack(side="left")
        d.bind("<Escape>", lambda e: d.destroy())
        atualizar_tela()
        d.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - d.winfo_reqwidth()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - d.winfo_reqheight()) // 3
        d.geometry(f"+{max(0, x)}+{max(0, y)}")
        d.grab_set()
