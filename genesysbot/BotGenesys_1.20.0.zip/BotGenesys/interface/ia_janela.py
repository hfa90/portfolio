# -*- coding: utf-8 -*-
"""Menu IA: configurar a chave, criar/alterar o roteiro descrevendo em português e explicar o último erro.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import os

from interface.comum import (APP_DIR, _CTX_VALIDAR, abrir_texto, cat, messagebox, proteger_texto, resumo, tb,
                             threading, tk)
import fluxo
import ia
from PIL import Image

EXEMPLOS_PEDIDO = (
    "Ex.: Abra C:\\relatorios\\notas.xlsx, copie para uma aba nova chamada 'Acima de 1000' as linhas em que a coluna "
    "Nota for maior que 1.000, salve e me avise na tela.\n"
    "Ex.: Para cada PDF em Downloads, mova para a pasta Notas\\{data} e mande um e-mail para fiscal@empresa.com com "
    "a lista.\n"
    "Ex.: (com o roteiro aberto) Se der erro em qualquer passo, me avise no Telegram com o erro.")


class IAJanelaMixin:

    # ------------------------------------------------------------ utilidades
    def _ia_chave(self):
        try:
            return ia.chave_configurada(APP_DIR, abrir_texto)
        except ia.ErroIA as e:
            messagebox.showerror("IA", str(e))
            return None

    def _ia_em_fundo(self, trabalho, ok, falhou):
        """Roda trabalho() numa linha separada (a janela não trava) e devolve o resultado na tela."""
        def rodar():
            try:
                r = trabalho()
            except Exception as e:
                self.post(lambda e=e: falhou(e))
                return
            self.post(lambda: ok(r))
        threading.Thread(target=rodar, daemon=True).start()

    def _ia_tamanho(self, win, largura, altura):
        """Tamanho que cabe na tela (com a barra de tarefas e a escala do Windows)."""
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w, h = min(largura, sw - 60), min(altura, sh - 110)
        win.geometry(f"{w}x{h}")
        win.minsize(min(560, w), min(420, h))

    def _ia_centralizar(self, win):
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_height()) // 4
        win.geometry(f"+{max(0, x)}+{max(0, y)}")

    def _ia_precisa_chave(self):
        chave = self._ia_chave()
        if chave:
            return chave
        if messagebox.askyesno("IA", "A IA ainda não está configurada.\n\nPara usar, você precisa de uma chave da API "
                                     "da Anthropic (crie em console.anthropic.com; cada uso custa centavos).\n\n"
                                     "Configurar agora?"):
            self.configurar_ia()
        return None

    # ------------------------------------------------------------ configurar
    def configurar_ia(self):
        cfg = self.app_cfg.get("ia") or {}
        win = tb.Toplevel(title="Configurar IA")
        win.transient(self.root)
        corpo = tb.Frame(win, padding=20)
        corpo.pack(fill="both", expand=True)
        tb.Label(corpo, text="IA (Claude, da Anthropic)", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tb.Label(corpo, text="Crie uma chave em console.anthropic.com › API Keys. Ela fica guardada criptografada "
                             "pelo Windows (só funciona neste usuário). Cada uso custa centavos, cobrados na sua conta "
                             "da Anthropic.", wraplength=480, justify="left", bootstyle="secondary").pack(
            anchor="w", pady=(4, 12))
        tb.Label(corpo, text="Chave da API").pack(anchor="w")
        atual = ""
        if cfg.get("chave_protegida"):
            try:
                atual = abrir_texto(cfg["chave_protegida"])
            except Exception:
                atual = ""
        v_chave = tk.StringVar(value=atual)
        ent = tb.Entry(corpo, textvariable=v_chave, width=56, show="•")
        ent.pack(anchor="w", fill="x")
        v_ver = tk.BooleanVar(value=False)
        tb.Checkbutton(corpo, text="mostrar", variable=v_ver,
                       command=lambda: ent.config(show="" if v_ver.get() else "•")).pack(anchor="w", pady=(2, 8))
        tb.Label(corpo, text="Modelo").pack(anchor="w")
        v_modelo = tk.StringVar(value=cfg.get("modelo") or ia.MODELO_PADRAO)
        tb.Combobox(corpo, textvariable=v_modelo, values=ia.MODELOS, width=30).pack(anchor="w")
        tb.Label(corpo, text="sonnet = equilíbrio (recomendado) · opus = o mais capaz · haiku = o mais rápido e barato",
                 bootstyle="secondary").pack(anchor="w", pady=(2, 10))
        lbl = tb.Label(corpo, text="", wraplength=480, justify="left")
        lbl.pack(anchor="w")
        if os.environ.get("ANTHROPIC_API_KEY"):
            lbl.config(text="ℹ Este Windows tem a variável ANTHROPIC_API_KEY (de outra ferramenta). O bot usa a chave "
                            "salva aqui; a variável só vale se o campo acima ficar vazio.", bootstyle="info")

        def salvar(fechar=True):
            chave = ia.limpar_chave(v_chave.get())
            v_chave.set(chave)
            problema = ia.formato_chave(chave) if chave else None
            if problema and fechar and not messagebox.askyesno(
                    "Chave da API", f"Esta chave parece estranha: {problema}.\n\nSalvar mesmo assim?", parent=win):
                return
            novo = {"modelo": v_modelo.get().strip() or ia.MODELO_PADRAO}
            if chave:
                novo["chave_protegida"] = proteger_texto(chave)
            self.app_cfg["ia"] = novo
            self._salvar_app_cfg()
            if fechar:
                win.destroy()
                self.log("IA configurada.", "ok")

        def testar():
            salvar(fechar=False)
            chave, modelo = v_chave.get(), v_modelo.get().strip()
            problema = ia.formato_chave(chave)
            if problema:
                lbl.config(text=f"⚠ Esta chave {problema}.", bootstyle="warning")
                return
            lbl.config(text="Testando...", bootstyle="secondary")
            self._ia_em_fundo(lambda: ia.chamar(chave, "Responda só: OK", max_tokens=20, modelo=modelo),
                              lambda r: lbl.config(text=f"✓ Funcionando ({modelo}): {r[:40]}", bootstyle="success"),
                              lambda e: lbl.config(text=f"✗ {e}", bootstyle="danger"))

        barra = tb.Frame(corpo)
        barra.pack(fill="x", pady=(12, 0))
        tb.Button(barra, text="Salvar", bootstyle="success", command=salvar).pack(side="left")
        tb.Button(barra, text="Testar", bootstyle="info-outline", command=testar).pack(side="left", padx=6)
        tb.Button(barra, text="Cancelar", bootstyle="secondary", command=win.destroy).pack(side="right")
        win.bind("<Escape>", lambda e: win.destroy())
        self._ia_centralizar(win)
        ent.focus_set()

    # ------------------------------------------------------------ criar / alterar roteiro
    def criar_com_ia(self):
        if self.running or self.gravando:
            return
        chave = self._ia_precisa_chave()
        if not chave:
            return
        win = tb.Toplevel(title="Criar ou alterar o roteiro com IA")
        win.transient(self.root)
        self._ia_tamanho(win, 880, 700)
        rodape = tb.Frame(win, padding=(16, 10))
        rodape.pack(side="bottom", fill="x")  # primeiro: fica sempre visível, mesmo com a lista grande
        tb.Separator(win).pack(side="bottom", fill="x")
        corpo = tb.Frame(win, padding=16)
        corpo.pack(fill="both", expand=True)
        tb.Label(corpo, text="Descreva o que o robô deve fazer", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tb.Label(corpo, text=EXEMPLOS_PEDIDO, wraplength=820, justify="left", bootstyle="secondary").pack(
            anchor="w", pady=(2, 6))
        txt = tb.Text(corpo, height=5, wrap="word")
        txt.pack(fill="x")
        v_modo = tk.StringVar(value="acrescentar")
        modos = tb.Frame(corpo)
        modos.pack(fill="x", pady=6)
        tb.Radiobutton(modos, text="Acrescentar os passos novos (depois do selecionado)", variable=v_modo,
                       value="acrescentar").pack(side="left")
        tb.Radiobutton(modos, text="Alterar o roteiro inteiro", variable=v_modo, value="substituir").pack(
            side="left", padx=12)
        btn = tb.Button(corpo, text="✦  Gerar passos", bootstyle="primary")
        btn.pack(anchor="w")
        lbl = tb.Label(corpo, text="", wraplength=820, justify="left")
        lbl.pack(anchor="w", pady=(8, 4))
        quadro = tb.Frame(corpo)
        quadro.pack(fill="both", expand=True)
        tv = tb.Treeview(quadro, columns=("tipo", "det"), show="headings", height=8)
        tv.heading("tipo", text="Passo")
        tv.heading("det", text="Detalhes")
        tv.column("tipo", width=230)
        tv.column("det", width=560)
        rolagem = tb.Scrollbar(quadro, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=rolagem.set)
        rolagem.pack(side="right", fill="y")
        tv.pack(side="left", fill="both", expand=True)
        btn_ok = tb.Button(rodape, text="✔  INSERIR NO ROTEIRO", bootstyle="success", state="disabled", padding=(16, 8))
        btn_ok.pack(side="left")
        tb.Button(rodape, text="Fechar", bootstyle="secondary", command=win.destroy, padding=(16, 8)).pack(side="right")
        estado = {"passos": None}

        def mostrar(r):
            passos, explicacao, avisos = r
            estado["passos"] = passos
            tv.delete(*tv.get_children())
            recuo = fluxo.profundidades([p["tipo"] for p in passos])
            for i, p in enumerate(passos):
                tv.insert("", "end", values=(f"{i + 1}. {'   ' * recuo[i]}{cat.TIPOS[p['tipo']]}", resumo(p)))
            texto = explicacao or ""
            if avisos:
                texto += "\n⚠ " + "\n⚠ ".join(avisos[:8])
            lbl.config(text=texto + "\n\nConfira os passos; depois de inserir, Ctrl+Z desfaz.",
                       bootstyle="warning" if avisos else "default")
            btn.config(state="normal", text="✦  Gerar de novo")
            btn_ok.config(state="normal")

        def erro(e):
            lbl.config(text=f"✗ {e}", bootstyle="danger")
            btn.config(state="normal")

        def gerar():
            pedido = txt.get("1.0", "end").strip()
            if not pedido:
                return
            substituir = v_modo.get() == "substituir"
            colunas = [c for c in (self.dados[0].keys() if self.dados else []) if not str(c).startswith("_")]
            atuais = list(self.steps)
            modelo = (self.app_cfg.get("ia") or {}).get("modelo")
            btn.config(state="disabled")
            btn_ok.config(state="disabled")
            lbl.config(text="A IA está montando os passos (10 a 60 s)...", bootstyle="secondary")
            self._ia_em_fundo(lambda: ia.gerar_passos(chave, pedido, cat, fluxo, atuais, colunas, substituir,
                                                      _CTX_VALIDAR, modelo), mostrar, erro)

        def inserir():
            passos = estado["passos"]
            if not passos:
                return
            self._snap()
            if v_modo.get() == "substituir":
                self.steps = [dict(p) for p in passos]
                sel = 0
            else:
                i = self._sel()
                pos = len(self.steps) if i is None else i + 1
                self.steps[pos:pos] = [dict(p) for p in passos]
                sel = pos
            self.dirty = True
            self._refresh(sel)
            self.log(f"IA: {len(passos)} passo(s) {'no roteiro' if v_modo.get() == 'substituir' else 'inseridos'}. "
                     "Ctrl+Z desfaz.", "ok")
            win.destroy()

        btn.config(command=gerar)
        btn_ok.config(command=inserir)
        win.bind("<Escape>", lambda e: win.destroy())
        txt.focus_set()
        self._ia_centralizar(win)

    # ------------------------------------------------------------ explicar e corrigir o erro
    def explicar_erro_ia(self):
        info = getattr(self.motor, "ultimo_erro", None)
        if not info:
            messagebox.showinfo("IA", "Nenhum erro para explicar: execute o roteiro primeiro (esta opção explica a "
                                      "última execução que falhou).")
            return
        if self.running or self.gravando:
            return
        chave = self._ia_precisa_chave()
        if not chave:
            return
        i = info.get("passo")
        passo_txt = "(não identificado)"
        if i is not None and 0 <= i < len(self.steps):
            p = self.steps[i]
            passo_txt = f"{i + 1}. {cat.TIPOS.get(p['tipo'], p['tipo'])} — {resumo(p)}"
        img = None
        if info.get("print") and os.path.exists(info["print"]):
            try:
                img = Image.open(info["print"])
                img.load()
            except Exception:
                img = None
        win = tb.Toplevel(title="Explicação e solução do erro (IA)")
        win.transient(self.root)
        self._ia_tamanho(win, 820, 640)
        rodape = tb.Frame(win, padding=(16, 10))
        rodape.pack(side="bottom", fill="x")  # sempre visível
        tb.Separator(win).pack(side="bottom", fill="x")
        corpo = tb.Frame(win, padding=16)
        corpo.pack(fill="both", expand=True)
        tb.Label(corpo, text=f"Erro: {info.get('erro', '')[:220]}", wraplength=760, justify="left",
                 bootstyle="danger").pack(anchor="w")
        tb.Label(corpo, text=f"Passo: {passo_txt[:200]}", wraplength=760, justify="left",
                 bootstyle="secondary").pack(anchor="w", pady=(2, 8))
        quadro = tb.Frame(corpo)
        quadro.pack(fill="both", expand=True)
        txt = tb.Text(quadro, wrap="word", height=10)
        rol = tb.Scrollbar(quadro, orient="vertical", command=txt.yview)
        txt.configure(yscrollcommand=rol.set)
        rol.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        tb.Label(corpo, text="O que a solução muda no roteiro:", font=("Segoe UI", 10, "bold")).pack(
            anchor="w", pady=(10, 2))
        lbl_mud = tb.Label(corpo, text="(aguardando a IA...)", wraplength=760, justify="left", bootstyle="secondary")
        lbl_mud.pack(anchor="w")
        btn_aplicar = tb.Button(rodape, text="✔  APLICAR SOLUÇÃO", bootstyle="success", state="disabled",
                                padding=(16, 8))
        btn_aplicar.pack(side="left")
        btn_rodar = tb.Button(rodape, text="▶  Aplicar e executar de novo", bootstyle="info", state="disabled",
                              padding=(16, 8))
        btn_rodar.pack(side="left", padx=8)
        tb.Button(rodape, text="Fechar", bootstyle="secondary", command=win.destroy, padding=(16, 8)).pack(
            side="right")
        win.bind("<Escape>", lambda e: win.destroy())
        self._ia_centralizar(win)
        estado = {}
        passos_enviados = [dict(p) for p in self.steps]  # o que a IA viu (se o roteiro mudar, não aplica)

        def escrever(texto):
            if not win.winfo_exists():
                return
            txt.config(state="normal")
            txt.delete("1.0", "end")
            txt.insert("1.0", texto)
            txt.config(state="disabled")

        escrever("A IA está analisando o roteiro, o log" + (" e o print do erro" if img else "") + "...")

        def mostrar(r):
            if not win.winfo_exists():
                return
            escrever(r["explicacao"] or "(a IA não explicou)")
            try:
                novos, descr, avisos, inicio = ia.aplicar_alteracoes(passos_enviados, r["alteracoes"], cat, fluxo,
                                                                    _CTX_VALIDAR, r.get("executar_de"))
            except ia.ErroIA as e:
                lbl_mud.config(text=f"✗ {e}", bootstyle="danger")
                return
            if not descr:
                lbl_mud.config(text="A IA não sugeriu mudança no roteiro: siga a explicação acima (o problema está "
                                    "fora do roteiro)." + ("\n⚠ " + "\n⚠ ".join(avisos[:5]) if avisos else ""),
                               bootstyle="warning")
                return
            estado.update(novos=novos, inicio=inicio)
            lbl_mud.config(text="• " + "\n• ".join(descr[:12]) + ("\n⚠ " + "\n⚠ ".join(avisos[:5]) if avisos else ""),
                           bootstyle="warning" if avisos else "default")
            btn_aplicar.config(state="normal")
            if inicio is not None:
                btn_rodar.config(state="normal", text=f"▶  Aplicar e executar de novo do passo {inicio + 1}")

        def aplicar(rodar=False):
            if not estado.get("novos"):
                return
            if self.steps != passos_enviados:
                messagebox.showwarning("IA", "O roteiro mudou depois da análise: peça a explicação de novo.",
                                       parent=win)
                return
            self._snap()
            self.steps = estado["novos"]
            self.dirty = True
            inicio = estado.get("inicio")
            self._refresh(inicio if inicio is not None else 0)
            self.motor.ultimo_erro = None
            self._solucao_ia_pendente = True  # se a próxima execução der 100% certo, o bot salva sozinho
            self.log("IA: solução aplicada ao roteiro (Ctrl+Z desfaz). Se a próxima execução terminar sem falhas, "
                     "o roteiro corrigido é salvo automaticamente.", "ok")
            win.destroy()
            if rodar and inicio is not None:
                self.root.after(300, lambda: self.executar(inicio))

        btn_aplicar.config(command=aplicar)
        btn_rodar.config(command=lambda: aplicar(rodar=True))
        modelo = (self.app_cfg.get("ia") or {}).get("modelo")
        self._ia_em_fundo(lambda: ia.diagnosticar(chave, info.get("erro", ""), i, passos_enviados,
                                                  info.get("log", ""), cat, img, modelo),
                          mostrar, lambda e: escrever(f"Não consegui a explicação: {e}"))
