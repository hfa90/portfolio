# -*- coding: utf-8 -*-
"""Infraestrutura da janela: fila entre threads, log, atalhos globais e marcadores na tela.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import diario
from interface.comum import (LOG_DIR, WIN, ctypes, datetime, os, pkb, pyautogui, queue)


class InfraMixin:

    # ------------------------------------------------------ infra de thread --
    def post(self, fn):
        self.uiq.put(fn)

    def _poll(self):
        try:
            while True:
                fn = self.uiq.get_nowait()
                try:
                    fn()
                except Exception as e:  # um erro numa atualização da tela não pode parar a fila (o app "congelava")
                    diario.detalhe(LOG_DIR, "erro ao atualizar a tela", diario.texto_erro(e))
        except queue.Empty:
            pass
        finally:
            self.root.after(30, self._poll)

    def _erro_interface(self, tipo, valor, tb_):
        """Erro num botão/menu/atalho da janela: vai para o log (com o caminho técnico) em vez de sumir."""
        import traceback
        diario.detalhe(LOG_DIR, "erro na interface", "".join(traceback.format_exception(tipo, valor, tb_)))
        try:
            self.log(f"Erro interno na interface: {tipo.__name__}: {valor} (detalhes técnicos no log do dia).", "erro")
        except Exception:
            pass

    def _track_mouse(self):
        try:
            x, y = pyautogui.position()
            self.lbl_pos.config(text=f"X {x:<5} Y {y:<5}")
            self.lbl_sb_mouse.config(text=f"mouse {x}, {y}")
        except Exception:
            pass
        self.root.after(80, self._track_mouse)

    def log(self, msg, tag=None):
        linha = f"[{datetime.datetime.now():%H:%M:%S}] {msg}\n"
        diario.escrever(LOG_DIR, linha)  # no arquivo NA HORA: se o app travar ou fechar, o log já está no disco

        def _w():
            self.txt_log.config(state="normal")
            self.txt_log.insert("end", linha[:11], "hora")
            self.txt_log.insert("end", linha[11:], tag or ())
            self.txt_log.see("end")
            self.txt_log.config(state="disabled")
        self.post(_w)

    @staticmethod
    def _mods_reais():
        """Ctrl/Alt/Shift/Win apertados neste instante, lidos do próprio Windows. Não depende de ter visto
        cada evento (um atalho rápido, Alt+Tab ou o menu Iniciar não deixam mais um Ctrl 'preso')."""
        if not WIN:
            return None
        try:
            estado = ctypes.windll.user32.GetAsyncKeyState
            m = {nome for nome, vk in (("ctrl", 0x11), ("alt", 0x12), ("shift", 0x10)) if estado(vk) & 0x8000}
            if estado(0x5B) & 0x8000 or estado(0x5C) & 0x8000:
                m.add("win")
            return m
        except Exception:
            return None

    def _start_hotkeys(self):
        if not pkb:
            self.log("pynput não instalado: atalhos globais e gravação desativados.", "erro")
            return

        def on_press(key, *_):
            if self.sending or self.motor.sending:
                return
            if self.gravando:
                if key == pkb.Key.f4:
                    self.post(self.parar_gravacao)
                elif key == pkb.Key.f9:
                    self.post(self._rec_marcar_ponto)
                else:
                    mods = self._mods_reais()  # lido AGORA, no instante da tecla (não depois, na fila)
                    self.post(lambda k=key, m=mods: self._rec_tecla(k, True, m))
                return
            if self.running:
                if self._fundo_atual:
                    return  # segundo plano: Pausar/Parar pelo cartão na tela ou pelo app
                if key == pkb.Key.esc:
                    self.motor.parar()
                elif key == pkb.Key.f2:
                    self.post(self.pausar)
                return
            if any(p.poll() is None for p in self.filhos.values()):
                return  # execução agendada rodando em outro processo
            if key == pkb.Key.f8:
                self.post(self.capturar_pos)
            elif key == pkb.Key.f9:
                self.post(self.adicionar_clique_rapido)
            elif key == pkb.Key.f4:
                self.post(self.alternar_gravacao)

        def on_release(key, *_):
            if self.gravando and not self.sending and not self.motor.sending:
                self.post(lambda k=key: self._rec_tecla(k, False))

        self.listener = pkb.Listener(on_press=on_press, on_release=on_release)
        self.listener.daemon = True
        self.listener.start()

    # ------------------------------------------------- marcadores na tela --
    def _marcador(self, x, y, w=0, h=0, cor="#ff1744", ms=700):
        self.painel.marcador(x, y, w, h, cor, ms)

    def _overlay_mostrar(self, dica="ESC = parar     F2 = pausar", titulo="BOT GENESYS", cor=None, modo="frente"):
        self.painel.mostrar(modo, titulo, dica, ao_pausar=self.pausar, ao_parar=self.parar,
                            estado="gravando" if "GRAV" in titulo else "rodando")

    def _overlay_texto(self, t, cor=None):
        self.painel.texto(t, cor)

    def _overlay_esconder(self):
        self.painel.esconder()

    def _progresso(self, feito, total, texto=None):
        frac = 0 if not total else max(0.0, min(1.0, feito / total))
        self.prog.configure(value=frac * 100)
        if texto:
            self.lbl_sb.config(text=texto)
        self.painel.progresso(frac)
