# -*- coding: utf-8 -*-
"""Menu Ajuda: manutenção dos logs, diagnóstico, voltar versão, sobre, atalhos e recentes.

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
from interface.comum import (APP_DIR, DATA_VERSAO, HISTORICO, IMG_DIR, LOG_DIR, NOME, VERSAO, WIN, diag,
                             messagebox, os, tb, threading, tk, versoes)


class AjudaMixin:

    # ------------------------------------------------------------ logs e diagnóstico
    def _manutencao_logs(self):
        """Ao abrir: guarda uma cópia desta versão, confere os arquivos, apaga logs antigos e esconde senhas."""
        try:
            if versoes.guardar_versao_atual(APP_DIR):
                self.post(lambda: self.log(f"Cópia de segurança da versão {VERSAO} guardada em {versoes.PASTA}\\.",
                                           "ok"))
        except Exception as e:
            erro = str(e)
            self.post(lambda: self.log(f"Aviso: não consegui guardar a cópia desta versão ({erro}).", "erro"))
        try:
            ok, txt, _ = versoes.conferir(APP_DIR)
            if not ok:
                self.post(lambda: self.log(f"ATENÇÃO: arquivos do programa {txt}. Pode ser uma atualização pela "
                                           "metade — rode Ajuda → Verificar sistema ou volte a versão anterior.",
                                           "erro"))
        except Exception:
            pass
        try:
            msg = diag.manutencao_logs(APP_DIR, LOG_DIR, int(self.app_cfg.get("dias_logs", 30)))
        except Exception:
            msg = ""
        if msg:
            self.post(lambda: self.log(f"Manutenção dos logs: {msg}.", "ok"))

    def diagnostico(self):
        if self.running or self.gravando:
            messagebox.showinfo("Diagnóstico", "Espere a execução / gravação terminar.")
            return
        win = tb.Toplevel(title=f"Diagnóstico — {NOME} {VERSAO}")
        win.transient(self.root)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h = min(1000, sw - 80), min(640, sh - 100)
        win.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 30)}")
        topo = tb.Frame(win, padding=(16, 14, 16, 6))
        topo.pack(fill="x")
        v_titulo = tk.StringVar(value="Verificando o sistema...")
        v_passo = tk.StringVar(value="O teste do Excel abre o Excel escondido por alguns segundos.")
        lbl = tb.Label(topo, textvariable=v_titulo, font=("Segoe UI", 13, "bold"))
        lbl.pack(anchor="w")
        tb.Label(topo, textvariable=v_passo, bootstyle="secondary").pack(anchor="w")
        barra = tb.Progressbar(topo, mode="indeterminate", bootstyle="info-striped")
        barra.pack(fill="x", pady=(8, 0))
        meio = tb.Frame(win, padding=(16, 6))
        meio.pack(fill="both", expand=True)
        tv = tb.Treeview(meio, columns=("detalhe",), show="tree headings", bootstyle="info")
        tv.heading("#0", text="Item")
        tv.heading("detalhe", text="Resultado")
        tv.column("#0", width=330, stretch=False)
        tv.column("detalhe", width=600)
        sb = tb.Scrollbar(meio, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        cores = {diag.OK: "#2e7d32", diag.AVISO: "#ef6c00", diag.ERRO: "#c62828", diag.INFO: "#607d8b"}
        for st, cor in cores.items():
            tv.tag_configure(st, foreground=cor)
        baixo = tb.Frame(win, padding=(16, 8, 16, 14))
        baixo.pack(fill="x")
        estado = {"res": [], "arquivo": None}
        botoes = {}

        def acao(tipo):
            if tipo == "limpar":
                n, tam = diag.limpar_logs(LOG_DIR, int(self.app_cfg.get("dias_logs", 30)))
                messagebox.showinfo("Logs", f"{n} arquivo(s) antigo(s) apagado(s) ({diag._tamanho(tam)}).", parent=win)
            elif tipo == "ocultar":
                n = diag.ocultar_senhas_nos_logs(LOG_DIR, diag.senhas_conhecidas(APP_DIR))
                messagebox.showinfo("Logs", f"Senhas trocadas por {diag.MASCARA} em {n} arquivo(s).", parent=win)
            rodar()

        def copiar():
            win.clipboard_clear()
            win.clipboard_append(diag.relatorio_texto(estado["res"]))
            v_passo.set("Relatório copiado. Cole na conversa para eu analisar.")

        def abrir_rel():
            if estado["arquivo"] and WIN:
                os.startfile(estado["arquivo"])

        def mostrar(res, arquivo):
            if not win.winfo_exists():
                return
            estado["res"], estado["arquivo"] = res, arquivo
            barra.stop()
            barra.pack_forget()
            tv.delete(*tv.get_children())
            grupos = {}
            for r in res:
                g = r["grupo"]
                if g not in grupos:
                    grupos[g] = tv.insert("", "end", text=g, open=True, values=("",))
                tv.insert(grupos[g], "end", text=f"{diag.ICONE[r['status']]}  {r['item']}",
                          values=(r["detalhe"],), tags=(r["status"],))
            for g, iid in grupos.items():
                pior = [r["status"] for r in res if r["grupo"] == g]
                st = diag.ERRO if diag.ERRO in pior else diag.AVISO if diag.AVISO in pior else diag.OK
                tv.item(iid, text=f"{diag.ICONE[st]}  {g}", tags=(st,))
            st, txt = diag.resumo(res)
            v_titulo.set({diag.OK: "✓  ", diag.AVISO: "⚠  ", diag.ERRO: "✗  "}[st] + txt)
            lbl.configure(foreground=cores[st])
            v_passo.set(f"Relatório salvo em {arquivo}" if arquivo else "")
            acoes = {r["acao"] for r in res if r.get("acao")}
            botoes["limpar"].configure(state="normal" if "limpar" in acoes else "disabled")
            botoes["ocultar"].configure(state="normal" if "ocultar" in acoes else "disabled")
            for b in ("rodar", "copiar", "abrir"):
                botoes[b].configure(state="normal")

        def rodar():
            for b in botoes.values():
                b.configure(state="disabled")
            tv.delete(*tv.get_children())
            v_titulo.set("Verificando o sistema...")
            lbl.configure(foreground="")
            barra.pack(fill="x", pady=(8, 0))
            barra.start(12)

            def trabalho():
                passo = lambda t: self.post(lambda: win.winfo_exists() and v_passo.set(t))
                try:
                    res = diag.executar(APP_DIR, LOG_DIR, IMG_DIR, int(self.app_cfg.get("dias_logs", 30)),
                                        ao_passo=passo)
                except Exception as e:
                    res = [diag._r("Diagnóstico", "Erro geral", diag.ERRO, e)]
                try:
                    arq = diag.salvar_relatorio(res, LOG_DIR)
                except OSError:
                    arq = None
                self.post(lambda: mostrar(res, arq))
            threading.Thread(target=trabalho, daemon=True).start()

        botoes["rodar"] = tb.Button(baixo, text="↻  Verificar de novo", bootstyle="primary", command=rodar)
        botoes["copiar"] = tb.Button(baixo, text="⧉  Copiar relatório", bootstyle="secondary-outline", command=copiar)
        botoes["abrir"] = tb.Button(baixo, text="Abrir relatório", bootstyle="secondary-outline", command=abrir_rel)
        botoes["limpar"] = tb.Button(baixo, text="Apagar logs antigos", bootstyle="warning-outline",
                                     command=lambda: acao("limpar"))
        botoes["ocultar"] = tb.Button(baixo, text="Ocultar senhas nos logs", bootstyle="danger-outline",
                                      command=lambda: acao("ocultar"))
        for b in ("rodar", "copiar", "abrir", "limpar", "ocultar"):
            botoes[b].pack(side="left", padx=(0, 8))
        tb.Button(baixo, text="Fechar", bootstyle="secondary", command=win.destroy).pack(side="right")
        win.bind("<Escape>", lambda e: win.destroy())
        rodar()

    def voltar_versao(self):
        if self.running or self.gravando:
            messagebox.showinfo("Versões", "Espere a execução / gravação terminar.")
            return
        lista = [v for v in versoes.listar(APP_DIR) if v[0] != VERSAO]
        if not lista:
            messagebox.showinfo("Versões", "Ainda não há outra versão guardada.\n\nA partir da 1.6.0, cada versão "
                                           f"que você abrir fica guardada em {versoes.PASTA}\\.")
            return
        win = tb.Toplevel(title="Voltar para uma versão anterior")
        win.transient(self.root)
        corpo = tb.Frame(win, padding=20)
        corpo.pack(fill="both", expand=True)
        tb.Label(corpo, text=f"Versão em uso: {VERSAO}", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tb.Label(corpo, text="Escolha a versão. Só os arquivos do programa voltam — roteiros, planilhas, imagens e "
                             "logs não são tocados. A versão atual também fica guardada.", wraplength=460,
                 bootstyle="secondary", justify="left").pack(anchor="w", pady=(4, 10))
        tv = tb.Treeview(corpo, columns=("data",), show="tree headings", height=min(8, len(lista)))
        tv.heading("#0", text="Versão")
        tv.heading("data", text="Guardada em")
        tv.column("#0", width=140)
        tv.column("data", width=200)
        for v, data, _ in lista:
            tv.insert("", "end", iid=v, text=v, values=(data,))
        tv.selection_set(lista[0][0])
        tv.pack(fill="x")

        def restaurar():
            sel = tv.selection()
            if not sel:
                return
            v = sel[0]
            if not messagebox.askyesno("Voltar versão", f"Voltar o programa da versão {VERSAO} para a {v}?\n\n"
                                                        "O programa vai fechar; abra de novo pelo iniciar.bat.",
                                       parent=win):
                return
            try:
                versoes.restaurar(APP_DIR, v)
            except Exception as e:
                messagebox.showerror("Voltar versão", f"Não deu certo: {e}", parent=win)
                return
            messagebox.showinfo("Voltar versão", f"Pronto: arquivos da versão {v} restaurados.\n"
                                                 "Abra o Bot Genesys de novo.", parent=win)
            self._ao_fechar()

        barra = tb.Frame(corpo)
        barra.pack(fill="x", pady=(12, 0))
        tb.Button(barra, text="↶  Voltar para esta versão", bootstyle="warning", command=restaurar).pack(side="left")
        tb.Button(barra, text="Cancelar", bootstyle="secondary", command=win.destroy).pack(side="right")
        win.bind("<Escape>", lambda e: win.destroy())
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_height()) // 3
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
        win.grab_set()

    def _sobre(self):
        historico = "\n".join(f"  {v}  —  {t}" for v, t in HISTORICO)
        messagebox.showinfo(f"Sobre o {NOME}",
                            f"{NOME}\nVersão {VERSAO}  ({DATA_VERSAO})\n\n"
                            "Automação de chamados no Chrome: grava o processo, executa na tela ou em segundo "
                            "plano, agenda e exporta para Python.\n\nHistórico:\n" + historico +
                            f"\n\nPasta do programa:\n{APP_DIR}")

    def _mostrar_atalhos(self):
        messagebox.showinfo("Atalhos", "F4 - iniciar / parar a gravação\nF5 - executar tudo\n"
                                       "F8 - capturar a posição do mouse\nF9 - adicionar clique na posição do mouse\n"
                                       "F2 - pausar / continuar a execução\nESC - parar a execução\n"
                                       "Mouse no canto superior esquerdo - parada de emergência\n\n"
                                       "Ctrl+S salvar   Ctrl+O abrir   Ctrl+N novo\nCtrl+Z desfazer   Ctrl+D duplicar\n"
                                       "Delete remover   Espaço ativar/desativar\n"
                                       "Arraste os passos na lista para reordenar. Botão direito = mais opções.")

    def _atualizar_recentes(self, novo=None):
        rec = self.app_cfg["recentes"]
        if novo:
            novo = os.path.abspath(novo)
            if novo in rec:
                rec.remove(novo)
            rec.insert(0, novo)
            del rec[8:]
            self._salvar_app_cfg()
        self.menu_recentes.delete(0, "end")
        for p in rec:
            self.menu_recentes.add_command(label=p, command=lambda p=p: self._abrir_recente(p))
        if not rec:
            self.menu_recentes.add_command(label="(nenhum)", state="disabled")

    def _abrir_recente(self, p):
        if os.path.exists(p) and self._confirmar_descartar():
            self._carregar(p)

    def historico_execucoes(self):
        """Ajuda → Histórico de execuções: o que rodou, quando, quanto durou e onde falhou."""
        import diario
        execucoes = diario.ler_execucoes(LOG_DIR)
        r = diario.resumo_execucoes(execucoes)
        win = tb.Toplevel(title=f"Histórico de execuções — {NOME}")
        win.transient(self.root)
        win.geometry("980x520")
        corpo = tb.Frame(win, padding=14)
        corpo.pack(fill="both", expand=True)
        if not execucoes:
            texto = "Nenhuma execução registrada ainda. A partir da versão 1.20.0 cada execução aparece aqui."
        else:
            texto = (f"{r['total']} execuções  ·  {r['ok']} ok  ·  {r['aviso']} com avisos  ·  {r['erro']} com erro  ·  "
                     f"{r['parado']} interrompidas"
                     + (f"  ·  {r['taxa']}% terminaram bem" if r["taxa"] is not None else ""))
            if r["piores"]:
                texto += "\nOnde mais falha: " + ";  ".join(f"{rot}, passo {p} ({n}x)" for rot, p, n in r["piores"])
        tb.Label(corpo, text=texto, justify="left", wraplength=940).pack(anchor="w", pady=(0, 10))
        colunas = (("quando", "Quando", 130), ("roteiro", "Roteiro", 200), ("resultado", "Resultado", 90),
                   ("duracao", "Duração", 70), ("avisos", "Avisos", 55), ("detalhe", "Detalhe", 400))
        quadro = tb.Frame(corpo)
        quadro.pack(fill="both", expand=True)
        arv = tb.Treeview(quadro, columns=[c[0] for c in colunas], show="headings", height=16)
        for chave, titulo, largura in colunas:
            arv.heading(chave, text=titulo)
            arv.column(chave, width=largura, anchor="w", stretch=(chave == "detalhe"))
        barra = tb.Scrollbar(quadro, orient="vertical", command=arv.yview)
        arv.configure(yscrollcommand=barra.set)
        barra.pack(side="right", fill="y")
        arv.pack(side="left", fill="both", expand=True)
        nomes = {"ok": "✓ ok", "aviso": "⚠ com avisos", "erro": "✗ erro", "parado": "■ interrompida"}
        for e in execucoes:
            detalhe = str(e.get("erro") or "")
            if e.get("parcial"):
                detalhe = "(teste de um passo) " + detalhe
            if e.get("agendamento"):
                detalhe = f"[agendamento: {e['agendamento']}] " + detalhe
            seg = int(e.get("duracao_s") or 0)
            arv.insert("", "end", values=(str(e.get("quando", "")).replace("T", " "), e.get("roteiro", ""),
                                          nomes.get(e.get("resultado"), e.get("resultado", "")),
                                          f"{seg // 60}min {seg % 60:02d}s" if seg >= 60 else f"{seg}s",
                                          e.get("avisos", 0), detalhe.replace("\n", " ")))
        tb.Button(corpo, text="Fechar", bootstyle="secondary", command=win.destroy).pack(anchor="e", pady=(10, 0))
        win.bind("<Escape>", lambda ev: win.destroy())
