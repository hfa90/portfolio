# -*- coding: utf-8 -*-
"""Gravação de detalhes do mouse: ARRASTAR (selecionar intervalo, alça de preencher...), Ctrl/Shift+clique, a
CÉLULA do Excel e o ELEMENTO da janela (botão, campo, menu... de qualquer programa) debaixo de cada clique (o Excel é consultado numa linha de trabalho separada, para não atrasar
a captura do mouse).

Parte da janela do Bot Genesys (a classe App junta todas as partes em interface/janela.py)."""
import itertools
import queue

from interface.comum import WIN, jc, threading
import excel_tela as xt
import janelas_uia as uia

NAVEGADORES_REC = {"chrome.exe", "msedge.exe"}  # no navegador o elemento vem da própria página
DISTANCIA_ARRASTO = 8  # px: mais que isso entre apertar e soltar = arrastar


class GravadorMouseMixin:

    _rec_contador = itertools.count(1)

    def _rec_segurar_agora(self):
        """'ctrl', 'shift', 'ctrl+shift', 'alt' ou 'nenhuma' — teclas seguradas NO INSTANTE do clique."""
        mods = self._mods_reais()
        if mods is None:
            mods = set(self._rec.get("mods", ()))
        m = [k for k in ("ctrl", "shift") if k in mods]
        if m:
            return "+".join(m)
        return "alt" if "alt" in mods else "nenhuma"

    def _rec_novo_token(self):
        return next(self._rec_contador)

    # ---------------------------------------------------------------- célula do Excel debaixo do clique
    def _rec_pedir_celula(self, token, campo, x, y):
        if not WIN:
            return
        fila = getattr(self, "_rec_fila_excel", None)
        if fila is None:
            fila = self._rec_fila_excel = queue.Queue()
            threading.Thread(target=self._rec_trabalho_excel, args=(fila,), daemon=True).start()
        fila.put((token, campo, x, y))

    def _rec_trabalho_excel(self, fila):
        while True:
            token, campo, x, y = fila.get()
            try:
                info = jc.info_janela(jc.janela_no_ponto(x, y))
                if not info:
                    continue
                proc = info.get("processo")
                cel = xt.celula_no_ponto(x, y) if proc == "excel.exe" else None
                if not cel and campo == "alvo_excel" and proc not in NAVEGADORES_REC and uia.HAS_UIA:
                    elem = uia.capturar_elemento(x, y)  # programa desktop (ou a faixa/menus do Excel): o elemento clicado
                    if elem:
                        self.post(lambda t=token, i=elem: self._rec_celula_lida(t, "alvo_uia", i))
            except Exception:
                cel = None
            if cel:
                self.post(lambda t=token, c=campo, i=cel: self._rec_celula_lida(t, c, i))

    def _rec_passo_do_token(self, token):
        for p in reversed(self.steps[-12:]):
            if p.get("_tk") == token:
                return p
        return None

    def _rec_celula_lida(self, token, campo, info):
        p = self._rec_passo_do_token(token)
        if p is not None:
            p[campo] = info
            self._rec_atualizado()

    # ---------------------------------------------------------------- arrastar
    def _rec_soltou(self, x, y, botao, agora):
        """Soltou o botão (chamado na linha do mouse). Se andou desde o apertar, vira um passo Arrastar."""
        ap = getattr(self, "_rec_apertou", None)
        self._rec_apertou = None
        if not ap or ap["botao"] != botao:
            return
        if abs(x - ap["x"]) <= DISTANCIA_ARRASTO and abs(y - ap["y"]) <= DISTANCIA_ARRASTO:
            return
        self._rec_pedir_celula(ap["token"], "alvo_excel_fim", x, y)
        self.post(lambda: self._rec_virou_arrasto(ap["token"], x, y, agora - ap["t"]))

    def _rec_virou_arrasto(self, token, x2, y2, duracao):
        p = self._rec_passo_do_token(token)
        if p is None or p["tipo"] != "clique":
            return
        for k in ("cliques", "conferir", "imagem", "ref_x", "ref_y"):
            p.pop(k, None)
        p.update(tipo="arrastar", x2=int(x2), y2=int(y2), duracao=round(min(max(duracao, 0.2), 3.0), 2))
        self._rec_atualizado()
