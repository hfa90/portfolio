# Bot Genesys — histórico de versões

Formato: **MAIOR.MENOR.CORREÇÃO** — MAIOR quando algo deixa de ser compatível, MENOR para recursos novos,
CORREÇÃO para correções. A versão aparece no topo do app, no título da janela, em *Ajuda → Sobre*,
no log de cada execução e no cabeçalho dos arquivos `.py` exportados.

## 1.20.0 — 16/11/2026
- **Histórico de execuções** (*Ajuda → Histórico de execuções*): cada execução fica registrada em
  `logs\execucoes.jsonl` — quando, roteiro, resultado, duração, avisos, erro e em qual passo falhou. A janela mostra
  o resumo (quantas terminaram bem) e os passos que mais falham.
- **Tela bloqueada**: se o roteiro usa o mouse/teclado e o Windows está bloqueado (ou com pedido de
  senha/administrador na frente), o bot para logo no início com essa explicação — em vez de clicar no vazio e dar um
  erro enganoso. Se bloquear no meio, o erro avisa.
- **O computador não suspende durante a execução**: enquanto o roteiro roda, o Windows não entra em suspensão nem
  apaga a tela.
- **Imagens conferidas antes de começar**: se um passo *Clicar/Esperar imagem* ou *Se: imagem* usa uma imagem que não
  existe mais, o bot avisa antes do passo 1 (fora de blocos *Tentar*, que já tratam a falha).
- **Chrome do bot mais fechado**: saiu a opção `--remote-allow-origins=*` (o bot nunca precisou dela); páginas abertas
  em outros navegadores não conseguem mais se conectar ao Chrome controlado.
- Resultado na planilha: se não der para gravar o arquivo no fim (planilha aberta em outro programa), agora aparece
  um aviso — antes falhava em silêncio.
- Correção: ocultar senhas nos logs podia cruzar com uma linha sendo gravada no mesmo instante.
- Correção: o arquivo `logs\.executando` nunca era apagado no Windows ao fim da execução (era removido ainda aberto).
- `.gitignore` e `requirements.lock` (versões exatas das bibliotecas que estão funcionando neste computador).

## 1.19.1 — 16/11/2026
Versão de confiabilidade — nada muda no jeito de usar.
- **Log gravado na hora**: cada linha vai para o arquivo do dia no instante em que acontece (antes passava pela fila
  da janela; se o app travasse ou fechasse, as últimas linhas — as mais importantes — se perdiam).
- **Detalhe técnico dos erros no log**: quando uma execução falha (ou um erro é tratado por um *Tentar*), o log do dia
  ganha um bloco `DETALHE TÉCNICO` com o caminho completo do erro. Na tela continua a mensagem simples.
- **Erros que escapavam agora ficam registrados**: erro ao abrir o programa, numa tarefa em paralelo ou num
  botão/menu da janela vai para o log (nos agendamentos, com `pythonw`, eles sumiam sem deixar rastro).
- Correção: um erro numa atualização da tela parava a fila da interface para sempre (o app parecia congelado e a
  execução nunca "terminava"). Agora o erro é registrado e a fila continua.
- **Salvar sem risco de corromper**: roteiro e configurações são gravados num arquivo temporário e só então trocados
  pelo definitivo. Se faltar luz ou o disco falhar no meio, o arquivo anterior continua inteiro.
- **Trava de execução pelo Windows**: duas execuções ao mesmo tempo (agendamento + manual) são barradas por uma trava
  do próprio sistema — sem a brecha de dois processos passarem juntos, sem "trava presa" se o bot fechar de repente.
- `diario.py`; testes novos em `testes/test_diario.py`.

## 1.19.0 — 16/11/2026
- **Chrome: anexar arquivo (sem a janela Abrir)**: entrega o arquivo ao campo de upload da página pelo Chrome controlado
  (espera o campo existir, escolhe o campo certo, confere o nome do arquivo na página). Funciona em segundo plano.
- **Windows: escolher arquivo na janela Abrir/Salvar**: espera a janela, escreve o caminho no campo Nome (conferido),
  confirma e espera fechar — nada de digitar antes de a janela abrir.
- **Vigiar pop-up**: regras para avisos do Chrome (alert/confirm/"sair da página?") e janelas do Windows (pelo título
  ou texto da caixa), conferidas antes/depois de cada passo e durante as esperas; responder OK/Cancelar/fechar/botão e
  seguir ou parar com erro. Aviso do Chrome sem regra para o roteiro com a mensagem dele.
- IA: "boas práticas" nos pedidos de criar e corrigir roteiro (cadeia de eventos, anexos, janelas, pop-ups,
  confirmar resultados, Gmail) — a solução corrige a causa e previne o próximo problema da mesma cadeia.
- **Correção que deu certo é salva sozinha**: depois de Aplicar solução, execução sem falhas → salva por cima (cópia
  da anterior em logs\roteiros_antes_da_ia) e avisa.
- Exemplo Gmail: anexo pelo novo passo, vigias de aviso no início e envio confirmado (senão para com erro).
- `motor_vigias.py`; 11 testes novos.

## 1.18.0 — 16/11/2026
- **APLICAR SOLUÇÃO** em *IA › Explicar o último erro*: a IA recebe o roteiro inteiro (sem senhas), o log e o print e
  devolve a explicação + as alterações (alterar campos, inserir passos antes/depois, remover). O bot confere tudo
  (tipos, campos, opções, validação, blocos — se quebrar algum bloco, nada é aplicado), mostra a lista do que muda e
  aplica com um clique (Ctrl+Z desfaz). *Aplicar e executar de novo* roda a partir do passo certo.
- Janelas da IA: os botões (Inserir no roteiro, Aplicar solução, Fechar) ficam fixos no rodapé, sempre visíveis; a
  janela se ajusta à tela e as listas têm rolagem.
- Correção: *Aguardar página carregar* (e Abrir Chrome com "aguardar") travava 60 s e dava erro em sites que carregam
  imagens sem parar, como o Gmail ("faltou: imagens"). Com o documento pronto, segue depois de alguns segundos.
- 9 testes novos.

## 1.17.2 — 16/11/2026
- Correção: o botão Testar usava a chave digitada, mas o resto do programa dava preferência à variável do Windows
  `ANTHROPIC_API_KEY` (que pode ter uma chave antiga de outra ferramenta) — por isso "Testar" funcionava e
  "Explicar o erro"/passos de IA davam "chave recusada". Agora vale a chave salva em IA › Configurar; a variável só é
  usada se nenhuma for salva, e a tela avisa quando ela existe.

## 1.17.1 — 16/11/2026
- A **caixinha de status** da execução, o cartão "esperando você" e o cartão final agora podem ser **arrastados** com
  o mouse; a posição fica guardada (se o monitor mudar, voltam ao canto). Se o bot for clicar num ponto debaixo da
  caixinha, ela sai da frente sozinha antes; na gravação, cliques na caixinha não viram passos.
- IA: a chave colada é limpa (espaços, quebras de linha, aspas); formato conferido ao salvar/testar (sk-ant-…,
  chave de administração, chave curta); a mensagem de "chave recusada" explica a causa provável.
- 8 testes novos.

## 1.17.0 — 16/11/2026
- Passo **Pausar: esperar você**: cartão "o robô está esperando você" com Continuar/Parar (e F2); continua sozinho
  quando um elemento/texto aparece na página do Chrome ou na tela (ex.: a caixa de entrada depois do login); tempo
  máximo opcional.
- *Definir variável*: operação **codificar para link (URL)** (texto dentro de um endereço, ex.: e-mail do Gmail).
- Exemplo **`exemplos/roteiro_ia_excel_gmail.json`** + `exemplos/vendas_ia.xlsx`: 12 fórmulas e 2 tabelas
  dinâmicas no Excel, relatório escrito pela IA, Gmail com pausa para login, anexo pelo clique da IA e envio.
- 6 testes novos.

## 1.16.0 — 16/11/2026
- **IA (Claude)**, menu novo *IA*: **Criar ou alterar o roteiro descrevendo** (Ctrl+I) — o pedido em português vira
  passos do catálogo, conferidos (tipos, campos, opções, validação do formulário, blocos fechados; uma rodada
  automática de correção), com prévia e Ctrl+Z; **Explicar o último erro** (log + passo + print); **Configurar**
  (chave criptografada pelo Windows, modelo, botão Testar).
- Passos **IA: perguntar / extrair** (texto, tela, janela ou arquivo de imagem; resposta texto/número/sim-não/JSON)
  e **IA: clicar no que eu descrever** (visão: localiza na captura e clica).
- *Ler texto da tela*: nova opção **arquivo de imagem** (OCR de png/jpg/bmp/tif, também em segundo plano).
- Senhas, tokens e dados de gravação nunca vão para a IA. Chamada direta à API (sem biblioteca extra).
- `ia.py`, `motor_ia.py`, `interface/ia_janela.py`; 22 testes novos (com IA falsa: nada sai do computador).

## 1.15.0 — 16/11/2026
- **E-mail: enviar** pelo Outlook do computador (enviar, abrir para revisar ou salvar rascunho; escolher a conta)
  ou por SMTP (Gmail, Office 365...; servidor descoberto pelo e-mail; STARTTLS/SSL), com Cc, Cco, HTML, variáveis
  e anexos com `*`.
- **E-mail: esperar / ler (Outlook)**: filtros por remetente, assunto, texto e anexo; só novos, não lidos ou o mais
  recente; salva anexos (com filtro de tipo), marca como lido, move para outra pasta; variáveis `{email_...}`.
- **Notificar**: aviso do Windows, Telegram, Microsoft Teams (Workflows), Slack, Discord ou webhook.
- Campo novo do tipo *segredo* (senha SMTP, token, webhook): oculto na tela e criptografado pelo Windows no arquivo
  do roteiro; também entra na lista de senhas escondidas dos logs.
- Exemplo `exemplos/roteiro_email_aviso.json`. `mensagens.py` e `motor_mensagens.py`; 19 testes novos (nada é
  enviado de verdade nos testes).

## 1.14.3 — 16/11/2026
- Correção da captura de elementos de janela: o `janelas.py` declara `GetAncestor(HWND, UINT)` no user32
  compartilhado e a biblioteca uiautomation chama a mesma função com `c_int`, o que o Python recusa
  ("'c_long' object cannot be interpreted as an integer"). O `janelas_uia.py` agora acha a janela principal
  com uma cópia própria do user32 e não usa mais o `GetTopLevelControl` da biblioteca.

## 1.14.2 — 16/11/2026
- Correção: no Python 3.14 a pergunta direta "qual elemento está neste ponto" da biblioteca uiautomation falha
  (erro de tipo do ctypes). Agora, se ela falhar, o bot pega a janela no ponto e desce pela árvore de elementos
  até o menor elemento com nome debaixo do clique.

## 1.14.1 — 16/11/2026
- Correção: quando o clique cai num pedaço sem nome de um botão (o ícone, um painel interno — como no botão
  Iniciar do Windows 11), a gravação sobe até o botão com nome; se o ponto estiver num painel, desce até o
  menor elemento com nome debaixo do clique. O diagnóstico mostra o motivo quando não consegue.

## 1.14.0 — 16/11/2026
- **Clique pelo elemento em qualquer programa do Windows**: a gravação guarda o elemento clicado (botão, campo,
  menu, aba, item de lista...) pelo UI Automation do Windows; na execução o bot acha esse elemento na janela,
  mesmo que tenha mudado de lugar. Se houver vários iguais, fica com o mais perto da gravação. Sem achar: usa a
  imagem e depois a posição (como antes). Ordem no clique: página do Chrome → célula do Excel → elemento da
  janela → imagem → posição.
- **Texto da tela (OCR do Windows, sem instalar nada)**: passos *Ler texto da tela* (com padrão/regex e espera),
  *Clicar no texto da tela* (ocorrência, deslocamento, botão, cliques) e a condição *Se: texto aparece na tela*.
- Diagnóstico: grupo "Outros programas" testa o OCR (lê um texto desenhado) e o elemento do botão Iniciar
  (sem clicar em nada).
- Nova biblioteca `uiautomation` no requirements: rode **instalar.bat** uma vez (o `iniciar.bat` também
  instala sozinho na primeira vez).
- `janelas_uia.py` e `ocr_tela.py`; 14 testes novos.

## 1.13.0 — 16/11/2026
- **Condições**: *Se: comparar valores* (números, datas e textos como uma pessoa compararia), *Se: imagem aparece
  na tela*, *Se: arquivo existe*, *Se: texto/elemento na página*, *Se: janela aberta* — todas com "Inverter
  (SE NÃO)" e tempo de espera —, *Senão* e *Fim do se*.
- **Repetições**: *Repetir* N vezes, para cada item de uma lista ({item}; ex.: {arquivo_lista}) ou enquanto uma
  comparação for verdadeira, com limite de segurança; *Sair da repetição*; {volta} = número da volta.
- **Tratamento de erro**: *Tentar* / *Se der erro* ({erro} = mensagem) / *Fim do tentar* — o roteiro não para.
- *Parar o roteiro* (como sucesso ou erro), *Definir variável* (definir, somar, subtrair, juntar texto) e
  *Executar outro roteiro* (pedaços reutilizáveis, com as mesmas variáveis).
- A estrutura dos blocos é conferida antes de executar (e mostrada na hora, na lista); passos dentro de blocos
  aparecem recuados; adicionar um Se/Repetir/Tentar cria o fechamento junto.
- Exemplo: `exemplos/roteiro_fluxo_organizar_pdfs.json` (copia os PDFs de Downloads para uma pasta do dia).
- `fluxo.py` e `motor_fluxo.py`; 36 testes novos.

## 1.12.1 — 16/11/2026
- Correção: célula do Excel fora da tela (ex.: C200) não era achada — a rolagem agora ajusta a primeira
  linha/coluna visível e espera o Excel redesenhar antes de conferir. Se falhar, o autoteste mostra o que estava
  visível e onde o bot calculou.
- Teste `test_arrastar_vira_um_passo`: não maximiza mais a janela que estiver na sua tela (era o próprio teste,
  não o programa).

## 1.12.0 — 16/11/2026
- **Passos de Arquivos** (sem mouse/teclado — funcionam também em segundo plano): copiar, mover, renomear,
  excluir (para a Lixeira, com limite de segurança), criar pasta, **esperar arquivo aparecer** (ex.: download do
  Chrome terminar; ignora .crdownload/.tmp), listar pasta (o mais novo primeiro), compactar/extrair zip.
  Aceitam curingas, `~` (sua pasta de usuário), `%VARIAVEIS%` e {variáveis}; "se já existir": manter os dois,
  substituir, pular ou parar. O caminho final fica numa variável ({arquivo}) para os próximos passos.
- **Passos de Windows**: abrir arquivo/pasta/programa/site, área de transferência (copiar texto ou ler para
  variável) e rodar comando (cmd ou PowerShell, saída em {saida}).
- Correção: janelas do **Explorador de Arquivos** passam a ser reconhecidas (trazidas para a frente e
  maximizadas antes dos cliques); só a barra de tarefas, a área de trabalho e telas do sistema são ignoradas.
- `arquivos_win.py` e `motor_arquivos.py`; 11 testes novos (inclui um roteiro de arquivos de ponta a ponta).

## 1.11.0 — 16/11/2026
- **Clique gravado numa célula do Excel guarda a célula** (ex.: `Dados!B5`), perguntando ao próprio Excel qual
  célula está debaixo do clique. Na execução o bot acha a célula na tela **naquele momento** (troca de aba e rola
  a planilha se precisar) e confere com o Excel antes de clicar — funciona com a planilha rolada, outro zoom,
  janela de outro tamanho. Se não conseguir, usa a posição gravada e avisa. (`excel_tela.py`)
- **Passo novo: Arrastar** — a gravação detecta quando você arrasta (selecionar intervalo, alça de preencher,
  mover gráfico, selecionar texto) e grava início e fim (no Excel, as células de início e fim).
- **Ctrl+clique e Shift+clique**: o clique guarda as teclas seguradas (lidas do Windows no instante do clique) e
  a execução segura as mesmas teclas. Campo novo "Segurar tecla" no clique; também no segundo plano.
- Correção: "Atualizar" no formulário não apaga mais o que a gravação guardou além dos campos (elemento da
  página, célula do Excel, programa da janela), a não ser que você mude a posição à mão.
- Diagnóstico e testes: autoteste "célula ↔ posição na tela" num Excel separado (zoom 100% e 150%, com rolagem).

## 1.10.0 — 16/11/2026
- **Instalador** (`instalar.bat`): instala o Python se faltar (winget ou python.org), cria a `.venv`, instala as
  bibliotecas, confere Chrome (oferece instalar) e Excel, cria atalhos com ícone na Área de Trabalho e no Menu
  Iniciar e roda o diagnóstico. `desinstalar.bat` e `instalador/empacotar.py` (pacote .zip para outro computador).
  `iniciar.bat` chama o instalador na primeira vez.
- **Atalhos na gravação**: o estado de Ctrl/Alt/Shift/Win é lido do Windows no instante de cada tecla — atalhos
  rápidos não se perdem e um Ctrl "preso" não transforma mais o texto em atalhos. Atalhos com pontuação e teclado
  numérico (Ctrl+;, Ctrl+-, Ctrl++ ...) passam a ser gravados. Alt sozinho + letras (dicas de tecla do Excel)
  vira sequência de teclas.
- **Fórmulas em português ou inglês**: ~265 funções com nome PT/EN, categoria, sintaxe e descrição
  (`formulas_excel.py`); idioma detectado sozinho; conversão nos dois sentidos (textos, abas e colunas de tabela
  protegidos); funciona com o Excel em qualquer idioma (Formula2/Formula/Local, nessa ordem) e sem o Excel
  (prefixo `_xlfn.` nas funções novas). Botão **ƒx Funções** no passo, conversão de idioma e leitura da lista
  completa do seu Excel. O passo ganhou "Idioma da fórmula" (automático/português/inglês) no lugar de
  "Fórmula em português" (roteiros antigos continuam funcionando).
- Diagnóstico: fórmula em inglês e idioma do Excel. 30 testes novos (atalhos, fórmulas, instalador).

## 1.9.0 — 16/11/2026
- **Motor dividido** (1.156 linhas): `motor.py` ficou com o núcleo (laço dos passos, repetições, planilha) e as
  partes foram para `motor_tela.py` (mouse, teclado, imagens, Chrome, rolagem), `motor_dados.py` (Excel e
  leitura da página), `motor_fundo.py` (segundo plano) e `motor_util.py` (utilidades). Os métodos foram movidos
  sem alterar nenhuma linha — **o programa funciona exatamente igual**, e o arquivo .py exportado também.
- `janela_chrome.py` passou a se chamar `janelas.py` (cuida de qualquer programa, não só do Chrome);
  o nome antigo continua funcionando.
- `pyput.py` (a primeira versão do programa) foi para a pasta `_antigo/`.
- Novo teste: o arquivo .py exportado é gerado e **executado de verdade**, sozinho.

## 1.8.0 — 16/11/2026
- **Interface dividida**: o `bot_genesys.py` (2.838 linhas) virou só o ponto de entrada (50 linhas); a janela
  ficou na pasta `interface/`, um arquivo por assunto: `janela.py` (montagem da tela), `editor.py` (lista e
  formulário), `gravador.py`, `execucao.py`, `agenda.py`, `arquivos.py`, `ajuda.py`, `infra.py` e `comum.py`.
  Os 131 métodos foram movidos sem alterar nenhuma linha — **o programa funciona exatamente igual**.
- Cópias de versão, "voltar versão" e manifesto passam a incluir a pasta `interface/`.
- Novos testes: nenhum método repetido entre as partes; nenhum arquivo da interface passa de 700 linhas.

## 1.7.0 — 16/11/2026
- **Catálogo de passos** (`passos.py`): nome, ícone, campos, dica, resumo, validação do formulário e
  características de cada tipo de passo agora ficam num lugar só (antes: espalhados em 6 lugares de 2 arquivos).
  Reorganização interna — **o programa funciona exatamente igual**.
- Teste de "retrato" (`testes/ouro_catalogo.json`): 6 definições, 43 resumos e 37 validações de formulário
  conferidos contra o comportamento anterior. Novos testes: todo tipo do catálogo é executado pelo motor e
  o catálogo está bem formado.

## 1.6.1 — 16/11/2026
- Correção no teste do Excel (diagnóstico e `testar.bat`): o resultado esperado da SOMA estava errado (90, não 102).
- Avisos de "DeprecationWarning" do ttkbootstrap não poluem mais a saída dos testes.

## 1.6.0 — 16/11/2026
- **Testes automáticos** (`testar.bat`, pasta `testes/`): 47 verificações — todo tipo de passo tem formulário,
  ícone e resumo; todos os roteiros da pasta (inclusive os seus, só leitura) carregam e mostram cada passo;
  motor; fórmulas e gráficos; proteção das planilhas; exportação para .py; versões e logs. Com o Excel
  instalado, os roteiros de exemplo rodam de ponta a ponta numa cópia e o Excel é testado de verdade.
- **Cópia de cada versão**: ao abrir, os arquivos do programa são guardados em `_versoes/<versão>/`
  (as 10 últimas). Roteiros, planilhas, imagens e logs não entram e nunca são trocados.
- **Ajuda → Voltar para uma versão anterior**.
- **Manifesto** (`manifesto.json`): ao abrir e no diagnóstico, o programa confere se todos os arquivos são da
  mesma versão — avisa se uma atualização ficou pela metade.

## 1.5.0 — 16/11/2026
- **Diagnóstico** (*Ajuda → Verificar sistema*, ou `diagnostico.bat`): confere Windows, tela/escala,
  componentes, Chrome, **teste real do Excel** (fórmula em português, tabela dinâmica, gráficos — inclusive
  com a seleção dentro de uma tabela dinâmica —, gráfico dinâmico e PDF), Agendador, criptografia das senhas,
  permissões das pastas, roteiros (tipos desconhecidos, imagens faltando) e logs. Salva o relatório em `logs/`.
- **Limpeza automática dos logs** ao abrir o programa: apaga logs e prints de erro com mais de 30 dias
  (`dias_logs` no `config_app.json`) e troca por •••••• qualquer senha dos roteiros que tenha ficado num log.

## 1.4.2 — 16/11/2026
- Correção: o Excel preenche todo gráfico novo com a SELEÇÃO atual (inclusive pelo método usado na 1.4.1).
  Agora o bot seleciona os próprios dados do gráfico antes de criá-lo e, se ainda falhar, recria a partir
  de uma célula vazia. Depois de criar uma tabela dinâmica, a seleção não fica mais dentro dela.

## 1.4.1 — 16/11/2026
- Correção: *Excel: gráfico* falhava ("Exceção.") com o Excel visível quando a seleção estava dentro de uma
  tabela dinâmica — o gráfico agora é criado vazio e só depois recebe os dados, sem depender da seleção.
- Erros do Excel aparecem explicados no log em vez do código bruto.

## 1.4.0 — 16/11/2026
- A gravação guarda **em qual programa** foi cada clique/digitação (Chrome, Excel, SAP, sistema desktop...).
- Na execução, antes de cada ação, a janela daquele programa é detectada: se estiver **minimizada, pela
  metade ou solta**, é **maximizada** e trazida para a frente (caixas de diálogo só vêm para a frente).
- Na gravação: clicar numa janela que não está maximizada maximiza ela e pede para clicar de novo
  (esse clique não é gravado, para a posição bater com a execução).
- Antes de rodar um roteiro com passos de Excel, o bot **pergunta**: segundo plano (Excel invisível) ou
  ver o processo (Excel visível e maximizado, selecionando cada célula/tabela/gráfico enquanto trabalha).
- Aviso claro se o modo segundo plano for usado com passos gravados fora do Chrome.

## 1.3.0 — 16/11/2026
- Passo **Excel: gráfico**: cria ou recria gráficos de colunas, colunas empilhadas, barras, linhas, pizza, rosca
  e área a partir de um intervalo — ou do **nome de uma tabela dinâmica** (vira gráfico dinâmico).
- *Excel: copiar intervalo* sem "só valores" ajusta as fórmulas para a linha de destino (como copiar/colar).
- Proteção: sem o Excel instalado, planilhas com gráficos/tabelas dinâmicas/imagens não são salvas por cima.
- Exemplo pronto: `exemplos/painel_graficos.xlsx` + `exemplos/roteiro_excel_graficos.json`.

## 1.2.0 — 16/11/2026
- Passo **Excel: tabela dinâmica**: cria (ou recria com os dados atuais) escolhendo linhas, colunas, valores,
  filtros e a função (soma, contagem, média, máximo, mínimo).
- **Fórmulas em português** (=SE(...;...), PROCV, SOMA...) no passo *Excel: escrever célula*; num intervalo
  (ex.: `H2:H{ultima_linha}`) a fórmula é preenchida para baixo ajustando as linhas. Excel em inglês: tradução automática.
- Passo **Excel: última linha preenchida** → `{ultima_linha}` e `{proxima_linha}`.
- *Excel: salvar / exportar* com escolha da aba para PDF/CSV.
- Exemplo pronto: `exemplos/relatorio_chamados.xlsx` + `exemplos/roteiro_excel_dinamica.json`.
- Roteiros só de Excel não procuram mais o Chrome.

## 1.1.0 — 15/11/2026
- **Excel sem mouse**: novos passos *Excel: abrir planilha, ler célula, escrever célula, copiar intervalo,
  rodar macro, atualizar / recalcular, salvar / exportar (xlsx, xlsm, PDF, CSV) e fechar*. Usa o próprio
  Excel numa cópia invisível (não mexe no Excel que você estiver usando); sem Excel, usa openpyxl.
- **Planilha .xlsx/.xlsm como lista de chamados** (além de CSV), com escolha da aba.
- **Resultado na própria planilha**: coluna de status com "OK data hora" ou "Erro ...", e valores lidos nas
  colunas de mesmo nome (ex.: coluna *Numero* ← `{Numero}`). Linhas já OK são puladas (continua de onde parou).
- Opção **seguir para o próximo chamado** quando um der erro.
- Passo **Ler da página**: guarda um valor da página (ex.: número do chamado) numa variável `{nome}`.
- Variáveis novas: `{linha_planilha}`, `{data_arquivo}`, `{hora_arquivo}`.
- Em segundo plano, vários chamados reaproveitam a mesma janela do Chrome do bot.

## 1.0.0 — 15/11/2026
- Novo nome: **Bot Genesys** (arquivo principal `bot_genesys.py`; `bot_chamado.py` continua funcionando como atalho).
- Versões numeradas, tela *Ajuda → Sobre* com histórico, versão no log e nos arquivos exportados.
- Agendamentos do Windows passam para a pasta **BotGenesys** do Agendador de Tarefas
  (os criados antes, na pasta BotChamados, continuam rodando e podem ser editados/excluídos normalmente).

## 0.5.0
- **Rodar em segundo plano**: o bot age direto na página do Chrome controlado, sem usar mouse e teclado.
- Cartão na tela sempre visível: em execução / pausado / concluído / com avisos / erro / interrompido.
- Gravação guarda o **elemento** clicado (campo/botão), além da posição.
- **Exportar para Python**: um arquivo `.py` único, com o motor completo, passos legíveis e imagens embutidas.

## 0.4.2
- Rolagem executada na aba certa, esperando o conteúdo carregar e conferindo o resultado.
- Correção do clique pela imagem mais rigorosa (não "acha" botões parecidos longe do lugar).
- Campos de senha ocultos na tela/log e criptografados no arquivo (DPAPI do Windows).

## 0.4.1
- Gravação da rolagem pelo touchpad e pela roda do mouse (inclusive rodas de rolagem suave).

## 0.4.0
- Chrome sempre maximizado no monitor principal (corrige minimizado, meia tela, tela cheia, outro monitor).
- Visual novo (tema claro/escuro, lista com ícones, arrastar para reordenar, abas, barra de status).
- Agendamento: uma vez, diário, dias úteis, dias da semana ou a cada X minutos; pelo app ou pelo Windows.

## 0.3.0
- Gravação automática do processo (cliques, textos, teclas, rolagem, esperas).
- Planilha CSV (vários chamados), tentativas, ativar/desativar passos, desfazer, logs e print do erro.

## 0.2.0
- Aguardar a página carregar (lendo o Chrome ou pela tela parar de mudar).

## 0.1.0
- Primeira versão: cliques por posição, digitação, teclas e imagem, com opção de ver o bot executando.
