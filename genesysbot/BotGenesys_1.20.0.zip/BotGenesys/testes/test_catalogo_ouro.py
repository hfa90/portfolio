# -*- coding: utf-8 -*-
"""O catálogo de passos (tipos, campos, ícones, dicas, resumos e validações do formulário) se comporta
EXATAMENTE como no retrato gravado (testes/ouro_catalogo.json)."""
import json

import pytest

from conftest import isolar_janela, precisa_tela, nova_janela
from ouro_casos import ARQ_OURO, tirar_retrato

pytestmark = precisa_tela


@pytest.fixture(scope="module")
def retrato(tmp_path_factory):
    import bot_genesys as b
    import ttkbootstrap as tb
    tmp = tmp_path_factory.mktemp("ouro")
    mp = pytest.MonkeyPatch()
    isolar_janela(mp, tmp)
    root = nova_janela(tb, b.TEMA_CLARO)
    root.withdraw()
    app = b.App(root)
    r = tirar_retrato(app)
    root.destroy()
    mp.undo()
    return r


@pytest.fixture(scope="module")
def ouro():
    with open(ARQ_OURO, encoding="utf-8") as f:
        return json.load(f)


@pytest.mark.parametrize("parte", ["tipos", "campos", "icones", "dicas", "precisa_tela", "retentaveis"])
def test_definicoes_iguais(retrato, ouro, parte):
    assert retrato[parte] == ouro[parte]


def test_resumos_iguais(retrato, ouro):
    for novo, velho in zip(retrato["resumos"], ouro["resumos"]):
        assert novo == velho
    assert len(retrato["resumos"]) == len(ouro["resumos"])


def test_validacoes_do_formulario_iguais(retrato, ouro):
    for novo, velho in zip(retrato["formularios"], ouro["formularios"]):
        assert novo == velho, f"{velho['tipo']} {velho['valores']}"
    assert len(retrato["formularios"]) == len(ouro["formularios"])
