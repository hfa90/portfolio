# -*- coding: utf-8 -*-
"""Fórmulas do Excel em português e inglês: detecção do idioma, conversão nos dois sentidos e escrita."""
import openpyxl
import pytest

import excel as xlm
import formulas_excel as fx

CASOS = [  # (português, inglês)
    ('=SE(A2>0;"Sim";"Não")', '=IF(A2>0,"Sim","Não")'),
    ("=PROCV(D2;SLA!$A$2:$B$5;2;FALSO)", "=VLOOKUP(D2,SLA!$A$2:$B$5,2,FALSE)"),
    ("=SOMA(A1:A3)*1,5", "=SUM(A1:A3)*1.5"),
    ('=SEERRO(PROCX(A1;B:B;C:C);"#N/D")', '=IFERROR(XLOOKUP(A1,B:B,C:C),"#N/D")'),
    ('=CONT.SES(A:A;"x";B:B;">1,5")', '=COUNTIFS(A:A,"x",B:B,">1,5")'),
    ("=ÍNDICE(B:B;CORRESP(E1;A:A;0))", "=INDEX(B:B,MATCH(E1,A:A,0))"),
    ("=DIATRABALHOTOTAL(A1;B1)", "=NETWORKDAYS(A1,B1)"),
    ('=UNIRTEXTO(", ";VERDADEIRO;A1:A3)', '=TEXTJOIN(", ",TRUE,A1:A3)'),
    ("=SE(ÉERROS(A1);#N/D;A1)", "=IF(ISERROR(A1),#N/A,A1)"),
]


@pytest.mark.parametrize("pt,en", CASOS)
def test_conversao_e_deteccao(pt, en):
    assert fx.detectar_idioma(pt) == "pt"
    assert fx.detectar_idioma(en) == "en"
    assert fx.para_ingles(pt) == en
    assert fx.para_portugues(en) == pt
    assert fx.para_ingles(en) == en and fx.para_portugues(pt) == pt  # já no idioma: não muda


def test_partes_protegidas_nao_mudam():
    f = "='SOMA SE'!A1+SOMA(Tabela1[PROCV];\"SE(1;2)\")"
    assert fx.para_ingles(f) == "='SOMA SE'!A1+SUM(Tabela1[PROCV],\"SE(1;2)\")"


def test_minusculas_e_neutras():
    assert fx.para_ingles("=se(a1>1;verdadeiro;falso)") == "=IF(a1>1,TRUE,FALSE)"
    assert fx.detectar_idioma("=A1+B1") == "neutro"
    assert fx.detectar_idioma("=ABS(A1;B1)") == "pt" and fx.detectar_idioma("=ABS(A1,B1)") == "en"


def test_dicionario_sem_conflitos():
    assert len(fx.FUNCOES) >= 250
    ambos = set(fx.EN_PARA_PT) & set(fx.PT_PARA_EN)
    assert all(fx.EN_PARA_PT[n] == n == fx.PT_PARA_EN[n] for n in ambos), "nome igual com sentidos diferentes"
    assert len({f["pt"] for f in fx.FUNCOES}) == len(fx.FUNCOES)


def test_funcoes_novas_ganham_prefixo_no_arquivo():
    assert fx.para_arquivo("=XLOOKUP(A1,B:B,C:C)") == "=_xlfn.XLOOKUP(A1,B:B,C:C)"
    assert fx.para_arquivo("=FILTER(A:A,B:B>1)") == "=_xlfn._xlws.FILTER(A:A,B:B>1)"
    assert fx.para_arquivo("=SUM(A1:A3)") == "=SUM(A1:A3)"


def test_busca_e_sintaxe():
    f = fx.procurar("PROCV")[0]
    assert f["en"] == "VLOOKUP"
    assert fx.sintaxe(f, "pt").startswith("PROCV(valor; tabela")
    assert fx.sintaxe(f, "en").startswith("VLOOKUP(valor, tabela")
    assert any(x["en"] == "SUMIFS" for x in fx.procurar("critérios"))


@pytest.mark.parametrize("idioma", ["automático", "português", "inglês"])
def test_escrever_em_qualquer_idioma_sem_excel(tmp_path, idioma):
    caminho = tmp_path / "t.xlsx"
    wb = openpyxl.Workbook()
    wb.active.title = "Dados"
    wb.save(caminho)
    xl = xlm.Excel(lambda *a, **k: None).abrir(str(caminho), "Dados", usar_excel=False)
    pt, en = '=SE(A1>1;"sim";"não")', '=IF(A1>1,"sim","não")'
    xl.escrever("B1", en if idioma == "inglês" else pt, idioma=idioma)
    xl.escrever("C1:C3", "=PROCX(A1;D:D;E:E)" if idioma != "inglês" else "=XLOOKUP(A1,D:D,E:E)", idioma=idioma)
    ws = xl.wb["Dados"]
    assert ws["B1"].value == en
    assert ws["C3"].value == "=_xlfn.XLOOKUP(A3,D:D,E:E)"


def test_roteiro_antigo_formula_pt_continua_funcionando(tmp_path):
    caminho = tmp_path / "t.xlsx"
    openpyxl.Workbook().save(caminho)
    xl = xlm.Excel(lambda *a, **k: None).abrir(str(caminho), usar_excel=False)
    xl.escrever("A1", "=SOMA(1;2)", formula_pt=True)
    xl.escrever("A2", "=SUM(1,2)", formula_pt=False)
    assert xl.wb.active["A1"].value == xl.wb.active["A2"].value == "=SUM(1,2)"


@pytest.mark.skipif(not xlm.HAS_COM, reason="precisa do Microsoft Excel (Windows)")
def test_excel_de_verdade_aceita_os_dois_idiomas(tmp_path):
    caminho = tmp_path / "t.xlsx"
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Dados"
    for i in range(1, 6):
        ws.cell(i, 1, i)
    wb.save(caminho)
    xl = xlm.Excel(lambda *a, **k: None).abrir(str(caminho), "Dados")
    try:
        xl.escrever("B1", "=SOMA(A1:A5)")
        xl.escrever("B2", "=SUM(A1:A5)")
        xl.escrever("B3", '=SE(B1=B2;"igual";"diferente")')
        xl.escrever("B4", '=IF(B1=B2,"same","different")')
        xl.recalcular()
        assert [xl.ler(c) for c in ("B1", "B2", "B3", "B4")] == [15, 15, "igual", "same"]
    finally:
        xl.fechar()
