# -*- coding: utf-8 -*-
"""Passo 'Pausar: esperar você' (login, captcha...) e 'codificar para link'."""
import json
import threading
import time
import urllib.parse

import pytest

from conftest import APP_DIR, precisa_tela

pytestmark = precisa_tela
CFG = {"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0}


class _UiGrava:
    def __init__(self, ui):
        self.ui, self.eventos = ui, []

    def __getattr__(self, n):
        return getattr(self.ui, n)

    def aguardar_usuario(self, msg):
        self.eventos.append(("aguardar", msg))

    def fim_aguardar(self):
        self.eventos.append(("fim",))


def test_continua_sozinho_quando_a_pagina_mostra_o_elemento(motor, monkeypatch):
    motor.ui = _UiGrava(motor.ui)
    chamadas = []
    monkeypatch.setattr(motor, "_pagina_tem", lambda t, s: chamadas.append(s) or len(chamadas) >= 3)
    monkeypatch.setattr(motor, "_esperar", lambda seg: None)
    p = {"tipo": "aguardar_usuario", "mensagem": "Faça login", "continuar": "aparecer na página do Chrome",
         "seletor": 'div[gh="cm"]', "timeout": 0}
    cod, erro = motor.rodar([p], cfg=CFG)
    assert cod == 0, erro
    assert motor.ui.eventos == [("aguardar", "Faça login"), ("fim",)] and chamadas[0] == 'div[gh="cm"]'
    assert motor.pausado is False


def test_continua_quando_voce_clica_em_continuar(motor):
    p = {"tipo": "aguardar_usuario", "mensagem": "Confira", "continuar": "eu clicar em Continuar (ou F2)"}
    threading.Timer(0.6, lambda: setattr(motor, "pausado", False)).start()
    t0 = time.time()
    cod, erro = motor.rodar([p, {"tipo": "definir_variavel", "nome": "depois", "valor": "ok"}], cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["depois"] == "ok" and 0.5 < time.time() - t0 < 5


def test_tempo_acabou(motor, monkeypatch):
    monkeypatch.setattr(motor, "_pagina_tem", lambda t, s: False)
    p = {"tipo": "aguardar_usuario", "mensagem": "Login", "continuar": "aparecer na página do Chrome",
         "texto": "Caixa de entrada", "timeout": 0.5}
    cod, erro = motor.rodar([p], cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "tempo de espera" in erro
    cod, erro = motor.rodar([dict(p, se_acabar="seguir")], cfg=CFG)
    assert cod == 0, erro


def test_codificar_para_link(motor):
    passos = [{"tipo": "definir_variavel", "nome": "txt", "valor": "Olá, R$ 1.000 & mais"},
              {"tipo": "definir_variavel", "nome": "url", "operacao": "codificar para link (URL)", "valor": "{txt}"}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["url"] == "Ol%C3%A1%2C%20R%24%201.000%20%26%20mais"
    assert urllib.parse.unquote(motor.vars["url"]) == "Olá, R$ 1.000 & mais"


def test_exemplo_ia_excel_gmail_bem_montado():
    import os
    import fluxo as fx
    import passos as cat
    with open(os.path.join(APP_DIR, "exemplos", "roteiro_ia_excel_gmail.json"), encoding="utf-8") as f:
        passos = json.load(f)["passos"]
    fx.estrutura([p["tipo"] for p in passos])
    tipos = [p["tipo"] for p in passos]
    formulas = [p for p in passos if p["tipo"] == "excel_escrever" and str(p["valor"]).startswith("=")]
    assert len(formulas) >= 5 and tipos.count("excel_dinamica") == 2
    assert {"ia_perguntar", "aguardar_usuario", "abrir_chrome", "chrome_anexar", "vigiar_popup"} <= set(tipos)
    assert os.path.exists(os.path.join(APP_DIR, "exemplos", "vendas_ia.xlsx"))
    from interface.comum import _CTX_VALIDAR
    for p in passos:
        assert cat.validar(p, _CTX_VALIDAR) is None, p
