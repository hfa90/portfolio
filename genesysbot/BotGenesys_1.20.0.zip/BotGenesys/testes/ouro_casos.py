# -*- coding: utf-8 -*-
"""Casos usados pelo 'retrato' (teste de ouro) do catálogo de passos.
O retrato registra como o programa se comporta; o teste exige que continue IGUAL depois de reorganizações."""
import json
import os

AQUI = os.path.dirname(os.path.abspath(__file__))
ARQ_OURO = os.path.join(AQUI, "ouro_catalogo.json")

# Variações de passos para conferir o texto do resumo (o que aparece na lista)
PASSOS = [
    {"tipo": "abrir_chrome", "url": "https://x.com"},
    {"tipo": "clique", "x": 10, "y": 20},
    {"tipo": "clique", "x": 10, "y": 20, "botao": "direito", "cliques": 2, "aguardar": True, "conferir": True,
     "alvo": {"texto": "Enviar formulário de abertura de chamado agora", "tag": "button"}, "descricao": "Enviar"},
    {"tipo": "clique", "x": 1, "y": 2, "alvo": {"tag": "input"}, "janela": {"processo": "excel.exe"}},
    {"tipo": "clique", "x": 1, "y": 2, "janela": {"processo": "chrome.exe"}},
    {"tipo": "digitar", "texto": "linha 1\nlinha 2", "enter": True},
    {"tipo": "digitar", "texto": "x" * 60},
    {"tipo": "digitar", "texto": "segredo", "senha": True, "enter": True},
    {"tipo": "digitar", "texto": "a", "janela": {"processo": "sap.exe"}},
    {"tipo": "tecla", "teclas": "tab"},
    {"tipo": "tecla", "teclas": "ctrl+c", "repetir": 3},
    {"tipo": "esperar", "segundos": 2.5},
    {"tipo": "aguardar_carregar", "timeout": 30},
    {"tipo": "aguardar_carregar", "metodo": "visual", "timeout": 10, "seletor": "#id"},
    {"tipo": "clicar_imagem", "imagem": "imagens/botao.png", "confianca": 0.9, "aguardar": True},
    {"tipo": "esperar_imagem", "imagem": "C:/x/y.png", "confianca": 0.8},
    {"tipo": "rolar", "pixels": 300},
    {"tipo": "rolar", "pixels": -120, "alvo_y": 800, "seletor": ".lista", "x": 5, "y": 6, "origem": "touchpad"},
    {"tipo": "rolar", "quantidade": -3, "origem": "roda"},
    {"tipo": "rolar", "pixels": 50, "alvo_y": 0, "origem": "pagina", "janela": {"processo": "acrord32.exe"}},
    {"tipo": "ler_pagina", "variavel": "num", "seletor": "#n", "regex": "(INC\\d+)"},
    {"tipo": "ler_pagina", "variavel": "num"},
    {"tipo": "excel_abrir", "arquivo": "pasta/plan.xlsx", "aba": "Dados", "visivel": True},
    {"tipo": "excel_abrir", "arquivo": "plan.xlsx"},
    {"tipo": "excel_ler", "celula": "B2", "variavel": "total"},
    {"tipo": "excel_escrever", "celula": "A1", "valor": "=SE(A2>1;\"sim\";\"não\")" + "x" * 50},
    {"tipo": "excel_copiar", "origem": "A1:B2", "destino": "C1"},
    {"tipo": "excel_copiar", "origem": "A1:B2", "destino": "C1", "so_valores": False},
    {"tipo": "excel_ultima_linha", "coluna": "B", "aba": "Chamados"},
    {"tipo": "excel_ultima_linha"},
    {"tipo": "excel_grafico", "dados": "Ind!A3:B8", "destino": "P!H4", "tipo_grafico": "linhas", "titulo": "T"},
    {"tipo": "excel_grafico", "dados": "din1", "destino": "P!H4"},
    {"tipo": "excel_dinamica", "nome": "d", "destino": "P!A3", "linhas": "Setor", "colunas": "Status",
     "valores": "Chamado", "funcao": "contagem", "filtros": "Prioridade"},
    {"tipo": "excel_dinamica", "nome": "d", "destino": "P!A3", "valores": "Horas"},
    {"tipo": "excel_macro", "macro": "Modulo1.X", "argumentos": "1;2"},
    {"tipo": "excel_macro", "macro": "X"},
    {"tipo": "excel_atualizar"},
    {"tipo": "excel_atualizar", "acao": "só recalcular fórmulas"},
    {"tipo": "excel_salvar", "arquivo": "saida/r.pdf", "formato": "pdf", "fechar": True},
    {"tipo": "excel_salvar"},
    {"tipo": "excel_fechar", "salvar": True},
    {"tipo": "excel_fechar"},
    {"tipo": "desconhecido"},
]

# Validações do formulário: (tipo, valores dos campos que mudam em relação ao padrão)
FORMULARIOS = [
    ("clique", {}),
    ("clique", {"pos": (100, 200)}),
    ("clique", {"pos": (100, 200), "conferir": True}),
    ("clique", {"pos": (100, 200), "conferir": True, "imagem": "nao/existe.png"}),
    ("clique", {"pos": (100, 200), "cliques": "2"}),
    ("digitar", {"texto": "olá\nmundo"}),
    ("tecla", {"teclas": "ctrl+shift+i"}),
    ("tecla", {"teclas": "tecla_que_nao_existe"}),
    ("tecla", {"teclas": ""}),
    ("tecla", {"repetir": "abc"}),
    ("esperar", {"segundos": "2,5"}),
    ("rolar", {"alvo_y": "800"}),
    ("rolar", {"alvo_y": "oito"}),
    ("clicar_imagem", {}),
    ("clicar_imagem", {"imagem": "nao/existe.png"}),
    ("esperar_imagem", {}),
    ("ler_pagina", {"variavel": ""}),
    ("ler_pagina", {}),
    ("excel_abrir", {}),
    ("excel_abrir", {"arquivo": "plan.xlsx"}),
    ("excel_ler", {"variavel": ""}),
    ("excel_ler", {"celula": "Dados!A1:C{proxima_linha}"}),
    ("excel_ler", {"celula": "isso não é célula"}),
    ("excel_escrever", {"celula": "A{linha_planilha}", "valor": "=SOMA(A1:A2)"}),
    ("excel_escrever", {"celula": "???"}),
    ("excel_grafico", {}),
    ("excel_grafico", {"dados": "Ind!A3:B8"}),
    ("excel_dinamica", {}),
    ("excel_dinamica", {"valores": "Horas"}),
    ("excel_copiar", {"origem": "A1", "destino": "B1"}),
    ("excel_macro", {"macro": "M"}),
    ("excel_ultima_linha", {}),
    ("excel_atualizar", {}),
    ("excel_salvar", {}),
    ("excel_fechar", {}),
    ("abrir_chrome", {}),
    ("aguardar_carregar", {"timeout": "x"}),
]


def _normalizar(v):
    return json.loads(json.dumps(v, ensure_ascii=False, default=list))


def tirar_retrato(app):
    """app = instância de bot_genesys.App (janela escondida). Devolve o retrato (dict)."""
    import bot_genesys as b
    import motor
    from tkinter import messagebox
    r = {
        "tipos": list(motor.TIPOS.items()),
        "campos": {t: [list(c[:4]) + [c[4]] for c in b.FIELDS[t]] for t in b.FIELDS},
        "icones": b.ICONES,
        "dicas": b.DICAS,
        "precisa_tela": sorted(motor.PRECISA_TELA),
        "retentaveis": sorted(motor.RETENTAVEIS),
        "resumos": [motor.resumo(dict(p)) for p in PASSOS],
        "formularios": [],
    }
    erros = []
    orig = messagebox.showerror
    messagebox.showerror = lambda titulo, msg, **k: erros.append([titulo, msg])
    try:
        for tipo, valores in FORMULARIOS:
            app._set_tipo(tipo)
            for chave, valor in valores.items():
                kind, var = app.fvars[chave]
                if kind == "pos":
                    var[0].set(valor[0])
                    var[1].set(valor[1])
                elif kind == "text":
                    var.delete("1.0", "end")
                    var.insert("1.0", valor)
                else:
                    var.set(valor)
            erros.clear()
            d = app._ler_form()
            r["formularios"].append({"tipo": tipo, "valores": valores, "resultado": d, "erros": list(erros)})
    finally:
        messagebox.showerror = orig
    return _normalizar(r)
