# -*- coding: utf-8 -*-
"""Diário (1.19.1): log gravado na hora, detalhe técnico, erros que escapam e salvar sem corromper."""
import json
import os
import sys
import threading

import pytest

import diario
from conftest import precisa_tela


def _log(pasta):
    with open(diario.arquivo_de_hoje(str(pasta)), encoding="utf-8") as f:
        return f.read()


def test_escrever_grava_na_hora_e_cria_a_pasta(tmp_path):
    pasta = tmp_path / "logs"
    assert diario.escrever(str(pasta), "[10:00:00] primeira")
    assert diario.escrever(str(pasta), "[10:00:01] segunda\n")
    assert _log(pasta) == "[10:00:00] primeira\n[10:00:01] segunda\n"


def test_escrever_nunca_da_erro(tmp_path):
    arquivo = tmp_path / "nao_e_pasta"
    arquivo.write_text("x", encoding="utf-8")
    assert diario.escrever(str(arquivo), "linha") is False


def test_escrever_de_varias_threads_nao_mistura_linhas(tmp_path):
    def varias(n):
        for i in range(50):
            diario.escrever(str(tmp_path), f"t{n} linha {i} " + "x" * 200)
    ts = [threading.Thread(target=varias, args=(n,)) for n in range(6)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    linhas = _log(tmp_path).splitlines()
    assert len(linhas) == 300 and all(l.endswith("x" * 200) and l.startswith("t") for l in linhas)


def test_detalhe_tem_o_caminho_do_erro_e_a_causa(tmp_path):
    try:
        try:
            {}["excel_grafico"]
        except KeyError as e:
            raise RuntimeError("Passo 15 (Excel: gráfico): 'excel_grafico'") from e
    except RuntimeError as e:
        diario.detalhe(str(tmp_path), "erro que parou a execução", diario.texto_erro(e))
    texto = _log(tmp_path)
    assert "DETALHE TÉCNICO — erro que parou a execução:" in texto
    assert "KeyError" in texto and "RuntimeError" in texto and "test_diario.py" in texto
    assert all(l.startswith(("[", "    | ")) for l in texto.splitlines())


def test_erro_em_outra_thread_vai_para_o_log(tmp_path, monkeypatch):
    monkeypatch.setattr(diario, "_ganchos", dict(diario._ganchos, instalado=False))
    monkeypatch.setattr(sys, "excepthook", lambda *a: None)
    monkeypatch.setattr(threading, "excepthook", lambda a: None)
    avisos = []
    diario.instalar_ganchos(str(tmp_path), ao_erro=avisos.append)

    def quebra():
        raise ValueError("estourou na thread")
    t = threading.Thread(target=quebra, name="tarefa-teste")
    t.start()
    t.join()
    texto = _log(tmp_path)
    assert "tarefa-teste" in texto and "ValueError: estourou na thread" in texto
    assert avisos == ["ValueError: estourou na thread"]


def test_erro_que_fecha_o_programa_vai_para_o_log_e_chama_o_gancho_anterior(tmp_path, monkeypatch):
    monkeypatch.setattr(diario, "_ganchos", dict(diario._ganchos, instalado=False))
    vistos = []
    monkeypatch.setattr(sys, "excepthook", lambda *a: vistos.append(a[0]))
    monkeypatch.setattr(threading, "excepthook", lambda a: None)
    diario.instalar_ganchos(str(tmp_path))
    diario.instalar_ganchos(str(tmp_path))  # de novo: não empilha
    try:
        raise OSError("disco cheio")
    except OSError:
        sys.excepthook(*sys.exc_info())
    assert _log(tmp_path).count("OSError: disco cheio") == 1 and vistos == [OSError]


def test_salvar_json_troca_o_arquivo_e_nao_deixa_temporario(tmp_path):
    p = tmp_path / "roteiro.json"
    p.write_text('{"antigo": true}', encoding="utf-8")
    diario.salvar_json(str(p), {"passos": [{"tipo": "esperar", "descricao": "ação"}]})
    assert json.loads(p.read_text(encoding="utf-8"))["passos"][0]["descricao"] == "ação"
    assert os.listdir(tmp_path) == ["roteiro.json"]


def test_salvar_json_que_falha_mantem_o_arquivo_anterior(tmp_path, monkeypatch):
    p = tmp_path / "roteiro.json"
    p.write_text('{"antigo": true}', encoding="utf-8")
    with pytest.raises(TypeError):  # conteúdo que não vira JSON: nem toca no disco
        diario.salvar_json(str(p), {"x": object()})
    assert json.loads(p.read_text(encoding="utf-8")) == {"antigo": True}

    def falha(a, b):
        raise OSError("disco falhou na troca")
    monkeypatch.setattr(os, "replace", falha)
    with pytest.raises(OSError):
        diario.salvar_json(str(p), {"novo": 1})
    assert json.loads(p.read_text(encoding="utf-8")) == {"antigo": True}
    assert os.listdir(tmp_path) == ["roteiro.json"]


def test_salvar_json_insiste_quando_o_arquivo_esta_ocupado(tmp_path, monkeypatch):
    p = tmp_path / "config_app.json"
    real, chamadas = os.replace, []

    def ocupado(a, b):
        chamadas.append(1)
        if len(chamadas) < 3:
            raise PermissionError("em uso por outro processo")
        return real(a, b)
    monkeypatch.setattr(os, "replace", ocupado)
    monkeypatch.setattr(diario.time, "sleep", lambda s: None)
    diario.salvar_json(str(p), {"tema": "flatly"})
    assert len(chamadas) == 3 and json.loads(p.read_text(encoding="utf-8")) == {"tema": "flatly"}


@precisa_tela
def test_motor_manda_o_detalhe_tecnico_quando_a_execucao_falha(motor):
    detalhes = []
    motor.ui.detalhe = lambda titulo, texto: detalhes.append((titulo, texto))
    cod, erro = motor.rodar([{"tipo": "tecla", "teclas": "tecla_que_nao_existe"}], cfg={"contagem": 0, "tent": 1})
    assert cod == 1 and detalhes and detalhes[0][0] == "erro que parou a execução"
    assert "Traceback" in detalhes[0][1] and "ValueError" in detalhes[0][1]


@precisa_tela
def test_trava_de_execucao(tmp_path, monkeypatch):
    import interface.comum as c
    monkeypatch.setattr(c, "LOG_DIR", str(tmp_path))
    monkeypatch.setattr(c, "LOCK_FILE", str(tmp_path / ".executando"))
    try:
        assert c.pegar_trava() and c.pegar_trava()  # o mesmo processo pode pegar de novo
        assert json.loads((tmp_path / ".executando").read_text(encoding="utf-8"))["pid"] == os.getpid()
    finally:
        c.soltar_trava()
    assert not (tmp_path / ".executando").exists() and c._MUTEX is None
    # sobra de um processo que morreu (ou PID reaproveitado): no Windows a trava do sistema decide, não o arquivo
    (tmp_path / ".executando").write_text(json.dumps({"pid": os.getpid() + 1, "t": 0}), encoding="utf-8")
    try:
        assert c.pegar_trava()
    finally:
        c.soltar_trava()


@pytest.mark.skipif(sys.platform != "win32", reason="trava do Windows")
def test_trava_barra_outro_processo(tmp_path, monkeypatch):
    import subprocess
    import interface.comum as c
    monkeypatch.setattr(c, "LOG_DIR", str(tmp_path))
    monkeypatch.setattr(c, "LOCK_FILE", str(tmp_path / ".executando"))
    codigo = ("import sys, interface.comum as c; c.LOG_DIR = sys.argv[1]; "
              "c.LOCK_FILE = sys.argv[1] + r'\\.executando'; sys.exit(0 if c.pegar_trava() else 7)")
    pasta_app = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    try:
        assert c.pegar_trava()
        assert subprocess.run([sys.executable, "-c", codigo, str(tmp_path)], cwd=pasta_app).returncode == 7
    finally:
        c.soltar_trava()
    assert subprocess.run([sys.executable, "-c", codigo, str(tmp_path)], cwd=pasta_app).returncode == 0


# ------------------------------------------------------------------ 1.20.0
def test_reescrever_troca_o_conteudo_e_preserva_as_quebras_de_linha(tmp_path):
    p = tmp_path / "bot_20261116.log"
    p.write_bytes("[10:00:00] Digitar: Segredo@99\r\n[10:00:01] fim\r\n".encode("utf-8"))
    assert diario.reescrever(str(p), lambda t: t.replace("Segredo@99", "••••••")) is True
    assert p.read_bytes() == "[10:00:00] Digitar: ••••••\r\n[10:00:01] fim\r\n".encode("utf-8")
    assert diario.reescrever(str(p), lambda t: t) is False


def test_historico_de_execucoes(tmp_path):
    pasta = str(tmp_path / "logs")
    assert diario.ler_execucoes(pasta) == []
    base = {"roteiro": "chamados.json", "duracao_s": 12, "avisos": 0, "parcial": False}
    diario.registrar_execucao(pasta, dict(base, resultado="ok"))
    diario.registrar_execucao(pasta, dict(base, resultado="erro", erro="Passo 7: não achou", passo_falhou=7))
    diario.registrar_execucao(pasta, dict(base, resultado="erro", erro="Passo 7: não achou", passo_falhou=7))
    diario.registrar_execucao(pasta, dict(base, resultado="aviso"))
    diario.registrar_execucao(pasta, dict(base, resultado="parado"))
    diario.registrar_execucao(pasta, dict(base, resultado="erro", parcial=True))  # 'testar só este passo' não conta
    with open(os.path.join(pasta, diario.HISTORICO), "a", encoding="utf-8") as f:
        f.write("linha estragada {\n")
    execucoes = diario.ler_execucoes(pasta)
    assert len(execucoes) == 6 and execucoes[0]["parcial"] is True and execucoes[-1]["resultado"] == "ok"
    assert all("quando" in e for e in execucoes)
    r = diario.resumo_execucoes(execucoes)
    assert (r["total"], r["ok"], r["aviso"], r["erro"], r["parado"]) == (5, 1, 1, 2, 1)
    assert r["taxa"] == 50 and r["piores"] == [("chamados.json", 7, 2)]
    assert diario.resumo_execucoes([])["taxa"] is None


def test_registrar_execucao_nunca_da_erro(tmp_path):
    arquivo = tmp_path / "nao_e_pasta"
    arquivo.write_text("x", encoding="utf-8")
    assert diario.registrar_execucao(str(arquivo), {"x": object()}) is False


def test_chrome_do_bot_nao_aceita_conexao_de_qualquer_origem():
    import navegador
    assert not any("remote-allow-origins" in f for f in navegador.FLAGS_CONTROLE)


def test_tela_bloqueada_e_manter_acordado_nunca_dao_erro():
    import janelas
    assert janelas.tela_bloqueada() in (True, False, None)
    assert janelas.manter_acordado(True) in (True, False)
    assert janelas.manter_acordado(False) in (True, False)


@precisa_tela
def test_imagem_que_nao_existe_e_avisada_antes_de_comecar(motor):
    passos = [{"tipo": "esperar", "segundos": 5}, {"tipo": "clicar_imagem", "imagem": "imagens/sumiu.png"}]
    cod, erro = motor.rodar(passos, cfg={"contagem": 0})
    assert cod == 1 and "antes de começar" in erro and "passo 2" in erro and "sumiu.png" in erro
    assert "Execução iniciada" not in motor.ui.texto()
    protegido = [{"tipo": "tentar"}, {"tipo": "clicar_imagem", "imagem": "imagens/sumiu.png", "timeout": 0.2},
                 {"tipo": "se_der_erro"}, {"tipo": "fim_tentar"}]
    assert motor._conferir_arquivos(list(enumerate(protegido))) == []  # dentro de um Tentar: o roteiro já trata


@precisa_tela
def test_tela_bloqueada_para_antes_de_comecar(motor, monkeypatch):
    import janelas
    monkeypatch.setattr(janelas, "tela_bloqueada", lambda: True)
    cod, erro = motor.rodar([{"tipo": "tecla", "teclas": "f13"}], cfg={"contagem": 0})
    assert cod == 1 and "bloqueada" in erro
    cod, erro = motor.rodar([{"tipo": "esperar", "segundos": 0.01}], cfg={"contagem": 0, "pausa": 0})
    assert cod == 0  # roteiro que não usa a tela roda mesmo com ela bloqueada
