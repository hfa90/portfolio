# -*- coding: utf-8 -*-
"""Caixinha de status: arrastar, lembrar a posição e sair da frente quando o bot vai clicar debaixo dela."""
import pytest

from conftest import nova_janela, precisa_tela

pytestmark = precisa_tela


@pytest.fixture
def painel():
    import ttkbootstrap as tb
    from painel import Painel
    root = nova_janela(tb, "flatly")
    root.withdraw()
    p = Painel(root)
    yield p
    p.esconder()
    root.destroy()


def _arrastar(win, de, para):
    w = win
    w.event_generate("<ButtonPress-1>", x=5, y=5, rootx=de[0], rooty=de[1])
    w.event_generate("<B1-Motion>", x=5, y=5, rootx=para[0], rooty=para[1])
    w.event_generate("<ButtonRelease-1>", x=5, y=5, rootx=para[0], rooty=para[1])
    w.update()


def test_arrastar_guarda_a_posicao(painel):
    salvou = []
    painel.ao_mover = lambda: salvou.append(True)
    painel.mostrar("frente")
    painel.root.update()
    x0, y0 = painel.win.winfo_x(), painel.win.winfo_y()
    _arrastar(painel.win, (x0 + 5, y0 + 5), (x0 - 295, y0 + 205))  # pega 5 px dentro da caixa
    assert painel.posicoes["frente"] == [x0 - 300, y0 + 200] and salvou
    assert painel.contem(x0 - 290, y0 + 210) and not painel.contem(x0 + 5, y0 + 5, margem=0)
    painel.esconder()
    painel.mostrar("frente")  # próxima execução: aparece onde você deixou
    painel.root.update()
    assert (painel.win.winfo_x(), painel.win.winfo_y()) == (x0 - 300, y0 + 200)


def test_sai_da_frente_quando_o_bot_vai_clicar_debaixo(painel):
    painel.mostrar("frente")
    painel.root.update()
    x1, y1, x2, y2 = painel._ret
    alvo = ((x1 + x2) // 2, (y1 + y2) // 2)
    assert painel.contem(*alvo)
    painel.desviar(*alvo)
    painel.root.update()
    assert not painel.contem(*alvo, margem=0)


def test_posicao_fora_da_tela_volta_ao_canto(painel):
    painel.posicoes["frente"] = [99999, 99999]  # monitor que não existe mais
    painel.mostrar("frente")
    painel.root.update()
    assert painel.win.winfo_x() < painel.root.winfo_screenwidth()
