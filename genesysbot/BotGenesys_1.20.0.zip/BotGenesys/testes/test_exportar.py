# -*- coding: utf-8 -*-
"""Exportar para .py gera um arquivo Python válido com todos os passos."""
import json
import os
import py_compile

import pytest

from conftest import APP_DIR, precisa_tela

pytestmark = precisa_tela


@pytest.mark.parametrize("nome", ["roteiro_excel_dinamica.json", "roteiro_excel_graficos.json"])
def test_exportar_gera_python_valido(nome, tmp_path):
    import exportar
    with open(os.path.join(APP_DIR, "exemplos", nome), encoding="utf-8") as f:
        r = json.load(f)
    destino = str(tmp_path / "bot.py")
    info = exportar.exportar(r["passos"], r.get("config", {}), destino, APP_DIR, str(tmp_path / "perfil"))
    assert info["passos"] == len(r["passos"])
    py_compile.compile(destino, doraise=True)


def test_arquivo_exportado_roda_de_verdade(tmp_path):
    """Exporta um roteiro e RODA o .py gerado (sozinho, sem o app): ele escreve numa planilha temporária."""
    import subprocess
    import sys

    import openpyxl
    import exportar
    planilha = tmp_path / "teste.xlsx"
    wb = openpyxl.Workbook()
    wb.active.title = "Dados"
    wb.save(planilha)
    passos = [{"tipo": "excel_abrir", "descricao": "", "arquivo": str(planilha), "aba": "Dados", "visivel": False,
               "somente_leitura": False},
              {"tipo": "excel_escrever", "descricao": "", "celula": "A1", "valor": "ok-exportado", "formula_pt": False},
              {"tipo": "excel_salvar", "descricao": "", "arquivo": "", "formato": "mesmo", "aba": "", "fechar": True}]
    destino = tmp_path / "bot_teste.py"
    exportar.exportar(passos, {"contagem": "0", "visual": False, "maximizar_chrome": False}, str(destino),
                      APP_DIR, None)
    r = subprocess.run([sys.executable, str(destino), "--sem-painel"], cwd=str(tmp_path), capture_output=True,
                       text=True, timeout=180)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    assert openpyxl.load_workbook(planilha)["Dados"]["A1"].value == "ok-exportado"
