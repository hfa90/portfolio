# -*- coding: utf-8 -*-
"""Gravação de teclas e atalhos (inclusive digitados rápido, como no Excel). Simula as teclas que o
Windows entrega, com o estado real de Ctrl/Alt/Shift no instante de cada tecla."""
import time

import pytest

from conftest import isolar_janela, precisa_tela, nova_janela

pytestmark = precisa_tela


@pytest.fixture
def app(tmp_path):
    import bot_genesys as b
    import ttkbootstrap as tb
    mp = pytest.MonkeyPatch()
    isolar_janela(mp, tmp_path)
    root = nova_janela(tb, b.TEMA_CLARO)
    root.withdraw()
    a = b.App(root)
    a.gravando = True
    a._rol_cdp, a._t_roda = False, 0.0
    a._rec = {"cfg": {"pos": 0, "esperas": False, "limite": 2.5, "recorte": False}, "pos": 0, "texto_idx": None,
              "mods": set(), "ultimo_t": time.time(), "n": 0, "acento": None, "t_tecla": 0.0, "t_rolar": 0.0}
    yield a
    a.gravando = False
    a.dirty = False
    root.destroy()
    mp.undo()


def K(nome):
    from pynput.keyboard import Key
    return getattr(Key, nome)


def C(ch, vk=None):
    from pynput.keyboard import KeyCode
    return KeyCode(vk=vk, char=ch)


def apertar(app, key, mods=frozenset(), soltar=True):
    app._rec_tecla(key, True, set(mods))
    if soltar:
        app._rec_tecla(key, False, None)


def teclas(app):
    return [(s["tipo"], s.get("teclas") or s.get("texto"), s.get("repetir", 1)) for s in app.steps]


def test_ctrl_c_rapido(app):
    """Ctrl apertado e solto quase junto com o C: o estado real (lido no instante) garante o atalho."""
    app._rec_tecla(K("ctrl_l"), True, set())
    apertar(app, C("\x03", 67), {"ctrl"})      # Windows entrega '\x03' com vk 67
    app._rec_tecla(K("ctrl_l"), False, None)
    assert teclas(app) == [("tecla", "ctrl+c", 1)]


def test_ctrl_preso_nao_contamina_o_texto(app):
    """O Windows não entregou a soltura do Ctrl (ex.: Alt+Tab): antes tudo virava ctrl+letra."""
    app._rec_tecla(K("ctrl_l"), True, set())          # soltura nunca chega
    for ch, vk in (("o", 79), ("i", 73)):
        apertar(app, C(ch, vk), set())                 # estado real: nenhum modificador
    assert teclas(app) == [("digitar", "oi", 1)]


def test_atalhos_do_excel_com_pontuacao_e_numeros(app):
    apertar(app, C(None, 186), {"ctrl"})               # Ctrl+; (data de hoje) — tecla OEM
    apertar(app, C("1", 49), {"ctrl"})                 # Ctrl+1 (formatar células)
    apertar(app, K("enter"), {"ctrl"})                 # Ctrl+Enter
    apertar(app, C("l", 76), {"ctrl", "shift"})        # Ctrl+Shift+L (filtro)
    apertar(app, K("f2"), set())
    apertar(app, C(None, 107), {"ctrl"})               # Ctrl + (+) do teclado numérico: inserir
    t = [x[1] for x in teclas(app)]
    assert t[1:] == ["ctrl+1", "ctrl+enter", "ctrl+shift+l", "f2", "ctrl+add"]
    assert t[0] in ("ctrl+;", "ctrl+ç")  # depende do teclado (US / ABNT2); fora do Windows vem pelo caractere


def test_alt_sozinho_e_dicas_da_faixa_do_excel(app):
    """Alt, H, O, I (dicas de tecla da faixa) vira teclas, não o texto 'hoi'."""
    app._rec_tecla(K("alt_l"), True, set())
    app._rec_tecla(K("alt_l"), False, None)
    for ch, vk in (("h", 72), ("o", 79), ("i", 73)):
        apertar(app, C(ch, vk), set())
    assert teclas(app) == [("tecla", "alt", 1), ("tecla", "h", 1), ("tecla", "o", 1), ("tecla", "i", 1)]


def test_alt_tab_nao_grava_alt_sozinho(app):
    app._rec_tecla(K("alt_l"), True, set())
    apertar(app, K("tab"), {"alt"})
    app._rec_tecla(K("alt_l"), False, None)
    assert teclas(app) == [("tecla", "alt+tab", 1)]


def test_altgr_continua_sendo_texto(app):
    apertar(app, C("/", 81), {"ctrl", "alt"})          # AltGr+Q = '/' no ABNT2
    assert teclas(app) == [("digitar", "/", 1)]


def test_repeticao_rapida_vira_repetir(app):
    for _ in range(4):
        apertar(app, K("down"), set())
    apertar(app, C("\x16", 86), {"ctrl"})              # Ctrl+V
    assert teclas(app) == [("tecla", "down", 4), ("tecla", "ctrl+v", 1)]


def test_texto_normal_e_maiusculas(app):
    for ch, vk, m in (("O", 79, {"shift"}), ("i", 73, set()), ("!", 49, {"shift"})):
        apertar(app, C(ch, vk), m)
    apertar(app, K("enter"), set())
    assert app.steps[0]["texto"] == "Oi!" and app.steps[0]["enter"] is True
