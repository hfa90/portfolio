# -*- coding: utf-8 -*-
"""Arrastar, Ctrl/Shift+clique e célula do Excel: na gravação e na execução.
Os testes NÃO mexem no seu mouse: as funções de mouse/teclado são trocadas por gravadores."""
import time

import pytest

from conftest import isolar_janela, precisa_tela, nova_janela

pytestmark = precisa_tela


@pytest.fixture
def app(tmp_path):
    import bot_genesys as b
    import ttkbootstrap as tb
    mp = pytest.MonkeyPatch()
    isolar_janela(mp, tmp_path)
    root = nova_janela(tb, b.TEMA_CLARO)
    root.withdraw()
    a = b.App(root)
    a.gravando = True
    a._rol_cdp, a._t_roda, a._rec_ult_thread = False, 0.0, None
    a._rec_tela, a._rec_pag = [], []
    a._rec = {"cfg": {"pos": 0, "esperas": False, "limite": 2.5, "recorte": False}, "pos": 0, "texto_idx": None,
              "mods": set(), "ultimo_t": time.time(), "n": 0, "acento": None, "t_tecla": 0.0, "t_rolar": 0.0}
    mp.setattr(a, "post", lambda f: f())                 # executa na hora (sem a fila da tela)
    mp.setattr(a, "_rec_pedir_celula", lambda *x: None)  # sem Excel nos testes
    mp.setattr(a, "_dentro_da_janela", lambda x, y: False)
    mp.setattr(a, "_mods_reais", lambda: set())
    mp.setattr(a, "_rec_maximizar_no_clique", lambda x, y: False)  # não mexe nas janelas da sua tela
    yield a, mp
    a.gravando = False
    a.dirty = False
    root.destroy()
    mp.undo()


def _clique(a, x, y, apertou=True):
    from pynput.mouse import Button
    a._rec_on_click(x, y, Button.left, apertou)


def test_arrastar_vira_um_passo(app):
    a, _ = app
    _clique(a, 500, 400)
    _clique(a, 700, 650, apertou=False)
    p = a.steps[-1]
    assert p["tipo"] == "arrastar" and (p["x"], p["y"], p["x2"], p["y2"]) == (500, 400, 700, 650)
    assert 0.2 <= p["duracao"] <= 3 and "cliques" not in p


def test_clique_parado_continua_clique(app):
    a, _ = app
    _clique(a, 500, 400)
    _clique(a, 503, 402, apertou=False)  # tremidinha da mão não é arrastar
    assert a.steps[-1]["tipo"] == "clique"


@pytest.mark.parametrize("mods,esperado", [({"ctrl"}, "ctrl"), ({"shift"}, "shift"),
                                           ({"ctrl", "shift"}, "ctrl+shift"), (set(), None)])
def test_ctrl_e_shift_clique(app, mods, esperado):
    a, mp = app
    mp.setattr(a, "_mods_reais", lambda: set(mods))
    _clique(a, 500, 400)
    _clique(a, 500, 400, apertou=False)
    assert a.steps[-1].get("segurar") == esperado


def test_celula_do_excel_fica_no_passo_e_no_resumo(app):
    a, _ = app
    _clique(a, 500, 400)
    token = a.steps[-1]["_tk"]
    a._rec_celula_lida(token, "alvo_excel", {"pasta": "R.xlsx", "aba": "Dados", "celula": "B5"})
    from passos import resumo
    assert a.steps[-1]["alvo_excel"]["celula"] == "B5"
    assert "célula Dados!B5" in resumo(a.steps[-1])


def test_atualizar_no_formulario_mantem_o_que_a_gravacao_guardou(app):
    a, _ = app
    antigo = {"tipo": "clique", "x": 1, "y": 2, "alvo_excel": {"aba": "D", "celula": "A1"}, "janela": {"processo": "excel.exe"}}
    novo = {"tipo": "clique", "x": 1, "y": 2}
    a._manter_extras(antigo, novo)
    assert novo["alvo_excel"] and novo["janela"]
    movido = {"tipo": "clique", "x": 50, "y": 2}  # posição trocada à mão: vale a nova
    a._manter_extras(antigo, movido)
    assert "alvo_excel" not in movido and movido["janela"]


@pytest.fixture
def mouse_falso(monkeypatch):
    import pyautogui
    chamadas = []
    for nome in ("mouseDown", "mouseUp", "moveTo", "click", "keyDown", "keyUp"):
        monkeypatch.setattr(pyautogui, nome, lambda *a, _n=nome, **k: chamadas.append((_n, a, k.get("button"))))
    return chamadas


def test_execucao_do_arrastar_com_ctrl(motor, mouse_falso):
    p = {"tipo": "arrastar", "x": 100, "y": 120, "x2": 300, "y2": 420, "botao": "esquerdo", "segurar": "ctrl",
         "duracao": 0.3}
    cod, erro = motor.rodar([p], cfg={"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0})
    assert cod == 0, erro
    seq = [(n, a[:2]) for n, a, _ in mouse_falso]
    assert seq[seq.index(("keyDown", ("ctrl",))):] == [("keyDown", ("ctrl",)), ("mouseDown", (100, 120)),
                                                      ("moveTo", (300, 420)), ("mouseUp", (300, 420)),
                                                      ("keyUp", ("ctrl",))]


def test_execucao_do_shift_clique(motor, mouse_falso):
    p = {"tipo": "clique", "x": 50, "y": 60, "botao": "esquerdo", "cliques": 1, "segurar": "shift"}
    cod, erro = motor.rodar([p], cfg={"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0})
    assert cod == 0, erro
    nomes = [n for n, _, _ in mouse_falso]
    assert nomes[nomes.index("keyDown"):] == ["keyDown", "click", "keyUp"]


def test_segundo_plano_recusa_arrastar(motor):
    p = {"tipo": "arrastar", "x": 1, "y": 2, "x2": 30, "y2": 40}
    cod, erro = motor.rodar([p], cfg={"contagem": 0, "segundo_plano": True})
    assert cod == 1 and "Arrastar" in erro


def test_celula_sem_excel_usa_a_posicao_gravada(motor, mouse_falso, monkeypatch):
    import excel_tela as xt
    monkeypatch.setattr(xt, "posicao_da_celula", lambda alvo, log=None: None)
    p = {"tipo": "clique", "x": 70, "y": 80, "botao": "esquerdo", "cliques": 1,
         "alvo_excel": {"aba": "Dados", "celula": "B5"}}
    cod, _ = motor.rodar([p], cfg={"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0})
    assert cod == 0 and ("click", (70, 80)) in [(n, a[:2]) for n, a, _ in mouse_falso]
    assert "não consegui achar a célula Dados!B5" in motor.ui.texto()


def test_celula_achada_ajusta_o_clique(motor, mouse_falso, monkeypatch):
    import excel_tela as xt
    monkeypatch.setattr(xt, "posicao_da_celula", lambda alvo, log=None: (640, 360))
    p = {"tipo": "clique", "x": 70, "y": 80, "botao": "esquerdo", "cliques": 1,
         "alvo_excel": {"aba": "Dados", "celula": "B5"}}
    cod, _ = motor.rodar([p], cfg={"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0})
    assert cod == 0 and ("click", (640, 360)) in [(n, a[:2]) for n, a, _ in mouse_falso]


def test_excel_de_verdade_celula_e_posicao_na_tela():
    """Abre um Excel separado por alguns segundos (visível) e confere célula <-> posição na tela."""
    import excel as xlm
    if not xlm.HAS_COM:
        pytest.skip("precisa do Microsoft Excel (Windows)")
    import excel_tela as xt
    ok, txt = xt.autoteste()
    assert ok, txt
