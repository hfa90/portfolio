# -*- coding: utf-8 -*-
"""Cópias de versões, manifesto e limpeza de logs (tudo numa pasta temporária)."""
import os
import time

import pytest

import diagnostico as diag
import versoes
from conftest import APP_DIR


def _app_falso(pasta, versao="1.0.0", extra=""):
    (pasta / "versao.py").write_text(f'VERSAO = "{versao}"\n', encoding="utf-8")
    (pasta / "motor.py").write_text(f"# motor {versao}{extra}\n", encoding="utf-8")
    (pasta / "iniciar.bat").write_text("@echo off\n", encoding="utf-8")
    (pasta / "meu_roteiro.json").write_text('{"passos": []}', encoding="utf-8")
    (pasta / "interface").mkdir(exist_ok=True)
    (pasta / "interface" / "editor.py").write_text(f"# editor {versao}{extra}\n", encoding="utf-8")


def test_guardar_e_voltar_versao(tmp_path):
    _app_falso(tmp_path, "1.0.0")
    assert versoes.guardar_versao_atual(str(tmp_path))
    assert versoes.guardar_versao_atual(str(tmp_path)) is None  # só uma vez por versão
    _app_falso(tmp_path, "1.1.0", " novo")
    (tmp_path / "so_na_nova.py").write_text("x = 1\n", encoding="utf-8")
    (tmp_path / "meu_roteiro.json").write_text('{"passos": [1]}', encoding="utf-8")
    versoes.restaurar(str(tmp_path), "1.0.0")
    assert 'VERSAO = "1.0.0"' in (tmp_path / "versao.py").read_text(encoding="utf-8")
    assert not (tmp_path / "so_na_nova.py").exists()
    assert (tmp_path / "interface" / "editor.py").read_text(encoding="utf-8") == "# editor 1.0.0\n"
    assert (tmp_path / "meu_roteiro.json").read_text(encoding="utf-8") == '{"passos": [1]}'  # roteiro intacto
    assert [v for v, _, _ in versoes.listar(str(tmp_path))] == ["1.1.0", "1.0.0"]


def test_manifesto_detecta_atualizacao_pela_metade(tmp_path):
    _app_falso(tmp_path, "2.0.0")
    versoes.gerar_manifesto(str(tmp_path))
    assert versoes.conferir(str(tmp_path))[0]
    (tmp_path / "motor.py").write_text("# motor antigo\n", encoding="utf-8")
    ok, txt, det = versoes.conferir(str(tmp_path))
    assert not ok and det["diferentes"] == ["motor.py"]
    (tmp_path / "interface" / "editor.py").unlink()
    assert "interface/editor.py" in versoes.conferir(str(tmp_path))[2]["faltando"]


def test_manifesto_desta_pasta_confere():
    if not os.path.exists(os.path.join(APP_DIR, versoes.MANIFESTO)):
        pytest.skip("sem manifesto")
    ok, txt, _ = versoes.conferir(APP_DIR)
    assert ok, txt


def test_limpa_logs_antigos_e_oculta_senhas(tmp_path):
    logs = tmp_path / "logs"
    logs.mkdir()
    (tmp_path / "r.json").write_text('{"passos": [{"tipo": "digitar", "senha": true, "texto": "Segredo@99"}]}',
                                     encoding="utf-8")
    (logs / "bot_20261115.log").write_text("Digitar: Segredo@99\n", encoding="utf-8")
    velho = logs / "bot_20200101.log"
    velho.write_text("velho", encoding="utf-8")
    t = time.time() - 90 * 86400
    os.utime(velho, (t, t))
    (logs / "anotacoes.txt").write_text("Segredo@99", encoding="utf-8")  # não é log do bot: não mexe
    msg = diag.manutencao_logs(str(tmp_path), str(logs), 30)
    assert "apagado" in msg and "ocultada" in msg
    assert not velho.exists()
    assert "Segredo" not in (logs / "bot_20261115.log").read_text(encoding="utf-8")
    assert "Segredo" in (logs / "anotacoes.txt").read_text(encoding="utf-8")
