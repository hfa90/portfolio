# -*- coding: utf-8 -*-
"""Todos os roteiros da pasta (os seus e os exemplos) continuam válidos. Só LEITURA: nada é alterado."""
import os

import pytest

from conftest import APP_DIR
import diagnostico as diag

ROTEIROS = diag.arquivos_roteiro(APP_DIR)


def _id(r):
    return os.path.relpath(r[0], APP_DIR)


def test_existe_algum_roteiro():
    assert ROTEIROS


@pytest.mark.parametrize("roteiro", ROTEIROS, ids=[_id(r) for r in ROTEIROS])
def test_roteiro_so_usa_tipos_conhecidos(roteiro):
    from motor import TIPOS
    _, passos = roteiro
    desconhecidos = [s.get("tipo") for s in passos if isinstance(s, dict) and s.get("tipo") not in TIPOS]
    assert not desconhecidos, f"tipos desconhecidos: {desconhecidos}"


@pytest.mark.parametrize("roteiro", ROTEIROS, ids=[_id(r) for r in ROTEIROS])
def test_roteiro_tem_campos_basicos(roteiro):
    _, passos = roteiro
    for i, s in enumerate(passos, 1):
        assert isinstance(s, dict) and "tipo" in s, f"passo {i}"
        if s["tipo"] == "clique":
            assert "x" in s and "y" in s, f"passo {i}: clique sem posição"


def test_planilhas_dos_exemplos_existem():
    for caminho, passos in ROTEIROS:
        if os.sep + "exemplos" + os.sep not in caminho:
            continue
        for s in passos:
            if s.get("tipo") == "excel_abrir":
                assert os.path.exists(os.path.join(APP_DIR, s["arquivo"])), s["arquivo"]
