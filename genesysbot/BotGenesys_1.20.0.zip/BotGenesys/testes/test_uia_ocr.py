# -*- coding: utf-8 -*-
"""Elementos de janela (UI Automation) e texto da tela (OCR): partes puras com trocas, e no Windows os testes
de verdade (sem clicar em nada)."""
import json
import sys

import pytest

import janelas_uia as uia
import ocr_tela as ocr
from conftest import precisa_tela

so_windows = pytest.mark.skipif(sys.platform != "win32", reason="só no Windows")
CFG = {"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0}

LINHAS = [
    {"texto": "Arquivo Editar Exibir", "palavras": [
        {"t": "Arquivo", "x": 10, "y": 5, "w": 50, "h": 12}, {"t": "Editar", "x": 70, "y": 5, "w": 40, "h": 12},
        {"t": "Exibir", "x": 120, "y": 5, "w": 40, "h": 12}]},
    {"texto": "Protocolo INC0045123 gerado", "palavras": [
        {"t": "Protocolo", "x": 10, "y": 100, "w": 70, "h": 14}, {"t": "INC0045123", "x": 90, "y": 100, "w": 80, "h": 14},
        {"t": "gerado", "x": 180, "y": 100, "w": 50, "h": 14}]},
    {"texto": "Confirmar Cancelar Confirmar", "palavras": [
        {"t": "Confirmar", "x": 10, "y": 200, "w": 60, "h": 14}, {"t": "Cancelar", "x": 80, "y": 200, "w": 60, "h": 14},
        {"t": "Confirmar", "x": 150, "y": 200, "w": 60, "h": 14}]},
]


# ------------------------------------------------------------------ OCR: procurar no resultado
def test_procura_texto_de_varias_palavras_sem_acento_e_maiuscula():
    assert ocr.procurar_nas_linhas(LINHAS, "editar exibir") == (70, 5, 90, 12)
    assert ocr.procurar_nas_linhas(LINHAS, "PROTOCOLO") == (10, 100, 70, 14)
    assert ocr.normalizar("  Ação  Concluída ") == "acao concluida"


def test_procura_a_segunda_ocorrencia():
    assert ocr.procurar_nas_linhas(LINHAS, "confirmar", 1)[0] == 10
    assert ocr.procurar_nas_linhas(LINHAS, "confirmar", 2)[0] == 150
    assert ocr.procurar_nas_linhas(LINHAS, "confirmar", 3) is None
    assert ocr.procurar_nas_linhas(LINHAS, "nada disso") is None


def test_resposta_do_powershell_vira_linhas(monkeypatch):
    from PIL import Image

    class R:
        stdout = json.dumps({"idioma": "pt-BR", "linhas": {"texto": "Olá", "palavras": {
            "t": "Olá", "x": 20, "y": 10, "w": 40, "h": 20}}}).encode("utf-8")
        stderr = b""
    monkeypatch.setattr(ocr, "WIN_OCR", True)
    monkeypatch.setattr(ocr.subprocess, "run", lambda *a, **k: R())
    monkeypatch.setattr(ocr, "_arquivo_script", lambda: "x.ps1")
    linhas = ocr.reconhecer(Image.new("RGB", (300, 100), "white"))  # imagem pequena: ampliada 2x
    assert linhas == [{"texto": "Olá", "palavras": [{"t": "Olá", "x": 10, "y": 5, "w": 20, "h": 10}]}]


def test_erro_do_ocr_explica(monkeypatch):
    from PIL import Image

    class R:
        stdout = b'{"erro": "nenhum idioma de OCR instalado no Windows"}'
        stderr = b""
    monkeypatch.setattr(ocr, "WIN_OCR", True)
    monkeypatch.setattr(ocr.subprocess, "run", lambda *a, **k: R())
    monkeypatch.setattr(ocr, "_arquivo_script", lambda: "x.ps1")
    with pytest.raises(RuntimeError, match="idioma de OCR"):
        ocr.reconhecer(Image.new("RGB", (50, 50)))


# ------------------------------------------------------------------ elementos: escolha do mais perto
class _Ctrl:
    def __init__(self, ret, existe=True):
        self.BoundingRectangle = type("R", (), dict(zip(("left", "top", "right", "bottom"), ret)))()
        self._existe = existe

    def Exists(self, **k):
        return self._existe

    NativeWindowHandle = 0

    def GetParentControl(self):
        return None

    def GetTopLevelControl(self):
        return self


class _AutoFalso:
    def __init__(self, achados):
        self.achados, self.pedidos = achados, []

    def UIAutomationInitializerInThread(self, **k):
        import contextlib
        return contextlib.nullcontext()

    def ControlFromHandle(self, h):
        return _Ctrl((100, 100, 1100, 900))

    GetForegroundControl = ControlFromHandle

    def Control(self, searchFromControl, searchDepth, foundIndex, **cond):
        self.pedidos.append(cond)
        if foundIndex <= len(self.achados):
            return _Ctrl(self.achados[foundIndex - 1])
        return _Ctrl((0, 0, 0, 0), existe=False)


def test_varios_iguais_escolhe_o_mais_perto_da_gravacao(monkeypatch):
    falso = _AutoFalso([(110, 110, 150, 130), (600, 500, 660, 530), (900, 800, 960, 830)])
    monkeypatch.setattr(uia, "auto", falso)
    monkeypatch.setattr(uia, "HAS_UIA", True)
    alvo = {"nome": "OK", "tipo": 50000, "tipo_nome": "ButtonControl", "automation_id": "", "dx": 520, "dy": 410}
    assert uia.posicao_elemento(alvo, hwnd=1) == (630, 515)
    assert falso.pedidos[0] == {"ControlType": 50000, "Name": "OK"}


def test_automation_id_entra_na_busca_e_resumo(monkeypatch):
    falso = _AutoFalso([(200, 200, 260, 220)])
    monkeypatch.setattr(uia, "auto", falso)
    monkeypatch.setattr(uia, "HAS_UIA", True)
    alvo = {"nome": "Salvar", "tipo": 50000, "tipo_nome": "ButtonControl", "automation_id": "btnSalvar"}
    assert uia.posicao_elemento(alvo, hwnd=1) == (230, 210)
    assert falso.pedidos[0]["AutomationId"] == "btnSalvar"
    assert uia.descrever(alvo) == 'botão "Salvar"'
    from passos import resumo
    assert 'botão "Salvar"' in resumo({"tipo": "clique", "x": 1, "y": 2, "alvo_uia": alvo})


def test_sem_biblioteca_nao_atrapalha(monkeypatch):
    monkeypatch.setattr(uia, "HAS_UIA", False)
    assert uia.capturar_elemento(10, 10) is None and uia.posicao_elemento({"nome": "x"}) is None


# ------------------------------------------------------------------ catálogo e fluxo
def test_passos_novos_no_catalogo():
    import fluxo as fx
    from passos import PRECISA_TELA, TIPOS, resumo
    for t in ("ler_tela", "clicar_texto", "se_texto_tela"):
        assert t in TIPOS and t in PRECISA_TELA
    assert "se_texto_tela" in fx.SE_TIPOS
    assert "{protocolo}" in resumo({"tipo": "ler_tela", "regiao": "tela inteira", "variavel": "protocolo"})


# ------------------------------------------------------------------ execução (sem mexer no mouse)
@pytest.fixture
def mouse_falso(monkeypatch):
    import pyautogui
    chamadas = []
    for nome in ("mouseDown", "mouseUp", "moveTo", "click", "keyDown", "keyUp"):
        monkeypatch.setattr(pyautogui, nome, lambda *a, _n=nome, **k: chamadas.append((_n, a)))
    return chamadas


@precisa_tela
def test_clique_pelo_elemento_ajusta_a_posicao(motor, mouse_falso, monkeypatch):
    monkeypatch.setattr(uia, "posicao_elemento", lambda alvo, hwnd=None, espera=3.0: (444, 333))
    p = {"tipo": "clique", "x": 10, "y": 20, "botao": "esquerdo", "cliques": 1,
         "alvo_uia": {"nome": "Salvar", "tipo_nome": "ButtonControl"}}
    cod, erro = motor.rodar([p], cfg=CFG)
    assert cod == 0, erro
    assert ("click", (444, 333)) in [(n, a[:2]) for n, a in mouse_falso]


@precisa_tela
def test_ler_tela_com_padrao_guarda_variavel_e_clicar_texto(motor, mouse_falso, monkeypatch):
    monkeypatch.setattr(ocr, "ler", lambda regiao=None, idioma="pt-BR": "Protocolo INC0045123 gerado")
    monkeypatch.setattr(ocr, "achar", lambda texto, regiao=None, idioma="pt-BR", ocorrencia=1:
                        (300, 200) if texto == "INC0045123" else None)
    passos = [{"tipo": "ler_tela", "regiao": "tela inteira", "regex": r"(INC\d+)", "variavel": "chamado"},
              {"tipo": "clicar_texto", "texto": "{chamado}", "offset_x": 5, "timeout": 1},
              {"tipo": "se_texto_tela", "texto": "{chamado}", "espera": 0.2},
              {"tipo": "definir_variavel", "nome": "achou", "valor": "sim"},
              {"tipo": "fim_se"}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["chamado"] == "INC0045123" and motor.vars.get("achou") == "sim"
    assert ("click", (305, 200)) in [(n, a[:2]) for n, a in mouse_falso]


@precisa_tela
def test_texto_que_nao_aparece_da_erro_claro(motor, mouse_falso, monkeypatch):
    monkeypatch.setattr(ocr, "achar", lambda *a, **k: None)
    cod, erro = motor.rodar([{"tipo": "clicar_texto", "texto": "Confirmar", "timeout": 0.5}],
                            cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "Confirmar" in erro


def test_segundo_plano_recusa_ocr(motor):
    cod, erro = motor.rodar([{"tipo": "ler_tela", "variavel": "x"}], cfg={"contagem": 0, "segundo_plano": True})
    assert cod == 1 and "OCR" in erro


# ------------------------------------------------------------------ Windows de verdade (não clica em nada)
@so_windows
def test_windows_ocr_le_texto_desenhado():
    ok, txt = ocr.autoteste_ocr()
    assert ok, txt


@so_windows
def test_windows_elemento_do_botao_iniciar():
    if not uia.HAS_UIA:
        pytest.skip("uiautomation não instalada (rode instalar.bat)")
    ok, txt = uia.autoteste_uia()
    if ok is None:
        pytest.skip(txt)
    assert ok, txt


class _No:
    def __init__(self, nome="", aid="", ret=(0, 0, 100, 100), pai=None, tipo="ButtonControl", hwnd=0):
        self.Name, self.AutomationId, self.ClassName, self.ControlType = nome, aid, "", 50000
        self.ControlTypeName, self.NativeWindowHandle = tipo, hwnd
        self.BoundingRectangle = type("R", (), dict(zip(("left", "top", "right", "bottom"), ret)))()
        self.pai, self.filhos = pai, []
        if pai:
            pai.filhos.append(self)

    def GetParentControl(self):
        return self.pai

    def GetChildren(self):
        return self.filhos

    def GetTopLevelControl(self):
        n = self
        while n.pai:
            n = n.pai
        return n


def _uia_com(monkeypatch, no_do_ponto):
    import contextlib
    falso = type("A", (), {"UIAutomationInitializerInThread": lambda self, **k: contextlib.nullcontext(),
                           "ControlFromPoint": lambda self, x, y: no_do_ponto})()
    monkeypatch.setattr(uia, "auto", falso)
    monkeypatch.setattr(uia, "HAS_UIA", True)
    monkeypatch.setattr(uia, "_topo", lambda c: c.GetTopLevelControl())  # elementos falsos: não pergunta ao Windows


def test_clique_no_icone_sem_nome_sobe_ate_o_botao(monkeypatch):
    barra = _No("", ret=(0, 1000, 1920, 1080), tipo="PaneControl", hwnd=77)
    botao = _No("Iniciar", "StartButton", ret=(490, 1030, 545, 1075), pai=barra)
    icone = _No("", ret=(500, 1040, 535, 1065), pai=botao, tipo="ImageControl")
    _uia_com(monkeypatch, icone)
    a = uia.capturar_elemento(518, 1050)
    assert a and a["automation_id"] == "StartButton" and a["nome"] == "Iniciar"
    assert (a["dx"], a["dy"]) == (518, 50)


def test_ponto_no_painel_desce_ate_o_botao(monkeypatch):
    barra = _No("", ret=(0, 1000, 1920, 1080), tipo="PaneControl", hwnd=77)
    interno = _No("", ret=(0, 1000, 1920, 1080), pai=barra, tipo="PaneControl")
    _No("Pesquisar", "SearchButton", ret=(600, 1030, 650, 1075), pai=interno)
    _No("Iniciar", "StartButton", ret=(490, 1030, 545, 1075), pai=interno)
    _uia_com(monkeypatch, barra)
    assert uia.capturar_elemento(518, 1050)["automation_id"] == "StartButton"
    assert uia.capturar_elemento(5, 1005) is None and "sem nome" in uia._motivo["txt"]
