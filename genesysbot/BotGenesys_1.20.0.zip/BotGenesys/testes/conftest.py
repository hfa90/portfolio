# -*- coding: utf-8 -*-
"""Configuração comum dos testes do Bot Genesys (rode com testar.bat)."""
import os
import shutil
import sys

import pytest

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

WIN = sys.platform == "win32"
TEM_TELA = WIN or bool(os.environ.get("DISPLAY"))


def pytest_report_header(config):
    return f"Bot Genesys — pasta: {APP_DIR}  |  tela: {'sim' if TEM_TELA else 'não (testes de interface pulados)'}"


precisa_tela = pytest.mark.skipif(not TEM_TELA, reason="precisa de tela (Windows ou DISPLAY)")


def isolar_janela(mp, pasta):
    """Faz a janela usar configuração, agendamentos e logs TEMPORÁRIOS (não mexe nos seus).
    Troca os caminhos em bot_genesys e em todos os arquivos de interface/."""
    import bot_genesys as b  # importa também todos os arquivos de interface/
    valores = {"CONFIG_APP": str(pasta / "config_app.json"), "AGENDA_FILE": str(pasta / "agendamentos.json"),
               "LOG_DIR": str(pasta / "logs"), "LOCK_FILE": str(pasta / "logs" / ".executando")}
    for nome, mod in list(sys.modules.items()):
        if mod is not None and (nome == "bot_genesys" or nome.startswith("interface.")):
            for k, v in valores.items():
                if hasattr(mod, k):
                    mp.setattr(mod, k, v)
    mp.setattr(b.App, "_manutencao_logs", lambda self: None)


@pytest.fixture
def app_dir():
    return APP_DIR


@pytest.fixture
def exemplos(tmp_path):
    """Cópia da pasta exemplos/ num lugar temporário: os testes nunca mexem nos seus arquivos."""
    destino = tmp_path / "exemplos"
    shutil.copytree(os.path.join(APP_DIR, "exemplos"), destino,
                    ignore=shutil.ignore_patterns("saida", "~$*"))
    return tmp_path


class UiTeste:
    """Faz o papel da tela: só guarda as mensagens."""

    def __init__(self):
        self.msgs = []

    def log(self, msg, tag=None):
        self.msgs.append((tag, msg))

    def __getattr__(self, nome):  # status, progresso, destacar, marcador...
        return lambda *a, **k: None

    def texto(self):
        return "\n".join(m for _, m in self.msgs)


@pytest.fixture
def ui():
    return UiTeste()


@pytest.fixture
def motor(ui, tmp_path):
    if not TEM_TELA:
        pytest.skip("o motor usa pyautogui, que precisa de tela")
    from motor import Motor
    return Motor(ui=ui, base=str(tmp_path), log_dir=str(tmp_path / "logs"))


def nova_janela(tb, tema):
    """Janela do ttkbootstrap para os testes. O Tcl/Tk (sobretudo no Python 3.14 do Windows) às vezes falha ao
    criar mais um interpretador depois de muitos criados e destruídos no mesmo processo ("init.tcl",
    "tcl_findLibrary"): tenta de novo algumas vezes antes de desistir. O programa de verdade cria uma só."""
    import gc
    import time as _t
    import tkinter
    erro = None
    for tentativa in range(5):
        try:
            return tb.Window(themename=tema)
        except tkinter.TclError as e:
            erro = e
            gc.collect()
            _t.sleep(0.2 * (tentativa + 1))
    raise erro
