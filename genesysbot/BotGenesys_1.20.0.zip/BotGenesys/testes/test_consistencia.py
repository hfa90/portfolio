# -*- coding: utf-8 -*-
"""Tudo que precisa 'bater' entre os arquivos (ex.: um tipo de passo declarado em todos os lugares)."""
import os
import re

import pytest

from conftest import APP_DIR, precisa_tela


@precisa_tela
def test_todo_tipo_de_passo_tem_formulario_e_icone():
    import bot_genesys as b
    from motor import TIPOS
    assert set(TIPOS) - set(b.FIELDS) == set(), "tipos sem formulário (FIELDS)"
    assert set(b.FIELDS) - set(TIPOS) == set(), "formulários de tipos que não existem"
    assert set(TIPOS) - set(b.ICONES) == set(), "tipos sem ícone"
    assert set(b.DICAS) - set(TIPOS) == set(), "dicas de tipos que não existem"


@precisa_tela
def test_resumo_funciona_para_todo_tipo_com_valores_padrao():
    import bot_genesys as b
    from motor import TIPOS, resumo
    for tipo in TIPOS:
        passo = {"tipo": tipo, "descricao": ""}
        for campo in b.FIELDS[tipo]:
            chave, tipo_campo, padrao = campo[0], campo[2], campo[3]
            if tipo_campo == "pos":
                passo["x"], passo["y"] = 10, 20
            else:
                passo[chave] = padrao
        assert isinstance(resumo(passo), str), tipo


def test_versao_historico_e_changelog_batem():
    from versao import HISTORICO, VERSAO
    assert re.fullmatch(r"\d+\.\d+\.\d+", VERSAO)
    assert HISTORICO[0][0] == VERSAO, "o HISTORICO deve começar pela versão atual"
    with open(os.path.join(APP_DIR, "CHANGELOG.md"), encoding="utf-8") as f:
        assert f"## {VERSAO}" in f.read(), "falta a versão atual no CHANGELOG.md"


def test_modulos_da_exportacao_existem():
    import exportar
    for m in exportar.MODULOS:
        assert os.path.exists(os.path.join(APP_DIR, m)), m


def test_dependencias_listadas():
    with open(os.path.join(APP_DIR, "requirements.txt"), encoding="utf-8") as f:
        req = f.read().lower()
    for pacote in ("pyautogui", "pynput", "pillow", "opencv-python", "websocket-client", "ttkbootstrap",
                   "openpyxl", "pywin32"):
        assert pacote in req, pacote


@pytest.mark.parametrize("arquivo", ["iniciar.bat", "executar_roteiro.bat", "diagnostico.bat", "testar.bat"])
def test_atalhos_bat_existem(arquivo):
    assert os.path.exists(os.path.join(APP_DIR, arquivo))


def test_todo_tipo_do_catalogo_e_executado_pelo_motor():
    """Um tipo novo no catálogo precisa ter a execução escrita no motor."""
    import passos
    fonte = ""
    for nome in os.listdir(APP_DIR):  # motor.py e suas partes (motor_tela.py, motor_dados.py...)
        if nome.startswith("motor") and nome.endswith(".py"):
            with open(os.path.join(APP_DIR, nome), encoding="utf-8") as f:
                fonte += f.read()
    faltando = [t for t in passos.TIPOS if f'"{t}"' not in fonte]
    assert not faltando, f"tipos sem execução no motor: {faltando}"


def test_catalogo_bem_formado():
    import passos
    tipos_campo = {"str", "int", "float", "bool", "choice", "text", "pos", "img", "arq", "formula", "segredo"}
    vistos = set()
    for p in passos.CATALOGO:
        assert p.tipo not in vistos, f"tipo repetido: {p.tipo}"
        vistos.add(p.tipo)
        assert p.nome and p.icone and callable(p.resumo), p.tipo
        for c in p.campos:
            assert len(c) == 5 and c[2] in tipos_campo, (p.tipo, c)
            if c[2] == "choice":
                assert c[4] and str(c[3]) in [str(o) for o in c[4]], (p.tipo, c)
    assert len(set(passos.TIPO_POR_NOME)) == len(passos.CATALOGO), "nomes repetidos"


@precisa_tela
def test_partes_da_janela_nao_repetem_metodos():
    """Cada método da janela está em UMA parte só (senão uma esconderia a outra sem aviso)."""
    import bot_genesys as b
    vistos = {}
    for parte in b.App.__mro__[:-1]:
        for nome, valor in vars(parte).items():
            if callable(valor) and not nome.startswith("__"):
                assert nome not in vistos, f"{nome} em {vistos.get(nome)} e {parte.__name__}"
                vistos[nome] = parte.__name__
    assert len(vistos) > 100


def test_arquivos_continuam_pequenos():
    """Proteção contra voltar a ter um arquivo gigante (interface/ e motor)."""
    arquivos = [os.path.join("interface", n) for n in os.listdir(os.path.join(APP_DIR, "interface"))
                if n.endswith(".py")]
    arquivos += [n for n in os.listdir(APP_DIR) if n.startswith("motor") and n.endswith(".py")]
    for nome in arquivos:
        with open(os.path.join(APP_DIR, nome), encoding="utf-8") as f:
            n = sum(1 for _ in f)
        assert n <= 700, f"{nome} tem {n} linhas"


@precisa_tela
def test_partes_do_motor_nao_repetem_metodos():
    from motor import Motor
    vistos = {}
    for parte in Motor.__mro__[:-1]:
        for nome, valor in vars(parte).items():
            if callable(valor) or isinstance(valor, staticmethod):
                if nome.startswith("__") and nome != "__init__":
                    continue
                assert nome not in vistos, f"{nome} em {vistos.get(nome)} e {parte.__name__}"
                vistos[nome] = parte.__name__


def test_nome_antigo_janela_chrome_continua_funcionando():
    import janela_chrome
    import janelas
    assert janela_chrome is janelas
