# -*- coding: utf-8 -*-
"""Gera testes/ouro_catalogo.json com o comportamento ATUAL. Só se usa antes de uma reorganização."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ttkbootstrap as tb  # noqa: E402

import bot_genesys as b  # noqa: E402
from ouro_casos import ARQ_OURO, tirar_retrato  # noqa: E402

root = tb.Window(themename=b.TEMA_CLARO)
root.withdraw()
b.App._manutencao_logs = lambda self: None
app = b.App(root)
retrato = tirar_retrato(app)
root.destroy()
with open(ARQ_OURO, "w", encoding="utf-8") as f:
    json.dump(retrato, f, ensure_ascii=False, indent=1)
print("retrato salvo:", ARQ_OURO, "|", len(retrato["resumos"]), "resumos,", len(retrato["formularios"]), "formulários")
