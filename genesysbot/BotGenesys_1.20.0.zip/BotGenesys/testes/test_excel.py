# -*- coding: utf-8 -*-
"""Planilhas: fórmulas em português, cópia ajustando fórmulas, gráficos e proteção contra perda de objetos."""

import openpyxl
import pytest

import excel as xlm


@pytest.fixture
def planilha(tmp_path):
    caminho = tmp_path / "teste.xlsx"
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Dados"
    ws.append(["Mês", "Chamados"])
    for i, n in enumerate([10, 20, 15, 30], start=1):
        ws.append([f"M{i}", n])
    wb.save(caminho)
    return str(caminho)


def _abrir(caminho):
    return xlm.Excel(lambda *a, **k: None).abrir(caminho, "Dados", usar_excel=False)


def test_separar_ref():
    assert xlm.separar_ref("Dados!A1:C5") == ("Dados", "A1", "C5")
    assert xlm.separar_ref("B2") == (None, "B2", None)


def test_formula_pt_para_en():
    assert xlm.formula_pt_para_en('=SE(A1>1;"sim";"não")') == '=IF(A1>1,"sim","não")'
    assert xlm.formula_pt_para_en("=PROCV(D2;SLA!$A$2:$B$5;2;FALSO)") == "=VLOOKUP(D2,SLA!$A$2:$B$5,2,FALSE)"
    assert xlm.formula_pt_para_en("=SOMA(A1:A3)*1,5") == "=SUM(A1:A3)*1.5"


def test_escrever_formula_em_intervalo_ajusta_linhas(planilha):
    xl = _abrir(planilha)
    xl.escrever("C2:C5", "=B2*2", formula_pt=True)
    ws = xl.wb["Dados"]
    assert ws["C2"].value == "=B2*2" and ws["C5"].value == "=B5*2"


def test_copiar_formula_ajusta_para_o_destino(planilha):
    xl = _abrir(planilha)
    xl.escrever("C2", "=B2*2")
    xl.copiar("C2", "C5", so_valores=False)
    assert xl.wb["Dados"]["C5"].value == "=B5*2"


def test_ultima_linha(planilha):
    assert _abrir(planilha).ultima_linha("A") == 5


def test_grafico_sem_excel(planilha):
    xl = _abrir(planilha)
    assert xl.criar_grafico("Dados!A1:B5", "Dados!E2", "colunas", "Teste", "g1") == "Dados!E2"
    xl.salvar()
    assert xlm.tem_objetos(planilha)


def test_protege_planilha_com_graficos_sem_excel(planilha):
    xl = _abrir(planilha)
    xl.criar_grafico("Dados!A1:B5", "Dados!E2", "linhas", "", "g1")
    xl.salvar()
    xl2 = _abrir(planilha)
    with pytest.raises(RuntimeError, match="poderia perder"):
        xl2.salvar()


def test_erro_do_excel_fica_legivel():
    e = Exception(-2147352567, "Exceção.", (0, None, None, None, 0, -2147467259), None)
    txt = xlm.erro_legivel(e)
    assert "recusou" in txt and "0x80004005" in txt
    assert xlm.erro_legivel(ValueError("x")) == "x"


@pytest.mark.skipif(not xlm.HAS_COM, reason="precisa do Microsoft Excel (Windows)")
def test_excel_de_verdade():
    """Fórmula, tabela dinâmica, gráficos (inclusive com a seleção dentro da dinâmica) e PDF no Excel real."""
    import diagnostico as diag
    res = diag._excel()
    erros = [f"{r['item']}: {r['detalhe']}" for r in res if r["status"] == diag.ERRO]
    assert not erros, "\n".join(erros)
