# -*- coding: utf-8 -*-
"""Passos de Arquivos e Windows (numa pasta temporária: nada seu é tocado)."""
import os
import sys
import threading
import time
import zipfile

import pytest

import arquivos_win as aw
from conftest import precisa_tela

WIN = sys.platform == "win32"


def _arq(p, texto="x"):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(texto)
    return p


def test_copiar_mover_conflitos(tmp_path):
    a = _arq(str(tmp_path / "in" / "rel.xlsx"))
    _arq(str(tmp_path / "in" / "outro.pdf"))
    assert aw.arq_copiar(a, str(tmp_path / "out") + os.sep) == [str(tmp_path / "out" / "rel.xlsx")]
    segundo = aw.arq_copiar(a, str(tmp_path / "out") + os.sep)  # já existe: "manter os dois"
    assert segundo == [str(tmp_path / "out" / "rel (2).xlsx")]
    assert aw.arq_copiar(a, str(tmp_path / "out") + os.sep, "pular") == []
    with pytest.raises(FileExistsError):
        aw.arq_copiar(a, str(tmp_path / "out") + os.sep, "parar com erro")
    movidos = aw.arq_copiar(str(tmp_path / "in" / "*"), str(tmp_path / "todos"), mover=True)
    assert len(movidos) == 2 and not os.listdir(tmp_path / "in")


def test_copiar_com_novo_nome_e_curinga_vazio(tmp_path):
    a = _arq(str(tmp_path / "a.txt"), "oi")
    novo = aw.arq_copiar(a, str(tmp_path / "sub" / "b.txt"))[0]
    assert open(novo, encoding="utf-8").read() == "oi"
    with pytest.raises(FileNotFoundError):
        aw.arq_copiar(str(tmp_path / "*.nada"), str(tmp_path / "x"))


def test_renomear_mantem_extensao(tmp_path):
    a = _arq(str(tmp_path / "relatorio.xlsx"))
    novo = aw.arq_renomear(a, "Chamados_2026-11-16")
    assert os.path.basename(novo) == "Chamados_2026-11-16.xlsx" and os.path.exists(novo)


def test_excluir_tem_travas(tmp_path):
    for i in range(5):
        _arq(str(tmp_path / f"t{i}.csv"))
    with pytest.raises(RuntimeError, match="máximo"):
        aw.arq_excluir(str(tmp_path / "*.csv"), lixeira=False, maximo=3)
    assert len(aw.arq_excluir(str(tmp_path / "*.csv"), lixeira=False, maximo=10)) == 5
    assert aw.arq_excluir(str(tmp_path / "*.csv"), lixeira=False) == []
    assert aw._proibido_excluir(os.path.expanduser("~")) and aw._proibido_excluir(os.path.abspath(os.sep))


def test_esperar_download_terminar(tmp_path):
    """Simula o Chrome: primeiro .crdownload, depois o arquivo final crescendo, depois parado."""
    dl = tmp_path / "dl"
    dl.mkdir()

    def baixar():
        time.sleep(0.3)
        p = dl / "rel.xlsx.crdownload"
        p.write_text("parte")
        time.sleep(0.5)
        os.replace(p, dl / "rel.xlsx")
    threading.Thread(target=baixar).start()
    inicio = time.time()
    achado = aw.arq_esperar(str(dl / "*.xlsx"), timeout=10, estavel=0.6, dormir=lambda s: time.sleep(0.1))
    assert achado.endswith("rel.xlsx") and time.time() - inicio >= 0.8


def test_esperar_desiste_no_tempo(tmp_path):
    with pytest.raises(TimeoutError):
        aw.arq_esperar(str(tmp_path / "*.pdf"), timeout=0.5, dormir=lambda s: time.sleep(0.1))


def test_listar_e_zip(tmp_path):
    a = _arq(str(tmp_path / "p" / "a.xlsx"))
    time.sleep(0.05)
    b = _arq(str(tmp_path / "p" / "b.xlsx"))
    _arq(str(tmp_path / "p" / "sub" / "c.xlsx"))
    assert aw.arq_listar(str(tmp_path / "p"), "*.xlsx") == [b, a]  # mais novo primeiro
    assert len(aw.arq_listar(str(tmp_path / "p"), "*.XLSX", subpastas=True)) == 3
    z = aw.arq_zip("compactar", str(tmp_path / "p"), str(tmp_path / "pacote"))
    assert z.endswith("pacote.zip") and "p/sub/c.xlsx" in zipfile.ZipFile(z).namelist()
    destino = aw.arq_zip("extrair", z, str(tmp_path / "volta"))
    assert os.path.exists(os.path.join(destino, "p", "a.xlsx"))


def test_comando_e_area_de_transferencia():
    cod, saida = aw.win_comando("echo bot genesys")
    assert cod == 0 and "bot genesys" in saida
    if WIN:  # usa a área de transferência de verdade: guarda e devolve o que estava nela
        antes = aw.win_area_ler()
        try:
            aw.win_area_copiar("teste Ção ✓\nlinha 2")
            assert aw.win_area_ler() == "teste Ção ✓\nlinha 2"
        finally:
            aw.win_area_copiar(antes)
    else:
        aw.win_area_copiar("abc")
        assert aw.win_area_ler() == "abc"


def test_caminhos_com_til_e_variaveis(tmp_path):
    assert aw.arq_caminho("~") == os.path.expanduser("~")
    assert aw.arq_caminho("sub\\a.txt" if WIN else "sub/a.txt", str(tmp_path)) == os.path.join(str(tmp_path), "sub", "a.txt")


@precisa_tela
def test_roteiro_de_arquivos_de_ponta_a_ponta(tmp_path, ui):
    """Baixou -> espera terminar -> move para a pasta do dia -> renomeia -> lista -> copia o caminho ->
    comando -> zip -> limpa. Tudo pelo motor, com variáveis."""
    from motor import Motor
    dl = tmp_path / "Downloads"
    dl.mkdir()
    threading.Timer(0.6, lambda: _arq(str(dl / "relatorio_sistema.xlsx"), "dados")).start()
    sep = os.sep
    passos = [
        {"tipo": "arq_pasta", "pasta": f"saida{sep}{{data_arquivo}}", "variavel": "pasta"},
        {"tipo": "arq_esperar", "padrao": str(dl / "*.xlsx"), "timeout": 15, "so_novos": True},
        {"tipo": "arq_mover", "origem": "{arquivo}", "destino": "{pasta}" + sep},
        {"tipo": "arq_renomear", "arquivo": "{arquivo}", "novo_nome": "Chamados_{data_arquivo}"},
        {"tipo": "arq_listar", "pasta": "{pasta}", "padrao": "*.xlsx", "variavel": "ultimo"},
        {"tipo": "win_area", "acao": "copiar texto para ela", "texto": "{ultimo}"},
        {"tipo": "win_area", "acao": "ler para variável", "variavel": "copiado"},
        {"tipo": "win_comando", "comando": "echo pronto", "variavel": "saida"},
        {"tipo": "arq_zip", "acao": "compactar", "origem": "{pasta}", "destino": "backup{sep}dia".replace("{sep}", sep)},
        {"tipo": "arq_excluir", "arquivos": "{ultimo}", "lixeira": False},
    ]
    if WIN:  # não mexe na área de transferência de verdade no teste de ponta a ponta
        passos = [p for p in passos if p["tipo"] != "win_area"]
    m = Motor(ui=ui, base=str(tmp_path), log_dir=str(tmp_path / "logs"))
    cod, erro = m.rodar(passos, cfg={"contagem": 0, "pausa": 0, "max_chrome": False})
    assert cod == 0, f"{erro}\n{ui.texto()}"
    hoje = time.strftime("%Y-%m-%d")
    assert m.vars["ultimo"].endswith(f"Chamados_{hoje}.xlsx")
    assert m.vars["ultimo_quantidade"] == "1" and "pronto" in m.vars["saida"]
    assert not os.path.exists(m.vars["ultimo"])  # excluído no fim
    assert zipfile.ZipFile(tmp_path / "backup" / "dia.zip").namelist() == [f"{hoje}/Chamados_{hoje}.xlsx"]
    if not WIN:
        assert m.vars["copiado"] == m.vars["ultimo"]


@precisa_tela
def test_passos_de_arquivo_funcionam_em_segundo_plano(tmp_path, ui):
    from motor import Motor
    m = Motor(ui=ui, base=str(tmp_path), log_dir=str(tmp_path / "logs"))
    m._bg = True
    m.executar_passo({"tipo": "arq_pasta", "pasta": "x"}, {})
    assert os.path.isdir(tmp_path / "x")
