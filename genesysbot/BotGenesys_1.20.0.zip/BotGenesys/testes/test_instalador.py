# -*- coding: utf-8 -*-
"""Instalador: arquivos no lugar, scripts bem formados para o Windows e pacote para outro computador."""
import os
import re
import zipfile

from conftest import APP_DIR

PS = os.path.join(APP_DIR, "instalador", "instalar.ps1")


def _ler(caminho):
    with open(caminho, "rb") as f:
        return f.read()


def test_arquivos_do_instalador_existem():
    for n in ("instalar.bat", "desinstalar.bat", "instalador/instalar.ps1", "instalador/desinstalar.ps1",
              "instalador/bot_genesys.ico", "instalador/empacotar.py"):
        assert os.path.exists(os.path.join(APP_DIR, *n.split("/"))), n


def test_powershell_com_bom_e_quebras_do_windows():
    """Sem BOM o PowerShell 5.1 lê os acentos errado; sem CRLF alguns editores do Windows estragam o script."""
    for n in ("instalar.ps1", "desinstalar.ps1"):
        b = _ler(os.path.join(APP_DIR, "instalador", n))
        assert b.startswith(b"\xef\xbb\xbf"), n
        assert b"\r\n" in b and b"\n" not in b.replace(b"\r\n", b""), n


def test_bat_chamam_os_scripts_que_existem():
    for bat in ("instalar.bat", "desinstalar.bat"):
        txt = _ler(os.path.join(APP_DIR, bat)).decode("ascii")  # .bat só com ASCII (cmd não lê UTF-8 bem)
        ps = re.search(r"instalador\\(\w+\.ps1)", txt).group(1)
        assert os.path.exists(os.path.join(APP_DIR, "instalador", ps))
        assert "-ExecutionPolicy Bypass" in txt
    assert "instalar.bat" in _ler(os.path.join(APP_DIR, "iniciar.bat")).decode("ascii")


def test_instalador_faz_todas_as_etapas():
    txt = _ler(PS).decode("utf-8-sig")
    for trecho in ("Achar-Python", "winget install", "python.org", "-m venv", "requirements.txt",
                   "instalado_v5.ok", "Google.Chrome", "Excel.Application", "CreateShortcut", "--diagnostico",
                   'ErrorActionPreference = "Continue"', "PYTHONIOENCODING"):
        assert trecho in txt, trecho
    assert txt.count("{") == txt.count("}"), "chaves desbalanceadas no PowerShell"
    assert txt.count("(") == txt.count(")"), "parênteses desbalanceados no PowerShell"


def test_pacote_nao_leva_dados_do_usuario(tmp_path):
    import sys
    sys.path.insert(0, os.path.join(APP_DIR, "instalador"))
    import empacotar
    destino, n = empacotar.empacotar(str(tmp_path / "pacote.zip"))
    nomes = zipfile.ZipFile(destino).namelist()
    assert "BotGenesys/instalar.bat" in nomes and "BotGenesys/bot_genesys.py" in nomes
    assert "BotGenesys/interface/janela.py" in nomes and "BotGenesys/LEIA-ME.txt" in nomes
    proibidos = ("roteiro01.json", "config_app.json", "agendamentos.json", "/logs/", "/.venv/", "/_versoes/",
                 "chrome_perfil_bot", "/imagens/", "__pycache__")
    assert not [x for x in nomes if any(p in x for p in proibidos)]
