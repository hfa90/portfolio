# -*- coding: utf-8 -*-
"""Condições, repetições, tratamento de erro, parar, variáveis e sub-roteiros."""
import json

import pytest

import fluxo as fx
from conftest import precisa_tela


# ------------------------------------------------------------------ estrutura dos blocos
def test_estrutura_aponta_para_onde_pular():
    t = ["se_valor", "definir_variavel", "senao", "definir_variavel", "fim_se",
         "repetir", "sair_repeticao", "fim_repetir", "tentar", "definir_variavel", "se_der_erro", "fim_tentar"]
    e = fx.estrutura(t)
    assert e[0]["senao"] == 2 and e[0]["fim"] == 4 and e[2]["fim"] == 4
    assert e[5]["fim"] == 7 and e[7]["inicio"] == 5 and e[6]["laco"] == 5
    assert e[8]["erro"] == 10 and e[8]["fim"] == 11
    assert e[9]["tentar"] == 8 and e[10]["tentar"] is None and e[1]["tentar"] is None


@pytest.mark.parametrize("tipos,trecho", [
    (["se_valor"], "não foi fechado"),
    (["fim_se"], "não fecha nenhum"),
    (["repetir", "fim_se"], "o bloco aberto é 'Repetir' do passo 1"),
    (["senao"], "Senão"),
    (["sair_repeticao"], "não está dentro de um 'Repetir'"),
    (["se_valor", "senao", "senao", "fim_se"], "já tem"),
])
def test_estrutura_com_erro_explica(tipos, trecho):
    with pytest.raises(fx.ErroEstrutura, match=trecho):
        fx.estrutura(tipos)


def test_recuo_da_lista():
    t = ["se_valor", "tecla", "senao", "repetir", "tecla", "fim_repetir", "fim_se", "tecla"]
    assert fx.profundidades(t) == [0, 1, 0, 1, 2, 1, 0, 0]
    assert fx.profundidades(["fim_se", "fim_se"]) == [0, 0]  # tolera estrutura incompleta


# ------------------------------------------------------------------ comparações
@pytest.mark.parametrize("a,op,b,esperado", [
    ("1.234,56", "é igual a", "1234.56", True), ("10", "é maior que", "9", True), ("10", "é maior que", "9,5", True),
    ("Fechado ", "é igual a", "fechado", True), ("Status: FECHADO", "contém", "fechado", True),
    ("abc", "não contém", "x", True), ("INC0012", "começa com", "inc", True), ("rel.pdf", "termina com", ".PDF", True),
    ("15/11/2026", "é menor que", "01/12/2026", True), ("", "está vazio", "", True), ("x", "não está vazio", "", True),
    ("R$ 1.500,00", "é maior ou igual a", "1500", True), ("2", "é diferente de", "2,0", False),
    ("banana", "é maior que", "abacaxi", True),
])
def test_comparar(a, op, b, esperado):
    assert fx.comparar(a, op, b) is esperado


def test_numero_e_lista():
    assert fx.numero("15%") == 15 and fx.numero("abc") is None and fx.numero("1,234.5") == 1234.5
    assert fx.dividir_lista("a; b ;;c") == ["a", "b", "c"]
    assert fx.dividir_lista("x\ny", "\\n") == ["x", "y"]
    assert fx.formatar_numero(3.0) == "3" and fx.formatar_numero(2.5) == "2.5"


# ------------------------------------------------------------------ execução pelo motor
def V(nome, valor, op="definir"):
    return {"tipo": "definir_variavel", "nome": nome, "operacao": op, "valor": valor}


def rodar(motor, passos, **cfg):
    return motor.rodar(passos, cfg={"contagem": 0, "pausa": 0, "max_chrome": False, **cfg})


@precisa_tela
def test_se_senao(motor):
    passos = [V("total", "1500"),
              {"tipo": "se_valor", "valor1": "{total}", "operador": "é maior que", "valor2": "1000"},
              V("faixa", "alta"),
              {"tipo": "senao"},
              V("faixa", "baixa"),
              {"tipo": "fim_se"}]
    assert rodar(motor, passos) == (0, None) and motor.vars["faixa"] == "alta"
    passos[0] = V("total", "10")
    assert rodar(motor, passos)[0] == 0 and motor.vars["faixa"] == "baixa"


@precisa_tela
def test_repetir_vezes_soma_e_sair(motor):
    passos = [V("soma", "0"),
              {"tipo": "repetir", "modo": "vezes", "vezes": "10", "variavel": "i"},
              V("soma", "{i}", "somar"),
              {"tipo": "se_valor", "valor1": "{i}", "operador": "é igual a", "valor2": "4"},
              {"tipo": "sair_repeticao"},
              {"tipo": "fim_se"},
              {"tipo": "fim_repetir"},
              V("depois", "ok")]
    assert rodar(motor, passos) == (0, None)
    assert motor.vars["soma"] == "10" and motor.vars["depois"] == "ok"  # 1+2+3+4 e saiu


@precisa_tela
def test_para_cada_item_e_laco_dentro_de_laco(motor):
    passos = [V("saida", ""),
              {"tipo": "repetir", "modo": "para cada item da lista", "lista": "A;B", "variavel": "x"},
              V("letra", "{item}"),
              {"tipo": "repetir", "modo": "vezes", "vezes": "2", "variavel": "y"},
              V("saida", "{letra}{y} ", "juntar ao texto"),
              {"tipo": "fim_repetir"},
              {"tipo": "fim_repetir"}]
    assert rodar(motor, passos) == (0, None) and motor.vars["saida"] == "A1 A2 B1 B2 "


@precisa_tela
def test_enquanto_e_limite_de_seguranca(motor):
    passos = [V("n", "0"),
              {"tipo": "repetir", "modo": "enquanto (comparar valores)", "valor1": "{n}", "operador": "é menor que",
               "valor2": "5"},
              V("n", "1", "somar"),
              {"tipo": "fim_repetir"}]
    assert rodar(motor, passos) == (0, None) and motor.vars["n"] == "5"
    infinito = [{"tipo": "repetir", "modo": "enquanto (comparar valores)", "valor1": "1", "operador": "é igual a",
                 "valor2": "1", "maximo": 20}, {"tipo": "fim_repetir"}]
    cod, erro = rodar(motor, infinito)
    assert cod == 1 and "20 voltas" in erro


@precisa_tela
def test_tentar_trata_o_erro_e_continua(motor, tmp_path):
    passos = [{"tipo": "tentar"},
              {"tipo": "repetir", "modo": "vezes", "vezes": "3"},
              {"tipo": "arq_copiar", "origem": str(tmp_path / "nao_existe.xlsx"), "destino": str(tmp_path / "x")},
              {"tipo": "fim_repetir"},
              V("chegou", "não deveria"),
              {"tipo": "se_der_erro"},
              V("tratado", "sim: {erro}"),
              {"tipo": "fim_tentar"},
              {"tipo": "repetir", "modo": "vezes", "vezes": "2"},  # repetições depois continuam normais
              V("depois", "{volta}"),
              {"tipo": "fim_repetir"}]
    assert rodar(motor, passos) == (0, None)
    assert motor.vars["tratado"].startswith("sim:") and "nao_existe" in motor.vars["erro"]
    assert "chegou" not in motor.vars and motor.vars["depois"] == "2"


@precisa_tela
def test_tentar_sem_erro_pula_o_tratamento(motor):
    passos = [{"tipo": "tentar"}, V("a", "1"), {"tipo": "se_der_erro"}, V("b", "2"), {"tipo": "fim_tentar"}]
    assert rodar(motor, passos) == (0, None) and "b" not in motor.vars


@precisa_tela
def test_parar_roteiro(motor):
    ok = [V("a", "1"), {"tipo": "parar_roteiro", "resultado": "sucesso", "mensagem": "nada a fazer"}, V("b", "2")]
    assert rodar(motor, ok) == (0, None) and "b" not in motor.vars
    cod, erro = rodar(motor, [{"tipo": "parar_roteiro", "resultado": "erro", "mensagem": "faltou {a}"}])
    assert cod == 1 and "faltou" in erro
    # dentro de um Tentar, "Parar o roteiro" continua parando (não é tratado como erro comum)
    dentro = [{"tipo": "tentar"}, {"tipo": "parar_roteiro", "resultado": "erro", "mensagem": "x"},
              {"tipo": "se_der_erro"}, V("tratou", "1"), {"tipo": "fim_tentar"}]
    assert rodar(motor, dentro)[0] == 1 and "tratou" not in motor.vars


@precisa_tela
def test_estrutura_errada_nao_comeca(motor):
    cod, erro = rodar(motor, [V("a", "1"), {"tipo": "se_valor", "valor1": "1", "operador": "é igual a", "valor2": "1"}])
    assert cod == 1 and "estrutura" in erro and "passo 2" in erro and "a" not in motor.vars


@precisa_tela
def test_se_arquivo_e_se_janela(motor, tmp_path):
    (tmp_path / "rel.pdf").write_text("x")
    passos = [{"tipo": "se_arquivo", "padrao": str(tmp_path / "*.pdf")}, V("tem_pdf", "sim"), {"tipo": "fim_se"},
              {"tipo": "se_arquivo", "padrao": str(tmp_path / "*.xlsx"), "negar": True}, V("sem_xlsx", "sim"),
              {"tipo": "fim_se"},
              {"tipo": "se_janela", "titulo": "janela-que-nao-existe-123", "negar": True}, V("sem_janela", "sim"),
              {"tipo": "fim_se"}]
    assert rodar(motor, passos) == (0, None)
    assert motor.vars["tem_pdf"] == motor.vars["sem_xlsx"] == motor.vars["sem_janela"] == "sim"


@precisa_tela
def test_executar_outro_roteiro(motor, tmp_path):
    (tmp_path / "pedaco.json").write_text(json.dumps({"passos": [V("dobro", "{n}"), V("dobro", "{n}", "somar")]}),
                                          encoding="utf-8")
    passos = [V("n", "21"), {"tipo": "executar_roteiro", "arquivo": "pedaco.json"}, V("fim", "{dobro}")]
    assert rodar(motor, passos) == (0, None) and motor.vars["fim"] == "42"
    (tmp_path / "loop.json").write_text(json.dumps({"passos": [{"tipo": "executar_roteiro", "arquivo": "loop.json"}]}),
                                        encoding="utf-8")
    cod, erro = rodar(motor, [{"tipo": "executar_roteiro", "arquivo": "loop.json"}])
    assert cod == 1 and "níveis" in erro


def test_operadores_iguais_no_catalogo_e_no_fluxo():
    import passos
    assert passos.OPERADORES == fx.OPERADORES


@precisa_tela
def test_exemplo_organizar_pdfs(motor, tmp_path, monkeypatch):
    """O exemplo pronto, numa pasta de usuário de mentira (não abre janelas nem mexe na área de transferência)."""
    import os
    from conftest import APP_DIR
    casa = tmp_path / "casa"
    (casa / "Downloads").mkdir(parents=True)
    for n in ("a.pdf", "b.pdf", "nota.txt"):
        (casa / "Downloads" / n).write_text(n)
    monkeypatch.setenv("HOME", str(casa))
    monkeypatch.setenv("USERPROFILE", str(casa))
    with open(os.path.join(APP_DIR, "exemplos", "roteiro_fluxo_organizar_pdfs.json"), encoding="utf-8") as f:
        passos = json.load(f)["passos"]
    for p in passos:
        if p["tipo"] in ("win_abrir", "win_area"):
            p["ativo"] = False
    assert rodar(motor, passos) == (0, None)
    assert motor.vars["copiados"] == "2" and motor.vars["falhas"] == "0"
    assert sorted(os.listdir(motor.vars["pasta"])) == ["a.pdf", "b.pdf"]
    assert sorted(os.listdir(casa / "Downloads")) == ["a.pdf", "b.pdf", "nota.txt"]  # nada foi movido/apagado
