# -*- coding: utf-8 -*-
"""E-mail (SMTP e Outlook) e notificações. Nada sai do computador: SMTP, Outlook e a internet são trocados por
falsos que guardam o que receberiam."""
import datetime
import json

import pytest

import mensagens as mg
import passos as cat
from conftest import precisa_tela

CFG = {"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0}


# ------------------------------------------------------------------ utilidades
def test_enderecos_e_anexos(tmp_path):
    assert mg.enderecos("a@x.com; b@y.com, A@X.com\nc@z.com;;") == ["a@x.com", "b@y.com", "c@z.com"]
    (tmp_path / "r1.pdf").write_text("1")
    (tmp_path / "r2.pdf").write_text("2")
    (tmp_path / "base.xlsx").write_text("3")
    achados = mg.arquivos_anexos("*.pdf; base.xlsx", str(tmp_path))
    assert [p.rsplit("/", 1)[-1].rsplit("\\", 1)[-1] for p in achados] == ["r1.pdf", "r2.pdf", "base.xlsx"]
    with pytest.raises(FileNotFoundError, match="nao_existe"):
        mg.arquivos_anexos("nao_existe.pdf", str(tmp_path))


def test_servidor_pelo_email():
    assert mg.servidor_sugerido("fulano@gmail.com") == ("smtp.gmail.com", 587)
    assert mg.servidor_sugerido("eu@empresa.com.br") == ("smtp.office365.com", 587)


def test_listas_iguais_no_catalogo_e_no_modulo():  # no .py exportado os dois viram um só
    assert cat.ACOES_OUTLOOK == mg.ACOES_OUTLOOK and cat.CANAIS == mg.CANAIS and cat.SE_NAO_ACHAR == mg.SE_NAO_ACHAR
    assert cat.QUAIS_EMAILS == mg.QUAIS and cat.SEGURANCAS_SMTP == mg.SEGURANCAS and cat.VIAS_EMAIL == mg.VIAS


# ------------------------------------------------------------------ SMTP
class _SMTPFalso:
    enviados = []

    def __init__(self, host, porta, timeout=None, context=None):
        self.host, self.porta, self.passos = host, porta, []

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def ehlo(self):
        pass

    def starttls(self, context=None):
        self.passos.append("tls")

    def login(self, u, s):
        if s != "certa":
            import smtplib
            raise smtplib.SMTPAuthenticationError(535, b"bad")
        self.passos.append("login")

    def send_message(self, msg, from_addr, to_addrs):
        _SMTPFalso.enviados.append((self.host, self.porta, self.passos, msg, from_addr, to_addrs))


@pytest.fixture
def smtp(monkeypatch):
    _SMTPFalso.enviados = []
    monkeypatch.setattr(mg.smtplib, "SMTP", _SMTPFalso)
    monkeypatch.setattr(mg.smtplib, "SMTP_SSL", _SMTPFalso)
    return _SMTPFalso.enviados


def test_smtp_envia_com_anexo_e_copia_oculta(smtp, tmp_path):
    anexo = tmp_path / "relatório.pdf"
    anexo.write_bytes(b"%PDF-1.4 teste")
    mg.enviar_smtp("", 0, "eu@gmail.com", "certa", ["a@x.com"], "Relatório", "Olá", cc=["c@x.com"],
                   cco=["oculto@x.com"], anexos=[str(anexo)])
    host, porta, passos, msg, de, para = smtp[0]
    assert (host, porta, passos, de) == ("smtp.gmail.com", 587, ["tls", "login"], "eu@gmail.com")
    assert para == ["a@x.com", "c@x.com", "oculto@x.com"] and "oculto" not in str(msg)  # Cco não aparece no e-mail
    nomes = [p.get_filename() for p in msg.iter_attachments()]
    assert nomes == ["relatório.pdf"] and msg["Subject"] == "Relatório"


def test_smtp_senha_errada_explica_senha_de_app(smtp):
    with pytest.raises(RuntimeError, match="senha de app"):
        mg.enviar_smtp("smtp.gmail.com", 587, "eu@gmail.com", "errada", ["a@x.com"], "x", "y")


# ------------------------------------------------------------------ Outlook (falso)
class _Anexo:
    def __init__(self, nome):
        self.FileName = nome

    def SaveAsFile(self, destino):
        with open(destino, "w") as f:
            f.write(self.FileName)


class _Anexos:
    def __init__(self, nomes):
        self.lista = [_Anexo(n) for n in nomes]
        self.Count = len(self.lista)

    def Item(self, i):
        return self.lista[i - 1]

    def Add(self, caminho):
        self.lista.append(_Anexo(caminho))
        self.Count += 1


class _Email:
    Class = 43
    SenderEmailType = "SMTP"

    def __init__(self, assunto, de, minutos_atras, anexos=(), lido=False, corpo="corpo"):
        self.Subject, self.SenderEmailAddress, self.SenderName = assunto, de, de.split("@")[0].title()
        self.ReceivedTime = datetime.datetime.now() - datetime.timedelta(minutes=minutos_atras)
        self.Attachments, self.UnRead, self.Body = _Anexos(anexos), not lido, corpo
        self.salvo = self.movido = None

    def Save(self):
        self.salvo = True

    def Move(self, pasta):
        self.movido = pasta.Name


class _Itens:
    def __init__(self, emails):
        self.emails = emails

    def Sort(self, campo, desc):
        self.emails = sorted(self.emails, key=lambda e: e.ReceivedTime, reverse=desc)
        self.i = 0

    def GetFirst(self):
        self.i = 0
        return self.GetNext()

    def GetNext(self):
        if self.i >= len(self.emails):
            return None
        self.i += 1
        return self.emails[self.i - 1]


class _Pasta:
    def __init__(self, nome, emails=(), filhas=(), pai=None):
        self.Name, self._emails, self.Folders, self.Parent = nome, list(emails), list(filhas), pai

    @property
    def Items(self):
        return _Itens(list(self._emails))


class _Outlook:
    def __init__(self, emails):
        self.feitos = _Pasta("Processados")
        self.entrada = _Pasta("Caixa de Entrada", emails, [self.feitos])
        self.criados = []

    def GetNamespace(self, n):
        return self

    def GetDefaultFolder(self, n):
        return self.entrada

    def CreateItem(self, n):
        app = self

        class Item:
            Attachments = _Anexos([])

            def Send(self):
                app.criados.append(("enviado", self))

            def Display(self, modal):
                app.criados.append(("aberto", self))

            def Save(self):
                app.criados.append(("rascunho", self))
        return Item()


def test_procura_o_mais_recente_que_bate():
    emails = [_Email("Base diária 14/11", "sistema@empresa.com", 600, ["base.xlsx"], lido=True),
              _Email("Base diária 15/11", "sistema@empresa.com", 30, ["base.xlsx"]),
              _Email("Almoço", "colega@empresa.com", 5)]
    app = _Outlook(emails)
    e = mg.procurar_outlook(assunto="base diária", com_anexo=True, quais="não lidos", app=app)
    assert e.Subject == "Base diária 15/11"
    assert mg.procurar_outlook(remetente="sistema@", quais="o mais recente (lido ou não)", app=app).Subject.endswith("15/11")
    desde = datetime.datetime.now() - datetime.timedelta(minutes=1)
    assert mg.procurar_outlook(assunto="base", quais="só os que chegarem a partir de agora", desde=desde, app=app) is None


def test_subpasta_e_anexos_filtrados(tmp_path):
    e = _Email("Relatórios", "a@b.com", 1, ["vendas.xlsx", "logo.png", "resumo.pdf"])
    app = _Outlook([])
    app.feitos._emails = [e]
    assert mg.procurar_outlook(pasta="Caixa de Entrada/Processados", app=app) is e
    salvos = mg.salvar_anexos(e, str(tmp_path / "anexos"), ".xlsx; *.pdf")
    assert sorted(p.replace("\\", "/").rsplit("/", 1)[-1] for p in salvos) == ["resumo.pdf", "vendas.xlsx"]
    with pytest.raises(LookupError, match="Inexistente"):
        mg.procurar_outlook(pasta="Caixa de Entrada/Inexistente", app=app)


def test_outlook_enviar_rascunho_e_revisar():
    app = _Outlook([])
    mg.enviar_outlook(["a@x.com"], "Oi", "texto", app=app)
    mg.enviar_outlook([], "Rascunho", "texto", acao="salvar como rascunho", app=app)
    assert [c[0] for c in app.criados] == ["enviado", "rascunho"] and app.criados[0][1].To == "a@x.com"
    with pytest.raises(ValueError, match="destinatário"):
        mg.enviar_outlook([], "x", "y", app=app)


# ------------------------------------------------------------------ notificações
@pytest.fixture
def internet(monkeypatch):
    chamadas = []

    class R:
        status = 200

        def __init__(self, corpo):
            self.corpo = corpo

        def read(self):
            return self.corpo

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def urlopen(req, timeout=None):
        chamadas.append((req.full_url, json.loads(req.data.decode("utf-8"))))
        return R(b'{"ok": true}')
    monkeypatch.setattr(mg.urllib.request, "urlopen", urlopen)
    return chamadas


@pytest.mark.parametrize("canal,url,chave_texto", [
    ("Telegram", "https://api.telegram.org/bot123:ABC/sendMessage", "text"),
    ("Slack", "https://hooks.slack.com/services/x", "text"),
    ("Discord", "https://discord.com/api/webhooks/x", "content"),
    ("Microsoft Teams", "https://prod.logic.azure.com/x", "attachments"),
])
def test_cada_servico_recebe_o_formato_dele(internet, canal, url, chave_texto):
    chave = "123:ABC" if canal == "Telegram" else url
    mg.notificar(canal, "Robô", "Falhou no passo 3", chave, chat_id="999")
    enviado_para, dados = internet[0]
    assert enviado_para == url and chave_texto in dados
    assert "Falhou no passo 3" in json.dumps(dados, ensure_ascii=False)


def test_notificar_sem_endereco_explica():
    with pytest.raises(ValueError, match="webhook"):
        mg.notificar("Slack", "t", "m", "")
    with pytest.raises(ValueError, match="https"):
        mg.notificar("Slack", "t", "m", "hooks.slack.com/x")


# ------------------------------------------------------------------ segredos no arquivo do roteiro
def test_senha_e_token_ficam_criptografados_ao_salvar():
    passo = {"tipo": "email_enviar", "smtp_usuario": "eu@gmail.com", "smtp_senha": "minha senha"}
    salvo = cat.guardar_segredos(passo, lambda t: "b64:" + t[::-1])
    assert "smtp_senha" not in salvo and salvo["smtp_senha_protegido"] == "b64:ahnes ahnim"
    assert passo["smtp_senha"] == "minha senha"  # o passo em uso não muda
    carregado = json.loads(json.dumps(salvo))
    assert cat.abrir_segredos(carregado, lambda g: g[4:][::-1]) == []
    assert carregado["smtp_senha"] == "minha senha" and "smtp_senha_protegido" not in carregado
    assert "minha senha" not in cat.resumo(passo)
    falha = {"tipo": "notificar", "chave_protegido": "dpapi:xx"}
    assert cat.abrir_segredos(falha, lambda g: 1 / 0) == ["chave"] and falha["chave"] == ""


def test_validacoes():
    assert cat.validar({"tipo": "email_enviar", "via": "Outlook do computador", "acao": "enviar"}, None)[0] == \
        "Falta o destinatário"
    assert cat.validar({"tipo": "email_enviar", "via": "Outlook do computador", "acao": "salvar como rascunho"},
                       None) is None
    assert cat.validar({"tipo": "notificar", "canal": "Telegram", "mensagem": "x", "chave": "1:a"}, None)[0] == \
        "Falta o chat_id"


# ------------------------------------------------------------------ no motor (também em segundo plano)
@precisa_tela
def test_motor_le_email_salva_anexo_e_avisa_no_telegram(motor, monkeypatch, internet, tmp_path):
    e = _Email("Base diária 15/11", "sistema@empresa.com", 2, ["base.xlsx"], corpo="Segue a base.")
    app = _Outlook([e])
    monkeypatch.setattr(mg, "_outlook", lambda: app)
    passos = [{"tipo": "email_esperar", "assunto": "base diária", "quais": "não lidos", "timeout": 0,
               "salvar_anexos": "entrada", "mover_para": "Processados"},
              {"tipo": "notificar", "canal": "Telegram", "titulo": "Bot", "chave": "1:A", "chat_id": "7",
               "mensagem": "Chegou {email_assunto} com {email_qtd_anexos} anexo(s)"}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["email_corpo"] == "Segue a base." and motor.vars["email_anexos"].endswith("base.xlsx")
    assert (tmp_path / "entrada" / "base.xlsx").exists() and e.UnRead is False and e.movido == "Processados"
    assert internet[0][1]["text"] == "Bot\nChegou Base diária 15/11 com 1 anexo(s)"


@precisa_tela
def test_motor_email_que_nao_chega(motor, monkeypatch):
    monkeypatch.setattr(mg, "_outlook", lambda: _Outlook([]))
    seguir = [{"tipo": "email_esperar", "assunto": "x", "timeout": 0, "se_nao_achar": "seguir com as variáveis vazias"},
              {"tipo": "se_valor", "valor1": "{email_assunto}", "operador": "está vazio"},
              {"tipo": "definir_variavel", "nome": "resultado", "valor": "não chegou"},
              {"tipo": "fim_se"}]
    cod, erro = motor.rodar(seguir, cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["resultado"] == "não chegou"
    cod, erro = motor.rodar([{"tipo": "email_esperar", "assunto": "x", "timeout": 0}], cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "nenhum e-mail" in erro


@precisa_tela
def test_notificacao_que_falha_so_avisa(motor, monkeypatch):
    def cai(*a, **k):
        raise RuntimeError("sem internet")
    monkeypatch.setattr(mg, "notificar", cai)
    cod, erro = motor.rodar([{"tipo": "notificar", "canal": "Slack", "chave": "https://x", "mensagem": "oi"}],
                            cfg=CFG)
    assert cod == 0 and "não foi enviada: sem internet" in motor.ui.texto()


def test_segundo_plano_aceita_email(motor, monkeypatch, smtp):
    passo = {"tipo": "email_enviar", "via": "SMTP (Gmail, Office 365...)", "para": "a@x.com", "assunto": "Fim {data}",
             "corpo": "ok", "smtp_usuario": "eu@gmail.com", "smtp_senha": "certa"}
    cod, erro = motor.rodar([passo], cfg={"contagem": 0, "segundo_plano": True})
    assert cod == 0, erro
    assert smtp and smtp[0][3]["Subject"].startswith("Fim ") and "{data}" not in smtp[0][3]["Subject"]
