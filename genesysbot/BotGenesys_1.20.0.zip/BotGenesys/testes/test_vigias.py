# -*- coding: utf-8 -*-
"""Pop-ups (avisos do Chrome e janelas do Windows), anexar no Chrome sem a janela 'Abrir' e salvar a correção da IA
que deu certo. Chrome e Windows são trocados por falsos: nada abre de verdade."""
import json
import os

import pytest

import arquivos_win as aw
from conftest import precisa_tela

pytestmark = precisa_tela
CFG = {"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0}
CHROME = "aviso do Chrome (alerta/confirmação da página)"


class ChromeFalso:
    vivo = True

    def __init__(self, dialogo=None, campos_depois=0):
        self.dialogo, self.respostas, self.anexados = dialogo, [], []
        self.dialogos = {"aba": dialogo} if dialogo else {}
        self._tentativas, self.campos_depois = 0, campos_depois

    def dialogo_aberto(self):
        return ("aba", self.dialogo) if self.dialogo else (None, None)

    def responder_dialogo(self, aceitar=True, texto=None, tid=None):
        self.respostas.append(aceitar)
        self.dialogo, self.dialogos = None, {}

    def anexar_arquivos(self, caminhos, seletor="", tid=None):
        self._tentativas += 1
        if self._tentativas <= self.campos_depois:
            return 0  # o formulário ainda não montou o campo de upload
        self.anexados.append(list(caminhos))
        return 2

    def fechar(self):
        pass


@pytest.fixture
def chrome(motor, monkeypatch):
    estado = {}

    def usar(falso):
        estado["n"] = falso
        motor.nav = falso
        monkeypatch.setattr(motor, "_conectar", lambda: falso)
        return falso
    return usar


def test_aviso_esqueceu_anexo_e_cancelado_e_para(motor, chrome):
    c = chrome(ChromeFalso({"message": "Parece que você esqueceu de anexar um arquivo. Enviar mesmo assim?",
                            "type": "confirm"}))
    passos = [{"tipo": "vigiar_popup", "onde": CHROME, "texto": "anexar", "acao": "Cancelar / não",
               "depois": "parar o roteiro com erro"},
              {"tipo": "esperar", "segundos": 0}]
    cod, erro = motor.rodar(passos, cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "esqueceu de anexar" in erro and c.respostas == [False]


def test_aviso_sem_regra_para_com_a_mensagem_dele(motor, chrome):
    chrome(ChromeFalso({"message": "Sessão expirada", "type": "alert"}))
    cod, erro = motor.rodar([{"tipo": "esperar", "segundos": 0}], cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "Sessão expirada" in erro and "Vigiar pop-up" in erro


def test_aviso_com_regra_ok_segue(motor, chrome):
    c = chrome(ChromeFalso({"message": "Deseja sair desta página?", "type": "beforeunload"}))
    passos = [{"tipo": "vigiar_popup", "onde": CHROME, "texto": "sair", "acao": "OK / aceitar",
               "depois": "registrar e seguir"},
              {"tipo": "definir_variavel", "nome": "x", "valor": "ok"}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert c.respostas == [True] and motor.vars["x"] == "ok" and "Pop-up do Chrome" in motor.ui.texto()


def test_janela_do_windows_no_meio_de_uma_espera(motor, monkeypatch):
    aparecidas = iter([[], [], [(77, "Confirmar Salvar como")]])
    monkeypatch.setattr(aw, "win_janelas_com", lambda texto: next(aparecidas, []))
    clicados = []
    monkeypatch.setattr(aw, "win_responder", lambda h, acao, botao="": clicados.append((h, acao, botao)) or
                        f"clicou em '{botao}'")
    passos = [{"tipo": "vigiar_popup", "onde": "janela do Windows", "texto": "substituir",
               "acao": "clicar no botão com o texto", "botao": "Sim", "depois": "registrar e seguir"},
              {"tipo": "esperar", "segundos": 2.6}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert clicados == [(77, "botao", "Sim")] and "Confirmar Salvar como" in motor.ui.texto()


def test_anexar_no_chrome_espera_o_campo_e_confere(motor, chrome, monkeypatch, tmp_path):
    (tmp_path / "relatorio.xlsx").write_text("x")
    c = chrome(ChromeFalso(campos_depois=2))
    monkeypatch.setattr(motor, "_pagina_tem", lambda texto, seletor: texto == "relatorio.xlsx")
    cod, erro = motor.rodar([{"tipo": "chrome_anexar", "arquivos": "relatorio.xlsx", "timeout": 10}], cfg=CFG)
    assert cod == 0, erro
    assert c.anexados == [[str(tmp_path / "relatorio.xlsx")]] and "Anexo confirmado" in motor.ui.texto()


def test_anexo_que_nao_aparece_na_pagina_da_erro(motor, chrome, monkeypatch, tmp_path):
    (tmp_path / "a.pdf").write_text("x")
    chrome(ChromeFalso())
    monkeypatch.setattr(motor, "_pagina_tem", lambda texto, seletor: False)
    cod, erro = motor.rodar([{"tipo": "chrome_anexar", "arquivos": "a.pdf", "timeout": 3}],
                            cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "não apareceu" in erro


def test_anexo_inexistente_explica(motor, chrome):
    chrome(ChromeFalso())
    cod, erro = motor.rodar([{"tipo": "chrome_anexar", "arquivos": "nao_existe.xlsx", "timeout": 3}],
                            cfg=dict(CFG, tentativas=0))
    assert cod == 1 and "nao_existe.xlsx" in erro


def test_janela_abrir_so_no_windows():
    import sys
    if sys.platform == "win32":
        pytest.skip("no Windows este passo abre de verdade")
    with pytest.raises(RuntimeError, match="só existe no Windows"):
        aw.win_escolher_arquivo("C:\\x.txt", 1)
    assert aw.dialogos_de_arquivo() == [] and aw.win_janelas_com("x") == []


def test_correcao_da_ia_que_deu_certo_e_salva(monkeypatch, tmp_path):
    import bot_genesys as b
    import ttkbootstrap as tb
    import interface.arquivos as ia_arq
    from conftest import isolar_janela, nova_janela
    mp = pytest.MonkeyPatch()
    isolar_janela(mp, tmp_path)
    mp.setattr(ia_arq, "LOG_DIR", str(tmp_path / "logs"))
    root = nova_janela(tb, b.TEMA_CLARO)
    root.withdraw()
    try:
        a = b.App(root)
        arq = tmp_path / "meu.json"
        arq.write_text(json.dumps({"versao": 1, "passos": [{"tipo": "esperar", "segundos": 1}]}), encoding="utf-8")
        a.arquivo = str(arq)
        a.steps = [{"tipo": "esperar", "segundos": 5}]  # a correção aplicada
        a._solucao_ia_pendente = True
        linhas = []
        a.log = lambda msg, tag=None: linhas.append(msg)
        a._salvar_solucao_que_deu_certo()
        assert json.loads(arq.read_text(encoding="utf-8"))["passos"][0]["segundos"] == 5
        copias = os.listdir(tmp_path / "logs" / "roteiros_antes_da_ia")
        assert len(copias) == 1 and copias[0].startswith("meu_")
        assert a._solucao_ia_pendente is False and any("correção da IA deu certo" in l for l in linhas)
        a.dirty = False
    finally:
        root.destroy()
        mp.undo()


def test_windows_de_verdade_procura_janelas_sem_erro():
    import sys
    if sys.platform != "win32":
        pytest.skip("só no Windows")
    assert aw.win_janelas_com("texto-que-nenhuma-janela-tem-1234") == []
    assert isinstance(aw.dialogos_de_arquivo(), list)
    with pytest.raises(TimeoutError, match="não apareceu"):
        aw.win_escolher_arquivo("C:\\nada.txt", timeout=1, titulo="janela-que-nao-existe-1234")
