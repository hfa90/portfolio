# -*- coding: utf-8 -*-
"""Motor de execução: variáveis, teclas, proteções e roteiros de Excel de ponta a ponta."""
import json
import os

import pytest

import excel as xlm
from conftest import precisa_tela

pytestmark = precisa_tela


def test_expandir_variaveis():
    from motor import expandir
    assert expandir("Olá {nome}", {"nome": "Ana"}) == "Olá Ana"
    assert expandir("{data}", {})[2] == "/" or "-" in expandir("{data}", {})
    assert expandir("{nao_existe}", {}) == "{nao_existe}"


def test_parse_teclas():
    from motor import parse_teclas
    assert parse_teclas("ctrl+c")
    assert parse_teclas("enter")


def test_outro_programa_e_resumo():
    from motor import outro_programa, resumo
    p = {"tipo": "clique", "x": 1, "y": 2, "botao": "esquerdo", "cliques": 1,
         "janela": {"processo": "excel.exe", "titulo": "x", "classe": "XLMAIN"}}
    assert outro_programa(p) == "excel.exe"
    assert "EXCEL" in resumo(p)
    assert outro_programa(dict(p, janela={"processo": "chrome.exe"})) == ""
    assert outro_programa({"tipo": "clique"}) == ""


def test_tipo_desconhecido_avisa_antes_de_comecar(motor):
    cod, erro = motor.rodar([{"tipo": "passo_do_futuro"}], cfg={"contagem": 0})
    assert cod == 1 and "não conhece" in erro


def test_segundo_plano_recusa_passo_de_outro_programa(motor):
    p = {"tipo": "clique", "x": 1, "y": 2, "janela": {"processo": "sap.exe"}}
    cod, erro = motor.rodar([p], cfg={"contagem": 0, "segundo_plano": True})
    assert cod == 1 and "segundo plano" in erro


def _roteiro(exemplos, nome):
    with open(os.path.join(exemplos, "exemplos", nome), encoding="utf-8") as f:
        return json.load(f)["passos"]


@pytest.mark.parametrize("nome", ["roteiro_excel_dinamica.json", "roteiro_excel_graficos.json"])
def test_roteiro_de_excel_de_ponta_a_ponta(nome, exemplos, ui):
    """Com o Excel instalado: roda o roteiro inteiro (invisível) numa CÓPIA da planilha.
    Sem o Excel: roda só os passos que não precisam dele."""
    from motor import Motor
    passos = _roteiro(exemplos, nome)
    if not xlm.HAS_COM:
        import openpyxl
        planilha = next(s["arquivo"] for s in passos if s["tipo"] == "excel_abrir")
        caminho = os.path.join(exemplos, planilha)
        wb = openpyxl.load_workbook(caminho)
        for ws in wb.worksheets:  # cópia sem gráficos, para o openpyxl poder salvar
            ws._charts = []
        wb.save(caminho)
        for s in passos:
            if (s["tipo"] in ("excel_dinamica", "excel_macro") or str(s.get("dados", "")).startswith("din")
                    or s.get("formato") == "pdf"):
                s["ativo"] = False
        for s in reversed(passos):
            if s["tipo"] == "excel_salvar" and s.get("ativo", True):
                s["fechar"] = True
                break
    m = Motor(ui=ui, base=str(exemplos), log_dir=str(exemplos / "logs"))
    cod, erro = m.rodar(passos, cfg={"contagem": 0, "pausa": 0, "max_chrome": False, "tent": 1,
                                     "excel_visivel": False})
    assert cod == 0, f"{erro}\n{ui.texto()}"
    assert "concluída com sucesso" in ui.texto()
