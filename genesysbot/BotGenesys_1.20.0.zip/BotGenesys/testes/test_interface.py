# -*- coding: utf-8 -*-
"""A janela abre, todo tipo de passo mostra o formulário e todos os roteiros carregam e aparecem na lista.
Usa arquivos de configuração temporários: não mexe nos seus recentes, agendamentos nem logs."""
import pytest

from conftest import isolar_janela, precisa_tela, nova_janela
import diagnostico as diag
from conftest import APP_DIR

pytestmark = precisa_tela


@pytest.fixture(scope="module")
def app(tmp_path_factory):
    import bot_genesys as b
    import ttkbootstrap as tb
    tmp = tmp_path_factory.mktemp("app")
    mp = pytest.MonkeyPatch()
    isolar_janela(mp, tmp)
    root = nova_janela(tb, b.TEMA_CLARO)
    root.withdraw()
    a = b.App(root)
    root.update()
    yield a
    a.dirty = False
    root.destroy()
    mp.undo()


def test_versao_no_titulo(app):
    from versao import VERSAO
    assert VERSAO in app.root.title()


def test_todo_tipo_mostra_formulario(app):
    from motor import TIPOS
    for tipo in TIPOS:
        app._set_tipo(tipo)
        app.root.update_idletasks()
        d = app._ler_form_silencioso()
        assert d and d["tipo"] == tipo, tipo


ROTEIROS = [p for p, _ in diag.arquivos_roteiro(APP_DIR)]


@pytest.mark.parametrize("caminho", ROTEIROS, ids=[p.replace(APP_DIR, "")[1:] for p in ROTEIROS])
def test_roteiro_carrega_na_tela(app, caminho):
    app._carregar(caminho)
    app.root.update_idletasks()
    assert len(app.tree.get_children()) == len(app.steps) > 0
    for i in range(len(app.steps)):  # selecionar cada passo mostra o formulário certo
        app.tree.selection_set(str(i))
        app.root.update()
        assert app.tipo_atual == app.steps[i]["tipo"]
    app.dirty = False


def test_criar_com_ia_insere_os_passos_e_desfaz(app, monkeypatch):
    import json
    import ia
    monkeypatch.setattr(ia, "chave_configurada", lambda *a: "sk-teste")
    monkeypatch.setattr(ia, "chamar", lambda *a, **k: json.dumps({"explicacao": "Duas esperas.", "passos": [
        {"tipo": "esperar", "segundos": 1}, {"tipo": "esperar", "segundos": 2}]}))
    monkeypatch.setattr(app, "_ia_em_fundo", lambda trabalho, ok, falhou: ok(trabalho()))  # sem linha separada
    app.steps = [{"tipo": "tecla", "teclas": "enter"}]
    app._refresh(0)
    antes = len(app.root.winfo_children())
    app.criar_com_ia()
    win = app.root.winfo_children()[-1]
    assert len(app.root.winfo_children()) == antes + 1

    def achar(w, classe):
        for f in w.winfo_children():
            if f.winfo_class() == classe:
                yield f
            yield from achar(f, classe)
    next(achar(win, "Text")).insert("1.0", "espere 1 e depois 2 segundos")
    botoes = {b.cget("text"): b for b in achar(win, "TButton")}
    botoes["✦  Gerar passos"].invoke()
    botoes["✔  INSERIR NO ROTEIRO"].invoke()
    assert [p["tipo"] for p in app.steps] == ["tecla", "esperar", "esperar"]
    assert app.steps[2]["segundos"] == 2.0
    app.desfazer()
    assert [p["tipo"] for p in app.steps] == ["tecla"]
    app.dirty = False


def test_cartao_esperando_voce(app):
    app.running = True
    try:
        app.motor.pausado = True
        app._cartao_aguardar("Faça login no Gmail")
        app.root.update()
        assert app._cartao is not None and app._cartao.winfo_exists()
        assert "ESPERANDO" in app.lbl_estado.cget("text")
        app._continuar_aguardo()
        assert app.motor.pausado is False and app._cartao is None
        assert "EXECUTANDO" in app.lbl_estado.cget("text")
    finally:
        app.running = False
        app.motor.pausado = False


def test_aplicar_solucao_da_ia(app, monkeypatch):
    import ia
    monkeypatch.setattr(ia, "chave_configurada", lambda *a: "sk-teste")
    monkeypatch.setattr(app, "_ia_em_fundo", lambda trabalho, ok, falhou: ok(trabalho()))
    monkeypatch.setattr(ia, "chamar", lambda *a, **k: (
        '{"explicacao": "Espera curta.", "alteracoes": [{"acao": "alterar", "passo": 2, "campos": '
        '{"segundos": 5}}], "executar_de": 2}'))
    executou = []
    monkeypatch.setattr(app, "executar", lambda inicio=0, so_um=False: executou.append(inicio))
    app.steps = [{"tipo": "tecla", "teclas": "enter", "repetir": 1}, {"tipo": "esperar", "segundos": 1}]
    app._refresh(0)
    app.motor.ultimo_erro = {"erro": "deu ruim", "passo": 1, "print": None, "log": "..."}
    app.explicar_erro_ia()
    win = app.root.winfo_children()[-1]

    def achar(w, classe):
        for f in w.winfo_children():
            if f.winfo_class() == classe:
                yield f
            yield from achar(f, classe)
    botoes = {b.cget("text"): b for b in achar(win, "TButton")}
    assert "✔  APLICAR SOLUÇÃO" in botoes and str(botoes["✔  APLICAR SOLUÇÃO"].cget("state")) == "normal"
    botoes["▶  Aplicar e executar de novo do passo 2"].invoke()
    import time
    for _ in range(12):  # 'executar de novo' é chamado logo depois de fechar a janela
        app.root.update()
        time.sleep(0.05)
    assert app.steps[1]["segundos"] == 5.0 and executou == [1]
    app.desfazer()
    assert app.steps[1]["segundos"] == 1
    app.dirty = False
