# -*- coding: utf-8 -*-
"""IA: geração de passos conferida com o catálogo, perguntas, visão (localizar) e explicação de erro.
Nada vai para a internet: a chamada à API é trocada por uma IA falsa com respostas prontas."""
import json

import pytest
from PIL import Image

import fluxo as fx
import ia
import passos as cat
from conftest import precisa_tela

CFG = {"contagem": 0, "visual": False, "max_chrome": False, "pausa": 0}


class IAFalsa:
    def __init__(self, *respostas):
        self.respostas, self.pedidos = list(respostas), []

    def __call__(self, chave, texto, sistema="", imagens=(), max_tokens=0, modelo=None):
        self.pedidos.append({"texto": texto, "sistema": sistema, "imagens": list(imagens), "modelo": modelo})
        r = self.respostas.pop(0)
        return r if isinstance(r, str) else json.dumps(r, ensure_ascii=False)


# ------------------------------------------------------------------ gerar roteiro
def test_pedido_vira_passos_conferidos():
    resposta = {"explicacao": "Filtra as notas acima de 1.000 para uma aba nova.", "passos": [
        {"tipo": "excel_abrir", "descricao": "Abrir a planilha", "arquivo": "C:\\rel\\notas.xlsx"},
        {"tipo": "se_valor", "valor1": "{total}", "operador": "É MAIOR QUE", "valor2": "1000"},
        {"tipo": "notificar", "canal": "Windows (aviso na tela)", "mensagem": "Acima de mil", "chave": "VAZOU"},
        {"tipo": "fim_se"},
        {"tipo": "teletransportar", "destino": "lua"},
        {"tipo": "esperar", "segundos": "2,5"},
    ]}
    falsa = IAFalsa("Claro! Aqui está:\n```json\n" + json.dumps(resposta, ensure_ascii=False) + "\n```")
    passos, explicacao, avisos = ia.gerar_passos("k", "filtre notas > 1000", cat, fx, chamar_fn=falsa)
    assert [p["tipo"] for p in passos] == ["excel_abrir", "se_valor", "notificar", "fim_se", "esperar"]
    assert passos[1]["operador"] == "é maior que"  # opção corrigida para a grafia exata
    assert passos[2]["chave"] == "" and passos[2]["titulo"] == "Bot Genesys"  # segredo nunca vem da IA; padrões
    assert passos[4]["segundos"] == 2.5
    assert any("teletransportar" in a for a in avisos) and explicacao.startswith("Filtra")
    assert "excel_escrever" in falsa.pedidos[0]["sistema"]  # o catálogo vai junto


def test_estrutura_quebrada_ganha_uma_correcao():
    quebrado = {"passos": [{"tipo": "repetir"}, {"tipo": "esperar"}]}
    certo = {"explicacao": "ok", "passos": [{"tipo": "repetir"}, {"tipo": "esperar"}, {"tipo": "fim_repetir"}]}
    falsa = IAFalsa(quebrado, certo)
    passos, _, avisos = ia.gerar_passos("k", "repita", cat, fx, chamar_fn=falsa)
    assert len(falsa.pedidos) == 2 and "não foi fechado" in falsa.pedidos[1]["texto"]
    assert [p["tipo"] for p in passos][-1] == "fim_repetir" and not avisos


def test_roteiro_atual_vai_sem_senhas():
    atuais = [{"tipo": "digitar", "texto": "minhaSenha123", "senha": True},
              {"tipo": "email_enviar", "smtp_senha": "outraSenha", "para": "a@x.com"},
              {"tipo": "clique", "x": 1, "y": 2, "janela": {"titulo": "x"}, "_tk": 5}]
    falsa = IAFalsa({"passos": [{"tipo": "esperar"}]})
    ia.gerar_passos("k", "acrescente uma espera", cat, fx, atuais=atuais, colunas=["Nota", "Cliente"],
                    chamar_fn=falsa)
    enviado = falsa.pedidos[0]["texto"]
    assert "minhaSenha123" not in enviado and "outraSenha" not in enviado and "_tk" not in enviado
    assert "Nota, Cliente" in enviado and "APENAS os passos NOVOS" in enviado


def test_resposta_sem_passos_validos_explica():
    with pytest.raises(ia.ErroIA, match="nenhum passo"):
        ia.gerar_passos("k", "x", cat, fx, chamar_fn=IAFalsa({"passos": [{"tipo": "voar"}]}))
    with pytest.raises(ia.ErroIA, match="formato"):
        ia.gerar_passos("k", "x", cat, fx, chamar_fn=IAFalsa("não sei fazer isso"))


def test_todos_os_tipos_estao_descritos_para_a_ia():
    texto = ia.descrever_catalogo(cat)
    for t in cat.TIPOS:
        assert f"### {t} =" in texto
    assert "smtp_senha" not in texto  # campos secretos não são descritos


# ------------------------------------------------------------------ perguntar
@pytest.mark.parametrize("formato,resposta,esperado", [
    ("número", "O total é R$ 1.234,56.", "1234.56"), ("número", "1,234.5", "1234.5"), ("número", "42", "42"),
    ("sim ou não", "Sim, aparece.", "sim"), ("sim ou não", "Não.", "não"),
    ("JSON", 'Segue: {"nome": "Ana", "cpf": "123"}', '{"nome": "Ana", "cpf": "123"}'),
    ("texto", "  reclamação \n", "reclamação"),
])
def test_formatos_da_resposta(formato, resposta, esperado):
    assert ia.interpretar(resposta, formato) == esperado


def test_resposta_fora_do_formato_da_erro():
    with pytest.raises(ia.ErroIA, match="sim ou não"):
        ia.interpretar("talvez", "sim ou não")


# ------------------------------------------------------------------ visão
def test_localizar_converte_para_a_tela_original():
    tela = Image.new("RGB", (3136, 1764), "white")  # maior que o limite: vai reduzida pela metade
    falsa = IAFalsa({"encontrado": True, "x": 700, "y": 400, "o_que_achou": "botão Salvar"})
    assert ia.localizar("k", "botão Salvar", tela, chamar_fn=falsa) == (1400, 800, "botão Salvar")
    assert "1568x882" in falsa.pedidos[0]["texto"] and falsa.pedidos[0]["imagens"][0]["type"] == "image"
    assert ia.localizar("k", "x", tela, chamar_fn=IAFalsa({"encontrado": False})) is None
    assert ia.localizar("k", "x", tela, chamar_fn=IAFalsa({"encontrado": True, "x": 99999, "y": 1})) is None


def test_chave_salva_vale_mais_que_a_variavel_de_ambiente(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", " sk-antiga-da-variavel ")
    assert ia.chave_configurada(str(tmp_path), lambda g: "x") == "sk-antiga-da-variavel"  # nada salvo: usa a variável
    (tmp_path / "config_app.json").write_text(json.dumps({"ia": {"chave_protegida": "b64:xx", "modelo": "m"}}))
    assert ia.chave_configurada(str(tmp_path), lambda g: "sk-guardada") == "sk-guardada"  # salva ganha
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    assert ia.modelo_configurado(str(tmp_path)) == "m"
    with pytest.raises(ia.ErroIA, match="chave"):
        ia.chamar("", "oi")


def test_chamada_monta_o_pedido_da_api(monkeypatch):
    feito = {}

    class R:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def read(self):
            return json.dumps({"content": [{"type": "text", "text": "OK"}], "stop_reason": "end_turn"}).encode()

    def urlopen(req, timeout=None):
        feito["url"], feito["headers"], feito["corpo"] = req.full_url, dict(req.header_items()), json.loads(req.data)
        return R()
    monkeypatch.setattr(ia.urllib.request, "urlopen", urlopen)
    assert ia.chamar("sk-x", "Responda", sistema="S", modelo="claude-sonnet-5-5") == "OK"
    assert feito["url"] == ia.URL_API and feito["headers"]["X-api-key"] == "sk-x"
    c = feito["corpo"]
    assert c["model"] == "claude-sonnet-5-5" and c["system"] == "S" and "temperature" not in c


# ------------------------------------------------------------------ no motor
@pytest.fixture
def ia_no_motor(monkeypatch):
    monkeypatch.setattr(ia, "chave_configurada", lambda *a: "sk-teste")
    monkeypatch.setattr(ia, "modelo_configurado", lambda *a: ia.MODELO_PADRAO)


@precisa_tela
def test_motor_pergunta_e_usa_a_resposta(motor, monkeypatch, ia_no_motor):
    falsa = IAFalsa("Sim.")
    monkeypatch.setattr(ia, "chamar", falsa)
    passos = [{"tipo": "definir_variavel", "nome": "msg", "valor": "Quero cancelar, péssimo atendimento"},
              {"tipo": "ia_perguntar", "pergunta": "É reclamação? {msg}", "formato": "sim ou não",
               "variavel": "reclamacao"},
              {"tipo": "se_valor", "valor1": "{reclamacao}", "operador": "é igual a", "valor2": "sim"},
              {"tipo": "definir_variavel", "nome": "fila", "valor": "urgente"},
              {"tipo": "fim_se"}]
    cod, erro = motor.rodar(passos, cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["fila"] == "urgente" and "péssimo atendimento" in falsa.pedidos[0]["texto"]


@precisa_tela
def test_motor_ia_clicar(motor, monkeypatch, ia_no_motor):
    import pyautogui
    cliques = []
    for n in ("click", "moveTo", "mouseDown", "mouseUp"):
        monkeypatch.setattr(pyautogui, n, lambda *a, _n=n, **k: cliques.append((_n, a[:2])))
    monkeypatch.setattr(ia, "chamar", IAFalsa({"encontrado": True, "x": 120, "y": 80, "o_que_achou": "Salvar"}))
    monkeypatch.setattr(motor, "_imagem_ia", lambda origem, arquivo="": (Image.new("RGB", (800, 600)), (100, 50)))
    cod, erro = motor.rodar([{"tipo": "ia_clicar", "descricao_alvo": "botão Salvar"}], cfg=CFG)
    assert cod == 0, erro
    assert ("click", (220, 130)) in cliques  # posição na imagem + canto da janela


@precisa_tela
def test_motor_guarda_o_ultimo_erro_para_explicar(motor, monkeypatch, ia_no_motor):
    monkeypatch.setattr(motor, "_print_erro", lambda: None)
    passos = [{"tipo": "esperar", "segundos": 0}, {"tipo": "arq_renomear", "arquivo": "nao_existe.txt",
                                                    "novo_nome": "x.txt"}]
    cod, erro = motor.rodar(passos, cfg=dict(CFG, tentativas=0))
    assert cod == 1 and motor.ultimo_erro["passo"] == 1 and "nao_existe" in motor.ultimo_erro["log"]
    falsa = IAFalsa("O arquivo não existe: confira o caminho no passo 2.")
    txt = ia.explicar_erro("k", motor.ultimo_erro["erro"], "2. Renomear", motor.ultimo_erro["log"], chamar_fn=falsa)
    assert "passo 2" in txt and "nao_existe" in falsa.pedidos[0]["texto"]


def test_segundo_plano_recusa_ia_que_olha_a_tela(motor):
    cod, erro = motor.rodar([{"tipo": "ia_perguntar", "pergunta": "x", "incluir": "tela inteira"}],
                            cfg={"contagem": 0, "segundo_plano": True})
    assert cod == 1 and "TELA" in erro


@precisa_tela
def test_ocr_de_arquivo_de_imagem(motor, monkeypatch, tmp_path):
    import ocr_tela as ocr
    Image.new("RGB", (200, 60), "white").save(tmp_path / "nota.png")
    monkeypatch.setattr(ocr, "reconhecer", lambda img, idioma="pt-BR": [{"texto": "Total R$ 99,90", "palavras": []}])
    cod, erro = motor.rodar([{"tipo": "ler_tela", "regiao": "arquivo de imagem", "arquivo": "nota.png",
                              "regex": r"R\$ ([\d,]+)", "variavel": "total"}], cfg=CFG)
    assert cod == 0, erro
    assert motor.vars["total"] == "99,90"


def test_chave_colada_com_sujeira_e_formato():
    certa = "sk-ant-api03-" + "a1B2" * 20
    assert ia.limpar_chave(f'  "{certa}"\n') == certa
    assert ia.formato_chave(certa) is None
    assert "sk-ant-" in ia.formato_chave("minha-chave-123")
    assert "metade" in ia.formato_chave("sk-ant-api03-abc")
    assert "ADMINISTRAÇÃO" in ia.formato_chave("sk-ant-admin01-" + "x" * 80)


def test_chave_recusada_explica(monkeypatch):
    import io
    import urllib.error

    def urlopen(req, timeout=None):
        raise urllib.error.HTTPError(req.full_url, 401, "Unauthorized", {},
                                     io.BytesIO(b'{"error": {"message": "invalid x-api-key"}}'))
    monkeypatch.setattr(ia.urllib.request, "urlopen", urlopen)
    with pytest.raises(ia.ErroIA, match="não começa com 'sk-ant-'"):
        ia.chamar("chave-errada", "oi")
    with pytest.raises(ia.ErroIA, match="desativada"):
        ia.chamar("sk-ant-api03-" + "z" * 80, "oi")


# ------------------------------------------------------------------ APLICAR SOLUÇÃO
ROTEIRO = [{"tipo": "abrir_chrome", "url": "https://mail.google.com", "maximizar": True, "controle": True,
            "aguardar": True, "espera": 3.0},
           {"tipo": "se_pagina", "texto": "", "seletor": "div[gh=cm]", "espera": 15.0, "negar": True},
           {"tipo": "aguardar_usuario", "mensagem": "login", "continuar": "eu clicar em Continuar (ou F2)",
            "texto": "", "seletor": "", "timeout": 0.0, "se_acabar": "dar erro"},
           {"tipo": "fim_se"},
           {"tipo": "tecla", "teclas": "ctrl+enter", "repetir": 1, "janela": {"processo": "chrome.exe"}}]


def test_aplicar_alterar_inserir_e_remover():
    alts = [{"acao": "alterar", "passo": 1, "campos": {"aguardar": "false", "espera": "5", "inventado": 1}},
            {"acao": "inserir_depois", "passo": 1, "passos": [
                {"tipo": "aguardar_carregar", "metodo": "chrome", "seletor": "div[gh=cm]", "timeout": 90}]},
            {"acao": "remover", "passo": 5}]
    novos, descr, avisos, inicio = ia.aplicar_alteracoes(ROTEIRO, alts, cat, fx, executar_de=1)
    assert [p["tipo"] for p in novos] == ["abrir_chrome", "aguardar_carregar", "se_pagina", "aguardar_usuario",
                                          "fim_se"]
    assert novos[0]["aguardar"] is False and novos[0]["espera"] == 5.0 and novos[1]["timeout"] == 90.0
    assert any("removido" in d for d in descr) and any("inventado" in a for a in avisos)
    assert inicio == 0 and ROTEIRO[0]["aguardar"] is True  # o original não muda


def test_inserir_antes_e_executar_do_passo_certo():
    alts = [{"acao": "inserir_antes", "passo": 5, "passos": [{"tipo": "esperar", "segundos": 2}]}]
    novos, _, _, inicio = ia.aplicar_alteracoes(ROTEIRO, alts, cat, fx, executar_de=5)
    assert novos[4]["tipo"] == "esperar" and inicio == 4  # começa pelo passo inserido
    assert novos[5]["janela"] == {"processo": "chrome.exe"}  # o que a gravação guardou continua lá


def test_solucao_que_quebra_os_blocos_nao_e_aplicada():
    with pytest.raises(ia.ErroIA, match="quebraria"):
        ia.aplicar_alteracoes(ROTEIRO, [{"acao": "remover", "passo": 4}], cat, fx)


def test_solucao_nao_mexe_em_senha_nem_passo_inexistente():
    r = [{"tipo": "email_enviar", "via": "SMTP (Gmail, Office 365...)", "para": "a@x.com", "smtp_senha": "s3gredo"}]
    novos, descr, avisos, _ = ia.aplicar_alteracoes(r, [
        {"acao": "alterar", "passo": 1, "campos": {"smtp_senha": "outra", "assunto": "Oi"}},
        {"acao": "remover", "passo": 9}], cat, fx)
    assert novos[0]["smtp_senha"] == "s3gredo" and novos[0]["assunto"] == "Oi"
    assert any("senhas" in a for a in avisos) and any("9 não existe" in a for a in avisos)


def test_diagnosticar_manda_o_roteiro_numerado():
    falsa = IAFalsa({"explicacao": "**O Gmail** carrega imagens sem parar.", "alteracoes": [
        {"acao": "alterar", "passo": 1, "campos": {"aguardar": False}}], "executar_de": 1})
    r = ia.diagnosticar("k", "faltou: imagens", 0, ROTEIRO, "log...", cat, chamar_fn=falsa)
    assert r["explicacao"] == "O Gmail carrega imagens sem parar." and r["executar_de"] == 1
    enviado = falsa.pedidos[0]["texto"]
    assert "PASSO QUE FALHOU: 1" in enviado and '5. {"tipo": "tecla"' in enviado and "janela" not in enviado


@precisa_tela
def test_pagina_que_carrega_imagens_sem_parar_nao_trava(motor, monkeypatch):
    import motor_tela
    relogio = [1000.0]

    class Tempo:
        @staticmethod
        def time():
            return relogio[0]
    monkeypatch.setattr(motor_tela, "time", Tempo)
    monkeypatch.setattr(motor, "_esperar", lambda s: relogio.__setitem__(0, relogio[0] + max(s, 0.25)))
    monkeypatch.setattr(motor, "_js", lambda expr: {"rs": "complete", "imgs": False, "fontes": True,
                                                    "url": "https://mail.google.com/", "res": int(relogio[0] * 7)})
    motor._aguardar_chrome("", 1.5, relogio[0] + 60)
    assert relogio[0] - 1000 < 15  # seguiu em ~10 s, não esperou os 60
    assert "imagens ainda chegando" in motor.ui.texto()
