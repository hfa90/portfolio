# -*- coding: utf-8 -*-
"""Nome antigo de janelas.py (até a versão 1.8). Mantido para que códigos antigos continuem funcionando."""
import sys

import janelas

sys.modules[__name__] = janelas
