# -*- coding: utf-8 -*-
"""Passos de dados: Excel e leitura da página do Chrome.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
try:
    from motor_util import (expandir, jc, json, nav, os, time, xlm)
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    pass


class DadosMixin:

    # ------------------------------------------------------------ Excel e leitura da página
    def _valores(self):
        """Variáveis disponíveis nos textos: colunas da planilha + valores lidos ({numero_chamado}...)."""
        return {**self.linha, **self.vars}

    def _x(self, texto):
        return expandir(str(texto or ""), self._valores())

    def _planilha(self):
        if not (self.xl and self.xl.aberto):
            raise RuntimeError("nenhuma planilha aberta: coloque antes o passo 'Excel: abrir planilha'")
        return self.xl

    def _passo_dados(self, s, cfg):
        t = s["tipo"]
        if t == "ler_pagina":
            nome = (s.get("variavel") or "valor").strip().strip("{}")
            seletor, regex = self._x(s.get("seletor")).strip(), s.get("regex") or ""
            como = {"valor do campo": "valor", "html": "html"}.get(s.get("como"), "texto")
            expr = (r"""((sel, como, rx) => { const el = sel ? document.querySelector(sel) : document.body;
              if (!el) return JSON.stringify({ok: false});
              let v = como === 'valor' ? (el.value ?? '') : como === 'html' ? el.innerHTML
                                       : (el.innerText || el.textContent || '');
              v = String(v).trim();
              if (rx) { const m = new RegExp(rx).exec(v); if (!m) return JSON.stringify({ok: false});
                        v = m[1] !== undefined ? m[1] : m[0]; }
              return JSON.stringify({ok: v !== '', v: v}); })""" +
                    f"({json.dumps(seletor)}, {json.dumps(como)}, {json.dumps(regex)})")
            if not self._bg and not nav.cdp_disponivel():
                raise RuntimeError("'Ler da página' precisa do Chrome controlado (passo 'Abrir Chrome' com modo "
                                   "controlado)")
            limite = time.time() + float(s.get("timeout", 10))
            while True:
                try:
                    r = self._js(expr) or {}
                except Exception:
                    r = {}
                if r.get("ok"):
                    self.vars[nome] = r["v"]
                    self.log(f"Lido da página: {{{nome}}} = {r['v'][:80]!r}", "ok")
                    return
                if time.time() >= limite:
                    raise TimeoutError(f"não encontrei {'o elemento ' + seletor if seletor else 'o texto'}"
                                       f"{' com o padrão ' + regex if regex else ''} na página")
                self._esperar(0.4)
        if t == "excel_abrir":
            self._fechar_excel(aviso=False)
            arquivo = self.caminho(self._x(s.get("arquivo")))
            visivel = s.get("visivel") if cfg.get("excel_visivel") is None else cfg["excel_visivel"]
            self.xl = xlm.Excel(self.log).abrir(arquivo, self._x(s.get("aba")) or None, visivel=bool(visivel),
                                               somente_leitura=bool(s.get("somente_leitura")))
            if visivel and self.xl.modo == "excel":
                try:  # mostra o Excel maximizado e na frente para você acompanhar
                    self.xl.app.WindowState = -4137  # xlMaximized
                    if jc.WIN:
                        jc.garantir_maximizado(int(self.xl.app.Hwnd), frente=True)
                except Exception:
                    pass
            self.log(f"Planilha aberta ({'Excel' if self.xl.modo == 'excel' else 'openpyxl'}"
                     f"{', visível' if visivel else ', invisível'}): {os.path.basename(arquivo)}")
        elif t == "excel_ler":
            v = self._planilha().ler(self._x(s.get("celula")))
            if isinstance(v, list):
                v = "\n".join("\t".join("" if c is None else str(c) for c in linha) for linha in v)
            elif isinstance(v, float) and v.is_integer():
                v = int(v)
            nome = (s.get("variavel") or "valor").strip().strip("{}")
            self.vars[nome] = "" if v is None else str(v)
            self.log(f"Lido do Excel: {{{nome}}} = {self.vars[nome][:80]!r}")
        elif t == "excel_escrever":
            idioma = s.get("idioma") or ("automático" if s.get("formula_pt", True) else "inglês")  # roteiros antigos
            lingua = self._planilha().escrever(self._x(s.get("celula")), self._x(s.get("valor")), idioma=idioma)
            if lingua in ("pt", "en") and idioma == "automático":
                self.log(f"Fórmula em {'português' if lingua == 'pt' else 'inglês'} (detectado).")
        elif t == "excel_ultima_linha":
            n = self._planilha().ultima_linha((s.get("coluna") or "A").strip(), self._x(s.get("aba")) or None)
            nome = (s.get("variavel") or "ultima_linha").strip().strip("{}")
            self.vars[nome] = str(n)
            self.vars["proxima_linha"] = str(n + 1)
            self.log(f"Última linha preenchida: {n}  →  {{{nome}}} = {n}, {{proxima_linha}} = {n + 1}")
        elif t == "excel_grafico":
            onde = self._planilha().criar_grafico(self._x(s.get("dados")).strip(), self._x(s.get("destino")),
                                                  s.get("tipo_grafico") or "colunas", self._x(s.get("titulo")),
                                                  self._x(s.get("nome")) or "Grafico1",
                                                  int(float(s.get("largura") or 480)), int(float(s.get("altura") or 290)))
            self.log(f"Gráfico '{s.get('nome')}' criado em {onde}.", "ok")
        elif t == "excel_dinamica":
            def lista(campo):
                return [c.strip() for c in self._x(s.get(campo)).split(";") if c.strip()]
            onde = self._planilha().criar_dinamica(self._x(s.get("origem")), self._x(s.get("destino")),
                                                   self._x(s.get("nome")) or "TabelaDinamica1", lista("linhas"),
                                                   lista("colunas"), lista("valores"), lista("filtros"),
                                                   s.get("funcao") or "soma")
            self.log(f"Tabela dinâmica '{s.get('nome')}' criada com os dados atuais em {onde}.", "ok")
        elif t == "excel_copiar":
            self._planilha().copiar(self._x(s.get("origem")), self._x(s.get("destino")),
                                    bool(s.get("so_valores", True)))
        elif t == "excel_macro":
            args = [self._x(a).strip() for a in str(s.get("argumentos") or "").split(";") if a.strip()]
            r = self._planilha().macro(self._x(s.get("macro")).strip(), args)
            if r is not None and s.get("variavel"):
                self.vars[s["variavel"].strip().strip("{}")] = str(r)
            self.log(f"Macro executada: {s.get('macro')}")
        elif t == "excel_atualizar":
            if "recalcular" in str(s.get("acao", "")):
                self._planilha().recalcular()
            else:
                self._planilha().atualizar_tudo()
        elif t == "excel_salvar":
            arquivo = self._x(s.get("arquivo")).strip()
            formato = s.get("formato") or "mesmo"
            destino = self._planilha().salvar(self.caminho(arquivo) if arquivo else None,
                                              None if formato == "mesmo" else formato, self._x(s.get("aba")) or None)
            self.log(f"Salvo: {destino}", "ok")
            if s.get("fechar"):
                self.xl.fechar(salvar=False)
                self.xl = None
        elif t == "excel_fechar":
            if self.xl and self.xl.aberto:
                self.xl.fechar(salvar=bool(s.get("salvar")))
            self.xl = None
