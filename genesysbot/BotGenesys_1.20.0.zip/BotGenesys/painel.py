# -*- coding: utf-8 -*-
"""
Legendas do bot na tela (sempre visíveis, sem roubar o foco de quem está usando o computador).

- Modo "frente" (o bot usa o mouse de verdade): painel no canto superior direito. Dá para ARRASTAR (a posição fica
  guardada); se o bot for clicar debaixo dele, o painel sai da frente sozinho antes.
- Modo "fundo" (segundo plano): cartão no canto inferior direito com Pausar / Parar.
- Ao terminar: cartão verde (concluído), vermelho (erro) ou cinza (interrompido), com "Ver log".
"""
import ctypes
import sys
import time
import tkinter as tk

WIN = sys.platform == "win32"
FUNDO, BORDA, TEXTO, APAGADO = "#16181d", "#2f333b", "#f0f0f0", "#9aa4b2"
CORES = {"rodando": "#4dabf7", "gravando": "#ff6b6b", "pausado": "#ffb300", "ok": "#40c057",
         "aviso": "#fab005", "erro": "#fa5252", "parado": "#adb5bd"}


def _estilo_janela(win, atravessar_cliques):
    """Janela que não rouba o foco (e, se pedido, que os cliques atravessam)."""
    if not WIN:
        return
    try:
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        estilo = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
        estilo |= 0x80000 | 0x80 | 0x08000000  # layered + ferramenta + não ativa
        if atravessar_cliques:
            estilo |= 0x20
        ctypes.windll.user32.SetWindowLongW(hwnd, -20, estilo)
    except Exception:
        pass


def tornar_click_through(win):
    _estilo_janela(win, True)


def area_trabalho(root):
    """(esquerda, topo, direita, baixo) da área de trabalho principal (sem a barra de tarefas)."""
    if WIN:
        try:
            from ctypes import wintypes
            r = wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA
            return r.left, r.top, r.right, r.bottom
        except Exception:
            pass
    return 0, 0, root.winfo_screenwidth(), root.winfo_screenheight() - 40


def arrastavel(win, ao_soltar=None):
    """Deixa uma janela sem borda ser arrastada pelo mouse (em qualquer parte que não seja botão)."""
    estado = {}

    def apertou(e):
        if str(e.widget.cget("cursor") if hasattr(e.widget, "cget") else "") == "hand2":
            return  # botão: não arrasta
        estado["d"] = (e.x_root - win.winfo_x(), e.y_root - win.winfo_y())
        estado["moveu"] = False

    def moveu(e):
        if "d" not in estado:
            return
        dx, dy = estado["d"]
        estado["pos"] = (e.x_root - dx, e.y_root - dy)
        win.geometry(f"+{estado['pos'][0]}+{estado['pos'][1]}")
        estado["moveu"] = True

    def soltou(e):
        if estado.pop("d", None) is not None and estado.get("moveu") and ao_soltar:
            win.update_idletasks()
            ao_soltar(*estado["pos"])

    def ligar(w):
        try:
            if str(w.cget("cursor")) != "hand2":
                w.configure(cursor="fleur")
        except tk.TclError:
            pass
        w.bind("<ButtonPress-1>", apertou, add="+")
        w.bind("<B1-Motion>", moveu, add="+")
        w.bind("<ButtonRelease-1>", soltou, add="+")
        for f in w.winfo_children():
            ligar(f)
    ligar(win)


def posicao_valida(root, x, y, w, h):
    """A posição guardada ainda cabe na tela (o monitor pode ter mudado)?"""
    try:
        sw, sh = root.winfo_vrootwidth() or root.winfo_screenwidth(), root.winfo_vrootheight() or root.winfo_screenheight()
        vx, vy = root.winfo_vrootx(), root.winfo_vrooty()
    except tk.TclError:
        return False
    return vx - w // 2 <= x <= vx + sw - w // 2 and vy <= y <= vy + sh - 30


def _duracao(seg):
    seg = int(seg)
    return f"{seg // 60}min {seg % 60:02d}s" if seg >= 60 else f"{seg}s"


class Painel:
    def __init__(self, root):
        self.root = root
        self.win = None
        self.card_final = None
        self.modo = "frente"
        self.inicio = time.time()
        self.estado = "rodando"
        self._pisca = True
        self.posicoes = {}      # onde a pessoa deixou cada caixinha ({'frente': [x, y], ...}); o app guarda
        self.ao_mover = None    # chamado quando a pessoa arrasta (o app salva a configuração)
        self._ret = None        # (x1, y1, x2, y2) do painel na tela, lido também pela linha do motor

    # ------------------------------------------------------------ posição
    def _lembrar(self, chave):
        def soltar(x, y):
            self.posicoes[chave] = [int(x), int(y)]
            if chave in ("frente", "fundo"):
                self._atualizar_ret(int(x), int(y))
            if self.ao_mover:
                self.ao_mover()
        return soltar

    def _posicionar(self, win, chave, x_padrao, y_padrao):
        win.update_idletasks()
        p = self.posicoes.get(chave)
        if p and posicao_valida(self.root, p[0], p[1], win.winfo_reqwidth(), win.winfo_reqheight()):
            x, y = int(p[0]), int(p[1])
        else:
            x, y = int(x_padrao), int(y_padrao)
        win.geometry(f"+{x}+{y}")
        return x, y

    def _atualizar_ret(self, x=None, y=None):
        try:
            w = self.win
            if w:
                w.update_idletasks()
                x = w.winfo_x() if x is None else x
                y = w.winfo_y() if y is None else y
                self._ret = (x, y, x + w.winfo_reqwidth(), y + w.winfo_reqheight())
            else:
                self._ret = None
        except tk.TclError:
            self._ret = None

    def contem(self, x, y, margem=24):
        """O ponto (x, y) da tela está debaixo do painel? (pode ser chamado de outra linha de execução)"""
        r = self._ret
        return bool(r) and r[0] - margem <= x <= r[2] + margem and r[1] - margem <= y <= r[3] + margem

    def desviar(self, x, y):
        """O bot vai clicar em (x, y), debaixo do painel: leva o painel para o outro lado da tela."""
        if not self.win or not self.contem(x, y):
            return
        l, t, r, b = area_trabalho(self.root)
        w, h = self.win.winfo_width(), self.win.winfo_height()
        nx = l + 16 if x > (l + r) // 2 else r - w - 16
        ny = self.win.winfo_y()
        if ny <= y <= ny + h and nx <= x <= nx + w:  # ainda em cima (tela estreita): sobe/desce
            ny = b - h - 16 if y < (t + b) // 2 else t + 16
        self.win.geometry(f"+{nx}+{ny}")
        self._atualizar_ret(nx, ny)

    # ------------------------------------------------------------ execução
    def mostrar(self, modo="frente", titulo="BOT GENESYS", dica="ESC = parar     F2 = pausar",
                ao_pausar=None, ao_parar=None, estado="rodando"):
        self.esconder()
        self._fechar_final()
        self.modo, self.inicio, self.estado = modo, time.time(), estado
        self.titulo_base = titulo
        cor = CORES[estado]
        o = tk.Toplevel(self.root)
        o.overrideredirect(True)
        o.attributes("-topmost", True)
        o.attributes("-alpha", 0.94)
        o.configure(bg=FUNDO, highlightthickness=1, highlightbackground=BORDA)
        self.faixa = tk.Frame(o, bg=cor, height=4)
        self.faixa.pack(fill="x")
        topo = tk.Frame(o, bg=FUNDO)
        topo.pack(fill="x", padx=14, pady=(8, 0))
        self.lbl_tit = tk.Label(topo, text=f"●  {titulo}", fg=cor, bg=FUNDO, font=("Segoe UI", 9, "bold"), anchor="w")
        self.lbl_tit.pack(side="left")
        self.lbl_tempo = tk.Label(topo, text="", fg=APAGADO, bg=FUNDO, font=("Segoe UI", 8))
        self.lbl_tempo.pack(side="right")
        self.lbl = tk.Label(o, text="Preparando...", fg=TEXTO, bg=FUNDO, font=("Segoe UI", 10, "bold"),
                            anchor="w", justify="left", padx=14, wraplength=360)
        self.lbl.pack(fill="x", pady=(2, 6))
        self.barra = tk.Canvas(o, height=6, width=352, bg="#2a2e36", highlightthickness=0)
        self.barra.pack(padx=14)
        self.cheio = self.barra.create_rectangle(0, 0, 0, 6, fill=cor, width=0)
        base = tk.Frame(o, bg=FUNDO)
        base.pack(fill="x", padx=14, pady=(6, 10))
        tk.Label(base, text=dica, fg=APAGADO, bg=FUNDO, font=("Segoe UI", 8)).pack(side="left")
        self.bt_pausa = None
        if modo == "fundo":
            if ao_parar:
                self._botao(base, "■ Parar", ao_parar, "#fa5252").pack(side="right")
            if ao_pausar:
                self.bt_pausa = self._botao(base, "❚❚ Pausar", ao_pausar, "#ffb300")
                self.bt_pausa.pack(side="right", padx=(0, 10))
        o.update_idletasks()
        l, t, r, b = area_trabalho(self.root)
        if modo == "fundo":
            pos = self._posicionar(o, "fundo", r - o.winfo_reqwidth() - 16, b - o.winfo_reqheight() - 16)
        else:
            pos = self._posicionar(o, "frente", r - o.winfo_reqwidth() - 20, t + 16)
        _estilo_janela(o, atravessar_cliques=False)  # dá para arrastar; o bot desvia dele antes de clicar
        arrastavel(o, self._lembrar(modo))
        self.win = o
        self._atualizar_ret(*pos)
        self._tique()

    def _botao(self, pai, texto, acao, cor):
        b = tk.Label(pai, text=texto, fg=cor, bg=FUNDO, font=("Segoe UI", 9, "bold"), cursor="hand2", padx=4)
        b.bind("<Button-1>", lambda e: acao())
        b.bind("<Enter>", lambda e: b.config(bg="#262a33"))
        b.bind("<Leave>", lambda e: b.config(bg=FUNDO))
        return b

    def _tique(self):
        if not self.win:
            return
        self._pisca = not self._pisca
        cor = CORES[self.estado]
        simbolo = "●" if (self._pisca or self.estado != "rodando") else "○"
        self.lbl_tit.config(text=f"{simbolo}  {self.titulo_base if self.estado != 'pausado' else 'PAUSADO'}", fg=cor)
        self.lbl_tempo.config(text=_duracao(time.time() - self.inicio))
        self.win.after(600, self._tique)

    def texto(self, t, cor=None):
        if self.win:
            self.lbl.config(text=t, fg=cor or TEXTO)

    def progresso(self, frac):
        if self.win:
            frac = max(0.0, min(1.0, frac))
            self.barra.coords(self.cheio, 0, 0, int(352 * frac), 6)

    def pausado(self, sim):
        self.estado = "pausado" if sim else "rodando"
        if self.win:
            cor = CORES[self.estado]
            self.faixa.config(bg=cor)
            self.barra.itemconfig(self.cheio, fill=cor)
            if self.bt_pausa:
                self.bt_pausa.config(text="▶ Continuar" if sim else "❚❚ Pausar")

    def esconder(self):
        self._ret = None
        if self.win:
            try:
                self.win.destroy()
            except tk.TclError:
                pass
            self.win = None

    # ------------------------------------------------------------ resultado final
    def final(self, resultado, msg, ao_ver_log=None, fechar_em=None):
        """resultado: 'ok' | 'aviso' | 'erro' | 'parado'. Mostra um cartão no canto inferior direito."""
        duracao = time.time() - self.inicio
        self.esconder()
        self._fechar_final()
        cor = CORES[resultado]
        titulo = {"ok": "✓  CONCLUÍDO COM SUCESSO", "aviso": "⚠  CONCLUÍDO COM AVISOS", "erro": "✗  ERRO NA EXECUÇÃO",
                  "parado": "■  EXECUÇÃO INTERROMPIDA"}[resultado]
        c = tk.Toplevel(self.root)
        c.overrideredirect(True)
        c.attributes("-topmost", True)
        c.attributes("-alpha", 0.96)
        c.configure(bg=FUNDO, highlightthickness=1, highlightbackground=cor)
        tk.Frame(c, bg=cor, height=4).pack(fill="x")
        tk.Label(c, text=titulo, fg=cor, bg=FUNDO, font=("Segoe UI", 10, "bold"), anchor="w", padx=14).pack(
            fill="x", pady=(10, 2))
        tk.Label(c, text=msg, fg=TEXTO, bg=FUNDO, font=("Segoe UI", 9), anchor="w", justify="left", padx=14,
                 wraplength=360).pack(fill="x")
        base = tk.Frame(c, bg=FUNDO)
        base.pack(fill="x", padx=14, pady=(8, 10))
        tk.Label(base, text=f"duração: {_duracao(duracao)}  ·  {time.strftime('%H:%M')}", fg=APAGADO, bg=FUNDO,
                 font=("Segoe UI", 8)).pack(side="left")
        self._botao(base, "Fechar", self._fechar_final, APAGADO).pack(side="right")
        if ao_ver_log:
            self._botao(base, "Ver log", ao_ver_log, "#4dabf7").pack(side="right", padx=(0, 10))
        c.update_idletasks()
        l, t, r, b = area_trabalho(self.root)
        c.geometry(f"{max(380, c.winfo_reqwidth())}x{c.winfo_reqheight()}")
        self._posicionar(c, "final", r - max(380, c.winfo_reqwidth()) - 16, b - c.winfo_reqheight() - 16)
        _estilo_janela(c, atravessar_cliques=False)
        arrastavel(c, self._lembrar("final"))
        self.card_final = c
        if fechar_em is None:
            fechar_em = {"ok": 20000, "parado": 12000}.get(resultado)  # erro e aviso ficam até fechar
        if fechar_em:
            c.after(fechar_em, self._fechar_final)

    def _fechar_final(self):
        if self.card_final:
            try:
                self.card_final.destroy()
            except tk.TclError:
                pass
            self.card_final = None

    # ------------------------------------------------------------ marcações (modo frente)
    def marcador(self, x, y, w=0, h=0, cor="#ff1744", ms=700):
        """Círculo onde o bot vai clicar, ou retângulo em volta da imagem encontrada."""
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        chave = "#ff00ff"
        if w and h:
            pad = 4
            win.geometry(f"{w + 2 * pad}x{h + 2 * pad}+{max(0, x - pad)}+{max(0, y - pad)}")
            cv = tk.Canvas(win, width=w + 2 * pad, height=h + 2 * pad, bg=chave, highlightthickness=0)
            cv.create_rectangle(2, 2, w + 2 * pad - 2, h + 2 * pad - 2, outline=cor, width=3)
        else:
            r = 24
            win.geometry(f"{2 * r}x{2 * r}+{max(0, x - r)}+{max(0, y - r)}")
            cv = tk.Canvas(win, width=2 * r, height=2 * r, bg=chave, highlightthickness=0)
            cv.create_oval(3, 3, 2 * r - 3, 2 * r - 3, outline=cor, width=4)
            cv.create_oval(r - 3, r - 3, r + 3, r + 3, fill=cor, outline=cor)
        cv.pack()
        if WIN:
            win.attributes("-transparentcolor", chave)
        else:
            win.attributes("-alpha", 0.6)
        tornar_click_through(win)
        win.after(ms, win.destroy)
