# -*- coding: utf-8 -*-
"""
Motor de execução do Bot Genesys (usado pelo app, pelos agendamentos e pelos arquivos .py exportados).

Dois modos:
  - frente (padrão): usa o mouse e o teclado de verdade, com a posição exata gravada
    (corrigida pelo elemento da página ou pela imagem quando possível);
  - segundo plano: cliques, teclas e texto vão direto para a página do Chrome controlado,
    e você continua usando o computador normalmente.
"""
import collections

try:
    from motor_util import (ALIASES, Achado, BTN_MAP, CFG_PADRAO, HAS_CV, Image, ImageChops, ImageGrab,
                            ImageNotFound, KB, NAVEGADORES, PRECISA_TELA, Parado, RETENTAVEIS, TIPOS, UiBase,
                            WIN, _BLOB, _dpapi, abrir_texto, base64, cat, ctypes, cursor_ocupado, cv2,
                            datetime, deslocamento_vertical, expandir, jc, json, melhor_correspondencia, nav,
                            np, os, outro_programa, parse_teclas, pixels_rolagem, proteger_texto, pyautogui,
                            resumo, sys, threading, time, xlm)
    from motor_dados import DadosMixin
    from motor_tela import TelaMixin
    from motor_fundo import FundoMixin
    from motor_arquivos import ArquivosMixin
    from motor_mensagens import MensagensMixin
    from motor_ia import IAMixin
    from motor_vigias import VigiasMixin
    from motor_fluxo import FluxoMixin
    import fluxo as fx
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    pass

# --------------------------------------------------------------------------- #
# Motor
# --------------------------------------------------------------------------- #
class Motor(DadosMixin, TelaMixin, FundoMixin, ArquivosMixin, MensagensMixin, IAMixin, VigiasMixin, FluxoMixin):
    def __init__(self, ui=None, base=None, perfil_chrome=None, log_dir=None):
        self.ui = ui or UiBase()
        self.base = base or os.getcwd()
        self.perfil = perfil_chrome
        self.log_dir = log_dir or os.path.join(self.base, "logs")
        self.stop_event = threading.Event()
        self.pausado = False
        self.sending = False  # o próprio bot está apertando teclas (para os atalhos globais ignorarem)
        self.linha = {}
        self.nav = None
        self._hwnd_chrome = None
        self._aviso_sem_chrome = False
        self._janelas_avisadas = set()
        self._vigias = []  # regras 'Vigiar pop-up' desta execução
        self._bg = False
        self.vars = {}   # valores lidos durante a execução ({numero_chamado}, {total}...)
        self.xl = None   # planilha aberta pelos passos de Excel
        self.avisos = 0  # avisos durante a execução (ex.: elemento não encontrado, usou a posição gravada)
        self.log_recente = collections.deque(maxlen=120)  # para 'Explicar o erro com IA'
        self.ultimo_erro = None  # {"erro", "passo", "print", "log"} da última execução que falhou
        self._passo_atual = None

    def log(self, msg, tag=None):
        self.log_recente.append(f"{datetime.datetime.now():%H:%M:%S} {msg}")
        if tag == "erro" and not msg.startswith(("ERRO", "Execução interrompida", "Parada de emergência",
                                                 "Print no momento")):
            self.avisos += 1
        self.ui.log(msg, tag)

    def _detalhe_tecnico(self, titulo, exc):
        """Manda o caminho técnico do erro (onde no código, causa original) para o log — nunca atrapalha."""
        try:
            import traceback
            fn = getattr(self.ui, "detalhe", None)
            if fn:
                fn(titulo, "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        except Exception:
            pass

    def _conferir_arquivos(self, itens):
        """Imagens de 'Clicar/Esperar imagem' e 'Se: imagem' que não existem no disco (fora de um bloco Tentar,
        que já trata a falha). Devolve a lista de problemas, vazia se está tudo no lugar."""
        try:
            est = fx.estrutura([s["tipo"] for _, s in itens], [i + 1 for i, _ in itens])
        except Exception:
            return []
        faltam = []
        for k, (i, s) in enumerate(itens):
            if s["tipo"] not in ("clicar_imagem", "esperar_imagem", "se_imagem") or est[k].get("tentar") is not None:
                continue
            img = str(s.get("imagem") or "")
            if "{" in img:
                continue  # nome montado durante a execução
            if not img or not os.path.exists(self.caminho(img)):
                faltam.append(f"o passo {i + 1} ({TIPOS[s['tipo']]}) usa a imagem '{img or '(vazia)'}', que não existe")
        return faltam

    def caminho(self, p):
        if not p:
            return p
        return p if os.path.isabs(p) else os.path.join(self.base, p)

    def parar(self):
        self.stop_event.set()
        self.pausado = False

    def _esperar(self, seg):
        vigiar = getattr(self, "_vigias", None) or (self.nav is not None and getattr(self.nav, "dialogos", None))
        if not vigiar or getattr(self, "_vigiando", False):
            if self.stop_event.wait(max(0.0, seg)):
                raise Parado()
            return
        fim = time.time() + max(0.0, seg)  # esperas longas: confere os pop-ups enquanto espera
        while True:
            if self.stop_event.wait(max(0.0, min(fim - time.time(), 0.5))):
                raise Parado()
            self._checar_vigias()
            if time.time() >= fim:
                return

    # ------------------------------------------------------------ laço principal
    def rodar(self, passos, itens=None, cfg=None, dados=None):
        """Executa. Devolve (código, erro): 0 = ok, 1 = erro, 2 = interrompido."""
        cfg = dict(CFG_PADRAO, **(cfg or {}))
        self._bg = bool(cfg["segundo_plano"])
        self.stop_event.clear()
        self.pausado = False
        self.avisos = 0
        self._hwnd_chrome = None
        self._aviso_sem_chrome = False
        itens = list(enumerate(passos)) if itens is None else itens
        itens = [(i, s) for i, s in itens if s.get("ativo", True)]
        novos = sorted({s.get("tipo", "?") for _, s in itens if s.get("tipo") not in TIPOS})
        if novos:  # roteiro feito numa versão mais nova do que a que está rodando
            msg = (f"este roteiro usa passo(s) que esta versão não conhece: {', '.join(novos)}. "
                   f"Feche e abra o Bot Genesys de novo (ou atualize os arquivos) e rode outra vez.")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        fora = [i for i, s in itens if s["tipo"] in PRECISA_TELA and outro_programa(s)]
        if self._bg and fora:
            prog = {outro_programa(passos[i]) for i in fora}
            msg = (f"o passo {fora[0] + 1} é no programa {', '.join(sorted(prog))}: o modo segundo plano só "
                   f"funciona no Chrome. Desligue 'Rodar em segundo plano' para este roteiro.")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        try:  # blocos Se/Repetir/Tentar fechados na ordem certa (confere ANTES de começar)
            fx.estrutura([s["tipo"] for _, s in itens], [i + 1 for i, _ in itens])
        except fx.ErroEstrutura as e:
            msg = f"estrutura do roteiro: {e}"
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        ocr = [i for i, s in itens if (s["tipo"] in ("clicar_texto", "se_texto_tela", "ia_clicar")
                                       or (s["tipo"] == "ler_tela" and not str(s.get("regiao", "")).startswith("arquivo"))
                                       or (s["tipo"] == "ia_perguntar"
                                           and str(s.get("incluir", "")).startswith(("tela", "janela"))))]
        if self._bg and ocr:
            msg = (f"o passo {ocr[0] + 1} olha a TELA (OCR/IA): o modo segundo plano não olha a tela. "
                   f"Desligue 'Rodar em segundo plano' para este roteiro.")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        arrastos = [i for i, s in itens if s["tipo"] == "arrastar"]
        if self._bg and arrastos:
            msg = (f"o passo {arrastos[0] + 1} (Arrastar) usa o mouse de verdade: o modo segundo plano não arrasta. "
                   f"Desligue 'Rodar em segundo plano' para este roteiro.")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        faltam = self._conferir_arquivos(itens)  # imagem que não existe: avisa ANTES de começar, não no passo 40
        if faltam:
            msg = "antes de começar: " + "; ".join(faltam[:5]) + (f" (e mais {len(faltam) - 5})" if len(faltam) > 5 else "")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        usa_tela = not self._bg and any(s["tipo"] in PRECISA_TELA for _, s in itens)
        if usa_tela and jc.tela_bloqueada() is True:
            msg = ("a tela do Windows está bloqueada (ou há um pedido de senha/administrador na frente): o mouse e o "
                   "teclado do bot não alcançam os programas. Desbloqueie o computador e rode de novo — ou use "
                   "'Rodar em segundo plano' quando o roteiro for só no Chrome.")
            self.log("ERRO: " + msg, "erro")
            return 1, msg
        self._janelas_avisadas = set()
        self._vigias = []  # regras 'Vigiar pop-up' desta execução
        linhas = dados if (dados and not cfg["so_um"]) else None
        registro = None
        if linhas and cfg.get("pular_ok"):
            col = cfg.get("coluna_status") or "Status"
            feitas = [l for l in linhas if str(l.get(col, "")).strip().upper().startswith("OK")]
            if feitas:
                linhas = [l for l in linhas if l not in feitas]
                self.log(f"{len(feitas)} linha(s) da planilha já estavam com '{col}' = OK e foram puladas.")
            if not linhas:
                self.log("Nada a fazer: todas as linhas da planilha já estão OK.", "ok")
                return 0, None
        if linhas and cfg.get("escrever_resultado") and cfg.get("planilha_arquivo"):
            registro = xlm.Registro(cfg["planilha_arquivo"], cfg.get("planilha_aba"), cfg.get("coluna_status"),
                                    self.log)
        rodadas = linhas if linhas else [{}] * int(cfg["rep"])
        total = len(rodadas)
        erros_linhas = 0
        total_passos, feitos = max(1, len(itens) * total), 0
        codigo, erro = 0, None
        inicio = time.time()
        try:
            jc.manter_acordado(True)  # o Windows não suspende nem apaga a tela no meio do roteiro
            if not self._bg:
                for n in range(int(cfg["contagem"]), 0, -1):
                    self.ui.status(f"Iniciando em {n}...\nDeixe o mouse e o teclado livres.")
                    self._esperar(1)
            else:
                self.ui.status("Preparando a execução em segundo plano...")
            modo = "em segundo plano" if self._bg else "na tela"
            self.log(f"=== Execução iniciada {modo} ({len(itens)} passos x {total}) ===", "ok")
            usa_chrome = any((s["tipo"] in PRECISA_TELA and not outro_programa(s)) or
                             s["tipo"] in ("abrir_chrome", "aguardar_carregar", "ler_pagina") for _, s in itens)
            tela = [s for _, s in itens if s["tipo"] in PRECISA_TELA or s["tipo"] == "abrir_chrome"]
            if self._bg and usa_chrome:
                self._preparar_fundo(itens)
            elif not self._bg and tela and tela[0]["tipo"] != "abrir_chrome":
                self._garantir_tela(tela[0], cfg)
            for r_i, linha in enumerate(rodadas):
                self.linha = dict(linha, linha_planilha=linha.get("_linha", ""))
                self.vars = {}
                rot = f"  |  {'chamado' if linhas else 'repetição'} {r_i + 1}/{total}" if total > 1 else ""
                if linhas:
                    vis = [str(v) for k, v in linha.items() if not k.startswith("_")][:3]
                    self.log(f"--- Chamado {r_i + 1}/{total} (linha {linha.get('_linha', '?')}): "
                             f"{' | '.join(vis)[:80]} ---")
                parar_tudo = None
                try:
                    try:
                        feitos = self._rodar_passos(passos, itens, cfg, rot, feitos, total_passos)
                    except fx.PararRoteiro as p:
                        if not p.sucesso:
                            raise RuntimeError(f"parado pelo roteiro: {p}") from None
                        parar_tudo = str(p)
                except (Parado, pyautogui.FailSafeException):
                    if registro and linhas:
                        registro.registrar(linha.get("_linha"), "Interrompido " + self._agora(), self.vars)
                    raise
                except Exception as e:
                    if registro and linhas:
                        registro.registrar(linha.get("_linha"), f"Erro {self._agora()}: {e}"[:250], self.vars)
                    if linhas and cfg.get("continuar_erro") and r_i + 1 < total:
                        erros_linhas += 1
                        self.log(f"ERRO no chamado {r_i + 1} (linha {linha.get('_linha')}): {e}", "erro")
                        self._detalhe_tecnico(f"erro no chamado {r_i + 1}", e)
                        self._print_erro()
                        self.log("Seguindo para o próximo chamado...")
                        self._fechar_excel(aviso=False)
                        self._esperar(1.0)
                        continue
                    raise
                if registro and linhas:
                    registro.registrar(linha.get("_linha"), "OK " + self._agora(), self.vars)
                if parar_tudo is not None:
                    if r_i + 1 < total:
                        self.log(f"'Parar o roteiro' ({parar_tudo}): os {total - r_i - 1} restante(s) não serão feitos.")
                    break
            if erros_linhas:
                raise RuntimeError(f"{erros_linhas} de {total} chamado(s) deram erro — veja a coluna "
                                   f"'{cfg.get('coluna_status') or 'Status'}' na planilha e o log")
            self.ui.progresso(1, 1, "Concluído")
            self.log(f"=== Execução concluída com sucesso ({int(time.time() - inicio)} s) ===", "ok")
        except Parado:
            codigo = 2
            self.log("Execução interrompida pelo usuário.", "erro")
        except pyautogui.FailSafeException:
            codigo = 2
            self.log("Parada de emergência: mouse no canto superior esquerdo.", "erro")
        except Exception as e:
            codigo, erro = 1, str(e)
            if usa_tela and jc.tela_bloqueada() is True:
                erro += " — ATENÇÃO: a tela do Windows estava bloqueada nesse momento (o bot não alcança os programas)"
            self.log(f"ERRO: {erro}", "erro")
            self._detalhe_tecnico("erro que parou a execução", e)
            self.ultimo_erro = {"erro": erro, "passo": self._passo_atual, "print": None}
            if not erros_linhas:
                self.ultimo_erro["print"] = self._print_erro()
            self.ultimo_erro["log"] = "\n".join(self.log_recente)
        finally:
            jc.manter_acordado(False)
            self.sending = False
            self.linha = {}
            self._fechar_excel(aviso=True)
            if registro:
                try:
                    registro.fechar()
                except Exception as e:
                    self.log(f"Aviso: não consegui gravar os resultados na planilha ({e}) — ela está aberta em "
                             "outro programa? Os resultados desta execução estão só no log.", "erro")
                    self._detalhe_tecnico("erro ao gravar os resultados na planilha", e)
            if self.nav:
                self.nav.fechar()
                self.nav = None
        return codigo, erro

    @staticmethod
    def _agora():
        return datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    def _fechar_excel(self, aviso=True):
        if self.xl and self.xl.aberto:
            if aviso:
                self.log("A planilha aberta pelo roteiro foi fechada sem salvar (faltou o passo 'Excel: fechar').")
            try:
                self.xl.fechar(salvar=False)
            except Exception:
                pass
        self.xl = None

    def _print_erro(self):
        try:
            os.makedirs(self.log_dir, exist_ok=True)
            caminho = os.path.join(self.log_dir, f"erro_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
            if self._bg and self.nav and self.nav.vivo:
                self.nav.captura()[0].save(caminho)  # a página do bot, não a sua tela
            else:
                ImageGrab.grab().save(caminho)
            self.log(f"Print no momento do erro: {caminho}", "erro")
            return caminho
        except Exception as e:
            self._detalhe_tecnico("não consegui salvar o print do erro", e)

    # ------------------------------------------------------------ um passo
    def executar_passo(self, s, cfg):
        cfg = dict(CFG_PADRAO, **(cfg or {}))
        if s["tipo"].startswith("excel_") or s["tipo"] == "ler_pagina":
            return self._passo_dados(s, cfg)  # iguais na tela e em segundo plano (não usam mouse/teclado)
        if s["tipo"].startswith(("arq_", "win_")):
            self._t_passo = time.time()
            return self._passo_arquivos(s, cfg)  # arquivos e Windows: também iguais nos dois modos
        if s["tipo"].startswith("email_") or s["tipo"] == "notificar":
            return self._passo_mensagens(s, cfg)  # e-mail e notificações: iguais nos dois modos
        if s["tipo"] == "vigiar_popup":
            return self._registrar_vigia(s)
        if s["tipo"] == "chrome_anexar":
            return self._chrome_anexar(s)  # pelo Chrome controlado: igual na tela e em segundo plano
        if s["tipo"] == "aguardar_usuario":
            return self._aguardar_usuario(s)  # pausa para a pessoa (login, captcha...)
        if s["tipo"] == "ia_perguntar":
            return self._passo_ia(s, cfg)  # só olha a tela se pedido (aí é recusado em segundo plano antes)
        if s["tipo"] == "ler_tela" and str(s.get("regiao", "")).startswith("arquivo"):
            return self._passo_ocr(s, cfg)  # OCR de arquivo de imagem: não usa a tela
        if self._bg:
            return self._passo_fundo(s, cfg)
        t = s["tipo"]
        if t == "abrir_chrome":
            controle = bool(s.get("controle", False))
            antes, ids_antes = set(jc.listar_chrome()), nav.cdp_ids()
            url = expandir(s.get("url", ""), self._valores())
            nav.abrir_chrome(url, controle, self.perfil)
            self._esperar(float(s.get("espera", 3)))
            nav.marcar_aba_nova(ids_antes, url=url)
            if controle:  # ouve a aba nova: um aviso da página (alert/confirm) não passa despercebido
                try:
                    if self.nav and self.nav.vivo and nav.CDP_PREFERIDA.get("id"):
                        self.nav.aba = nav.CDP_PREFERIDA["id"]
                    self._conectar().dialogo_aberto()
                except Exception:
                    pass
            self._aviso_sem_chrome = False
            if s.get("maximizar"):
                if jc.WIN:
                    self._hwnd_chrome = jc.aguardar_nova_janela(antes, 15)
                    jc.garantir_maximizado(self._hwnd_chrome, frente=True)
                else:
                    self._teclas("win+up")
                self._esperar(0.6)
            if s.get("aguardar", False):
                self._aguardar_carregar({"metodo": "automático", "estavel": 1.5, "timeout": 60}, cfg)
        elif t == "clique":
            x, y = int(s["x"]), int(s["y"])
            pos = self._posicao_por_elemento(s)
            if pos:
                if abs(pos[0] - x) > 3 or abs(pos[1] - y) > 3:
                    self.log(f"Posição pelo elemento da página: ({x}, {y}) -> {pos}")
                x, y = pos
            elif s.get("alvo_excel") and (pos := self._posicao_excel(s["alvo_excel"], x, y)):
                x, y = pos
            elif s.get("alvo_uia") and (pos := self._posicao_uia(s, x, y)):
                x, y = pos
            elif s.get("conferir") and s.get("imagem"):
                self._mover(x, y, cfg)
                x, y = self._posicao_conferida(s, x, y)
            self._clicar(x, y, s.get("botao", "esquerdo"), s.get("cliques", 1), cfg, s.get("segurar"))
            if s.get("aguardar"):
                self._aguardar_carregar({"metodo": "automático", "estavel": 1.2, "timeout": 60}, cfg)
        elif t == "arrastar":
            x, y, x2, y2 = int(s["x"]), int(s["y"]), int(s.get("x2", 0)), int(s.get("y2", 0))
            if s.get("alvo_excel") and (pos := self._posicao_excel(s["alvo_excel"], x, y)):
                x, y = pos
            if s.get("alvo_excel_fim") and (pos := self._posicao_excel(s["alvo_excel_fim"], x2, y2)):
                x2, y2 = pos
            self._arrastar(x, y, x2, y2, s.get("botao", "esquerdo"), s.get("duracao", 0.6), cfg, s.get("segurar"))
            if s.get("aguardar"):
                self._aguardar_carregar({"metodo": "automático", "estavel": 1.2, "timeout": 60}, cfg)
        elif t in ("ler_tela", "clicar_texto"):
            self._passo_ocr(s, cfg)
        elif t == "ia_clicar":
            self._passo_ia(s, cfg)
        elif t == "digitar":
            if s.get("limpar"):
                self._teclas("ctrl+a")
                self._teclas("delete")
            self._digitar(expandir(s.get("texto", ""), self._valores()), cfg)
            if s.get("enter"):
                self._teclas("enter")
        elif t == "tecla":
            for _ in range(max(1, int(s.get("repetir", 1)))):
                self._teclas(s["teclas"])
                self._esperar(0.15 / cfg["vel"] if cfg["visual"] else 0.03)
        elif t == "esperar":
            self._esperar(float(s.get("segundos", 1)))
        elif t == "aguardar_carregar":
            self._aguardar_carregar(s, cfg)
        elif t in ("clicar_imagem", "esperar_imagem"):
            box = self._procurar(s, cfg)
            if t == "clicar_imagem":
                cx = int(box.left + box.width / 2) + int(s.get("offset_x", 0))
                cy = int(box.top + box.height / 2) + int(s.get("offset_y", 0))
                self._clicar(cx, cy, s.get("botao", "esquerdo"), s.get("cliques", 1), cfg)
                if s.get("aguardar"):
                    self._aguardar_carregar({"metodo": "automático", "estavel": 1.2, "timeout": 60}, cfg)
        elif t == "rolar":
            self._rolar(s, cfg)
        else:
            raise ValueError(f"tipo de passo desconhecido: {t}")


# Compatibilidade: tudo que antes era importado de motor continua disponível aqui
__all__ = ['ALIASES', 'Achado', 'BTN_MAP', 'CFG_PADRAO', 'HAS_CV', 'Image',
           'ImageChops', 'ImageGrab', 'ImageNotFound', 'KB', 'NAVEGADORES', 'PRECISA_TELA',
           'Parado', 'RETENTAVEIS', 'TIPOS', 'UiBase', 'WIN', '_BLOB',
           '_dpapi', 'abrir_texto', 'base64', 'cat', 'ctypes', 'cursor_ocupado',
           'cv2', 'datetime', 'deslocamento_vertical', 'expandir', 'jc', 'json',
           'melhor_correspondencia', 'nav', 'np', 'os', 'outro_programa', 'parse_teclas',
           'pixels_rolagem', 'proteger_texto', 'pyautogui', 'resumo', 'sys', 'threading',
           'time', 'xlm', 'Motor']
