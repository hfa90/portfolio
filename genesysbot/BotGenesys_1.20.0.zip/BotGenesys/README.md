# Bot Genesys — automação visual

**Versão 1.20.0** · veja o histórico em [CHANGELOG.md](CHANGELOG.md) (ou *Ajuda → Sobre* no app).

App em Python (Tkinter + ttkbootstrap) para **gravar**, ajustar, **executar** e **agendar** um roteiro no Chrome
usando a posição exata do mouse, o teclado e reconhecimento de imagem.

## Instalar
Clique duas vezes em **`instalar.bat`**. Ele faz tudo o que falta e pode ser rodado de novo quando quiser:
1. **Python**: usa o que já existe (3.10+) ou instala o Python 3.12 só para o seu usuário (winget ou python.org);
2. **ambiente do programa** (`.venv`) e **bibliotecas** (`requirements.txt`);
3. confere o **Chrome** (oferece instalar) e o **Excel**;
4. cria os **atalhos** "Bot Genesys" na Área de Trabalho e no Menu Iniciar (com Verificar sistema e Testes);
5. roda o **diagnóstico** e mostra o resultado. Registro: `logs\instalacao.log`.

**Outro computador:** `instalador\empacotar.py` gera `BotGenesys_<versão>.zip` só com o programa (sem os seus
roteiros, planilhas, logs ou configurações). Lá: extrair e clicar em `instalar.bat`.
`desinstalar.bat` remove atalhos e `.venv` (mantém roteiros e planilhas).

## Como rodar
Pelo atalho **Bot Genesys** ou por **`iniciar.bat`** (na primeira vez ele chama o instalador).
Manual: `pip install -r requirements.txt` e depois `python bot_genesys.py`.

## A tela
- **Cabeçalho**: nome do roteiro (com aviso "não salvo"), selo de estado (PRONTO / GRAVANDO / EXECUTANDO / PAUSADO)
  e botão de **tema claro/escuro**.
- **Barra de ações**: Gravar processo · Executar · Do selecionado · Pausar · Parar · Agendar · Novo/Abrir/Salvar.
- **Lista de passos** (esquerda): ícone por tipo, filtro, **arraste para reordenar**, **botão direito** para mais
  opções, duplo clique para editar, passos desativados aparecem com ⊘.
- **Abas** (direita): **Passo** (posição do mouse ao vivo + editor), **Execução** (opções, planilha, janela do
  Chrome) e **Agendamentos**.
- **Log** colorido e **barra de status** com progresso, posição do mouse, estado do Chrome e próxima execução agendada.
- Durante a execução, um **painel flutuante** mostra o passo atual e o progresso, e uma **notificação** avisa
  quando termina.

## Atalhos
| Atalho | Função |
|---|---|
| **F4** | iniciar / parar a **gravação** |
| **F5** | executar tudo (com o app em foco) |
| **F8** | capturar a posição do mouse para o passo em edição |
| **F9** | adicionar um clique na posição do mouse (na gravação: marca um ponto sem clicar) |
| **F2** | pausar / continuar a execução |
| **ESC** | parar o bot |
| Mouse no canto superior esquerdo | parada de emergência |
| Ctrl+S / Ctrl+O / Ctrl+N | salvar / abrir / novo |
| Ctrl+Z / Ctrl+D / Delete / Espaço | desfazer / duplicar / remover / ativar-desativar |

## 1. Gravar o processo
1. Clique em **● Gravar processo** (ou F4). Se quiser, marque *Começar abrindo o Chrome nesta URL*.
2. Faça o processo normalmente no Chrome. Cliques, textos, teclas, rolagem e esperas viram passos automaticamente.
3. Aperte **F4** para parar. Revise, dê descrições e salve (Ctrl+S).

**Rolagem (roda do mouse e touchpad):** subir/descer a página é gravado de três formas, escolhidas sozinhas:
- **Chrome em modo controlado** (gravação iniciada com *Começar abrindo o Chrome nesta URL*, ou Chrome aberto pelo
  passo *Abrir Chrome*): o app lê a posição real da página, **exata**, venha do touchpad, da roda ou da barra de
  rolagem, inclusive dentro de **áreas roláveis internas** (listas, painéis). Na execução a página volta exatamente
  para a mesma posição.
- **Roda do mouse**: lida "bruta", inclusive mouses de rolagem suave/alta precisão.
- **Touchpad com o Chrome normal**: o Chrome não avisa o Windows sobre o gesto de dois dedos, então o app detecta
  pela tela quanto o conteúdo deslizou (aproximado; para precisão total use o modo controlado).

Cada clique guarda também um recorte da imagem do lugar clicado. Na execução, se o botão/campo tiver mudado de
lugar, o bot encontra o recorte e corrige o clique.

## Excel (sem mouse e sem teclado)
Passos novos em **Ação**: *Excel: abrir planilha · ler célula · escrever célula · copiar intervalo ·
rodar macro · atualizar / recalcular · salvar / exportar · fechar*.
- No Windows com o Excel instalado, o bot usa **o próprio Excel numa cópia invisível** — não mexe nas
  planilhas que você estiver usando. Se a planilha já estiver aberta no seu Excel, ele usa essa janela.
  Macros VBA, "Atualizar tudo", recalcular e salvar em PDF funcionam.
- Sem o Excel, usa **openpyxl** (ler/escrever/copiar/salvar .xlsx; sem macros e sem atualizar dados).
- Células: `B2`, `A1:C10`, `Dados!A1`, `'Minha Aba'!B3`. Valores aceitam variáveis: `{Numero}`, `{data}`...
- **Ler da página**: guarda um valor da página do Chrome controlado numa variável, ex.: o número do chamado
  com o padrão `(INC\d+)` → `{numero_chamado}`.

- **Fórmulas**: no *Excel: escrever célula*, marque *Fórmula em português* e escreva como no Excel:
  `=SE(G2="";"";ARRED((G2-F2)*24;1))`. Em um intervalo (`H2:H{proxima_linha}`) a fórmula é preenchida para baixo.
- **Tabela dinâmica**: *Excel: tabela dinâmica* com Dados (`Chamados!A1` = tabela inteira), Destino (`Painel!A4`),
  Linhas/Colunas/Valores/Filtros (nomes das colunas, separados por `;`) e a função. Se já existir, é recriada
  com os dados atuais. Precisa do Excel instalado.
- **Última linha**: *Excel: última linha preenchida* → `{ultima_linha}` e `{proxima_linha}` para inserir registros.

### Fórmulas em português ou inglês
No passo *Excel: escrever célula* escreva a fórmula como preferir — `=PROCV(A2;Dados!A:C;3;FALSO)` ou
`=VLOOKUP(A2,Dados!A:C,3,FALSE)`. O idioma é **detectado sozinho** (nomes das funções e `;`/`,`) e a fórmula
funciona com o Excel em qualquer idioma (e também sem o Excel). O botão **ƒx Funções** abre a lista de ~265
funções (procura em PT ou EN, sintaxe, descrição), insere na fórmula e converte a fórmula inteira de idioma.
"Ler a lista completa do meu Excel" pergunta ao seu próprio Excel o nome de TODAS as funções da sua versão.

### Exemplo pronto: fórmulas + tabelas dinâmicas
Abra `exemplos/roteiro_excel_dinamica.json` no app e clique em **Executar**. Ele usa
`exemplos/relatorio_chamados.xlsx` (abas Chamados, SLA, Resumo com fórmulas e Painel) para:
inserir um chamado novo → preencher as fórmulas (horas, PROCV do SLA, dentro do SLA, mês) → recalcular →
criar 3 tabelas dinâmicas no Painel (setor x status, tempo médio por categoria com filtro de prioridade,
SLA por prioridade) → ler o total e o % no SLA → salvar → exportar o Painel em PDF (`exemplos/saida/`).

- **Gráfico**: *Excel: gráfico* com Dados = intervalo (`Indicadores!A3:B8`: 1ª coluna = categorias,
  1ª linha = séries) ou o nome de uma tabela dinâmica (gráfico dinâmico), destino (`Painel!H4`), tipo e título.

### Para quem mexe no código
Cada tipo de passo é definido em `passos.py` (catálogo): nome, ícone, campos, dica, resumo e validação.
Um tipo novo = um `Passo(...)` no catálogo + a execução em `motor.py`. Rode `testar.bat` depois.

A janela fica em `interface/`: `janela.py` (montagem da tela), `editor.py` (lista de passos e formulário),
`gravador.py` (F4), `execucao.py`, `agenda.py`, `arquivos.py` (abrir/salvar/exportar), `ajuda.py`
(diagnóstico, versões), `infra.py` (log, atalhos) e `comum.py` (pastas e utilidades).
`bot_genesys.py` só inicia o programa.

### Segurança das atualizações
- `testar.bat` roda os testes automáticos (pasta `testes/`; não altera seus arquivos).
- Cada versão que você abre fica guardada em `_versoes/`; *Ajuda → Voltar para uma versão anterior* desfaz
  uma atualização (só os arquivos do programa — roteiros e planilhas não mudam).
- `manifesto.json` permite ao programa avisar se uma atualização ficou pela metade.

### Diagnóstico e logs
*Ajuda → Verificar sistema* (ou `diagnostico.bat`) testa tudo de que os roteiros dependem — inclusive um
teste real no Excel — e salva um relatório em `logs/diagnostico_*.txt`. Se algo der errado, mande esse relatório.
Ao abrir, o programa apaga logs com mais de 30 dias e esconde (••••••) senhas que tenham ficado nos logs.

### Outros programas (Excel na tela, sistemas desktop)
A gravação funciona em qualquer programa: cada passo guarda o programa em que foi feito (aparece como
"· no EXCEL" na lista). Com "Garantir a janela maximizada" ligado, o bot maximiza e traz para a frente a
janela certa antes de cada ação. O modo segundo plano só vale para o Chrome.

**Clique pelo elemento (qualquer programa).** Ao gravar um clique num programa desktop (sistema interno, SAP
GUI, Explorador, a faixa de opções do Excel...), o bot guarda *qual* elemento foi clicado — aparece como
`[botão "Salvar"]` na lista. Na execução ele procura esse elemento na janela, onde quer que ele esteja agora
(janela de outro tamanho, botão que mudou de lugar); se não achar, usa a imagem e depois a posição gravada.
Usa o UI Automation do Windows (biblioteca `uiautomation`, instalada pelo `instalar.bat`).

**Texto da tela (OCR).** Para programas em que nada mais funciona (sistemas antigos, área remota, PDF aberto):
- *Ler texto da tela* — guarda numa variável o texto da janela da frente, da tela inteira, de uma área ou de um
  arquivo de imagem (png, jpg...);
  com um padrão (regex), ex.: `(INC\d+)`, pega só o número do protocolo.
- *Clicar no texto da tela* — acha "Confirmar" (ou `{variável}`) e clica; escolhe a 2ª, 3ª... ocorrência.
- *Se: texto aparece na tela* — condição para "Erro", "Sessão expirada", "Gravado com sucesso"...

Usa o leitor de texto que já vem no Windows 10/11 (sem instalar nada); cada leitura leva 1 a 3 s. Precisa
do idioma Português instalado no Windows (Configurações › Hora e idioma › Idioma). Esses passos olham a tela,
então não rodam no modo segundo plano.

### Rodar o Excel escondido ou visível
Ao executar um roteiro com passos "Excel:", o bot pergunta: **segundo plano** (Excel invisível, você
continua usando o computador) ou **ver o processo** (Excel maximizado, mostrando cada passo).
Execuções agendadas não perguntam: usam o que está no passo "Excel: abrir planilha".

### Exemplo pronto: gráficos
`exemplos/roteiro_excel_graficos.json` usa `exemplos/painel_graficos.xlsx` (abas Chamados, SLA, Indicadores com
fórmulas, **Gráficos** com 4 gráficos prontos — incluindo um combinado colunas + linha — e Painel):
insere um chamado → copia as fórmulas da linha de cima → recalcula (os gráficos se atualizam sozinhos) →
cria tabela dinâmica + **gráfico dinâmico** e mais 2 gráficos no Painel → exporta as abas Gráficos e Painel em PDF.

**Planilha como lista de chamados** (aba Execução): escolha um `.xlsx`, `.xlsm` ou `.csv` e a **aba**.
A 1ª linha tem os nomes das colunas (use `{Coluna}` nos textos). Opções:
- **Escrever o resultado** em cada linha: coluna de status (padrão *Status*, criada se não existir) com
  "OK 15/11/2026 23:30" ou "Erro ...", e os valores lidos nas colunas de mesmo nome
  (crie a coluna *Numero* e use um passo *Ler da página* com variável `Numero`).
- **Pular linhas já OK**: se a execução parar no meio, a próxima continua de onde parou.
- **Seguir para o próximo** chamado quando um der erro (o erro fica anotado na linha).
- `{linha_planilha}` = número da linha do chamado atual (útil para escrever em outra planilha).

## Condições, repetições e erros
Blocos que abrem e fecham (os passos de dentro aparecem recuados na lista):

```
◇ Se: comparar valores   {total} é maior que 1000        ↻ Repetir  para cada item de {arquivo_lista}
      ... (se sim)                                              ⚑ Tentar
├ Senão                                                               ... (passos que podem falhar)
      ... (se não)                                              ⚠ Se der erro   → {erro}
└ Fim do se                                                           ... (o que fazer no erro)
                                                                └ Fim do tentar
                                                          └ Fim do repetir
```

- **Se**: comparar valores, imagem na tela, arquivo existe, texto/elemento na página, janela aberta (com "SE NÃO").
- **Repetir**: N vezes / para cada item de uma lista ({item}) / enquanto; *Sair da repetição*; limite de segurança.
- **Tentar / Se der erro**: o roteiro não para quando algo falha ({erro} tem a mensagem).
- *Parar o roteiro*, *Definir variável* (somar, juntar texto...) e *Executar outro roteiro*.
- Ao adicionar um Se/Repetir/Tentar, o fechamento é criado junto; um bloco aberto é avisado antes de executar.
- Exemplo: `exemplos/roteiro_fluxo_organizar_pdfs.json`.

## IA (Claude)
Configure uma vez em **IA › Configurar**: cole a chave da API da Anthropic (crie em console.anthropic.com; cada uso
custa centavos, cobrados na sua conta). A chave fica criptografada pelo Windows. Modelo padrão: `claude-sonnet-5-5`.
- **IA › Criar ou alterar o roteiro descrevendo** (Ctrl+I): escreva o que quer — "abra notas.xlsx e copie para uma
  aba nova as linhas com nota acima de 1.000" — e a IA monta os passos com o catálogo do bot. O bot confere cada passo
  (tipos, campos, opções, blocos Se/Repetir/Tentar fechados), mostra uma prévia com avisos e só então insere
  (Ctrl+Z desfaz). Com "Alterar o roteiro inteiro", ela reescreve o roteiro aberto aplicando o pedido.
- **IA: perguntar / extrair** (passo): pergunta sobre um texto, a tela, a janela da frente ou um arquivo de imagem;
  resposta em texto, número, sim/não ou JSON numa variável. Ex.: classificar e-mails, ler o total de uma nota.
- **IA: clicar no que eu descrever** (passo): "botão azul Salvar no rodapé" — a IA olha a tela e clica. Para telas
  que mudam de layout e ícones sem texto (3 a 10 s por clique).
- **IA › Explicar o último erro**: depois de uma execução que falhou, a IA lê o roteiro, o log e o print do erro, diz
  a causa e mostra exatamente o que muda nos passos. **APLICAR SOLUÇÃO** faz as mudanças (conferidas: campos,
  opções, blocos; senhas nunca são tocadas; Ctrl+Z desfaz) e **Aplicar e executar de novo** já roda a partir do passo
  certo.

A chave começa com `sk-ant-api…`: a assinatura do claude.ai não tem chave de API. O botão **Testar** confere na hora.
Senhas e tokens nunca são enviados à IA. Não use a IA com dados que não podem sair da empresa.

### Exemplo completo: Excel + IA + Gmail
`exemplos/roteiro_ia_excel_gmail.json` (com a planilha `exemplos/vendas_ia.xlsx`):
1. **Excel** — abre as vendas, cria as colunas Total, Comissão, Faixa e Mês e 8 indicadores na aba Resumo (12
   fórmulas: SOMA, MÉDIA, MÁXIMO, ÍNDICE+CORRESP, SOMASES, CONT.SE, ARRED, SE aninhado, DATA), monta 2 tabelas
   dinâmicas na aba Painel e salva uma cópia em `exemplos/saida` (o modelo não é alterado).
2. **IA** — escreve o e-mail com os números e observações para a gestão (sem IA configurada, usa um texto padrão).
3. **Gmail** — abre o Chrome; se a conta não estiver conectada, o robô **pausa** e mostra o cartão "esperando você":
   faça o login e ele continua sozinho quando a caixa de entrada aparecer. Abre a mensagem já preenchida, a IA acha
   o clipe e anexa a planilha, e envia com Ctrl+Enter.

O destinatário está no passo "Nova mensagem já preenchida" (`to=` no endereço; `@` vira `%40`).

### À prova de surpresas: anexos e pop-ups
- **Chrome: anexar arquivo (sem a janela Abrir)** — entrega o arquivo direto ao site (Gmail, portais, formulários)
  e confere se o nome dele apareceu na página. Sem clipe, sem janela do Windows, sem digitar caminho.
- **Windows: escolher arquivo na janela Abrir/Salvar** — para programas desktop: espera a janela aparecer, escreve
  o caminho no campo certo, confere, confirma e espera ela fechar.
- **Vigiar pop-up** — regra que vale até o fim da execução: quando aparecer o aviso (do Chrome ou uma janela do
  Windows) com tal texto, o robô responde (OK, Cancelar, fechar ou clica num botão) no meio de qualquer passo ou
  espera, e pode parar com erro quando o aviso significa que algo deu errado. Sem regra, um aviso do Chrome que trava
  a página para o roteiro com a mensagem dele, em vez de seguir às cegas.
- A IA (criar roteiro e Aplicar solução) conhece esses cenários e monta a cadeia completa: ação → o que abre → o que
  pode aparecer → como confirmar.
- Depois de **Aplicar solução**, se a execução terminar sem nenhuma falha nem aviso, o roteiro corrigido é **salvo
  sozinho** por cima do anterior (a versão anterior fica em `logs\roteiros_antes_da_ia`) — o bot só avisa.

### Pausar: esperar você
Passo para quando o robô precisa de você (login, captcha, conferir antes de enviar): mostra um cartão com a mensagem
e os botões **Continuar** / **Parar** (F2 também continua). Com "aparecer na página do Chrome" ou "aparecer na tela"
ele continua sozinho quando o elemento/texto surgir.

## E-mail e notificações
Funcionam também em segundo plano (não usam a tela).
- **E-mail: enviar** — pelo *Outlook do computador* (usa a conta já aberta, sem senha; pode enviar, abrir para
  você revisar ou salvar como rascunho) ou por *SMTP* (Gmail, Office 365, servidor da empresa). Aceita
  `{variáveis}` no assunto e na mensagem e anexos com `*` (ex.: `relatorios\*.pdf` ou `{arquivo}`). No Gmail use
  uma *senha de app* (Conta Google › Segurança › Senhas de app).
- **E-mail: esperar / ler (Outlook)** — espera chegar um e-mail (remetente, assunto, texto, só com anexo), salva os
  anexos numa pasta, marca como lido e move para outra pasta. Guarda `{email_assunto}`, `{email_remetente}`,
  `{email_corpo}`, `{email_data}`, `{email_anexos}` e `{email_qtd_anexos}`.
- **Notificar** — aviso no canto da tela do Windows, **Telegram**, **Microsoft Teams**, **Slack**, **Discord** ou
  um webhook qualquer. Dentro de *Tentar › Se der erro*, mande `{erro}` para saber no celular quando o robô falhar.

Senhas de e-mail, tokens e endereços de webhook ficam ocultos na tela (•••) e **criptografados pelo Windows** no
arquivo do roteiro, como as senhas do passo Digitar — e nunca aparecem nos logs.
Exemplo: `exemplos/roteiro_email_aviso.json` (abre no Outlook um e-mail com o PDF mais novo de Downloads para
você revisar e avisa na tela; se algo falhar, avisa o erro).

## Arquivos e Windows (sem mouse)
Passos que trabalham direto no Windows — não dependem de posição na tela e rodam também em segundo plano:

| Passo | Exemplo |
|---|---|
| Arquivos: esperar arquivo aparecer | `~\Downloads\*.xlsx` → {arquivo} (espera o download terminar) |
| Arquivos: mover / copiar | {arquivo} → `Relatórios\{data_arquivo}\` |
| Arquivos: renomear | {arquivo} → `Chamados_{data_arquivo}` (mantém a extensão) |
| Arquivos: listar pasta | o mais novo da pasta em {arquivo}; {arquivo_quantidade}, {arquivo_lista} |
| Arquivos: criar pasta / compactar-extrair zip / excluir (Lixeira) | |
| Windows: abrir arquivo, programa ou site | abrir {arquivo} no Excel |
| Windows: área de transferência | copiar {numero_chamado} → depois Tecla ctrl+v |
| Windows: rodar comando | cmd ou PowerShell; saída em {saida} |

Exemplo de roteiro misto: clicar em "Exportar" no Chrome → *esperar arquivo* → *mover* para a pasta do mês →
*renomear* com a data → *Excel: abrir planilha* {arquivo} → ler um total → digitar no sistema.

## Rodar em segundo plano (usar o computador ao mesmo tempo)
Aba **Execução → Rodar em segundo plano**. O bot não usa o seu mouse nem o seu teclado: cliques, teclas e texto
vão direto para dentro da página do **Chrome controlado** (o Chrome do bot fica atrás das suas janelas).
- Um **cartão no canto inferior direito** mostra sempre: ● em execução (piscando), passo atual, progresso, tempo,
  e os botões **Pausar** / **Parar**. Ele não rouba o foco de quem está digitando.
- No fim o cartão mostra **✓ Concluído** (verde), **⚠ Concluído com avisos** (amarelo, ex.: um elemento não foi
  encontrado e o bot usou a posição gravada), **✗ Erro** (vermelho, com o motivo) ou **■ Interrompido**,
  com o botão **Ver log**. Erros e avisos ficam na tela até você fechar.
- Os cliques miram o **elemento da página** (campo, botão) gravado — não dependem da posição da janela.
  Para isso, **grave o processo com o Chrome controlado** (marque *Começar abrindo o Chrome nesta URL* na
  gravação). Passos gravados antes desta versão continuam funcionando pela posição convertida, mas regravar
  deixa o segundo plano bem mais confiável.
- Se a página abrir uma nova aba, o bot continua nela. O bot espera sozinho os elementos aparecerem.
- Limites: só age dentro do Chrome do bot. Atalhos do Windows (ex.: `win+up`) e janelas do Windows
  (ex.: "Abrir arquivo" para anexos) não funcionam em segundo plano — o bot avisa e pula.
- Em segundo plano ESC/F2 não são usados (você está usando o teclado): use o cartão ou o app.

## Exportar para Python
**⇩ Exportar .py** (ou *Arquivo → Exportar para Python*) gera **um único arquivo .py** que roda sozinho, com:
o mesmo motor do app (na tela e em segundo plano, correção pelo elemento/imagem, espera de carregamento,
rolagem exata, senha criptografada, tentativas, planilha, logs e prints de erro), os passos legíveis com todos
os detalhes gravados, e as imagens de referência embutidas.
```
pip install pyautogui pynput pillow opencv-python websocket-client openpyxl pywin32
python bot_meu_roteiro.py                     # como foi configurado
python bot_meu_roteiro.py --segundo-plano     # sem usar mouse/teclado
python bot_meu_roteiro.py --na-tela --rapido  # mouse de verdade, sem animações
python bot_meu_roteiro.py --planilha chamados.xlsx --aba Dados  # um chamado por linha
```
O arquivo usa o mesmo perfil do Chrome do bot (login salvo). Senhas só abrem no mesmo usuário do Windows.

### Gravar no Excel com precisão
- **Clique numa célula** guarda a célula (ex.: `Dados!B5`) — aparece como `[célula Dados!B5]` na lista. Na execução
  o bot acha a célula na tela, mesmo com a planilha rolada, outro zoom ou outra janela.
- **Arrastar** (selecionar `A2:D20`, puxar a alça de preencher, mover um gráfico) vira o passo *Arrastar*, com as
  células de início e fim.
- **Ctrl+clique / Shift+clique** (seleção múltipla ou de intervalo) ficam no campo *Segurar tecla* do clique.
- Misturar Excel e Chrome na mesma gravação funciona: cada passo guarda o programa e o bot traz a janela certa.

### Atalhos na gravação
A gravação lê do Windows, no instante de cada tecla, se Ctrl/Alt/Shift/Win estão apertados — atalhos
digitados rápido (Ctrl+C, Ctrl+Shift+L, Ctrl+;, Ctrl+1, Ctrl+Enter...) são gravados certinho e um Ctrl
"perdido" (Alt+Tab, menu Iniciar) não contamina o texto. **Alt sozinho** + letras (dicas de tecla da faixa do
Excel: Alt, H, O, I) vira uma sequência de teclas, não texto.

## 2. Chrome sempre maximizado
As posições gravadas valem para o Chrome **maximizado no monitor principal**. Com a opção
*Garantir Chrome maximizado* (aba Execução, ligada por padrão) o bot confere a janela antes de começar e antes de
cada clique/digitação, e corrige sozinho quando ela está:
- **minimizada** → restaura e maximiza;
- **pela metade da tela** ou em janela solta → maximiza;
- em **tela cheia (F11)** → sai da tela cheia e maximiza;
- em **outro monitor** → traz para o monitor principal e maximiza;
- atrás de outra janela → traz para a frente.

O estado aparece ao vivo na aba Passo e na barra de status ("Chrome: ● maximizado"). Há também
*Executar > Maximizar o Chrome agora*. Ao iniciar uma gravação o Chrome também é maximizado antes.

## 3. Aguardar o navegador carregar
Passo **Aguardar página carregar** (modos *chrome*, *visual* e *automático*) ou a opção
*Aguardar página carregar depois* em cliques. O modo *chrome* precisa do Chrome aberto pelo passo *Abrir Chrome*
com **Modo controlado** (perfil próprio do bot em `chrome_perfil_bot`; faça login nele uma vez).

## 4. Agendar
Com o roteiro pronto e salvo, clique em **⏰ Agendar**:
- **Repetir**: uma vez, todos os dias, dias úteis, dias da semana escolhidos ou a cada X minutos;
- **Data e hora** (atalhos: *daqui 5 min*, *daqui 1 h*, *amanhã 08:00*) com a prévia da próxima execução;
- **Planilha (opcional)** para abrir vários chamados de uma vez;
- **Executar**:
  - **Pelo app**: o app precisa estar aberto (pode ficar minimizado);
  - **Pelo Windows**: registra no Agendador de Tarefas (pasta *BotGenesys*) e roda mesmo com o app fechado.

A aba **Agendamentos** mostra a próxima execução e o último resultado (✓ ok, ✗ erro, ■ interrompido, ⚠ perdida),
e permite editar, rodar agora, pausar e excluir. Cada execução agendada roda em um processo separado. Se já houver
outra execução em andamento, ela não roda por cima. Detalhes ficam em `logs/`.

> O computador precisa estar **ligado e desbloqueado** na hora, pois o bot usa o mouse e o teclado de verdade.

## Outros recursos
- **Planilha CSV**: use `{NomeDaColuna}` nos textos; o roteiro roda uma vez por linha (veja `exemplo_chamados.csv`).
- **Tentativas** para passos de imagem/carregamento, **Ativar/Desativar** passos, **Desfazer**.
- **Logs** diários em `logs/` e **print da tela** quando ocorre erro.
- **Abrir recente** no menu Arquivo. O app reabre o último roteiro usado.
- Linha de comando: `python bot_genesys.py --executar roteiro.json [--csv chamados.csv]`
  (`executar_roteiro.bat` faz isso).

## Arquivos
| Arquivo | Para quê |
|---|---|
| `bot_genesys.py` | inicia o programa |
| `interface/` | a janela, um arquivo por assunto (editor, gravador, execução, agenda, ajuda...) |
| `passos.py` | **catálogo de passos**: nome, campos, dica, resumo e validação de cada tipo |
| `motor.py` | núcleo da execução (laço dos passos, repetições, planilha) |
| `motor_tela.py` / `motor_dados.py` / `motor_fundo.py` | execução na tela / Excel e leitura da página / segundo plano |
| `motor_util.py` | utilidades do motor (imagens, variáveis, teclas, senhas) |
| `janelas.py` | detecta e maximiza a janela do Chrome ou de qualquer programa (`janela_chrome.py` = nome antigo) |
| `navegador.py` | conversa com o Chrome controlado |
| `excel.py` | Excel invisível / openpyxl e planilha de chamados |
| `fluxo.py`, `motor_fluxo.py` | condições, repetições, Tentar, variáveis e sub-roteiros |
| `arquivos_win.py`, `motor_arquivos.py` | passos de Arquivos e Windows |
| `excel_tela.py` | célula do Excel ↔ posição na tela (gravação e execução de cliques no Excel) |
| `formulas_excel.py` | funções do Excel em português e inglês, detecção e conversão de idioma |
| `instalar.bat`, `instalador/` | instalador, desinstalador, ícone e empacotador |
| `painel.py` | legendas/cartões na tela |
| `exportar.py` | gera o arquivo .py independente |
| `agendador.py` | agendamentos (app e Agendador do Windows) |
| `diagnostico.py`, `versoes.py` | Verificar sistema, limpeza de logs, cópias de versões e manifesto |
| `versao.py`, `CHANGELOG.md` | versão atual e histórico |
| `bot_chamado.py` | atalho de compatibilidade (versões antigas) |
| `testes/`, `testar.bat` | testes automáticos |
| `_versoes/`, `_antigo/` | cópias das versões anteriores e arquivos antigos (`pyput.py`) |
| `roteiro.json` | seu roteiro (criado ao salvar) |
| `agendamentos.json`, `config_app.json` | agendamentos e preferências (tema, recentes) |
| `imagens/`, `logs/`, `chrome_perfil_bot/` | recortes, logs e perfil do Chrome controlado |

## Dicas de precisão
- Mantenha o **zoom do Chrome em 100%** e não mude a escala/resolução do Windows depois de gravar.
- Se uma imagem não for encontrada, diminua a **precisão** (ex.: 0.75) ou recapture um recorte mais característico.
