# -*- coding: utf-8 -*-
"""Passos de IA: perguntar/extrair (texto, tela ou imagem) e clicar no que for descrito (visão).

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import os
import sys
import time

try:
    import ia
    from motor_util import Image, ImageGrab, abrir_texto, jc
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    ia = sys.modules[__name__]


class IAMixin:

    def _ia_chave(self):
        chave = ia.chave_configurada(self.base, abrir_texto)
        if not chave:
            raise ia.ErroIA("falta a chave da API da IA: menu IA › Configurar (ou a variável ANTHROPIC_API_KEY)")
        return chave, ia.modelo_configurado(self.base)

    def _imagem_ia(self, origem, arquivo=""):
        """Imagem para a IA: 'tela inteira', 'janela da frente' ou 'arquivo de imagem'. Devolve (img, (x0, y0))."""
        if str(origem).startswith("arquivo"):
            caminho = self.caminho(self._x(arquivo))
            if not caminho or not os.path.isfile(caminho):
                raise FileNotFoundError(f"imagem não encontrada: {caminho or '(vazio)'}")
            return Image.open(caminho), (0, 0)
        if str(origem).startswith("janela") and jc.WIN:
            r = jc.retangulo(jc.janela_em_foco())
            if r:
                return ImageGrab.grab(bbox=tuple(int(v) for v in r)), (int(r[0]), int(r[1]))
        return ImageGrab.grab(), (0, 0)

    def _passo_ia(self, s, cfg):
        chave, modelo = self._ia_chave()
        if s["tipo"] == "ia_perguntar":
            incluir = s.get("incluir") or ia.INCLUIR[0]
            img = None if incluir.startswith("nada") else self._imagem_ia(incluir, s.get("arquivo"))[0]
            formato = s.get("formato") or "texto"
            t0 = time.time()
            r = ia.perguntar(chave, self._x(s.get("pergunta")), formato, img, modelo)
            nome = (str(s.get("variavel") or "").strip().strip("{}")) or "resposta"
            self.vars[nome] = r
            self.log(f"IA respondeu em {time.time() - t0:.1f} s → {{{nome}}} = "
                     f"{r if len(r) <= 90 else r[:87] + '...'!r}")
            return
        # ia_clicar
        desc = self._x(s.get("descricao_alvo"))
        limite = time.time() + max(3.0, float(s.get("timeout") or 20))
        while True:
            img, (ox, oy) = self._imagem_ia(s.get("regiao") or "janela da frente")
            achado = ia.localizar(chave, desc, img, modelo)
            if achado or time.time() >= limite:
                break
            self._esperar(1.5)
        if not achado:
            raise RuntimeError(f"a IA não encontrou na tela: \"{desc}\"")
        x, y, viu = ox + achado[0], oy + achado[1], achado[2]
        self.log(f"IA achou \"{desc}\" em ({x}, {y})" + (f": {viu}" if viu else ""))
        self._clicar(x, y, s.get("botao", "esquerdo"), s.get("cliques", 1), cfg)
        if s.get("aguardar"):
            self._aguardar_carregar({"metodo": "automático", "estavel": 1.2, "timeout": 60}, cfg)
