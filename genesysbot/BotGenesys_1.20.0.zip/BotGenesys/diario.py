# -*- coding: utf-8 -*-
"""
Diário do Bot Genesys: o que precisa ficar gravado mesmo quando algo dá errado.

- escrever(): põe a linha no log do dia NA HORA (não depende da janela estar respondendo);
- detalhe(): guarda o caminho técnico do erro (traceback) no log, para dar para descobrir a causa depois;
- instalar_ganchos(): erros que escapam (do programa, de outra thread) vão para o log em vez de sumir —
  com pythonw (agendamentos) não existe console para mostrá-los;
- salvar_json(): salva sem risco de estragar o arquivo (grava num temporário e só então troca).
"""
import datetime
import json
import os
import sys
import threading
import time
import traceback

_trava = threading.Lock()
_ganchos = {"pasta": None, "instalado": False, "sys": None, "thread": None, "ao_erro": None}


def arquivo_de_hoje(log_dir):
    return os.path.join(log_dir, f"bot_{datetime.date.today():%Y%m%d}.log")


def escrever(log_dir, texto):
    """Acrescenta o texto ao log do dia imediatamente. Nunca dá erro (devolve False se não conseguiu)."""
    try:
        with _trava:
            os.makedirs(log_dir, exist_ok=True)
            with open(arquivo_de_hoje(log_dir), "a", encoding="utf-8") as f:
                f.write(texto if texto.endswith("\n") else texto + "\n")
        return True
    except Exception:
        return False


def texto_erro(exc):
    """O caminho técnico completo de um erro (inclui a causa original, quando há)."""
    try:
        return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    except Exception:
        return f"{type(exc).__name__}: {exc}"


def detalhe(log_dir, titulo, texto):
    """Grava um bloco técnico no log do dia (fica só no arquivo; a tela continua com a mensagem simples)."""
    linhas = [f"[{datetime.datetime.now():%H:%M:%S}] DETALHE TÉCNICO — {titulo}:"]
    linhas += ["    | " + l for l in str(texto).rstrip().splitlines()]
    return escrever(log_dir, "\n".join(linhas) + "\n")


def _avisar(titulo):
    fn = _ganchos["ao_erro"]
    if fn:
        try:
            fn(titulo)
        except Exception:
            pass


def _gancho_sys(tipo, valor, tb_):
    if not issubclass(tipo, KeyboardInterrupt) and _ganchos["pasta"]:
        detalhe(_ganchos["pasta"], "erro que fechou o programa",
                "".join(traceback.format_exception(tipo, valor, tb_)))
    anterior = _ganchos["sys"]
    if anterior:
        try:
            anterior(tipo, valor, tb_)
        except Exception:
            pass


def _gancho_thread(args):
    if args.exc_type is not SystemExit and _ganchos["pasta"]:
        nome = getattr(args.thread, "name", "?")
        detalhe(_ganchos["pasta"], f"erro numa tarefa em paralelo ({nome})",
                "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))
        _avisar(f"{args.exc_type.__name__}: {args.exc_value}")
    anterior = _ganchos["thread"]
    if anterior:
        try:
            anterior(args)
        except Exception:
            pass


def instalar_ganchos(log_dir, ao_erro=None):
    """Erros não tratados passam a ser gravados no log do dia. Pode ser chamado de novo (só troca a pasta)."""
    _ganchos["pasta"], _ganchos["ao_erro"] = log_dir, ao_erro
    if _ganchos["instalado"]:
        return
    _ganchos["instalado"] = True
    _ganchos["sys"], _ganchos["thread"] = sys.excepthook, threading.excepthook
    sys.excepthook, threading.excepthook = _gancho_sys, _gancho_thread


def salvar_json(caminho, dados, indent=2):
    """Salva o JSON sem risco de deixar o arquivo pela metade: grava num temporário, confere que foi para o
    disco e só então troca pelo definitivo. Se algo falhar, o arquivo anterior continua intacto."""
    texto = json.dumps(dados, ensure_ascii=False, indent=indent)  # se não der para converter, nem toca no disco
    tmp = f"{caminho}.{os.getpid()}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(texto)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        for tentativa in range(5):  # no Windows o antivírus/OneDrive às vezes segura o arquivo por um instante
            try:
                os.replace(tmp, caminho)
                return
            except PermissionError:
                if tentativa == 4:
                    raise
                time.sleep(0.15 * (tentativa + 1))
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass


def reescrever(caminho, transformar):
    """Troca o conteúdo de um arquivo de log (ex.: ocultar senhas) sem cruzar com quem está escrevendo nele agora.
    transformar(texto) -> texto novo. Devolve True se o arquivo mudou."""
    with _trava:
        with open(caminho, encoding="utf-8", errors="replace", newline="") as f:
            conteudo = f.read()
        novo = transformar(conteudo)
        if novo == conteudo:
            return False
        with open(caminho, "w", encoding="utf-8", newline="") as f:
            f.write(novo)
        return True


# --------------------------------------------------------------------------- #
# Histórico de execuções (uma linha JSON por execução, em logs/execucoes.jsonl)
# --------------------------------------------------------------------------- #
HISTORICO = "execucoes.jsonl"


def registrar_execucao(log_dir, dados):
    """Acrescenta uma execução ao histórico. Nunca dá erro."""
    try:
        linha = json.dumps(dict(dados, quando=datetime.datetime.now().isoformat(timespec="seconds")),
                           ensure_ascii=False)
        with _trava:
            os.makedirs(log_dir, exist_ok=True)
            with open(os.path.join(log_dir, HISTORICO), "a", encoding="utf-8") as f:
                f.write(linha + "\n")
        return True
    except Exception:
        return False


def ler_execucoes(log_dir, limite=500):
    """As últimas execuções registradas (a mais recente primeiro). Linhas estragadas são ignoradas."""
    try:
        with open(os.path.join(log_dir, HISTORICO), encoding="utf-8", errors="replace") as f:
            linhas = f.readlines()[-int(limite):]
    except OSError:
        return []
    saida = []
    for l in linhas:
        try:
            d = json.loads(l)
            if isinstance(d, dict):
                saida.append(d)
        except ValueError:
            pass
    return saida[::-1]


def resumo_execucoes(execucoes):
    """{'total', 'ok', 'aviso', 'erro', 'parado', 'taxa' (% que terminou bem), 'piores': [(roteiro, passo, vezes)]}"""
    completas = [e for e in execucoes if not e.get("parcial")]
    r = {k: sum(1 for e in completas if e.get("resultado") == k) for k in ("ok", "aviso", "erro", "parado")}
    r["total"] = len(completas)
    contam = r["ok"] + r["aviso"] + r["erro"]
    r["taxa"] = round(100 * (r["ok"] + r["aviso"]) / contam) if contam else None
    falhas = {}
    for e in completas:
        if e.get("resultado") == "erro" and e.get("passo_falhou"):
            chave = (e.get("roteiro") or "?", e["passo_falhou"])
            falhas[chave] = falhas.get(chave, 0) + 1
    r["piores"] = sorted(((rot, p, n) for (rot, p), n in falhas.items()), key=lambda x: -x[2])[:5]
    return r
