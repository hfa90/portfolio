# -*- coding: utf-8 -*-
"""
E-MAIL E NOTIFICAÇÕES.

- Enviar e-mail pelo OUTLOOK do computador (usa a conta já aberta, sem senha) ou por SMTP (Gmail, Office 365,
  servidor da empresa).
- Esperar/ler e-mail no Outlook: remetente, assunto, texto, anexos (salvos numa pasta).
- Notificar: aviso do Windows no canto da tela, Telegram, Microsoft Teams, Slack, Discord ou um webhook qualquer.
Nada aqui usa o mouse ou o teclado: funciona também no modo segundo plano.
"""
import datetime
import glob
import json
import mimetypes
import os
import re
import smtplib
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

WIN_MSG = sys.platform == "win32"
VIAS = ["Outlook do computador", "SMTP (Gmail, Office 365...)"]
ACOES_OUTLOOK = ["enviar", "abrir para eu revisar", "salvar como rascunho"]
SEGURANCAS = ["STARTTLS (porta 587)", "SSL (porta 465)", "nenhuma"]
QUAIS = ["só os que chegarem a partir de agora", "não lidos", "o mais recente (lido ou não)"]
SE_NAO_ACHAR = ["dar erro", "seguir com as variáveis vazias"]
CANAIS = ["Windows (aviso na tela)", "Telegram", "Microsoft Teams", "Slack", "Discord", "Webhook (outro)"]
SERVIDORES = {"gmail.com": ("smtp.gmail.com", 587), "googlemail.com": ("smtp.gmail.com", 587),
              "outlook.com": ("smtp-mail.outlook.com", 587), "hotmail.com": ("smtp-mail.outlook.com", 587),
              "live.com": ("smtp-mail.outlook.com", 587), "yahoo.com": ("smtp.mail.yahoo.com", 587),
              "yahoo.com.br": ("smtp.mail.yahoo.com", 587)}


# --------------------------------------------------------------------------- utilidades
def enderecos(texto):
    """'a@x.com; b@y.com, c@z.com' -> lista (sem vazios e sem repetidos)."""
    vistos, out = set(), []
    for e in re.split(r"[;,\n]+", str(texto or "")):
        e = e.strip()
        if e and e.casefold() not in vistos:
            vistos.add(e.casefold())
            out.append(e)
    return out


def arquivos_anexos(texto, base=None):
    """'C:\\rel\\*.pdf; resumo.xlsx' -> caminhos existentes (aceita * e ?). Erro claro se algum não existir."""
    out = []
    for parte in re.split(r"[;\n]+", str(texto or "")):
        parte = os.path.expandvars(os.path.expanduser(parte.strip().strip('"')))
        if not parte:
            continue
        if not os.path.isabs(parte) and base:
            parte = os.path.join(base, parte)
        achados = sorted(glob.glob(parte)) if any(c in parte for c in "*?") else ([parte] if os.path.isfile(parte)
                                                                                  else [])
        if not achados:
            raise FileNotFoundError(f"anexo não encontrado: {parte}")
        out += [a for a in achados if a not in out]
    return out


def servidor_sugerido(usuario):
    dominio = str(usuario or "").rpartition("@")[2].casefold()
    return SERVIDORES.get(dominio, ("smtp.office365.com", 587) if dominio else ("", 587))


# --------------------------------------------------------------------------- SMTP
def montar_email(de, para, assunto, corpo, cc=(), cco=(), anexos=(), html=False, nome_de=""):
    msg = EmailMessage()
    msg["From"] = formataddr((nome_de, de)) if nome_de else de
    msg["To"] = ", ".join(para)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = assunto
    msg["Message-ID"] = make_msgid()
    if html:
        msg.set_content(re.sub(r"<[^>]+>", "", corpo))
        msg.add_alternative(corpo, subtype="html")
    else:
        msg.set_content(corpo)
    for caminho in anexos:
        tipo, _ = mimetypes.guess_type(caminho)
        principal, sub = (tipo or "application/octet-stream").split("/", 1)
        with open(caminho, "rb") as f:
            msg.add_attachment(f.read(), maintype=principal, subtype=sub, filename=os.path.basename(caminho))
    return msg


def enviar_smtp(servidor, porta, usuario, senha, para, assunto, corpo, cc=(), cco=(), anexos=(), html=False,
                seguranca=SEGURANCAS[0], de="", timeout=60):
    if not para and not cc and not cco:
        raise ValueError("informe pelo menos um destinatário")
    if not servidor:
        servidor, porta = servidor_sugerido(usuario)
    if not servidor:
        raise ValueError("informe o servidor SMTP (ex.: smtp.gmail.com)")
    remetente = de or usuario
    msg = montar_email(remetente, para, assunto, corpo, cc, cco, anexos, html)
    ctx = ssl.create_default_context()
    try:
        if seguranca.startswith("SSL"):
            conexao = smtplib.SMTP_SSL(servidor, int(porta or 465), timeout=timeout, context=ctx)
        else:
            conexao = smtplib.SMTP(servidor, int(porta or 587), timeout=timeout)
        with conexao as s:
            s.ehlo()
            if seguranca.startswith("STARTTLS"):
                s.starttls(context=ctx)
                s.ehlo()
            if usuario and senha:
                s.login(usuario, senha)
            s.send_message(msg, from_addr=remetente, to_addrs=list(para) + list(cc) + list(cco))
    except smtplib.SMTPAuthenticationError as e:
        dica = (" No Gmail use uma 'senha de app' (Conta Google > Segurança > Senhas de app), não a senha normal."
                if "gmail" in servidor else " Confira usuário e senha (algumas empresas exigem senha de app).")
        raise RuntimeError(f"o servidor recusou o login ({e.smtp_code}).{dica}") from None
    except (OSError, smtplib.SMTPException) as e:
        raise RuntimeError(f"não consegui enviar pelo servidor {servidor}:{porta} — {e}") from None
    return msg["Message-ID"]


# --------------------------------------------------------------------------- Outlook
def _outlook():
    if not WIN_MSG:
        raise RuntimeError("o Outlook só existe no Windows")
    try:
        import win32com.client
    except ImportError:
        raise RuntimeError("falta o pywin32 (rode instalar.bat)") from None
    try:
        return win32com.client.Dispatch("Outlook.Application")
    except Exception as e:
        raise RuntimeError(f"não consegui abrir o Outlook do computador (ele está instalado e configurado?): {e}") \
            from None


def enviar_outlook(para, assunto, corpo, cc=(), cco=(), anexos=(), html=False, acao=ACOES_OUTLOOK[0], conta="",
                   app=None):
    app = app or _outlook()
    item = app.CreateItem(0)  # olMailItem
    item.To, item.CC, item.BCC = "; ".join(para), "; ".join(cc), "; ".join(cco)
    item.Subject = assunto
    if html:
        item.HTMLBody = corpo
    else:
        item.Body = corpo
    for a in anexos:
        item.Attachments.Add(os.path.abspath(a))
    if conta:
        for c in app.Session.Accounts:
            if conta.casefold() in str(c.SmtpAddress).casefold() or conta.casefold() in str(c.DisplayName).casefold():
                item._oleobj_.Invoke(*(64209, 0, 8, 0, c))  # SendUsingAccount (funciona com late binding)
                break
        else:
            raise ValueError(f"a conta '{conta}' não está no Outlook")
    if acao.startswith("abrir"):
        item.Display(False)
    elif acao.startswith("salvar"):
        item.Save()
    else:
        if not para and not cc and not cco:
            raise ValueError("informe pelo menos um destinatário")
        item.Send()
    return acao


def _pasta_outlook(app, caminho):
    """'' = Caixa de Entrada; 'Caixa de Entrada/Chamados' ou 'Chamados' (subpasta da entrada) ou outra pasta raiz."""
    ns = app.GetNamespace("MAPI")
    entrada = ns.GetDefaultFolder(6)
    partes = [p for p in re.split(r"[\\/]+", str(caminho or "").strip()) if p]
    if not partes:
        return entrada
    nomes_entrada = {"caixa de entrada", "inbox", entrada.Name.casefold()}
    if partes[0].casefold() in nomes_entrada:
        pasta, partes = entrada, partes[1:]
    else:
        pasta = entrada
        try:
            _filha(entrada, partes[0])
        except LookupError:  # não é subpasta da entrada: procura na raiz da conta
            pasta = entrada.Parent
    for p in partes:
        pasta = _filha(pasta, p)
    return pasta


def _filha(pasta, nome):
    for f in pasta.Folders:
        if f.Name.casefold() == nome.casefold():
            return f
    raise LookupError(f"pasta '{nome}' não encontrada dentro de '{pasta.Name}' no Outlook")


def _data(v):
    try:  # o Outlook devolve a hora local marcada como UTC: tirar o fuso dá a hora certa daqui
        return datetime.datetime(v.year, v.month, v.day, v.hour, v.minute, v.second)
    except Exception:
        return None


def _remetente(item):
    try:
        if item.SenderEmailType == "EX":
            return item.Sender.GetExchangeUser().PrimarySmtpAddress or item.SenderName
    except Exception:
        pass
    return getattr(item, "SenderEmailAddress", "") or ""


def _confere(item, remetente, assunto, contem, com_anexo, quais, desde):
    if getattr(item, "Class", 43) != 43:  # só e-mails (não convites, relatórios de entrega...)
        return False
    if quais.startswith("não lidos") and not item.UnRead:
        return False
    if quais.startswith("só os que") and desde and (_data(item.ReceivedTime) or desde) < desde:
        return False
    if remetente:
        quem = f"{item.SenderName} <{_remetente(item)}>".casefold()
        if not any(r.casefold() in quem for r in enderecos(remetente)):
            return False
    if assunto and assunto.casefold() not in str(item.Subject or "").casefold():
        return False
    if contem and contem.casefold() not in str(item.Body or "").casefold():
        return False
    if com_anexo and not item.Attachments.Count:
        return False
    return True


def procurar_outlook(pasta="", remetente="", assunto="", contem="", com_anexo=False, quais=QUAIS[1], desde=None,
                     app=None, limite=300):
    """E-mail mais recente que atende aos filtros, ou None."""
    app = app or _outlook()
    itens = _pasta_outlook(app, pasta).Items
    itens.Sort("[ReceivedTime]", True)
    item = itens.GetFirst()
    n = 0
    while item is not None and n < limite:
        n += 1
        try:
            if quais.startswith("só os que") and desde and (_data(item.ReceivedTime) or desde) < desde:
                return None  # ordenado do mais novo para o mais velho: daqui para trás só tem mais antigos
            if _confere(item, remetente, assunto, contem, com_anexo, quais, desde):
                return item
        except Exception:
            pass
        item = itens.GetNext()
    return None


def nome_seguro(nome):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(nome)).strip(" .") or "anexo"


def salvar_anexos(item, pasta, filtro=""):
    os.makedirs(pasta, exist_ok=True)
    salvos = []
    padroes = [p.strip().casefold() for p in str(filtro or "").split(";") if p.strip()]
    for i in range(1, item.Attachments.Count + 1):
        a = item.Attachments.Item(i)
        nome = nome_seguro(a.FileName)
        if padroes and not any(_casa(nome.casefold(), p) for p in padroes):
            continue
        destino = os.path.join(pasta, nome)
        raiz, ext = os.path.splitext(destino)
        n = 2
        while os.path.exists(destino):
            destino = f"{raiz} ({n}){ext}"
            n += 1
        a.SaveAsFile(destino)
        salvos.append(destino)
    return salvos


def _casa(nome, padrao):
    import fnmatch
    return fnmatch.fnmatch(nome, padrao if any(c in padrao for c in "*?") else f"*{padrao}*")


def dados_do_email(item):
    data = _data(item.ReceivedTime)
    return {"assunto": str(item.Subject or ""), "remetente": _remetente(item), "remetente_nome": str(item.SenderName or ""),
            "corpo": str(item.Body or "").strip(), "data": data.strftime("%d/%m/%Y %H:%M") if data else "",
            "qtd_anexos": str(item.Attachments.Count)}


def mover_outlook(item, app, pasta):
    item.Move(_pasta_outlook(app, pasta))


# --------------------------------------------------------------------------- notificações
def _post(url, dados, timeout=30, json_=True):
    corpo = json.dumps(dados).encode("utf-8") if json_ else urllib.parse.urlencode(dados).encode("utf-8")
    req = urllib.request.Request(url, data=corpo, method="POST", headers={
        "Content-Type": "application/json; charset=utf-8" if json_ else "application/x-www-form-urlencoded",
        "User-Agent": "BotGenesys"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        detalhe = e.read().decode("utf-8", "replace")[:200]
        raise RuntimeError(f"o serviço respondeu {e.code}: {detalhe or e.reason}") from None
    except urllib.error.URLError as e:
        raise RuntimeError(f"sem conexão com o serviço ({e.reason})") from None



def payload(canal, titulo, mensagem, chat_id=""):
    """(endereço extra, dados) do POST de cada serviço."""
    texto = f"{titulo}\n{mensagem}".strip() if titulo else mensagem
    if canal == "Telegram":
        return {"chat_id": chat_id, "text": texto[:4000], "disable_web_page_preview": True}
    if canal == "Microsoft Teams":  # webhook de Workflows (Power Automate) e o conector antigo aceitam este cartão
        corpo = [{"type": "TextBlock", "text": titulo, "weight": "Bolder", "size": "Medium", "wrap": True}] if titulo else []
        corpo.append({"type": "TextBlock", "text": mensagem, "wrap": True})
        return {"type": "message", "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive", "contentUrl": None,
            "content": {"$schema": "http://adaptivecards.io/schemas/adaptive-card.json", "type": "AdaptiveCard",
                        "version": "1.4", "body": corpo}}]}
    if canal == "Slack":
        return {"text": f"*{titulo}*\n{mensagem}" if titulo else mensagem}
    if canal == "Discord":
        return {"content": (f"**{titulo}**\n{mensagem}" if titulo else mensagem)[:1990]}
    return {"titulo": titulo, "mensagem": mensagem, "texto": texto,
            "quando": datetime.datetime.now().isoformat(timespec="seconds")}


def notificar(canal, titulo, mensagem, chave="", chat_id=""):
    """Envia a notificação. chave = token do bot (Telegram) ou endereço do webhook (outros)."""
    if canal.startswith("Windows"):
        return aviso_windows(titulo, mensagem)
    if not chave:
        raise ValueError("falta o token (Telegram) ou o endereço do webhook")
    if canal == "Telegram":
        if not chat_id:
            raise ValueError("falta o chat_id do Telegram (veja a dica do passo)")
        status, resp = _post(f"https://api.telegram.org/bot{chave}/sendMessage", payload(canal, titulo, mensagem,
                                                                                         chat_id))
        if '"ok":true' not in resp.replace(" ", ""):
            raise RuntimeError(f"o Telegram recusou: {resp[:200]}")
        return status
    if not re.match(r"https?://", chave):
        raise ValueError("o endereço do webhook precisa começar com https://")
    return _post(chave, payload(canal, titulo, mensagem))[0]


_SCRIPT_AVISO = r'''
param([string]$Titulo, [string]$Texto)
$ErrorActionPreference = "Stop"
try {
    $null = [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
    $null = [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]
    $esc = [System.Security.SecurityElement]
    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $xml.LoadXml("<toast><visual><binding template='ToastGeneric'><text>" + $esc::Escape($Titulo) +
                 "</text><text>" + $esc::Escape($Texto) + "</text></binding></visual></toast>")
    $app = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
    [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($app).Show(
        [Windows.UI.Notifications.ToastNotification]::new($xml))
    "ok"
} catch {
    Add-Type -AssemblyName System.Windows.Forms
    $n = New-Object System.Windows.Forms.NotifyIcon
    $n.Icon = [System.Drawing.SystemIcons]::Information
    $n.Visible = $true
    $n.ShowBalloonTip(8000, $Titulo, $Texto, "Info")
    Start-Sleep -Seconds 8
    $n.Dispose()
    "balão"
}
'''


def aviso_windows(titulo, mensagem):
    """Notificação do Windows (canto da tela, fica na Central de notificações)."""
    if not WIN_MSG:
        raise RuntimeError("o aviso na tela é do Windows")
    import tempfile
    p = os.path.join(tempfile.gettempdir(), "botgenesys_aviso.ps1")
    with open(p, "w", encoding="utf-8-sig") as f:
        f.write(_SCRIPT_AVISO)
    subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                      "-File", p, "-Titulo", str(titulo or "Bot Genesys")[:120], "-Texto", str(mensagem)[:500]],
                     creationflags=0x08000000, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return "ok"


def esperar(funcao, segundos, dormir=time.sleep, intervalo=5.0):
    """Repete funcao() até devolver algo ou o tempo acabar."""
    limite = time.time() + max(0.0, float(segundos))
    while True:
        r = funcao()
        if r is not None or time.time() >= limite:
            return r
        dormir(min(intervalo, max(0.1, limite - time.time())))
