# -*- coding: utf-8 -*-
"""
Agendamentos do Bot Genesys.

Dois modos:
  - "app":     o próprio app dispara na hora (precisa estar aberto, pode ficar minimizado);
  - "windows": registra no Agendador de Tarefas do Windows (roda mesmo com o app fechado).

Em ambos a execução acontece num processo separado:
    pythonw bot_genesys.py --executar roteiro.json [--csv dados.csv] --agendamento <id>
"""
import datetime as dt
import json
import math
import os
import re
import subprocess
import sys
import uuid

FORMATO = "%Y-%m-%d %H:%M"
REPETICOES = {
    "uma_vez": "Uma vez",
    "diario": "Todos os dias",
    "dias_uteis": "Dias úteis (seg a sex)",
    "semanal": "Dias da semana escolhidos",
    "intervalo": "A cada X minutos",
}
DIAS = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]
DIAS_PS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
PASTA_TAREFAS = "\\BotGenesys\\"
PASTAS_ANTIGAS = ["\\BotChamados\\"]  # versões anteriores (antes do nome Bot Genesys)
TOLERANCIA_MIN = 15  # atraso máximo para ainda executar uma execução que "passou da hora"


def novo(nome, roteiro, quando, repetir="uma_vez", dias=None, intervalo=60, modo="app", planilha=None):
    return {"id": uuid.uuid4().hex[:8], "nome": nome, "roteiro": roteiro, "planilha": planilha,
            "quando": quando.strftime(FORMATO), "repetir": repetir, "dias": sorted(dias or []),
            "intervalo": int(intervalo), "modo": modo, "ativo": True,
            "criado": dt.datetime.now().strftime(FORMATO), "ultima": None, "resultado": ""}


def _dt(texto):
    return dt.datetime.strptime(texto, FORMATO) if texto else None


def proxima(ag, agora=None):
    """Próxima data/hora em que o agendamento deve rodar (pode estar no passado = atrasado). None = nunca."""
    if not ag.get("ativo", True):
        return None
    inicio = _dt(ag["quando"])
    rep = ag.get("repetir", "uma_vez")
    if rep == "uma_vez":
        return None if ag.get("ultima") else inicio
    base = max(inicio, _dt(ag.get("criado")) or inicio)
    if ag.get("ultima"):
        base = max(base, _dt(ag["ultima"]) + dt.timedelta(minutes=1))
    if rep == "intervalo":
        passo = dt.timedelta(minutes=max(1, int(ag.get("intervalo", 60))))
        if base <= inicio:
            return inicio
        k = math.ceil((base - inicio) / passo)
        return inicio + k * passo
    dias_ok = {"diario": set(range(7)), "dias_uteis": {0, 1, 2, 3, 4}}.get(rep, set(ag.get("dias") or []))
    if not dias_ok:
        return None
    cand = dt.datetime.combine(base.date(), inicio.time())
    if cand < base:
        cand += dt.timedelta(days=1)
    for _ in range(8):
        if cand.weekday() in dias_ok:
            return cand
        cand += dt.timedelta(days=1)
    return None


def descrever(ag):
    rep = ag.get("repetir", "uma_vez")
    h = ag["quando"][-5:]
    if rep == "uma_vez":
        d = _dt(ag["quando"])
        return f"Uma vez, {d:%d/%m/%Y} às {h}"
    if rep == "diario":
        return f"Todos os dias às {h}"
    if rep == "dias_uteis":
        return f"Seg a sex às {h}"
    if rep == "semanal":
        return f"{', '.join(DIAS[i] for i in ag.get('dias', []))} às {h}"
    return f"A cada {ag.get('intervalo')} min (desde {_dt(ag['quando']):%d/%m %H:%M})"


def carregar(caminho):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def salvar(caminho, lista):
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(lista, f, ensure_ascii=False, indent=2)
    os.replace(tmp, caminho)


def registrar_resultado(caminho, ag_id, resultado):
    """Chamado pelo processo que executou o agendamento (no modo Windows também marca a última execução)."""
    lista = carregar(caminho)
    for ag in lista:
        if ag.get("id") == ag_id:
            ag["resultado"] = resultado
            if ag.get("modo") == "windows":
                ag["ultima"] = dt.datetime.now().strftime(FORMATO)
    salvar(caminho, lista)


def mesclar(memoria, disco):
    """Traz para a lista em memória os resultados que o processo de execução gravou no disco."""
    por_id = {a.get("id"): a for a in disco}
    for a in memoria:
        d = por_id.get(a.get("id"))
        if not d:
            continue
        if (d.get("ultima") or "") > (a.get("ultima") or ""):
            a["ultima"], a["resultado"] = d.get("ultima"), d.get("resultado", "")
        elif (d.get("ultima") or "") == (a.get("ultima") or "") and d.get("resultado"):
            a["resultado"] = d["resultado"]
    return memoria


# --------------------------------------------------------------------------- #
# Agendador de Tarefas do Windows
# --------------------------------------------------------------------------- #
def _ps(texto):
    return "'" + str(texto).replace("'", "''") + "'"


def nome_tarefa(ag):
    limpo = re.sub(r"[^\w \-]", "", ag.get("nome", "Bot"), flags=re.UNICODE).strip() or "Bot"
    return f"{limpo} [{ag['id']}]"


def comando(ag, script):
    """(executável, argumentos) para rodar o agendamento sem janela de console."""
    exe = sys.executable
    pw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.path.exists(pw):
        exe = pw
    args = f'"{script}" --executar "{ag["roteiro"]}" --agendamento {ag["id"]}'
    if ag.get("planilha"):
        args += f' --csv "{ag["planilha"]}"'
    return exe, args


def script_registro(ag, script, pasta_app):
    exe, args = comando(ag, script)
    at = f"([datetime]'{_dt(ag['quando']):%Y-%m-%dT%H:%M:%S}')"
    rep = ag.get("repetir", "uma_vez")
    if rep == "uma_vez":
        gatilho = f"New-ScheduledTaskTrigger -Once -At {at}"
    elif rep == "diario":
        gatilho = f"New-ScheduledTaskTrigger -Daily -At {at}"
    elif rep in ("dias_uteis", "semanal"):
        dias = range(5) if rep == "dias_uteis" else ag.get("dias", [])
        gatilho = f"New-ScheduledTaskTrigger -Weekly -WeeksInterval 1 -DaysOfWeek {','.join(DIAS_PS[i] for i in dias)} -At {at}"
    else:
        gatilho = (f"New-ScheduledTaskTrigger -Once -At {at} -RepetitionInterval "
                   f"(New-TimeSpan -Minutes {max(1, int(ag.get('intervalo', 60)))}) "
                   f"-RepetitionDuration (New-TimeSpan -Days 3650)")
    return "; ".join([
        "$ErrorActionPreference = 'Stop'",
        f"$a = New-ScheduledTaskAction -Execute {_ps(exe)} -Argument {_ps(args)} -WorkingDirectory {_ps(pasta_app)}",
        f"$t = {gatilho}",
        "$s = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries "
        "-DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 3) -MultipleInstances IgnoreNew",
        f"Register-ScheduledTask -TaskName {_ps(nome_tarefa(ag))} -TaskPath {_ps(PASTA_TAREFAS)} "
        f"-Action $a -Trigger $t -Settings $s -Description {_ps('Bot Genesys: ' + ag.get('nome', ''))} -Force "
        "| Out-Null",
    ])


def _powershell(script):
    if sys.platform != "win32":
        return False, "Agendador do Windows só está disponível no Windows."
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                           capture_output=True, text=True, timeout=60,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        return False, str(e)
    if r.returncode != 0:
        erro = (r.stderr or r.stdout or "erro desconhecido").strip().splitlines()
        return False, erro[0] if erro else "erro desconhecido"
    return True, "ok"


def registrar_windows(ag, script, pasta_app):
    return _powershell(script_registro(ag, script, pasta_app))


def ativar_windows(ag, ativo):
    acao = "Enable-ScheduledTask" if ativo else "Disable-ScheduledTask"
    ok, msg = _powershell(f"{acao} -TaskName {_ps(nome_tarefa(ag))} -TaskPath {_ps(PASTA_TAREFAS)} | Out-Null")
    if not ok:  # agendamento criado por uma versão anterior
        for pasta in PASTAS_ANTIGAS:
            ok2, _ = _powershell(f"{acao} -TaskName {_ps(nome_tarefa(ag))} -TaskPath {_ps(pasta)} | Out-Null")
            if ok2:
                return ok2, "ok"
    return ok, msg


def remover_windows(ag):
    resultado = (True, "ok")
    for pasta in [PASTA_TAREFAS] + PASTAS_ANTIGAS:
        r = _powershell(f"Unregister-ScheduledTask -TaskName {_ps(nome_tarefa(ag))} "
                        f"-TaskPath {_ps(pasta)} -Confirm:$false -ErrorAction SilentlyContinue")
        if pasta == PASTA_TAREFAS:
            resultado = r
    return resultado
