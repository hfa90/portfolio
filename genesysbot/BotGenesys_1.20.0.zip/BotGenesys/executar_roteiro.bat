@echo off
rem Executa o roteiro.json automaticamente (use no Agendador de Tarefas do Windows).
rem Para usar uma planilha: executar_roteiro.bat --csv chamados.csv
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python bot_genesys.py --executar roteiro.json %*
exit /b %errorlevel%
