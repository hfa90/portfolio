# -*- coding: utf-8 -*-
"""
Diagnóstico do Bot Genesys: confere, no computador do usuário, tudo de que os roteiros dependem
(Windows, componentes, Chrome, Excel de verdade, Agendador, criptografia de senhas, pastas, roteiros e logs)
e gera um relatório em texto. Também cuida da limpeza dos logs:
  - apaga logs e prints de erro mais antigos que N dias;
  - procura nos logs as senhas guardadas nos roteiros e troca por ••••••.
"""
import diario
import datetime
import glob
import importlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time

WIN = sys.platform == "win32"
OK, AVISO, ERRO, INFO = "ok", "aviso", "erro", "info"
ICONE = {OK: "✓", AVISO: "⚠", ERRO: "✗", INFO: "•"}
MASCARA = "••••••"
PASTAS_ROTEIROS = ("", "gravacoes", "exemplos")
NAO_ROTEIROS = {"config_app.json", "agendamentos.json"}


def _r(grupo, item, status, detalhe="", acao=None):
    return {"grupo": grupo, "item": item, "status": status, "detalhe": str(detalhe), "acao": acao}


# --------------------------------------------------------------------------- #
# Roteiros e senhas
# --------------------------------------------------------------------------- #
def arquivos_roteiro(app_dir):
    achados = []
    for sub in PASTAS_ROTEIROS:
        for p in sorted(glob.glob(os.path.join(app_dir, sub, "*.json"))):
            if os.path.basename(p).lower() in NAO_ROTEIROS:
                continue
            try:
                with open(p, encoding="utf-8") as f:
                    d = json.load(f)
            except (OSError, ValueError):
                continue
            passos = d.get("passos") if isinstance(d, dict) else d if isinstance(d, list) else None
            if isinstance(passos, list):
                achados.append((p, passos))
    return achados


def senhas_conhecidas(app_dir):
    """Senhas guardadas nos roteiros (protegidas pelo Windows ou marcadas como senha)."""
    try:
        from motor import abrir_texto
    except ImportError:
        abrir_texto = None
    senhas = set()
    for _, passos in arquivos_roteiro(app_dir):
        for s in passos:
            if not isinstance(s, dict):
                continue
            texto = None
            if s.get("texto_protegido") and abrir_texto:
                try:
                    texto = abrir_texto(s["texto_protegido"])
                except Exception:
                    texto = None
            elif s.get("senha") and s.get("texto"):
                texto = s["texto"]
            if texto and len(texto) >= 4 and "{" not in texto:
                senhas.add(texto)
            for k, v in s.items():  # senhas de e-mail, tokens e webhooks (campos 'segredo')
                if k.endswith("_protegido") and k != "texto_protegido" and abrir_texto and isinstance(v, str):
                    try:
                        segredo = abrir_texto(v)
                    except Exception:
                        continue
                    if len(segredo) >= 4:
                        senhas.add(segredo)
    return senhas


def _logs(log_dir):
    return [p for p in glob.glob(os.path.join(log_dir, "*")) if os.path.isfile(p)
            and re.match(r"^(bot_\d{8}\.log|erro_\d{8}_\d{6}\.png|diagnostico_\d{8}_\d{6}\.txt)$",
                         os.path.basename(p))]


def logs_com_senha(log_dir, senhas):
    achados = []
    if not senhas:
        return achados
    for p in _logs(log_dir):
        if not p.endswith((".log", ".txt")):
            continue
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                conteudo = f.read()
        except OSError:
            continue
        if any(s in conteudo for s in senhas):
            achados.append(p)
    return achados


def ocultar_senhas_nos_logs(log_dir, senhas):
    """Troca as senhas conhecidas por •••••• nos logs. Devolve quantos arquivos mudaram."""
    mudou = 0
    for p in logs_com_senha(log_dir, senhas):
        def mascarar(conteudo):
            for s in sorted(senhas, key=len, reverse=True):
                conteudo = conteudo.replace(s, MASCARA)
            return conteudo
        try:
            diario.reescrever(p, mascarar)  # com a trava do log: não cruza com uma linha sendo gravada agora
            mudou += 1
        except OSError:
            pass
    return mudou


def logs_antigos(log_dir, dias):
    limite = time.time() - max(1, int(dias)) * 86400
    return [p for p in _logs(log_dir) if os.path.getmtime(p) < limite]


def limpar_logs(log_dir, dias=30):
    """Apaga logs, prints de erro e relatórios mais antigos que 'dias'. Devolve (apagados, bytes)."""
    n, tam = 0, 0
    for p in logs_antigos(log_dir, dias):
        try:
            t = os.path.getsize(p)
            os.remove(p)
            n, tam = n + 1, tam + t
        except OSError:
            pass
    return n, tam


def manutencao_logs(app_dir, log_dir, dias=30):
    """Rodada automática ao abrir o programa. Devolve um texto curto (ou '' se nada mudou)."""
    partes = []
    try:
        n, tam = limpar_logs(log_dir, dias)
        if n:
            partes.append(f"{n} log(s) com mais de {dias} dias apagado(s) ({_tamanho(tam)})")
    except Exception:
        pass
    try:
        m = ocultar_senhas_nos_logs(log_dir, senhas_conhecidas(app_dir))
        if m:
            partes.append(f"senha(s) ocultada(s) em {m} log(s)")
    except Exception:
        pass
    return "; ".join(partes)


def _tamanho(b):
    for u in ("B", "KB", "MB", "GB"):
        if b < 1024 or u == "GB":
            return f"{b:.0f} {u}" if u == "B" else f"{b:.1f} {u}"
        b /= 1024


# --------------------------------------------------------------------------- #
# Verificações
# --------------------------------------------------------------------------- #
COMPONENTES = [("pyautogui", "pyautogui", True), ("pynput", "pynput", True), ("Pillow", "PIL", True),
               ("OpenCV", "cv2", False), ("websocket-client", "websocket", True),
               ("ttkbootstrap", "ttkbootstrap", True), ("openpyxl", "openpyxl", True)]


def _sistema(app_dir):
    G = "Sistema"
    out = []
    try:
        from versao import NOME, VERSAO
        out.append(_r(G, NOME, INFO, f"versão {VERSAO}"))
    except ImportError:
        pass
    out.append(_r(G, "Windows" if WIN else "Sistema", INFO if WIN else AVISO,
                  platform.platform() + ("" if WIN else " — o Bot Genesys foi feito para Windows")))
    v = sys.version_info
    out.append(_r(G, "Python", OK if v >= (3, 9) else ERRO,
                  f"{platform.python_version()} ({platform.architecture()[0]})"
                  + ("" if v >= (3, 9) else " — instale o Python 3.10 ou mais novo")))
    try:
        import janelas as jc
        esc = jc.escala() if WIN else 1.0
        import pyautogui
        w, h = pyautogui.size()
        mon = 1
        if WIN:
            import ctypes
            mon = ctypes.windll.user32.GetSystemMetrics(80)  # SM_CMONITORS
        out.append(_r(G, "Tela", INFO, f"{w}x{h}, escala {esc * 100:.0f}%, {mon} monitor(es) — roteiros com "
                                       "cliques por posição dependem disso: grave e execute na mesma configuração"))
    except Exception as e:
        out.append(_r(G, "Tela", AVISO, f"não consegui ler ({e})"))
    try:
        import versoes
        ok, txt, _ = versoes.conferir(app_dir)
        out.append(_r(G, "Arquivos do programa", OK if ok else ERRO,
                      txt + ("" if ok else " — atualização pela metade? Use Ajuda → Voltar para uma versão anterior "
                                           "ou peça a versão completa")))
        guardadas = [v for v, _, _ in versoes.listar(app_dir)]
        out.append(_r(G, "Versões guardadas", INFO, ", ".join(guardadas) if guardadas else "nenhuma ainda"))
    except Exception as e:
        out.append(_r(G, "Arquivos do programa", AVISO, f"não consegui conferir ({e})"))
    return out


def _componentes():
    G = "Componentes"
    out = []
    lista = COMPONENTES + ([("pywin32 (Excel/COM)", "win32com.client", True)] if WIN else [])
    for nome, modulo, obrigatorio in lista:
        try:
            m = importlib.import_module(modulo)
            raiz = sys.modules.get(modulo.split(".")[0], m)
            ver = getattr(raiz, "__version__", "") or getattr(raiz, "VERSION", "")
            out.append(_r(G, nome, OK, f"versão {ver}" if ver else "instalado"))
        except Exception as e:
            out.append(_r(G, nome, ERRO if obrigatorio else AVISO,
                          f"não instalado ({e.__class__.__name__}) — rode: pip install -r requirements.txt"))
    return out


def _chrome():
    G = "Chrome"
    out = []
    try:
        import navegador as nav
        c = nav.caminho_chrome()
        out.append(_r(G, "Chrome instalado", OK if c else ERRO,
                      c or "não encontrei o chrome.exe — instale o Google Chrome"))
        out.append(_r(G, "Chrome controlado (porta 9222)", OK if nav.cdp_disponivel() else INFO,
                      "aberto e respondendo" if nav.cdp_disponivel()
                      else "fechado agora (normal: o bot abre quando o roteiro precisar)"))
    except Exception as e:
        out.append(_r(G, "Chrome", ERRO, e))
    try:
        import janelas as jc
        if WIN:
            j = jc.listar_chrome()
            if j:
                e = jc.estado(jc.chrome_principal())
                out.append(_r(G, "Janela do Chrome", OK if e["ok"] else INFO,
                              f"{len(j)} janela(s); a principal está {e['descricao']}"
                              + ("" if e["ok"] else " (o bot maximiza antes de cada ação)")))
    except Exception:
        pass
    return out


def _excel(ao_passo=None):
    """Teste de verdade no Excel: abre (invisível), fórmula, tabela dinâmica, gráficos, PDF e fecha."""
    G = "Excel"
    if not WIN:
        return [_r(G, "Microsoft Excel", INFO, "teste só no Windows")]
    try:
        import excel as xlm
    except ImportError as e:
        return [_r(G, "Microsoft Excel", ERRO, e)]
    if not xlm.HAS_COM:
        return [_r(G, "Microsoft Excel", ERRO, "pywin32 não instalado: sem ele o bot não usa o Excel "
                                               "(pip install pywin32)")]
    out = []
    pasta = tempfile.mkdtemp(prefix="botgenesys_diag_")
    arq = os.path.join(pasta, "teste_diagnostico.xlsx")
    try:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Dados"
        ws.append(["Setor", "Status", "Horas"])
        for i in range(12):
            ws.append([["TI", "RH", "Financeiro"][i % 3], ["Aberto", "Fechado"][i % 2], 2 + i])
        wb.create_sheet("Painel")
        wb.save(arq)
    except Exception as e:
        return [_r(G, "Planilha de teste", ERRO, e)]

    xl = xlm.Excel(lambda *a, **k: None)
    etapas = [
        ("Abrir o Excel (invisível)", lambda: xl.abrir(arq, "Dados", visivel=False)),
        ("Versão do Excel", lambda: _versao_excel(xl)),
        ("Fórmula em português (SOMA)", lambda: (xl.escrever("E1", "=SOMA(C2:C13)", formula_pt=True),
                                                 xl.recalcular(), _confere(xl.ler("E1"), sum(range(2, 14))))[-1]),  # 2+3+...+13 = 90
        ("Fórmula em inglês (SUM)", lambda: (xl.escrever("E2", "=SUM(C2:C13)"), xl.recalcular(),
                                             _confere(xl.ler("E2"), sum(range(2, 14))))[-1]),
        ("Idioma do Excel", lambda: _idioma_excel(xl)),
        ("Tabela dinâmica", lambda: xl.criar_dinamica("Dados!A1", "Painel!A3", "dinTeste", ["Setor"], ["Status"],
                                                      ["Horas"], [], "soma")),
        ("Gráfico de um intervalo", lambda: xl.criar_grafico("Dados!A1:C13",
                                                             "Painel!H2", "colunas", "Teste", "grfIntervalo")),
        ("Gráfico com a seleção numa tabela dinâmica", lambda: (
            xl._selecionar(xl._aba("Painel").Range("A5")),
            xl.criar_grafico("Dados!A1:C13", "Painel!H20", "linhas", "Teste 2", "grfSelecao"))[-1]),
        ("Gráfico dinâmico", lambda: xl.criar_grafico("dinTeste", "Painel!H38", "colunas empilhadas", "Teste 3",
                                                      "grfDinamico")),
        ("Exportar PDF", lambda: os.path.basename(xl.salvar(os.path.join(pasta, "teste.pdf"), "pdf", "Painel"))),
        ("Salvar .xlsx", lambda: os.path.basename(xl.salvar())),
    ]
    etapas.append(("Célula ↔ posição na tela (gravação no Excel)", _celula_na_tela))
    falhou = False
    for nome, fn in etapas:
        if ao_passo:
            ao_passo(f"Excel: {nome}...")
        if falhou:
            out.append(_r(G, nome, INFO, "não testado (etapa anterior falhou)"))
            continue
        t0 = time.time()
        try:
            v = fn()
            det = v if isinstance(v, str) else ""
            out.append(_r(G, nome, OK, (det + "  " if det else "") + f"({time.time() - t0:.1f} s)"))
        except Exception as e:
            out.append(_r(G, nome, ERRO, xlm.erro_legivel(e)))
            falhou = nome.startswith("Abrir")
    try:
        xl.fechar(salvar=False)
    except Exception:
        pass
    shutil.rmtree(pasta, ignore_errors=True)
    return out


def _celula_na_tela():
    import excel_tela as xt
    ok, txt = xt.autoteste()
    if not ok:
        raise RuntimeError(txt)
    return txt


def _versao_excel(xl):
    if xl.modo != "excel":
        raise RuntimeError("abriu pelo openpyxl, não pelo Excel")
    nomes = {"16.0": "Microsoft 365 / 2016 ou mais novo", "15.0": "2013", "14.0": "2010"}
    v = str(xl.app.Version)
    return f"{v} ({nomes.get(v, 'versão antiga')})"


def _idioma_excel(xl):
    cod = xl.idioma_do_excel()
    nomes = {1046: "português do Brasil", 2070: "português de Portugal", 1033: "inglês (EUA)", 2057: "inglês (Reino Unido)",
             3082: "espanhol"}
    return f"{nomes.get(cod, 'código ' + str(cod))} — o bot aceita fórmulas em português e em inglês"


def _confere(v, esperado):
    try:
        if abs(float(v) - esperado) < 1e-6:
            return f"resultado {v:g}" if isinstance(v, float) else f"resultado {v}"
    except (TypeError, ValueError):
        pass
    raise RuntimeError(f"a fórmula deu {v!r}, esperado {esperado}")


def _outros_programas():
    """Elementos de janela (UI Automation) e leitura de texto da tela (OCR do Windows), sem clicar em nada."""
    G = "Outros programas"
    if not WIN:
        return [_r(G, "Elementos de janela e OCR", INFO, "só no Windows")]
    out = []
    for nome, mod, fn, falta in (("Elementos de janela (botão, campo, menu)", "janelas_uia", "autoteste_uia",
                              "sem isso o clique fora do Chrome usa só a imagem/posição — rode instalar.bat"),
                             ("Ler texto da tela (OCR do Windows)", "ocr_tela", "autoteste_ocr",
                              "confira se o Windows tem o idioma Português instalado (Configurações > Idioma)")):
        t0 = time.time()
        try:
            ok, txt = getattr(importlib.import_module(mod), fn)()
        except Exception as e:
            ok, txt = False, str(e)
        st = OK if ok else (AVISO if ok is None else ERRO)
        out.append(_r(G, nome, st, txt + (f"  ({time.time() - t0:.1f} s)" if ok else f" — {falta}")))
    return out


def _agendador():
    G = "Agendador do Windows"
    if not WIN:
        return [_r(G, "Agendador", INFO, "só no Windows")]
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                            "@(Get-ScheduledTask -TaskPath '\\BotGenesys\\' -ErrorAction SilentlyContinue).Count"],
                           capture_output=True, text=True, timeout=40,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            return [_r(G, "Acesso ao Agendador", ERRO, (r.stderr or r.stdout).strip()[:200])]
        n = (r.stdout or "0").strip().splitlines()[-1] if r.stdout.strip() else "0"
        return [_r(G, "Acesso ao Agendador", OK, f"{n} tarefa(s) do Bot Genesys registrada(s)")]
    except Exception as e:
        return [_r(G, "Acesso ao Agendador", ERRO, e)]


def _senhas():
    G = "Senhas"
    try:
        from motor import abrir_texto, proteger_texto
        g = proteger_texto("teste-ÇÃ-123")
        ok = abrir_texto(g) == "teste-ÇÃ-123"
        tipo = "criptografia do Windows (DPAPI)" if g.startswith("dpapi:") else "apenas codificada (fora do Windows)"
        return [_r(G, "Guardar senhas nos roteiros", OK if ok and g.startswith("dpapi:") else AVISO, tipo)]
    except Exception as e:
        return [_r(G, "Guardar senhas nos roteiros", ERRO, e)]


def _pastas(app_dir, log_dir, img_dir):
    G = "Pastas"
    out = []
    for nome, p in (("Pasta do programa", app_dir), ("Logs", log_dir), ("Imagens", img_dir)):
        try:
            os.makedirs(p, exist_ok=True)
            t = os.path.join(p, ".teste_escrita")
            with open(t, "w") as f:
                f.write("ok")
            os.remove(t)
            out.append(_r(G, nome, OK, p))
        except OSError as e:
            out.append(_r(G, nome, ERRO, f"sem permissão de escrita: {p} ({e.strerror})"))
    return out


def _roteiros(app_dir):
    G = "Roteiros"
    out = []
    try:
        from motor import TIPOS
    except ImportError:
        TIPOS = {}
    for p, passos in arquivos_roteiro(app_dir):
        rel = os.path.relpath(p, app_dir)
        problemas = []
        for i, s in enumerate(passos, 1):
            if not isinstance(s, dict):
                continue
            if TIPOS and s.get("tipo") not in TIPOS:
                problemas.append(f"passo {i}: tipo desconhecido '{s.get('tipo')}'")
            img = s.get("imagem")
            if img and not os.path.exists(img if os.path.isabs(img) else os.path.join(app_dir, img)):
                problemas.append(f"passo {i}: imagem não encontrada ({img})")
        out.append(_r(G, rel, AVISO if problemas else OK,
                      "; ".join(problemas[:4]) + (f" (+{len(problemas) - 4})" if len(problemas) > 4 else "")
                      if problemas else f"{len(passos)} passos"))
    if not out:
        out.append(_r(G, "Roteiros", INFO, "nenhum roteiro salvo na pasta do programa"))
    return out


def _logs_check(app_dir, log_dir, dias):
    G = "Logs"
    arquivos = _logs(log_dir)
    tam = sum(os.path.getsize(p) for p in arquivos)
    out = [_r(G, "Pasta de logs", INFO, f"{len(arquivos)} arquivo(s), {_tamanho(tam)}")]
    velhos = logs_antigos(log_dir, dias)
    out.append(_r(G, f"Logs com mais de {dias} dias", AVISO if velhos else OK,
                  f"{len(velhos)} arquivo(s) — são apagados ao abrir o programa" if velhos else "nenhum",
                  "limpar" if velhos else None))
    expostos = logs_com_senha(log_dir, senhas_conhecidas(app_dir))
    out.append(_r(G, "Senhas aparecendo nos logs", ERRO if expostos else OK,
                  ("em " + ", ".join(os.path.basename(p) for p in expostos[:5]) +
                   " — use 'Ocultar senhas nos logs'") if expostos else "nenhuma senha conhecida nos logs",
                  "ocultar" if expostos else None))
    return out


def executar(app_dir, log_dir, img_dir, dias_logs=30, testar_excel=True, ao_passo=None):
    """Roda tudo e devolve a lista de resultados (dicts)."""
    etapas = [("Sistema", lambda: _sistema(app_dir)), ("Componentes", _componentes), ("Chrome", _chrome),
              ("Excel", (lambda: _excel(ao_passo)) if testar_excel else
               (lambda: [_r("Excel", "Teste do Excel", INFO, "pulado")])),
              ("Outros programas", _outros_programas), ("Agendador", _agendador), ("Senhas", _senhas),
              ("Pastas", lambda: _pastas(app_dir, log_dir, img_dir)), ("Roteiros", lambda: _roteiros(app_dir)),
              ("Logs", lambda: _logs_check(app_dir, log_dir, dias_logs))]
    res = []
    for nome, fn in etapas:
        if ao_passo:
            ao_passo(f"Verificando: {nome}...")
        try:
            res.extend(fn())
        except Exception as e:
            res.append(_r(nome, "Verificação", ERRO, f"falhou: {e}"))
    return res


def resumo(resultados):
    n = {s: sum(1 for r in resultados if r["status"] == s) for s in (OK, AVISO, ERRO)}
    if n[ERRO]:
        return ERRO, f"{n[ERRO]} problema(s), {n[AVISO]} aviso(s), {n[OK]} ok"
    if n[AVISO]:
        return AVISO, f"{n[AVISO]} aviso(s), {n[OK]} ok"
    return OK, f"Tudo certo ({n[OK]} verificações ok)"


def relatorio_texto(resultados):
    try:
        from versao import NOME, VERSAO
    except ImportError:
        NOME, VERSAO = "Bot Genesys", "?"
    st, txt = resumo(resultados)
    linhas = [f"Diagnóstico — {NOME} {VERSAO} — {datetime.datetime.now():%d/%m/%Y %H:%M}", f"Resultado: {txt}", ""]
    grupo = None
    for r in resultados:
        if r["grupo"] != grupo:
            grupo = r["grupo"]
            linhas.append(f"[{grupo}]")
        linhas.append(f"  {ICONE[r['status']]} {r['item']}: {r['detalhe']}")
    return "\n".join(linhas) + "\n"


def salvar_relatorio(resultados, log_dir):
    os.makedirs(log_dir, exist_ok=True)
    p = os.path.join(log_dir, f"diagnostico_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt")
    with open(p, "w", encoding="utf-8") as f:
        f.write(relatorio_texto(resultados))
    return p
