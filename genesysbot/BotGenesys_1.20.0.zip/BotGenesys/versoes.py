# -*- coding: utf-8 -*-
"""
Segurança das atualizações do Bot Genesys.

- Cópia de cada versão: ao abrir, o programa guarda uma cópia dos SEUS arquivos de programa em
  _versoes/<versão>/ (só uma vez por versão). Roteiros, planilhas, logs, imagens e o perfil do Chrome
  NÃO entram — eles nunca são trocados por uma atualização.
- Voltar versão: copia de volta os arquivos de uma versão guardada (antes, guarda a atual).
- Manifesto: manifesto.json lista o "carimbo" (SHA-256) de cada arquivo da versão entregue. Ao abrir,
  o programa confere: se algum arquivo ficou de outra versão (atualização pela metade) ou foi alterado,
  avisa no log e no diagnóstico.
"""
import datetime
import glob
import hashlib
import json
import os
import shutil

PASTA = "_versoes"
MANIFESTO = "manifesto.json"
MANTER = 10  # quantas versões guardar
EXTRAS = ("requirements.txt", "README.md", "CHANGELOG.md")
SUBPASTAS = ("interface", "instalador")  # pastas com código do programa (interface: 1.8.0; instalador: 1.10.0)


def _p(app_dir, nome):
    """Caminho real de um nome do manifesto ('interface/editor.py' usa sempre '/')."""
    return os.path.join(app_dir, *nome.split("/"))


def arquivos_programa(app_dir):
    """Arquivos que fazem parte do programa (o que uma atualização troca)."""
    nomes = [os.path.basename(p) for p in glob.glob(os.path.join(app_dir, "*.py"))]
    nomes += [os.path.basename(p) for p in glob.glob(os.path.join(app_dir, "*.bat"))]
    nomes += [n for n in EXTRAS if os.path.exists(os.path.join(app_dir, n))]
    for sub in SUBPASTAS:
        for ext in ("*.py", "*.ps1", "*.ico"):
            nomes += [f"{sub}/{os.path.basename(p)}" for p in glob.glob(os.path.join(app_dir, sub, ext))]
    return sorted(set(nomes))


def _sha(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(65536), b""):
            h.update(bloco)
    return h.hexdigest()


def _versao_atual(app_dir):
    try:
        with open(os.path.join(app_dir, "versao.py"), encoding="utf-8") as f:
            for linha in f:
                if linha.startswith("VERSAO"):
                    return linha.split("=", 1)[1].strip().strip("\"'")
    except OSError:
        pass
    return "desconhecida"


# --------------------------------------------------------------------------- #
# Manifesto
# --------------------------------------------------------------------------- #
def gerar_manifesto(app_dir, versao=None):
    """Usado na entrega de uma versão nova (não pelo usuário)."""
    arquivos = {n: _sha(_p(app_dir, n)) for n in arquivos_programa(app_dir) if n != MANIFESTO}
    dados = {"versao": versao or _versao_atual(app_dir), "gerado": datetime.datetime.now().isoformat(timespec="seconds"),
             "arquivos": arquivos}
    with open(os.path.join(app_dir, MANIFESTO), "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=1)
    return dados


def conferir(app_dir):
    """Devolve (ok, texto, detalhes). detalhes = {'diferentes': [...], 'faltando': [...]}."""
    try:
        with open(os.path.join(app_dir, MANIFESTO), encoding="utf-8") as f:
            man = json.load(f)
    except (OSError, ValueError):
        return True, "sem manifesto (versão anterior à 1.6.0)", {"diferentes": [], "faltando": []}
    dif, falta = [], []
    for nome, sha in man.get("arquivos", {}).items():
        p = _p(app_dir, nome)
        if not os.path.exists(p):
            falta.append(nome)
        elif _sha(p) != sha:
            dif.append(nome)
    v = man.get("versao", "?")
    atual = _versao_atual(app_dir)
    if atual != v and "versao.py" not in dif:
        dif.append("versao.py")
    if not dif and not falta:
        return True, f"todos os {len(man.get('arquivos', {}))} arquivos são da versão {v}", {"diferentes": [], "faltando": []}
    partes = []
    if dif:
        partes.append("diferentes da versão " + v + ": " + ", ".join(dif))
    if falta:
        partes.append("faltando: " + ", ".join(falta))
    return False, "; ".join(partes), {"diferentes": dif, "faltando": falta}


# --------------------------------------------------------------------------- #
# Cópias de versões
# --------------------------------------------------------------------------- #
def guardar_versao_atual(app_dir, forcar=False):
    """Guarda a versão em uso em _versoes/<versão>/ (uma vez). Devolve a pasta criada ou None."""
    versao = _versao_atual(app_dir)
    destino = os.path.join(app_dir, PASTA, versao)
    if os.path.isdir(destino) and not forcar:
        return None
    os.makedirs(destino, exist_ok=True)
    nomes = arquivos_programa(app_dir)
    if os.path.exists(os.path.join(app_dir, MANIFESTO)):
        nomes.append(MANIFESTO)
    for n in set(nomes):
        alvo = _p(destino, n)
        os.makedirs(os.path.dirname(alvo), exist_ok=True)
        shutil.copy2(_p(app_dir, n), alvo)
    with open(os.path.join(destino, "_guardado_em.txt"), "w", encoding="utf-8") as f:
        f.write(datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    _podar(app_dir)
    return destino


def _chave(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def listar(app_dir):
    """Versões guardadas, da mais nova para a mais antiga: [(versao, data_texto, pasta)]."""
    base = os.path.join(app_dir, PASTA)
    out = []
    for p in glob.glob(os.path.join(base, "*")):
        if not os.path.isdir(p) or os.path.basename(p).startswith("_"):
            continue
        try:
            with open(os.path.join(p, "_guardado_em.txt"), encoding="utf-8") as f:
                data = f.read().strip()
        except OSError:
            data = ""
        out.append((os.path.basename(p), data, p))
    return sorted(out, key=lambda x: _chave(x[0]), reverse=True)


def _podar(app_dir):
    for v, _, p in listar(app_dir)[MANTER:]:
        shutil.rmtree(p, ignore_errors=True)


def restaurar(app_dir, versao):
    """Volta os arquivos de programa para 'versao'. Antes, guarda a atual (se ainda não estiver guardada).
    Arquivos que só existem na versão atual vão para _versoes/_removidos/. Devolve a lista restaurada."""
    origem = os.path.join(app_dir, PASTA, versao)
    if not os.path.isdir(origem):
        raise FileNotFoundError(f"versão {versao} não encontrada em {PASTA}")
    guardar_versao_atual(app_dir)
    antigos = set()
    for raiz, _, arquivos in os.walk(origem):
        rel = os.path.relpath(raiz, origem)
        for a in arquivos:
            antigos.add(a if rel == "." else "/".join(rel.split(os.sep) + [a]))
    antigos.discard("_guardado_em.txt")
    atuais = set(arquivos_programa(app_dir))
    removidos = os.path.join(app_dir, PASTA, "_removidos", datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    for n in sorted(atuais - antigos):
        if n.endswith((".py", ".bat")) and n != "versoes.py":  # versoes.py fica: permite voltar de novo
            alvo = _p(removidos, n)
            os.makedirs(os.path.dirname(alvo), exist_ok=True)
            shutil.move(_p(app_dir, n), alvo)
    for n in sorted(antigos):
        alvo = _p(app_dir, n)
        os.makedirs(os.path.dirname(alvo), exist_ok=True)
        shutil.copy2(_p(origem, n), alvo)
    if MANIFESTO not in antigos and os.path.exists(os.path.join(app_dir, MANIFESTO)):
        os.makedirs(removidos, exist_ok=True)
        shutil.move(os.path.join(app_dir, MANIFESTO), os.path.join(removidos, MANIFESTO))
    return sorted(antigos)
