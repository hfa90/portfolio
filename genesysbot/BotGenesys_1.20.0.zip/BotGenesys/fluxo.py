# -*- coding: utf-8 -*-
"""
Lógica de fluxo do roteiro (sem tela): estrutura dos blocos e comparações.

Blocos:  Se ... [Senão ...] Fim do se   |   Repetir ... Fim do repetir   |   Tentar ... [Se der erro ...] Fim do tentar
estrutura() confere se todo bloco foi fechado na ordem certa e devolve, para cada posição, para onde pular.
"""
import datetime
import re

SE_TIPOS = {"se_valor", "se_imagem", "se_arquivo", "se_pagina", "se_janela", "se_texto_tela"}
CONTROLE = SE_TIPOS | {"senao", "fim_se", "repetir", "fim_repetir", "sair_repeticao", "tentar", "se_der_erro",
                       "fim_tentar", "parar_roteiro", "definir_variavel", "executar_roteiro"}
ABRE = SE_TIPOS | {"repetir", "tentar"}
MEIO = {"senao", "se_der_erro"}
FECHA = {"fim_se", "fim_repetir", "fim_tentar"}
FECHAMENTO = {"repetir": "fim_repetir", "tentar": "fim_tentar", **{t: "fim_se" for t in SE_TIPOS}}

OPERADORES = ["é igual a", "é diferente de", "contém", "não contém", "começa com", "termina com",
              "é maior que", "é menor que", "é maior ou igual a", "é menor ou igual a", "está vazio", "não está vazio"]


class PararRoteiro(Exception):
    """Passo 'Parar o roteiro'. sucesso=True termina tudo como concluído."""

    def __init__(self, mensagem, sucesso):
        super().__init__(mensagem)
        self.sucesso = sucesso


class ErroEstrutura(ValueError):
    pass


# --------------------------------------------------------------------------- #
# Estrutura dos blocos
# --------------------------------------------------------------------------- #
_NOMES = {"se": "Se", "repetir": "Repetir", "tentar": "Tentar"}
_FIM = {"se": "Fim do se", "repetir": "Fim do repetir", "tentar": "Fim do tentar"}


def _familia(t):
    return "se" if t in SE_TIPOS else t


def estrutura(tipos, numeros=None):
    """tipos: lista dos tipos dos passos ATIVOS, na ordem. numeros: o número de cada um na lista (para mensagens).
    Devolve {posição: {...}}: se -> senao/fim; senao -> fim; repetir -> fim; fim_repetir -> inicio;
    sair_repeticao -> laco (posição do Repetir); tentar -> erro/fim; se_der_erro -> fim;
    e em todo passo 'tentar' = posição do Tentar mais interno que o protege (ou None)."""
    numeros = numeros or [k + 1 for k in range(len(tipos))]
    info = {k: {} for k in range(len(tipos))}
    pilha = []

    def n(k):
        return numeros[k]

    for k, t in enumerate(tipos):
        protetor = next((e["k"] for e in reversed(pilha) if e["f"] == "tentar" and e["meio"] is None), None)
        info[k]["tentar"] = protetor
        f = _familia(t)
        if t in ABRE:
            pilha.append({"f": f, "k": k, "meio": None})
        elif t in MEIO:
            esperado = "se" if t == "senao" else "tentar"
            nome = "Senão" if t == "senao" else "Se der erro"
            if not pilha or pilha[-1]["f"] != esperado or pilha[-1]["meio"] is not None:
                raise ErroEstrutura(f"o passo {n(k)} ({nome}) não está logo dentro de um bloco "
                                    f"'{_NOMES[esperado]}' (ou o bloco já tem um '{nome}').")
            pilha[-1]["meio"] = k
            info[k]["tentar"] = next((e["k"] for e in reversed(pilha[:-1]) if e["f"] == "tentar"
                                      and e["meio"] is None), None)
        elif t in FECHA:
            esperado = {"fim_se": "se", "fim_repetir": "repetir", "fim_tentar": "tentar"}[t]
            if not pilha or pilha[-1]["f"] != esperado:
                aberto = (f"; o bloco aberto é '{_NOMES[pilha[-1]['f']]}' do passo {n(pilha[-1]['k'])}, que precisa "
                          f"de '{_FIM[pilha[-1]['f']]}' antes") if pilha else ""
                raise ErroEstrutura(f"o passo {n(k)} ({_FIM[esperado]}) não fecha nenhum '{_NOMES[esperado]}'{aberto}.")
            e = pilha.pop()
            info[e["k"]]["fim"] = k
            if esperado == "se":
                info[e["k"]]["senao"] = e["meio"]
            if esperado == "tentar":
                info[e["k"]]["erro"] = e["meio"]
            if e["meio"] is not None:
                info[e["meio"]]["fim"] = k
            if esperado == "repetir":
                info[k]["inicio"] = e["k"]
        elif t == "sair_repeticao":
            laco = next((e["k"] for e in reversed(pilha) if e["f"] == "repetir"), None)
            if laco is None:
                raise ErroEstrutura(f"o passo {n(k)} (Sair da repetição) não está dentro de um 'Repetir'.")
            info[k]["laco"] = laco
    if pilha:
        e = pilha[-1]
        raise ErroEstrutura(f"o bloco '{_NOMES[e['f']]}' do passo {n(e['k'])} não foi fechado: falta o passo "
                            f"'{_FIM[e['f']]}'.")
    return info


def profundidades(tipos):
    """Recuo de cada passo na lista (para mostrar os blocos). Tolera estrutura incompleta."""
    nivel, out = 0, []
    for t in tipos:
        if t in FECHA or t in MEIO:
            nivel = max(0, nivel - 1)
        out.append(nivel)
        if t in ABRE or t in MEIO:
            nivel += 1
    return out


# --------------------------------------------------------------------------- #
# Comparações
# --------------------------------------------------------------------------- #
def numero(v):
    """'1.234,56' / '1234.56' / 'R$ 10' / '15%' -> float, ou None se não for número."""
    s = str(v if v is not None else "").strip().replace("R$", "").replace("%", "").replace(" ", "")
    if not s:
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def data(v):
    s = str(v or "").strip()
    for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def comparar(v1, operador, v2=""):
    """Compara como uma pessoa compararia: números como números (1.234,56 = 1234.56), datas como datas
    (dd/mm/aaaa), textos sem diferenciar maiúsculas e sem espaços nas pontas."""
    a, b = str(v1 if v1 is not None else "").strip(), str(v2 if v2 is not None else "").strip()
    op = operador or "é igual a"
    if op == "está vazio":
        return a == ""
    if op == "não está vazio":
        return a != ""
    na, nb = numero(a), numero(b)
    ta, tb = a.casefold(), b.casefold()
    if op in ("é igual a", "é diferente de"):
        igual = (na == nb) if (na is not None and nb is not None) else (ta == tb)
        return igual if op == "é igual a" else not igual
    if op == "contém":
        return tb in ta
    if op == "não contém":
        return tb not in ta
    if op == "começa com":
        return ta.startswith(tb)
    if op == "termina com":
        return ta.endswith(tb)
    if na is not None and nb is not None:
        x, y = na, nb
    elif data(a) and data(b):
        x, y = data(a), data(b)
    else:
        x, y = ta, tb
    return {"é maior que": x > y, "é menor que": x < y, "é maior ou igual a": x >= y,
            "é menor ou igual a": x <= y}.get(op, False)


def formatar_numero(x):
    return str(int(x)) if float(x).is_integer() else re.sub(r"0+$", "", f"{x:.6f}").rstrip(".")


def dividir_lista(texto, separador=";"):
    sep = separador or ";"
    if sep in ("\\n", "quebra de linha"):
        partes = str(texto or "").splitlines()
    else:
        partes = str(texto or "").split(sep)
    return [p.strip() for p in partes if p.strip()]
