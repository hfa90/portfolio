# -*- coding: utf-8 -*-
"""
Detecta o estado da janela do Google Chrome (e de qualquer outro programa) no Windows e garante que ela esteja
MAXIMIZADA, no monitor PRINCIPAL e em primeiro plano, para que as posições gravadas
(X/Y) caiam sempre no mesmo lugar.

Estados detectados: maximizado, minimizado, metade (encaixado em meia tela),
normal (janela solta), tela_cheia (F11) e "em outro monitor".
"""
import ctypes
import os
import sys
import time

WIN = sys.platform == "win32"

DESCRICAO = {
    "maximizado": "maximizado",
    "minimizado": "minimizado",
    "metade": "aberto pela metade da tela",
    "normal": "em janela (não maximizado)",
    "tela_cheia": "em tela cheia (F11)",
}

if WIN:
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    SW_RESTORE, SW_MAXIMIZE = 9, 3
    GW_OWNER = 4
    MONITOR_DEFAULTTOPRIMARY, MONITOR_DEFAULTTONEAREST = 1, 2
    MONITORINFOF_PRIMARY = 1
    SWP_NOZORDER, SWP_NOACTIVATE = 0x0004, 0x0010
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    VK_F11, KEYEVENTF_KEYUP = 0x7A, 0x0002

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]

    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    user32.EnumWindows.argtypes = [EnumWindowsProc, wintypes.LPARAM]
    user32.EnumChildWindows.argtypes = [wintypes.HWND, EnumWindowsProc, wintypes.LPARAM]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.IsZoomed.argtypes = [wintypes.HWND]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetWindow.restype = wintypes.HWND
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.WindowFromPoint.argtypes = [wintypes.POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongW.restype = ctypes.c_long
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    user32.MonitorFromWindow.restype = wintypes.HANDLE
    user32.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
    user32.MonitorFromPoint.restype = wintypes.HANDLE
    user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MONITORINFO)]
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                                    ctypes.POINTER(wintypes.DWORD)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    user32.GetDpiForWindow.argtypes = [wintypes.HWND]
    user32.GetDpiForWindow.restype = wintypes.UINT
    kernel32.GetCurrentThreadId.restype = wintypes.DWORD

    def _texto(hwnd):
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value

    def _classe(hwnd):
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value

    def _exe(hwnd):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            tam = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(tam)):
                return os.path.basename(buf.value).lower()
            return ""
        finally:
            kernel32.CloseHandle(h)

    def _rect(hwnd):
        r = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        return r

    def _monitor(hmon):
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        user32.GetMonitorInfoW(hmon, ctypes.byref(mi))
        return mi


def retangulo(hwnd):
    """(esquerda, topo, direita, baixo) da janela, limitado à tela."""
    if not WIN or not hwnd:
        return None
    r = _rect(hwnd)
    mi = _monitor(user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)).rcMonitor
    return (max(r.left, mi.left), max(r.top, mi.top), min(r.right, mi.right), min(r.bottom, mi.bottom))


def escala(hwnd=None):
    """Escala do Windows (1.0 = 100%, 1.25 = 125%...)."""
    if not WIN:
        return 1.0
    try:
        dpi = user32.GetDpiForWindow(hwnd) if hwnd else user32.GetDpiForSystem()
        return (dpi or 96) / 96.0
    except Exception:
        return 1.0


def linhas_por_clique():
    """Linhas roladas por 'clique' da roda (configuração do Windows, padrão 3)."""
    if not WIN:
        return 3
    v = wintypes.UINT(3)
    try:
        user32.SystemParametersInfoW(0x0068, 0, ctypes.byref(v), 0)  # SPI_GETWHEELSCROLLLINES
    except Exception:
        pass
    return v.value if 0 < v.value < 100 else 3


def listar_chrome():
    """Janelas principais do Chrome, da que está mais na frente para a mais atrás."""
    if not WIN:
        return []
    achadas = []

    def cb(hwnd, _):
        try:
            if (user32.IsWindowVisible(hwnd) and _classe(hwnd) == "Chrome_WidgetWin_1"
                    and not user32.GetWindow(hwnd, GW_OWNER) and _texto(hwnd)
                    and _exe(hwnd) == "chrome.exe"):
                r = _rect(hwnd)
                if user32.IsIconic(hwnd) or (r.right - r.left > 200 and r.bottom - r.top > 150):
                    achadas.append(hwnd)
        except Exception:
            pass
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return achadas


def chrome_principal():
    """A janela do Chrome em foco ou, se nenhuma estiver em foco, a mais à frente."""
    lista = listar_chrome()
    if not lista:
        return None
    fg = user32.GetForegroundWindow()
    return fg if fg in lista else lista[0]


def estado(hwnd):
    """Retorna dict: estado, monitor_principal, titulo, descricao."""
    if not WIN or not hwnd:
        return None
    if user32.IsIconic(hwnd):
        est = "minimizado"
    elif user32.IsZoomed(hwnd):
        est = "maximizado"
    else:
        r = _rect(hwnd)
        mi = _monitor(user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST))
        m, w = mi.rcMonitor, mi.rcWork
        larg, alt = r.right - r.left, r.bottom - r.top
        larg_w, alt_w = w.right - w.left, w.bottom - w.top
        if (r.left, r.top, r.right, r.bottom) == (m.left, m.top, m.right, m.bottom):
            est = "tela_cheia"
        elif abs(larg - larg_w / 2) <= larg_w * 0.08 and alt >= alt_w * 0.9:
            est = "metade"
        else:
            est = "normal"
    mi = _monitor(user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST))
    principal = bool(mi.dwFlags & MONITORINFOF_PRIMARY)
    desc = DESCRICAO[est] + ("" if principal or est == "minimizado" else " em outro monitor")
    return {"estado": est, "monitor_principal": principal, "titulo": _texto(hwnd), "descricao": desc,
            "ok": est == "maximizado" and principal}


def trazer_para_frente(hwnd):
    if not WIN or not hwnd:
        return False
    fg = user32.GetForegroundWindow()
    if fg == hwnd:
        return True
    atual = kernel32.GetCurrentThreadId()
    outra = user32.GetWindowThreadProcessId(fg, None) if fg else 0
    ligado = bool(outra and outra != atual and user32.AttachThreadInput(atual, outra, True))
    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    finally:
        if ligado:
            user32.AttachThreadInput(atual, outra, False)
    return user32.GetForegroundWindow() == hwnd


def garantir_maximizado(hwnd=None, frente=True):
    """
    Garante o Chrome maximizado no monitor principal (e em primeiro plano).
    Retorna (hwnd, estado_antes, corrigiu) ou (None, None, False) se não há Chrome aberto.
    """
    if not WIN:
        return None, None, False
    hwnd = hwnd or chrome_principal()
    if not hwnd:
        return None, None, False
    antes = estado(hwnd)
    corrigiu = False
    if antes["estado"] == "tela_cheia" and _exe(hwnd) != "chrome.exe":
        antes["estado"] = "maximizado"  # outro programa em tela cheia já ocupa a tela toda (F11 lá faz outra coisa)
    elif antes["estado"] == "tela_cheia":
        trazer_para_frente(hwnd)
        user32.keybd_event(VK_F11, 0, 0, 0)
        user32.keybd_event(VK_F11, 0, KEYEVENTF_KEYUP, 0)
        time.sleep(0.8)
        corrigiu = True
    if not antes["monitor_principal"] and antes["estado"] != "minimizado":
        user32.ShowWindow(hwnd, SW_RESTORE)
        time.sleep(0.2)
        w = _monitor(user32.MonitorFromPoint(wintypes.POINT(0, 0), MONITOR_DEFAULTTOPRIMARY)).rcWork
        user32.SetWindowPos(hwnd, None, w.left + 40, w.top + 40, 1000, 700, SWP_NOZORDER | SWP_NOACTIVATE)
        time.sleep(0.2)
        corrigiu = True
    if corrigiu or antes["estado"] != "maximizado":
        user32.ShowWindow(hwnd, SW_MAXIMIZE)
        corrigiu = True
    if frente:
        trazer_para_frente(hwnd)
    if corrigiu:
        time.sleep(0.5)  # tempo da animação do Windows
        depois = estado(hwnd)
        if depois and not depois["monitor_principal"]:  # ex.: maximizou no monitor errado
            user32.ShowWindow(hwnd, SW_RESTORE)
            w = _monitor(user32.MonitorFromPoint(wintypes.POINT(0, 0), MONITOR_DEFAULTTOPRIMARY)).rcWork
            user32.SetWindowPos(hwnd, None, w.left + 40, w.top + 40, 1000, 700, SWP_NOZORDER)
            user32.ShowWindow(hwnd, SW_MAXIMIZE)
            time.sleep(0.5)
    return hwnd, antes, corrigiu


def janela_em_foco():
    return user32.GetForegroundWindow() if WIN else None


# ------------------------------------------------------------ qualquer programa (Excel, SAP, sistemas desktop...)
GA_ROOT = 2
GWL_STYLE = -16
WS_MAXIMIZEBOX = 0x00010000
IGNORAR_PROCESSOS = {"python.exe", "pythonw.exe", "py.exe", "searchhost.exe",
                     "shellexperiencehost.exe", "startmenuexperiencehost.exe", "textinputhost.exe",
                     "applicationframehost.exe", ""}
IGNORAR_CLASSES = {"Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Progman", "WorkerW", "NotifyIconOverflowWindow",
                   "#32768", "tooltips_class32",
                   # telas do próprio Windows (do explorer.exe), que não são janelas de pasta:
                   "MultitaskingViewFrame", "XamlExplorerHostIslandWindow", "TaskListThumbnailWnd",
                   "ForegroundStaging", "TopLevelWindowForOverflowXamlIsland", "Windows.UI.Core.CoreWindow",
                   "Shell_InputSwitchTopLevelWindow", "DV2ControlHost"}


def _raiz(hwnd):
    return user32.GetAncestor(hwnd, GA_ROOT) if hwnd else None


def _maximizavel(hwnd):
    return bool(user32.GetWindowLongW(hwnd, GWL_STYLE) & WS_MAXIMIZEBOX)


def maximizavel(hwnd):
    """A janela tem botão maximizar? (caixas de diálogo não têm)"""
    return bool(WIN and hwnd and _maximizavel(hwnd))


def info_janela(hwnd):
    """{'processo': 'excel.exe', 'titulo': ..., 'classe': ...} da janela principal que contém hwnd (ou None)."""
    if not WIN or not hwnd:
        return None
    try:
        r = _raiz(hwnd)
        exe, cls = _exe(r), _classe(r)
        if exe in IGNORAR_PROCESSOS or cls in IGNORAR_CLASSES:
            return None
        return {"processo": exe, "titulo": _texto(r)[:120], "classe": cls}
    except Exception:
        return None


def janela_no_ponto(x, y):
    """Janela principal debaixo do ponto da tela."""
    if not WIN:
        return None
    try:
        return _raiz(user32.WindowFromPoint(wintypes.POINT(int(x), int(y))))
    except Exception:
        return None


def listar_janelas(processo, classe=None):
    """Janelas principais de um programa (pelo .exe), da mais à frente para a mais atrás."""
    if not WIN:
        return []
    processo = (processo or "").lower()
    achadas = []

    def cb(hwnd, _):
        try:
            if (user32.IsWindowVisible(hwnd) and not user32.GetWindow(hwnd, GW_OWNER) and _texto(hwnd)
                    and _exe(hwnd) == processo and (not classe or _classe(hwnd) == classe)):
                r = _rect(hwnd)
                if user32.IsIconic(hwnd) or (r.right - r.left > 200 and r.bottom - r.top > 150):
                    achadas.append(hwnd)
        except Exception:
            pass
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return achadas


def titulos_janelas():
    """Títulos de todas as janelas abertas e visíveis (para a condição 'Se: janela aberta')."""
    if not WIN:
        return []
    titulos = []

    def cb(hwnd, _):
        try:
            if user32.IsWindowVisible(hwnd):
                t = _texto(hwnd)
                if t:
                    titulos.append(t)
        except Exception:
            pass
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return titulos


def achar_janela(info):
    """A janela que melhor corresponde à gravada: mesmo programa; prefere a que está em foco, depois mesmo título."""
    if not WIN or not info:
        return None
    lista = listar_janelas(info.get("processo"), info.get("classe")) or listar_janelas(info.get("processo"))
    if not lista:
        return None
    fg = user32.GetForegroundWindow()
    if fg in lista:
        return fg
    titulo = (info.get("titulo") or "").lower()
    for h in lista:
        if titulo and _texto(h).lower() == titulo:
            return h
    if titulo:  # ex.: "Pasta1 - Excel" x "Relatório - Excel": o começo do título (arquivo) costuma bater
        chave = titulo.split(" - ")[0]
        for h in lista:
            if chave and chave in _texto(h).lower():
                return h
    return lista[0]


def garantir_janela(info, frente=True):
    """
    Programa gravado (qualquer um) maximizado, no monitor principal e na frente.
    Janelas sem botão maximizar (caixas de diálogo) só vêm para a frente.
    Retorna (hwnd, estado_antes, corrigiu) ou (None, None, False) se o programa não está aberto.
    """
    hwnd = achar_janela(info)
    if not hwnd:
        return None, None, False
    if not _maximizavel(hwnd):
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, SW_RESTORE)
        if frente:
            trazer_para_frente(hwnd)
        return hwnd, estado(hwnd), False
    return garantir_maximizado(hwnd, frente=frente)


def origem_pagina(hwnd):
    """Canto superior esquerdo (na tela, pixels reais) da área onde a página é desenhada."""
    if not WIN or not hwnd:
        return None
    achadas = []

    def cb(filho, _):
        try:
            if _classe(filho) == "Chrome_RenderWidgetHostHWND" and user32.IsWindowVisible(filho):
                r = _rect(filho)
                achadas.append(((r.right - r.left) * (r.bottom - r.top), r.left, r.top))
        except Exception:
            pass
        return True

    user32.EnumChildWindows(hwnd, EnumWindowsProc(cb), 0)
    if not achadas:
        return None
    _, x, y = max(achadas)
    return x, y


def enviar_para_tras(hwnd):
    """Coloca a janela atrás de todas as outras, sem ativá-la."""
    if WIN and hwnd:
        user32.SetWindowPos(hwnd, 1, 0, 0, 0, 0, 0x0002 | 0x0001 | SWP_NOACTIVATE)  # HWND_BOTTOM


def restaurar_sem_ativar(hwnd):
    """Se estiver minimizada, mostra a janela de novo sem tirar o foco de quem está usando o computador."""
    if WIN and hwnd and user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 4)  # SW_SHOWNOACTIVATE
        time.sleep(0.3)


def aguardar_nova_janela(antes, timeout=15.0):
    """Espera aparecer uma janela do Chrome que não estava em `antes` (ex.: depois de abrir uma URL)."""
    if not WIN:
        return None
    fim = time.time() + timeout
    while time.time() < fim:
        novas = [h for h in listar_chrome() if h not in antes]
        if novas:
            return novas[0]
        time.sleep(0.3)
    return chrome_principal()


def tela_bloqueada():
    """True = o Windows está bloqueado (tela de senha, protetor de tela ou pedido de administrador na frente):
    o mouse e o teclado do bot não chegam a programa nenhum. False = liberada. None = não deu para saber."""
    if not WIN or os.environ.get("BOT_GENESYS_SEM_CHECAR_BLOQUEIO"):  # variável de ambiente = desliga a conferência
        return None
    try:
        u = ctypes.WinDLL("user32", use_last_error=True)
        u.OpenInputDesktop.restype = ctypes.c_void_p
        u.OpenInputDesktop.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        u.GetUserObjectInformationW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong,
                                                ctypes.POINTER(ctypes.c_ulong)]
        u.GetUserObjectInformationW.restype = ctypes.c_int
        u.CloseDesktop.argtypes = [ctypes.c_void_p]
        ctypes.set_last_error(0)
        h = u.OpenInputDesktop(0, 0, 0x0001)
        if not h:
            return True if ctypes.get_last_error() == 5 else None  # acesso negado = área de trabalho do bloqueio
        try:
            nome, n = ctypes.create_unicode_buffer(256), ctypes.c_ulong(0)
            if not u.GetUserObjectInformationW(h, 2, nome, ctypes.sizeof(nome), ctypes.byref(n)):
                return None
            return nome.value.strip().lower() != "default"
        finally:
            u.CloseDesktop(h)
    except Exception:
        return None


def manter_acordado(ligado=True):
    """Enquanto o bot executa, o Windows não suspende nem apaga a tela (vale para a thread que chamou)."""
    if not WIN:
        return False
    try:
        k = ctypes.WinDLL("kernel32")
        k.SetThreadExecutionState.restype = ctypes.c_ulong
        k.SetThreadExecutionState.argtypes = [ctypes.c_ulong]
        return bool(k.SetThreadExecutionState(0x80000003 if ligado else 0x80000000))
    except Exception:
        return False
