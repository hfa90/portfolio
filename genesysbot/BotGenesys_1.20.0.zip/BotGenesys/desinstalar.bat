@echo off
title Bot Genesys - desinstalar
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalador\desinstalar.ps1" %*
if errorlevel 1 pause
