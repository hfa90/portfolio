# -*- coding: utf-8 -*-
"""
Arquivos e Windows SEM mouse e teclado: copiar, mover, renomear, excluir (para a Lixeira), criar pasta,
esperar um arquivo aparecer (ex.: download), listar pasta, zip, abrir arquivo/programa/site, área de
transferência e rodar comandos. Usado pelos passos "Arquivos: ..." e "Windows: ..." (motor_arquivos.py).

Caminhos aceitam ~ (sua pasta de usuário), %USERPROFILE%, curingas (* e ?) e ** para incluir subpastas.
"""
import ctypes
import fnmatch
import glob
import os
import shutil
import subprocess
import sys
import time
import zipfile

WIN_ARQ = sys.platform == "win32"
TEMPORARIOS = (".crdownload", ".tmp", ".part", ".partial", ".download", ".opdownload")
CONFLITOS = ["manter os dois", "substituir", "pular", "parar com erro"]


def arq_caminho(p, base=None):
    """~ e %VARIAVEIS% expandidos; relativo = relativo à pasta do programa (base)."""
    p = str(p or "").strip().strip('"')
    if not WIN_ARQ:  # roteiros feitos no Windows (C:\pasta\arq) também funcionam aqui
        p = p.replace("\\", "/")
    p = os.path.expandvars(os.path.expanduser(p))
    if p and base and not os.path.isabs(p):
        p = os.path.join(base, p)
    return os.path.normpath(p) if p else p


def arq_encontrar(padrao, base=None):
    """Lista de arquivos (não pastas) que batem com o padrão. Sem curinga: o próprio arquivo, se existir."""
    p = arq_caminho(padrao, base)
    if not any(c in p for c in "*?["):
        return [p] if os.path.isfile(p) else []
    return sorted(f for f in glob.glob(p, recursive=True) if os.path.isfile(f))


def _nome_livre(caminho):
    """'relatorio.xlsx' já existe -> 'relatorio (2).xlsx'."""
    if not os.path.exists(caminho):
        return caminho
    raiz, ext = os.path.splitext(caminho)
    n = 2
    while os.path.exists(f"{raiz} ({n}){ext}"):
        n += 1
    return f"{raiz} ({n}){ext}"


def _destino_final(alvo, conflito):
    """Aplica a regra 'se já existir'. Devolve o caminho a usar ou None (= pular)."""
    if not os.path.exists(alvo):
        return alvo
    if conflito == "substituir":
        return alvo
    if conflito == "pular":
        return None
    if conflito == "parar com erro":
        raise FileExistsError(f"já existe: {alvo}")
    return _nome_livre(alvo)


def arq_copiar(origem, destino, conflito="manter os dois", mover=False, base=None):
    """Copia (ou move) os arquivos da origem (aceita curingas) para o destino.
    Destino = pasta (se termina com \\ ou /, se já é pasta ou se são vários arquivos) ou o novo caminho do arquivo.
    Devolve a lista dos caminhos finais."""
    arquivos = arq_encontrar(origem, base)
    if not arquivos:
        raise FileNotFoundError(f"nenhum arquivo encontrado em: {arq_caminho(origem, base)}")
    dest = arq_caminho(destino, base)
    e_pasta = str(destino).rstrip().endswith(("\\", "/")) or os.path.isdir(dest) or len(arquivos) > 1
    if e_pasta:
        os.makedirs(dest, exist_ok=True)
    else:
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    finais = []
    for a in arquivos:
        alvo = os.path.join(dest, os.path.basename(a)) if e_pasta else dest
        if os.path.abspath(alvo) == os.path.abspath(a):
            finais.append(a)
            continue
        alvo = _destino_final(alvo, conflito)
        if alvo is None:
            continue
        (shutil.move if mover else shutil.copy2)(a, alvo)
        finais.append(alvo)
    return finais


def arq_renomear(arquivo, novo_nome, conflito="manter os dois", base=None):
    """Renomeia mantendo a pasta. Novo nome sem extensão = mantém a extensão original."""
    origem = arq_encontrar(arquivo, base)
    if len(origem) != 1:
        raise FileNotFoundError(f"{'nenhum arquivo' if not origem else 'mais de um arquivo'} em: "
                                f"{arq_caminho(arquivo, base)} (renomear é para UM arquivo)")
    origem = origem[0]
    novo = os.path.basename(str(novo_nome).strip())
    if not novo:
        raise ValueError("informe o novo nome")
    if not os.path.splitext(novo)[1]:
        novo += os.path.splitext(origem)[1]
    alvo = os.path.join(os.path.dirname(origem), novo)
    if os.path.abspath(alvo) == os.path.abspath(origem):
        return origem
    alvo = _destino_final(alvo, conflito)
    if alvo is None:
        return origem
    os.replace(origem, alvo) if conflito == "substituir" else os.rename(origem, alvo)
    return alvo


def _proibido_excluir(caminho):
    c = os.path.abspath(caminho).rstrip("\\/")
    raiz = os.path.splitdrive(c)[0] + os.sep if WIN_ARQ else "/"
    protegidos = {raiz.rstrip("\\/"), os.path.expanduser("~").rstrip("\\/")}
    return not c or c in protegidos or os.path.dirname(c) == c


def _para_lixeira(arquivos):
    """Manda para a Lixeira do Windows (dá para recuperar)."""
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]
    FO_DELETE, FOF_SILENT, FOF_NOCONFIRMATION, FOF_ALLOWUNDO, FOF_NOERRORUI = 3, 4, 0x10, 0x40, 0x400
    op = SHFILEOPSTRUCTW(None, FO_DELETE, "\0".join(os.path.abspath(a) for a in arquivos) + "\0\0", None,
                         FOF_SILENT | FOF_NOCONFIRMATION | FOF_ALLOWUNDO | FOF_NOERRORUI, False, None, None)
    r = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if r != 0:
        raise OSError(f"o Windows não conseguiu mandar para a Lixeira (código {r})")


def arq_excluir(padrao, lixeira=True, maximo=50, base=None):
    """Exclui os arquivos (nunca pastas). lixeira=True = recuperável. Recusa mais que 'maximo' de uma vez."""
    arquivos = arq_encontrar(padrao, base)
    if not arquivos:
        return []
    if len(arquivos) > int(maximo):
        raise RuntimeError(f"{len(arquivos)} arquivos batem com '{padrao}' (máximo permitido: {maximo}). "
                           "Confira o padrão ou aumente o máximo no passo.")
    for a in arquivos:
        if _proibido_excluir(a):
            raise RuntimeError(f"por segurança o bot não exclui: {a}")
    if lixeira:
        if not WIN_ARQ:
            raise RuntimeError("a Lixeira só existe no Windows: desmarque 'Mandar para a Lixeira' para excluir de vez")
        _para_lixeira(arquivos)
    else:
        for a in arquivos:
            os.remove(a)
    return arquivos


def arq_criar_pasta(pasta, base=None):
    p = arq_caminho(pasta, base)
    os.makedirs(p, exist_ok=True)
    return p


def arq_listar(pasta, padrao="*", subpastas=False, ordem="mais novo primeiro", base=None):
    raiz = arq_caminho(pasta, base)
    if not os.path.isdir(raiz):
        raise FileNotFoundError(f"pasta não encontrada: {raiz}")
    achados = []
    for r, dirs, arqs in os.walk(raiz):
        for a in arqs:
            if fnmatch.fnmatch(a.lower(), (padrao or "*").lower()):
                achados.append(os.path.join(r, a))
        if not subpastas:
            break
    if ordem == "nome":
        return sorted(achados, key=str.lower)
    return sorted(achados, key=os.path.getmtime, reverse=(ordem != "mais antigo primeiro"))


def _pronto(caminho):
    """Arquivo completo: não é temporário de download e dá para abrir."""
    nome = os.path.basename(caminho).lower()
    if nome.endswith(TEMPORARIOS) or nome.startswith("~$"):
        return False
    try:
        with open(caminho, "rb"):
            return True
    except OSError:
        return False


def arq_esperar(padrao, timeout=120, so_novos=True, desde=None, estavel=1.5, base=None, dormir=time.sleep):
    """Espera um arquivo que bata com o padrão aparecer E terminar de ser gravado (tamanho parado por 'estavel'
    segundos). so_novos: só vale arquivo criado/alterado depois de 'desde'. Devolve o caminho."""
    desde = time.time() if desde is None else desde
    limite = time.time() + float(timeout)
    visto = {}
    while True:
        candidatos = [f for f in arq_encontrar(padrao, base) if _pronto(f)
                      and (not so_novos or os.path.getmtime(f) >= desde - 1)]
        for f in sorted(candidatos, key=os.path.getmtime, reverse=True):
            tam = os.path.getsize(f)
            ant = visto.get(f)
            if ant and ant[0] == tam and time.time() - ant[1] >= float(estavel):
                return f
            if not ant or ant[0] != tam:
                visto[f] = (tam, time.time())
        if time.time() > limite:
            raise TimeoutError(f"nenhum arquivo '{arq_caminho(padrao, base)}' apareceu em {timeout} s")
        dormir(0.5)


def arq_zip(acao, origem, destino, base=None):
    """acao 'compactar': origem (arquivo, pasta ou curinga) -> destino .zip.  'extrair': origem .zip -> pasta."""
    dest = arq_caminho(destino, base)
    if acao == "extrair":
        z = arq_encontrar(origem, base)
        if not z:
            raise FileNotFoundError(f"zip não encontrado: {arq_caminho(origem, base)}")
        os.makedirs(dest, exist_ok=True)
        with zipfile.ZipFile(z[0]) as f:
            f.extractall(dest)
        return dest
    orig = arq_caminho(origem, base)
    if not dest.lower().endswith(".zip"):
        dest += ".zip"
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as f:
        if os.path.isdir(orig):
            for r, _, arqs in os.walk(orig):
                for a in arqs:
                    cam = os.path.join(r, a)
                    f.write(cam, os.path.relpath(cam, os.path.dirname(orig)))
        else:
            arquivos = arq_encontrar(origem, base)
            if not arquivos:
                raise FileNotFoundError(f"nada para compactar em: {orig}")
            for a in arquivos:
                f.write(a, os.path.basename(a))
    return dest


# --------------------------------------------------------------------------- #
# Windows: abrir, área de transferência, comandos
# --------------------------------------------------------------------------- #
def win_abrir(alvo, argumentos="", base=None):
    """Arquivo (no programa padrão), pasta, programa (.exe, com argumentos) ou site (http...)."""
    alvo = str(alvo or "").strip()
    if not alvo:
        raise ValueError("informe o que abrir")
    if not alvo.lower().startswith(("http://", "https://", "mailto:")):
        cam = arq_caminho(alvo, base)
        if os.path.exists(cam):
            alvo = cam
    if argumentos:
        return subprocess.Popen(f'"{alvo}" {argumentos}' if WIN_ARQ else [alvo] + str(argumentos).split(),
                                cwd=os.path.dirname(alvo) if os.path.isfile(alvo) else None)
    if WIN_ARQ:
        os.startfile(alvo)
    else:
        subprocess.Popen(["xdg-open", alvo], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return None


_AREA_SIMULADA = {"texto": ""}  # fora do Windows (testes)


def win_area_copiar(texto):
    texto = str(texto)
    if not WIN_ARQ:
        _AREA_SIMULADA["texto"] = texto
        return
    from ctypes import wintypes
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    k32.GlobalAlloc.restype = ctypes.c_void_p
    k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    u32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
    u32.SetClipboardData.restype = ctypes.c_void_p
    dados = ctypes.create_unicode_buffer(texto)
    tam = ctypes.sizeof(dados)
    for _ in range(20):  # outro programa pode estar com a área de transferência aberta
        if u32.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        raise OSError("a área de transferência está ocupada por outro programa")
    try:
        u32.EmptyClipboard()
        h = k32.GlobalAlloc(0x0002, tam)  # GMEM_MOVEABLE
        p = k32.GlobalLock(h)
        ctypes.memmove(p, dados, tam)
        k32.GlobalUnlock(h)
        if not u32.SetClipboardData(13, h):  # CF_UNICODETEXT
            raise OSError("o Windows recusou o texto na área de transferência")
    finally:
        u32.CloseClipboard()


def win_area_ler():
    if not WIN_ARQ:
        return _AREA_SIMULADA["texto"]
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    u32.GetClipboardData.restype = ctypes.c_void_p
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    for _ in range(20):
        if u32.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        raise OSError("a área de transferência está ocupada por outro programa")
    try:
        h = u32.GetClipboardData(13)
        if not h:
            return ""
        p = k32.GlobalLock(h)
        try:
            return ctypes.wstring_at(p)
        finally:
            k32.GlobalUnlock(h)
    finally:
        u32.CloseClipboard()


def _decodificar(b):
    for enc in ("utf-8", "cp850", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", errors="replace")


def win_comando(comando, shell="cmd", pasta=None, esperar=True, timeout=300):
    """Roda um comando. Devolve (código, saída) — ou (None, '') se não esperar terminar."""
    if shell == "powershell":
        args = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", comando]
        usar_shell = False
    else:
        args, usar_shell = comando, True
    extra = {"creationflags": 0x08000000} if WIN_ARQ else {}  # CREATE_NO_WINDOW: sem janela preta
    if not esperar:
        subprocess.Popen(args, shell=usar_shell, cwd=pasta or None, **extra)
        return None, ""
    r = subprocess.run(args, shell=usar_shell, cwd=pasta or None, capture_output=True, timeout=float(timeout),
                       **extra)
    return r.returncode, (_decodificar(r.stdout) + _decodificar(r.stderr)).strip()


# --------------------------------------------------------------------------- janela "Abrir" / "Salvar como" do Windows
_U32 = {}


def _user32_dialogo():
    """Cópia própria do user32 (as declarações não brigam com as do janelas.py nem da uiautomation)."""
    if "u" not in _U32:
        import ctypes
        from ctypes import wintypes
        u = ctypes.WinDLL("user32", use_last_error=True)
        u.EnumWindows.argtypes = [ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM), wintypes.LPARAM]
        u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.GetDlgItem.argtypes = [wintypes.HWND, ctypes.c_int]
        u.GetDlgItem.restype = wintypes.HWND
        u.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
        u.FindWindowExW.restype = wintypes.HWND
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.SendMessageW.restype = wintypes.LPARAM
        u.IsWindow.argtypes = [wintypes.HWND]
        u.SetForegroundWindow.argtypes = [wintypes.HWND]
        _U32.update(u=u, ct=ctypes, wt=wintypes)
    return _U32["u"]


def _texto_janela(u, h, classe=False):
    ct = _U32["ct"]
    buf = ct.create_unicode_buffer(300)
    (u.GetClassNameW if classe else u.GetWindowTextW)(h, buf, 300)
    return buf.value


def dialogos_de_arquivo():
    """Janelas 'Abrir' / 'Salvar como' do Windows abertas agora: [(hwnd, título)]."""
    if sys.platform != "win32":
        return []
    u = _user32_dialogo()
    achadas = []

    def cada(h, _):
        if u.IsWindowVisible(h) and _texto_janela(u, h, classe=True) == "#32770" and u.GetDlgItem(h, 1148):
            achadas.append((h, _texto_janela(u, h)))  # 1148 = caixa "Nome do arquivo"
        return True
    u.EnumWindows(_U32["ct"].WINFUNCTYPE(_U32["wt"].BOOL, _U32["wt"].HWND, _U32["wt"].LPARAM)(cada), 0)
    return achadas


def _campo_nome(u, dlg):
    caixa = u.GetDlgItem(dlg, 1148)
    if not caixa:
        return None
    if _texto_janela(u, caixa, classe=True) == "Edit":
        return caixa
    combo = u.FindWindowExW(caixa, None, "ComboBox", None) or caixa
    return u.FindWindowExW(combo, None, "Edit", None)


def win_escolher_arquivo(caminho, timeout=20.0, titulo="", dormir=time.sleep):
    """Espera a janela 'Abrir'/'Salvar como' aparecer, escreve o caminho no campo do nome, confere e confirma.
    Devolve o título da janela usada."""
    if sys.platform != "win32":
        raise RuntimeError("a janela 'Abrir' do Windows só existe no Windows")
    u = _user32_dialogo()
    ct, limite = _U32["ct"], time.time() + max(1.0, float(timeout))
    while True:
        lista = [d for d in dialogos_de_arquivo() if not titulo or titulo.casefold() in d[1].casefold()]
        if lista:
            break
        if time.time() >= limite:
            raise TimeoutError(f"a janela 'Abrir' do Windows não apareceu em {timeout:.0f} s")
        dormir(0.3)
    dlg, nome = lista[0]
    dormir(0.4)  # a janela termina de montar
    campo = _campo_nome(u, dlg)
    if not campo:
        raise RuntimeError(f"não achei o campo 'Nome' na janela '{nome}'")
    WM_SETTEXT, WM_GETTEXT, BM_CLICK = 0x000C, 0x000D, 0x00F5
    for _ in range(3):
        u.SendMessageW(campo, WM_SETTEXT, 0, ct.cast(ct.c_wchar_p(caminho), ct.c_void_p).value)
        buf = ct.create_unicode_buffer(1024)
        u.SendMessageW(campo, WM_GETTEXT, 1024, ct.cast(buf, ct.c_void_p).value)
        if buf.value == caminho:
            break
        dormir(0.3)
    else:
        raise RuntimeError("não consegui escrever o caminho no campo 'Nome' da janela")
    botao = u.GetDlgItem(dlg, 1)  # IDOK = Abrir / Salvar
    u.SetForegroundWindow(dlg)
    u.SendMessageW(botao, BM_CLICK, 0, 0)
    fim = time.time() + 8
    while time.time() < fim:
        if not u.IsWindow(dlg) or not u.IsWindowVisible(dlg):
            return nome
        dormir(0.25)
    raise RuntimeError(f"a janela '{nome}' não fechou depois de confirmar (o arquivo existe? veja se abriu um aviso)")


# --------------------------------------------------------------------------- pop-ups / avisos de janelas do Windows
BOTOES_OK = ["ok", "sim", "yes", "aceitar", "continuar", "permitir", "confirmar", "abrir", "salvar", "repetir"]
BOTOES_CANCELAR = ["cancelar", "cancel", "não", "nao", "no", "fechar", "close", "ignorar"]


def _filhas(u, h):
    ct, wt = _U32["ct"], _U32["wt"]
    out = []
    u.EnumChildWindows.argtypes = [wt.HWND, ct.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM), wt.LPARAM]

    def cada(f, _):
        out.append((f, _texto_janela(u, f, classe=True), _texto_janela(u, f)))
        return True
    u.EnumChildWindows(h, ct.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)(cada), 0)
    return out


def win_janelas_com(texto):
    """Janelas visíveis (de outros programas) cujo título — ou o texto de dentro, nas caixas de aviso — contém o
    texto. [(hwnd, título)]."""
    if sys.platform != "win32" or not texto:
        return []
    u = _user32_dialogo()
    ct, wt = _U32["ct"], _U32["wt"]
    u.GetWindowThreadProcessId.argtypes = [wt.HWND, ct.POINTER(wt.DWORD)]
    alvo, meu, achadas = texto.casefold(), os.getpid(), []

    def cada(h, _):
        if not u.IsWindowVisible(h):
            return True
        pid = wt.DWORD()
        u.GetWindowThreadProcessId(h, ct.byref(pid))
        if pid.value == meu:
            return True
        titulo = _texto_janela(u, h)
        if alvo in titulo.casefold():
            achadas.append((h, titulo))
        elif _texto_janela(u, h, classe=True) == "#32770":  # caixa de aviso: procura no texto de dentro
            if any(alvo in t.casefold() for _, c, t in _filhas(u, h) if c in ("Static", "DirectUIHWND", "Edit")):
                achadas.append((h, titulo))
        return True
    u.EnumWindows(ct.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)(cada), 0)
    return achadas


def win_responder(hwnd, acao, botao_texto=""):
    """Responde a janela: 'ok', 'cancelar', 'fechar' ou 'botao' (clica no botão com botao_texto). Sem mouse."""
    u = _user32_dialogo()
    WM_CLOSE, BM_CLICK = 0x0010, 0x00F5
    u.PostMessageW.argtypes = [_U32["wt"].HWND, _U32["wt"].UINT, _U32["wt"].WPARAM, _U32["wt"].LPARAM]
    if acao == "fechar":
        u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
        return "fechou a janela"
    nomes = [botao_texto.casefold()] if acao == "botao" else (BOTOES_OK if acao == "ok" else BOTOES_CANCELAR)
    nomes = [n for n in nomes if n]

    def casa(t):
        t = t.replace("&", "").strip().casefold()
        return any(t == n or (acao == "botao" and n in t) for n in nomes)
    for f, classe, texto in _filhas(u, hwnd):
        if classe == "Button" and texto and casa(texto):
            u.SendMessageW(f, BM_CLICK, 0, 0)
            return f"clicou em '{texto.replace('&', '')}'"
    try:  # janelas modernas (sem botões Win32): pelo UI Automation
        import janelas_uia as uia
        if uia.HAS_UIA:
            with uia._sessao():
                raiz = uia.auto.ControlFromHandle(int(hwnd))
                for n in range(1, 30):
                    b = uia.auto.ButtonControl(searchFromControl=raiz, searchDepth=8, foundIndex=n)
                    if not b.Exists(maxSearchSeconds=0):
                        break
                    if casa(b.Name or ""):
                        b.GetInvokePattern().Invoke()
                        return f"clicou em '{b.Name}'"
    except Exception:
        pass
    if acao == "cancelar":
        u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
        return "fechou a janela (sem botão Cancelar)"
    raise RuntimeError(f"não achei o botão {'/'.join(nomes[:4])} na janela")
