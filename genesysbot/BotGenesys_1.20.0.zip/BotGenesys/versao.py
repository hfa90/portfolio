# -*- coding: utf-8 -*-
"""Nome e versão do programa (MAIOR.MENOR.CORREÇÃO).

MAIOR    muda quando algo deixa de ser compatível (ex.: roteiros antigos precisariam ser refeitos);
MENOR    muda quando entra um recurso novo;
CORREÇÃO muda quando só corrige problemas.
"""
NOME = "Bot Genesys"
VERSAO = "1.20.0"
DATA_VERSAO = "16/11/2026"

# Histórico resumido (o completo está em CHANGELOG.md)
HISTORICO = [
    ("1.20.0", "Histórico de execuções, aviso de tela bloqueada, PC não suspende durante o roteiro, imagens conferidas antes de começar, Chrome do bot mais fechado."),
    ("1.19.1", "Confiabilidade: log gravado na hora, detalhe técnico dos erros no log, salvar sem risco de corromper, trava de execução pelo Windows."),
    ("1.19.0", "Vigiar pop-up, Chrome: anexar sem janela, janela Abrir do Windows segura, IA prevê a cadeia de eventos, salva a correção que deu certo."),
    ("1.18.0", "APLICAR SOLUÇÃO: a IA corrige o roteiro que falhou; botões fixos no rodapé; páginas que carregam imagens sem parar (Gmail) não travam."),
    ("1.17.2", "Correção: a chave salva em IA › Configurar vale mais que a variável ANTHROPIC_API_KEY do Windows."),
    ("1.17.1", "Caixinhas de status arrastáveis (posição lembrada; saem da frente do clique) e chave da IA conferida."),
    ("1.17.0", "Passo Pausar: esperar você (login, captcha; continua sozinho), codificar para link e exemplo IA + Excel + Gmail."),
    ("1.16.0", "IA: criar/alterar roteiro descrevendo, perguntar/extrair, clicar pelo que se vê, explicar erro; OCR de arquivo de imagem."),
    ("1.15.0", "E-mail (enviar pelo Outlook ou SMTP, esperar/ler no Outlook com anexos) e notificações (Windows, Telegram, Teams, Slack, Discord)."),
    ("1.14.3", "Correção: conflito de declaração do GetAncestor entre janelas.py e uiautomation (elementos de janela)."),
    ("1.14.2", "Correção: captura do elemento no Python 3.14 (caminho alternativo pela janela no ponto)."),
    ("1.14.1", "Correção: clique no ícone de dentro de um botão (ex.: Iniciar do Windows 11) agora acha o botão."),
    ("1.14.0", "Clique pelo elemento em qualquer programa do Windows e texto da tela (OCR): ler, clicar e condição."),
    ("1.13.0", "Condições (Se/Senão), repetições, tratamento de erro (Tentar), parar, variáveis e sub-roteiros."),
    ("1.12.1", "Correção: achar célula do Excel que exige rolar a planilha; teste de arrastar não mexe mais nas janelas."),
    ("1.12.0", "Passos de Arquivos e Windows (copiar, mover, renomear, esperar download, zip, abrir, área de transferência, comando)."),
    ("1.11.0", "Gravação no Excel pela célula, passo Arrastar e Ctrl/Shift+clique."),
    ("1.10.0", "Instalador; atalhos rápidos na gravação (Excel); fórmulas em português ou inglês com detecção automática."),
    ("1.9.0", "Motor dividido em partes, janelas.py (antigo janela_chrome.py) e arrumação. Sem mudança de uso."),
    ("1.8.0", "Interface dividida em arquivos por assunto (pasta interface/). Sem mudança de uso."),
    ("1.7.0", "Catálogo de passos: cada tipo de passo definido num lugar só (passos.py). Sem mudança de uso."),
    ("1.6.1", "Correção no teste do Excel do diagnóstico (resultado esperado da SOMA estava errado)."),
    ("1.6.0", "Rede de segurança: testes automáticos, cópia de cada versão, voltar versão e conferência dos arquivos."),
    ("1.5.0", "Diagnóstico do sistema (Ajuda → Verificar sistema) e limpeza automática dos logs, com senhas ocultadas."),
    ("1.4.2", "Correção definitiva do gráfico com Excel visível: seleciona os próprios dados antes de criar o gráfico."),
    ("1.4.1", "Correção: gráfico falhava com o Excel visível logo depois de uma tabela dinâmica; erros do Excel mais claros."),
    ("1.4.0", "Maximiza automaticamente qualquer programa gravado (Excel, sistemas desktop) e pergunta como rodar o Excel."),
    ("1.3.0", "Gráficos no Excel (inclusive gráfico dinâmico) e proteção para não perder gráficos sem o Excel."),
    ("1.2.0", "Tabelas dinâmicas, fórmulas em português preenchidas em intervalos e última linha preenchida."),
    ("1.1.0", "Excel sem mouse (abrir, ler, escrever, copiar, macro, atualizar, salvar/PDF), planilha .xlsx "
              "como lista de chamados com resultado na própria linha e passo 'Ler da página'."),
    ("1.0.0", "Novo nome: Bot Genesys. Versões numeradas, tela 'Sobre' e histórico de mudanças."),
    ("0.5.0", "Rodar em segundo plano, legendas na tela (andamento, erro, conclusão) e exportar para Python."),
    ("0.4.2", "Rolagem executada na aba certa e conferida; correção por imagem mais segura; senhas protegidas."),
    ("0.4.1", "Gravação da rolagem pelo touchpad e pela roda do mouse."),
    ("0.4.0", "Chrome sempre maximizado, visual novo e agendamento de execuções."),
    ("0.3.0", "Gravação automática do processo, planilha CSV, tentativas, desfazer e logs."),
    ("0.2.0", "Aguardar a página carregar (pelo Chrome ou pela tela)."),
    ("0.1.0", "Primeira versão: cliques por posição, digitação, teclas e imagem, com execução visual."),
]
