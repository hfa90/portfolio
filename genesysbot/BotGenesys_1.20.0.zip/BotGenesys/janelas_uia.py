# -*- coding: utf-8 -*-
"""
ELEMENTOS DE JANELA (UI Automation do Windows): o mesmo recurso que leitores de tela e o Power Automate usam.

- capturar_elemento(x, y): na GRAVAÇÃO, qual elemento está debaixo do clique (botão "Salvar", campo "CPF", item de menu...)
  e onde ele fica dentro da janela.
- posicao_elemento(alvo, hwnd): na EXECUÇÃO, acha esse elemento na janela (onde quer que ele esteja agora) e devolve o
  centro dele. Se houver vários parecidos, escolhe o mais perto de onde estava na gravação.
Funciona em programas desktop (Win32, WPF, Windows Forms, a faixa do Excel, o Explorador...). Sem a biblioteca
'uiautomation' (instalada pelo instalar.bat) tudo continua funcionando pela imagem/posição.
"""
import sys

try:
    import uiautomation as auto
    HAS_UIA = sys.platform == "win32"
except Exception:  # não instalada, ou fora do Windows
    auto = None
    HAS_UIA = False

PROCURAR_PROFUNDIDADE = 30
NOMES_GENERICOS = {"", "Pane", "Painel", "Window", "Janela", "Client", "Cliente"}


_u32 = {}


def _user32():
    """Cópia PRÓPRIA do user32: o janelas.py declara GetAncestor(HWND, UINT) no user32 compartilhado, e a
    biblioteca uiautomation chama a mesma função com c_int — o Python recusa ('c_long' object cannot be
    interpreted as an integer). Com uma cópia separada, uma declaração não atrapalha a outra."""
    if "u" not in _u32:
        import ctypes
        from ctypes import wintypes
        u = ctypes.WinDLL("user32", use_last_error=True)
        u.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        u.GetAncestor.restype = wintypes.HWND
        u.WindowFromPoint.argtypes = [wintypes.POINT]
        u.WindowFromPoint.restype = wintypes.HWND
        _u32["u"], _u32["POINT"] = u, wintypes.POINT
    return _u32["u"]


def _topo(c):
    """Janela principal (top-level) do elemento, sem usar o GetTopLevelControl da biblioteca."""
    no, ultimo = c, c
    for _ in range(40):
        if no is None:
            return ultimo
        h = no.NativeWindowHandle
        if h and sys.platform == "win32":
            raiz = _user32().GetAncestor(int(h), 2)  # GA_ROOT
            return auto.ControlFromHandle(int(raiz or h))
        ultimo, no = no, no.GetParentControl()
    return ultimo


def _sessao():
    """O UI Automation precisa ser iniciado em cada linha de execução (thread) que o usa."""
    return auto.UIAutomationInitializerInThread(debug=False)


def _ret(ctrl):
    r = ctrl.BoundingRectangle
    return int(r.left), int(r.top), int(r.right), int(r.bottom)


_motivo = {"txt": ""}  # por que a última captura não deu certo (para o diagnóstico)


def _identificavel(c):
    """(nome, automation_id) se o elemento tem como ser achado de novo; None se é um pedaço genérico."""
    nome, aid = (c.Name or "").strip(), (c.AutomationId or "").strip()
    if aid.isdigit() and len(aid) > 5:  # ids numéricos longos costumam mudar a cada vez que o programa abre
        aid = ""
    if not aid and nome in NOMES_GENERICOS:
        return None
    return nome, aid


def _contem(c, x, y):
    l, t, r, b = _ret(c)
    return l <= x < r and t <= y < b


def _melhor_no_ponto(c, x, y, topo_hwnd):
    """O ponto caiu num pedaço sem nome (ícone dentro do botão, painel interno): sobe até o 'pai' com nome
    (o botão); se não houver, desce até o menor elemento com nome que contém o ponto."""
    p = c
    for _ in range(6):
        p = p.GetParentControl()
        if p is None or p.NativeWindowHandle == topo_hwnd and p.NativeWindowHandle:
            break
        if _identificavel(p) and _contem(p, x, y):
            return p
    return _descer_ate_o_ponto(c, x, y)


def _descer_ate_o_ponto(c, x, y):
    """O menor elemento com nome, debaixo de c, que contém o ponto (ou None)."""
    melhor, fila, vistos = None, [(c, 0)], 0
    while fila and vistos < 800:
        no, prof = fila.pop(0)
        vistos += 1
        if prof >= 12:
            continue
        for f in no.GetChildren():
            if not _contem(f, x, y):
                continue
            if _identificavel(f):
                l, t, r, b = _ret(f)
                area = (r - l) * (b - t)
                if melhor is None or area < melhor[0]:
                    melhor = (area, f)
            fila.append((f, prof + 1))
    return melhor[1] if melhor else None


def _elemento_no_ponto(x, y):
    """Pergunta ao Windows o elemento no ponto. Em algumas combinações de Python/comtypes (ex.: Python 3.14)
    essa pergunta direta falha; aí pega a JANELA no ponto e desce pela árvore de elementos até ele."""
    try:
        return auto.ControlFromPoint(x, y)
    except Exception:
        pass
    u32 = _user32()
    hwnd = u32.WindowFromPoint(_u32["POINT"](x, y))
    if not hwnd:
        return None
    raiz = auto.ControlFromHandle(int(hwnd))
    if raiz is None:
        return None
    return _descer_ate_o_ponto(raiz, x, y) or raiz


def capturar_elemento(x, y):
    """{'nome', 'tipo', 'automation_id', 'classe', 'dx', 'dy', 'janela'} do elemento no ponto, ou None
    (sem nada identificável)."""
    _motivo["txt"] = ""
    if not HAS_UIA:
        _motivo["txt"] = "biblioteca uiautomation ausente"
        return None
    x, y = int(x), int(y)
    try:
        with _sessao():
            c = _elemento_no_ponto(x, y)
            if c is None:
                _motivo["txt"] = "o Windows não devolveu nenhum elemento nesse ponto"
                return None
            topo = _topo(c)
            topo_hwnd = topo.NativeWindowHandle if topo else 0
            if not _identificavel(c):
                achado = _melhor_no_ponto(c, x, y, topo_hwnd)
                if achado is None:
                    _motivo["txt"] = (f"no ponto há só um elemento sem nome ({c.ControlTypeName}, "
                                      f"classe '{c.ClassName}')")
                    return None
                c = achado
            nome, aid = _identificavel(c)
            tl = _ret(topo) if topo else (0, 0, 0, 0)
            return {"nome": nome[:120], "tipo": int(c.ControlType), "tipo_nome": c.ControlTypeName,
                    "automation_id": aid, "classe": (c.ClassName or "")[:80],
                    "dx": x - tl[0], "dy": y - tl[1],
                    "janela": ((topo.Name or "") if topo else "")[:120]}
    except Exception as e:
        _motivo["txt"] = f"erro do UI Automation: {e}"
        return None


def _condicoes(alvo):
    cond = {"ControlType": int(alvo["tipo"])} if alvo.get("tipo") else {}
    if alvo.get("automation_id"):
        cond["AutomationId"] = alvo["automation_id"]
    if alvo.get("nome"):
        cond["Name"] = alvo["nome"]
    if not alvo.get("automation_id") and not alvo.get("nome") and alvo.get("classe"):
        cond["ClassName"] = alvo["classe"]
    return cond


def posicao_elemento(alvo, hwnd=None, espera=3.0):
    """(x, y) do centro do elemento gravado, procurando dentro da janela (hwnd) ou da janela da frente.
    None = não achou (aí o bot usa a imagem ou a posição gravada)."""
    if not HAS_UIA or not alvo:
        return None
    try:
        with _sessao():
            raiz = auto.ControlFromHandle(int(hwnd)) if hwnd else auto.GetForegroundControl()
            if raiz is None:
                return None
            raiz = _topo(raiz) or raiz
            tl = _ret(raiz)
            esperado = (tl[0] + int(alvo.get("dx", 0)), tl[1] + int(alvo.get("dy", 0)))
            cond = _condicoes(alvo)
            if not cond:
                return None
            primeiro = auto.Control(searchFromControl=raiz, searchDepth=PROCURAR_PROFUNDIDADE, foundIndex=1, **cond)
            if not primeiro.Exists(maxSearchSeconds=float(espera), searchIntervalSeconds=0.3):
                return None
            candidatos = [primeiro]
            for n in range(2, 9):  # vários iguais (ex.: vários "OK"): fica com o mais perto da gravação
                c = auto.Control(searchFromControl=raiz, searchDepth=PROCURAR_PROFUNDIDADE, foundIndex=n, **cond)
                if not c.Exists(maxSearchSeconds=0, searchIntervalSeconds=0.1):
                    break
                candidatos.append(c)
            melhores = []
            for c in candidatos:
                l, t, r, b = _ret(c)
                if r - l <= 0 or b - t <= 0:  # escondido / fora da tela
                    continue
                cx, cy = (l + r) // 2, (t + b) // 2
                melhores.append(((cx - esperado[0]) ** 2 + (cy - esperado[1]) ** 2, (cx, cy)))
            return min(melhores)[1] if melhores else None
    except Exception:
        return None


def descrever(alvo):
    """'botão "Salvar"' para os resumos e o log."""
    if not alvo:
        return ""
    tipo = {"ButtonControl": "botão", "EditControl": "campo", "MenuItemControl": "menu", "TabItemControl": "aba",
            "ListItemControl": "item", "TreeItemControl": "item", "CheckBoxControl": "caixa",
            "RadioButtonControl": "opção", "ComboBoxControl": "lista", "HyperlinkControl": "link",
            "DataItemControl": "célula", "TextControl": "texto", "SplitButtonControl": "botão",
            "MenuBarControl": "menu"}.get(alvo.get("tipo_nome", ""), "elemento")
    nome = alvo.get("nome") or alvo.get("automation_id") or alvo.get("classe") or "?"
    return f'{tipo} "{nome[:40]}"'


def autoteste_uia():
    """Sem abrir nada: acha o botão Iniciar da barra de tarefas pelo UI Automation, captura pelo ponto e acha de
    novo pelo elemento. Devolve (ok, texto)."""
    if not HAS_UIA:
        return None, "biblioteca 'uiautomation' não instalada (rode instalar.bat)"
    try:
        with _sessao():
            barra = auto.PaneControl(searchDepth=1, ClassName="Shell_TrayWnd")
            if not barra.Exists(maxSearchSeconds=2):
                return None, "barra de tarefas não encontrada (ela está oculta?)"
            botao = auto.ButtonControl(searchFromControl=barra, searchDepth=6, AutomationId="StartButton")
            if not botao.Exists(maxSearchSeconds=2):
                return None, "botão Iniciar não encontrado na barra de tarefas"
            l, t, r, b = _ret(botao)
            cx, cy = (l + r) // 2, (t + b) // 2
            hwnd = barra.NativeWindowHandle
    except Exception as e:
        return False, f"erro no UI Automation: {e}"
    alvo = capturar_elemento(cx, cy)
    if not alvo:
        return False, f"não consegui capturar o elemento no ponto ({cx}, {cy}): {_motivo['txt']}"
    pos = posicao_elemento(alvo, hwnd=hwnd, espera=2)
    if not pos or abs(pos[0] - cx) > 4 or abs(pos[1] - cy) > 4:
        return False, f"capturou {descrever(alvo)} mas achou em {pos} (esperado ({cx}, {cy}))"
    return True, f"capturou e achou de novo o {descrever(alvo)} da barra de tarefas"
