# -*- coding: utf-8 -*-
"""Passos de ARQUIVOS e WINDOWS (copiar, mover, renomear, excluir, pasta, esperar arquivo, listar, zip, abrir,
área de transferência, comando). Não usam mouse nem teclado: funcionam igual na tela e em segundo plano.

Parte do motor do Bot Genesys (a classe Motor junta as partes em motor.py)."""
import os
import sys
import time

try:
    import arquivos_win as aw
except ImportError:  # arquivo .py exportado: tudo já está neste mesmo arquivo
    aw = sys.modules[__name__]


class ArquivosMixin:

    def _var(self, s, padrao):
        return (str(s.get("variavel") or "").strip().strip("{}")) or padrao

    def _guardar(self, nome, valor, rotulo=""):
        self.vars[nome] = "" if valor is None else str(valor)
        mostra = self.vars[nome] if len(self.vars[nome]) <= 90 else self.vars[nome][:87] + "..."
        self.log(f"{rotulo}{{{nome}}} = {mostra!r}")

    def _passo_arquivos(self, s, cfg):
        t, x, base = s["tipo"], self._x, self.base
        if t in ("arq_copiar", "arq_mover"):
            mover = t == "arq_mover"
            finais = aw.arq_copiar(x(s.get("origem")), x(s.get("destino")), s.get("conflito") or "manter os dois",
                                   mover=mover, base=base)
            self.log(f"{len(finais)} arquivo(s) {'movido(s)' if mover else 'copiado(s)'}.", "ok")
            if finais:
                self._guardar(self._var(s, "arquivo"), finais[-1])
        elif t == "arq_renomear":
            novo = aw.arq_renomear(x(s.get("arquivo")), x(s.get("novo_nome")), s.get("conflito") or "manter os dois",
                                   base=base)
            self.log(f"Renomeado para {os.path.basename(novo)}.", "ok")
            self._guardar(self._var(s, "arquivo"), novo)
        elif t == "arq_excluir":
            lixeira = bool(s.get("lixeira", True))
            feitos = aw.arq_excluir(x(s.get("arquivos")), lixeira, int(s.get("maximo") or 50), base=base)
            self.log(f"{len(feitos)} arquivo(s) excluído(s){' (na Lixeira)' if lixeira and feitos else ''}.", "ok")
        elif t == "arq_pasta":
            self._guardar(self._var(s, "pasta"), aw.arq_criar_pasta(x(s.get("pasta")), base=base), "Pasta pronta: ")
        elif t == "arq_esperar":
            padrao = x(s.get("padrao"))
            self.log(f"Esperando arquivo: {aw.arq_caminho(padrao, base)} (até {s.get('timeout', 120)} s)...")
            achado = aw.arq_esperar(padrao, float(s.get("timeout") or 120), bool(s.get("so_novos", True)),
                                    desde=getattr(self, "_t_passo", None) or time.time(), base=base,
                                    dormir=self._esperar)
            self._guardar(self._var(s, "arquivo"), achado, "Arquivo pronto: ")
        elif t == "arq_listar":
            lista = aw.arq_listar(x(s.get("pasta")), x(s.get("padrao")) or "*", bool(s.get("subpastas")),
                                  s.get("ordem") or "mais novo primeiro", base=base)
            v = self._var(s, "arquivo")
            self.vars[f"{v}_quantidade"] = str(len(lista))
            self.vars[f"{v}_lista"] = "; ".join(lista)
            self.log(f"{len(lista)} arquivo(s) na pasta: {{{v}}} = o primeiro, {{{v}_quantidade}}, {{{v}_lista}}.")
            self._guardar(v, lista[0] if lista else "")
        elif t == "arq_zip":
            r = aw.arq_zip(s.get("acao") or "compactar", x(s.get("origem")), x(s.get("destino")), base=base)
            self._guardar(self._var(s, "arquivo"), r, "Zip pronto: " if s.get("acao") != "extrair" else "Extraído em: ")
        elif t == "win_abrir":
            aw.win_abrir(x(s.get("alvo")), x(s.get("argumentos")), base=base)
            self.log(f"Aberto: {x(s.get('alvo'))}", "ok")
            self._esperar(float(s.get("espera") or 0))
        elif t == "win_area":
            if s.get("acao") == "ler para variável":
                self._guardar(self._var(s, "copiado"), aw.win_area_ler(), "Da área de transferência: ")
            else:
                aw.win_area_copiar(x(s.get("texto")))
                self.log("Texto copiado para a área de transferência (pronto para Ctrl+V).", "ok")
        elif t == "win_escolher_arquivo":
            caminho = aw.arq_caminho(x(s.get("arquivo")), base)
            if not os.path.isabs(caminho):
                caminho = os.path.abspath(caminho)
            self.log(f"Esperando a janela 'Abrir/Salvar' do Windows (até {s.get('timeout', 20)} s)...")
            nome = aw.win_escolher_arquivo(caminho, float(s.get("timeout") or 20), x(s.get("titulo")).strip(),
                                           dormir=self._esperar)
            self.log(f"Janela '{nome}': escolhido {caminho}", "ok")
        elif t == "win_comando":
            cod, saida = aw.win_comando(x(s.get("comando")), s.get("shell") or "cmd",
                                        aw.arq_caminho(x(s.get("pasta")), base) or None, bool(s.get("esperar", True)),
                                        float(s.get("timeout") or 300))
            if cod is None:
                self.log("Comando iniciado (sem esperar terminar).", "ok")
                return
            self._guardar(self._var(s, "saida"), saida, f"Comando terminou (código {cod}): ")
            if cod != 0 and s.get("parar_se_erro", True):
                raise RuntimeError(f"o comando terminou com erro (código {cod}): {saida[-300:]}")
        else:
            raise ValueError(f"tipo de passo desconhecido: {t}")
