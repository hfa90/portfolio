# -*- coding: utf-8 -*-
"""
Excel NA TELA (o Excel que você está usando, visível):
- celula_no_ponto(x, y): na GRAVAÇÃO, qual célula está debaixo do ponto clicado (aba + endereço).
- posicao_da_celula(alvo): na EXECUÇÃO, onde essa célula está na tela agora — muda a aba se preciso, rola até ela
  e CONFERE (pergunta ao Excel qual célula está no ponto calculado) antes de devolver a posição.
Assim um clique gravado numa célula continua acertando a célula mesmo com a planilha rolada, outro zoom,
linhas a mais em cima ou a janela em outro tamanho.
"""
import sys
import time

try:
    import excel as xlm
    import janelas as jc
except ImportError:  # arquivo .py exportado: tudo está neste mesmo arquivo
    xlm = jc = sys.modules[__name__]


def _excel_do_usuario():
    if not xlm.HAS_COM:
        return None
    xlm._iniciar_com()
    try:
        return xlm.win32.GetActiveObject("Excel.Application")
    except Exception:
        return None


def _tentar(fn, vezes=4):
    """O Excel recusa chamadas enquanto edita uma célula ou mostra uma caixa: tenta de novo algumas vezes."""
    for i in range(vezes):
        try:
            return fn()
        except Exception:
            if i == vezes - 1:
                return None
            time.sleep(0.15)
    return None


def _endereco(rng):
    return str(rng.Address).replace("$", "")


def celula_no_ponto(x, y, app=None):
    """{'pasta': 'Relatório.xlsx', 'aba': 'Dados', 'celula': 'B5'} ou None (não é célula: faixa, gráfico...)."""
    app = app or _excel_do_usuario()
    if app is None:
        return None

    def ler():
        win = app.ActiveWindow
        if win is None:
            return None
        obj = win.RangeFromPoint(int(x), int(y))
        if obj is None:
            return None
        try:
            celula = _endereco(obj)
            ws = obj.Worksheet
        except Exception:  # é uma forma/gráfico, não uma célula
            return None
        return {"pasta": str(ws.Parent.Name), "aba": str(ws.Name), "celula": celula}
    return _tentar(ler)


def _mesma_celula(app, r, alvo):
    try:
        return r is not None and app.Intersect(r, alvo.MergeArea) is not None
    except Exception:
        return False


def _achar_na_tela(app, win, rng):
    """Centro da célula na tela, se ela estiver visível — conferido perguntando ao Excel o que há no ponto."""
    pane = win.ActivePane
    cx, cy = rng.Left + rng.Width / 2, rng.Top + rng.Height / 2
    candidatos = [(pane.PointsToScreenPixelsX(cx), pane.PointsToScreenPixelsY(cy))]
    try:  # Excel que não aplica o zoom/escala na conversão: calcula a partir do canto visível
        vr = pane.VisibleRange
        bx, by = pane.PointsToScreenPixelsX(vr.Left), pane.PointsToScreenPixelsY(vr.Top)
        ppp = (jc.escala() if jc.WIN else 1.0) * 96 / 72 * float(win.Zoom) / 100
        candidatos.append((bx + (cx - vr.Left) * ppp, by + (cy - vr.Top) * ppp))
    except Exception:
        pass
    for px, py in candidatos:
        px, py = int(round(px)), int(round(py))
        if _mesma_celula(app, win.RangeFromPoint(px, py), rng):
            return px, py
    return None


def posicao_da_celula(alvo, log=None, app=None):
    """(x, y) do centro da célula na tela, já conferido com o Excel; None se não der (aí o bot usa a posição
    gravada). Troca de pasta/aba e rola a planilha até a célula, se for preciso."""
    app = app or _excel_do_usuario()
    if app is None or not alvo or not alvo.get("celula"):
        return None
    avisar = log or (lambda *a, **k: None)

    def calcular():
        wb = None
        if alvo.get("pasta"):
            try:
                wb = app.Workbooks(alvo["pasta"])
            except Exception:
                wb = None
        wb = wb or app.ActiveWorkbook
        if wb is None:
            return None
        if str(app.ActiveWorkbook.Name) != str(wb.Name):
            wb.Activate()
        try:
            ws = wb.Worksheets(alvo["aba"]) if alvo.get("aba") else app.ActiveSheet
        except Exception:
            ws = app.ActiveSheet
            avisar(f"Aviso: aba '{alvo.get('aba')}' não existe; usando a aba aberta ({ws.Name}).", "erro")
        if str(app.ActiveSheet.Name) != str(ws.Name):
            ws.Activate()
            time.sleep(0.15)
        rng = ws.Range(alvo["celula"])
        win = app.ActiveWindow
        pos = _achar_na_tela(app, win, rng)
        if pos:
            return pos
        # fora da tela (ou cortada na borda): rola até ela — primeira linha/coluna visível um pouco antes da célula
        win.ScrollRow = max(1, int(rng.Row) - 5)
        win.ScrollColumn = max(1, int(rng.Column) - 2)
        limite = time.time() + 1.5
        while time.time() < limite:  # o Excel redesenha a tela um pouco depois de rolar
            time.sleep(0.15)
            pos = _achar_na_tela(app, win, rng)
            if pos:
                return pos
        return None
    return _tentar(calcular, vezes=3)


def texto_alvo(alvo):
    """'Dados!B5' (para os resumos e o log)."""
    if not alvo:
        return ""
    return f"{alvo['aba']}!{alvo['celula']}" if alvo.get("aba") else str(alvo.get("celula", ""))


def _detalhes(app, cel):
    """Para o relatório, se der errado: o que estava visível e onde o bot calculou."""
    try:
        win = app.ActiveWindow
        pane = win.ActivePane
        rng = app.ActiveSheet.Range(cel)
        x = pane.PointsToScreenPixelsX(rng.Left + rng.Width / 2)
        y = pane.PointsToScreenPixelsY(rng.Top + rng.Height / 2)
        no_ponto = win.RangeFromPoint(int(x), int(y))
        return (f"visível {pane.VisibleRange.Address}, zoom {win.Zoom}, ScrollRow {win.ScrollRow}, "
                f"calculado ({x}, {y}) -> {'nada' if no_ponto is None else _endereco(no_ponto)}, "
                f"escala {jc.escala() if jc.WIN else 1}")
    except Exception as e:
        return f"sem detalhes: {e}"


def autoteste():
    """Abre um Excel SEPARADO (visível por alguns segundos), acha células na tela com zoom 100% e 150%
    (inclusive uma que exige rolar) e confere a volta: a célula no ponto calculado é a mesma?
    Devolve (ok, texto)."""
    if not xlm.HAS_COM:
        return None, "precisa do Microsoft Excel (Windows)"
    xlm._iniciar_com()
    app = xlm.win32.DispatchEx("Excel.Application")
    erros, feitos = [], 0
    try:
        app.Visible = True
        app.DisplayAlerts = False
        wb = app.Workbooks.Add()
        ws = wb.Worksheets(1)
        ws.Name = "Teste"
        app.WindowState = -4137  # maximizado
        try:
            if jc.WIN:
                jc.trazer_para_frente(int(app.Hwnd))
        except Exception:
            pass
        time.sleep(0.8)
        for zoom in (100, 150):
            app.ActiveWindow.Zoom = zoom
            app.ActiveWindow.ScrollRow = 1
            app.ActiveWindow.ScrollColumn = 1
            time.sleep(0.3)
            for cel in ("B5", "H30", "C200"):
                pos = posicao_da_celula({"aba": "Teste", "celula": cel}, app=app)
                volta = celula_no_ponto(*pos, app=app) if pos else None
                feitos += 1
                if not volta or volta["celula"] != cel:
                    erros.append(f"{cel} com zoom {zoom}%: {'não achou na tela' if not pos else volta} "
                                 f"[{_detalhes(app, cel)}]")
        wb.Close(SaveChanges=False)
    finally:
        try:
            app.Quit()
        except Exception:
            pass
    if erros:
        return False, "; ".join(erros)
    return True, f"{feitos} células achadas na tela e conferidas (zoom 100% e 150%, com rolagem)"

