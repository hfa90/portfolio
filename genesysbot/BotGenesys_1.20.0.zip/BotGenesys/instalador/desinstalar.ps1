﻿# Remove os atalhos e o ambiente (.venv) do Bot Genesys. Seus roteiros, planilhas, imagens e logs FICAM na pasta.
$Pasta = Split-Path -Parent $PSScriptRoot
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Write-Host "Desinstalar o Bot Genesys (pasta: $Pasta)" -ForegroundColor Cyan
Write-Host "Remove: atalhos e a pasta .venv. NÃO remove: roteiros, planilhas, imagens, logs." -ForegroundColor Yellow
$r = Read-Host "Continuar? (S/N)"
if ($r -notmatch '^[sSyY]') { exit 0 }
Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "Bot Genesys.lnk") -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Programs")) "Bot Genesys") -Recurse -ErrorAction SilentlyContinue
Remove-Item (Join-Path $Pasta ".venv") -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Pronto. Para instalar de novo: instalar.bat" -ForegroundColor Green
