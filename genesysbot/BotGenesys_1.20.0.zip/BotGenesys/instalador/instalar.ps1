﻿# Instalador do Bot Genesys: instala o que falta (Python, bibliotecas), cria os atalhos e verifica o sistema.
# Uso: clique duas vezes em instalar.bat (na pasta do programa). Pode rodar de novo quando quiser: só faz o que falta.
param([switch]$SemPerguntas)

$ErrorActionPreference = "Continue"   # avisos do pip/py em stderr NÃO podem interromper a instalação
$ProgressPreference = "SilentlyContinue"
$env:PYTHONIOENCODING = "utf-8"       # o diagnóstico usa símbolos (✓ ⚠ ✗)
$env:PYTHONUTF8 = "1"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Pasta = Split-Path -Parent $PSScriptRoot
Set-Location $Pasta
$PythonVersao = "3.12.8"
$Log = Join-Path $Pasta "logs\instalacao.log"
New-Item -ItemType Directory -Force -Path (Join-Path $Pasta "logs") | Out-Null

function Escrever($texto, $cor = "Gray") { Write-Host $texto -ForegroundColor $cor; Add-Content -Path $Log -Value $texto -Encoding UTF8 }
function Etapa($n, $texto) { Escrever ""; Escrever "[$n/7] $texto" "Cyan" }
function Ok($texto) { Escrever "      OK  $texto" "Green" }
function Aviso($texto) { Escrever "      !   $texto" "Yellow" }
function Falha($texto) { Escrever "      X   $texto" "Red" }
function Perguntar($texto) {
    if ($SemPerguntas) { return $true }
    $r = Read-Host "      $texto (S/N)"
    return ($r -match '^[sSyY]')
}

$versao = "?"
try { $versao = (Select-String -Path (Join-Path $Pasta "versao.py") -Pattern '^VERSAO = "(.+)"').Matches[0].Groups[1].Value } catch {}
Clear-Host
Escrever "==============================================================" "Cyan"
Escrever "   Instalador do Bot Genesys $versao" "Cyan"
Escrever "   Pasta: $Pasta" "Cyan"
Escrever "==============================================================" "Cyan"
Escrever ("Início: " + (Get-Date -Format "dd/MM/yyyy HH:mm:ss"))

# ---------------------------------------------------------------- 1. Python
function Achar-Python {
    $candidatos = @()
    foreach ($v in @("3.13", "3.12", "3.11", "3.10", "3.14")) {
        try { $p = & py "-$v" -c "import sys; print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { $candidatos += $p.Trim() } } catch {}
    }
    foreach ($nome in @("python", "python3")) {
        $cmd = Get-Command $nome -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source -notlike "*WindowsApps*") { $candidatos += $cmd.Source }
    }
    $candidatos += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }
    foreach ($c in $candidatos) {
        try {
            $ok = & $c -c "import sys, tkinter; print(sys.version_info >= (3, 10))" 2>$null
            if ($LASTEXITCODE -eq 0 -and $ok -match "True") { return $c }
        } catch {}
    }
    return $null
}

Etapa 1 "Python"
$Python = Achar-Python
if ($Python) {
    Ok ("encontrado: " + (& $Python --version) + "  ($Python)")
} else {
    Aviso "Python 3.10 ou mais novo não encontrado. Instalando o Python $PythonVersao (só para o seu usuário)..."
    $instalou = $false
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        try {
            & winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Null
            $env:Path = [Environment]::GetEnvironmentVariable("Path", "User") + ";" + [Environment]::GetEnvironmentVariable("Path", "Machine")
            $instalou = $true
        } catch { Aviso "winget não conseguiu: $_" }
    }
    $Python = Achar-Python
    if (-not $Python) {
        $url = "https://www.python.org/ftp/python/$PythonVersao/python-$PythonVersao-amd64.exe"
        $arq = Join-Path $env:TEMP "python-$PythonVersao-amd64.exe"
        Escrever "      baixando $url"
        try {
            Invoke-WebRequest -Uri $url -OutFile $arq -UseBasicParsing -ErrorAction Stop
            Start-Process -FilePath $arq -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_pip=1" -Wait -ErrorAction Stop
        } catch { Falha "não consegui baixar/instalar o Python: $_" }
        $Python = Achar-Python
    }
    if (-not $Python) {
        Falha "Instale o Python manualmente (python.org, marque 'Add python.exe to PATH') e rode o instalador de novo."
        Read-Host "Enter para sair"; exit 1
    }
    Ok ("instalado: " + (& $Python --version))
}

# ---------------------------------------------------------------- 2. ambiente do programa (.venv)
Etapa 2 "Ambiente do programa (.venv)"
$VenvPy = Join-Path $Pasta ".venv\Scripts\python.exe"
$recriar = $false
if (Test-Path $VenvPy) {
    try { & $VenvPy -c "import sys" 2>$null; if ($LASTEXITCODE -ne 0) { $recriar = $true } } catch { $recriar = $true }
    if ($recriar) { Aviso "o .venv existente está quebrado (Python foi trocado?): recriando" ; Rename-Item (Join-Path $Pasta ".venv") (".venv_quebrado_" + (Get-Date -Format "yyyyMMddHHmmss")) -ErrorAction Stop }
}
if (-not (Test-Path $VenvPy)) {
    & $Python -m venv (Join-Path $Pasta ".venv")
    if ($LASTEXITCODE -ne 0) { Falha "não consegui criar o .venv"; Read-Host "Enter para sair"; exit 1 }
    Ok "criado"
} else { Ok "já existe" }

# ---------------------------------------------------------------- 3. bibliotecas
Etapa 3 "Bibliotecas (requirements.txt)"
& $VenvPy -m pip install --upgrade pip --disable-pip-version-check -q 2>&1 | Out-Null
$tentativa = 0
do {
    $tentativa++
    & $VenvPy -m pip install -r (Join-Path $Pasta "requirements.txt") pytest --disable-pip-version-check -q
    $codigo = $LASTEXITCODE
    if ($codigo -ne 0 -and $tentativa -lt 2) { Aviso "falhou; tentando de novo..." ; Start-Sleep 3 }
} while ($codigo -ne 0 -and $tentativa -lt 2)
if ($codigo -ne 0) { Falha "pip não conseguiu instalar tudo (internet/proxy?). Veja logs\instalacao.log"; Read-Host "Enter para sair"; exit 1 }
Set-Content -Path (Join-Path $Pasta ".venv\instalado_v5.ok") -Value "ok" -Encoding ASCII
Ok "bibliotecas instaladas"

# ---------------------------------------------------------------- 4. Chrome
Etapa 4 "Google Chrome"
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chrome) { Ok "encontrado: $chrome" }
else {
    Aviso "Chrome não encontrado (os roteiros de sites usam o Chrome)."
    if ((Get-Command winget -ErrorAction SilentlyContinue) -and (Perguntar "Instalar o Google Chrome agora?")) {
        try { & winget install -e --id Google.Chrome --silent --accept-package-agreements --accept-source-agreements | Out-Null; Ok "Chrome instalado" }
        catch { Aviso "não consegui instalar o Chrome: $_" }
    }
}

# ---------------------------------------------------------------- 5. Excel
Etapa 5 "Microsoft Excel"
if (Test-Path "Registry::HKEY_CLASSES_ROOT\Excel.Application") { Ok "instalado (passos de Excel usam o Excel de verdade)" }
else { Aviso "não encontrado: os passos de Excel funcionam em modo simples (sem tabela dinâmica, gráfico dinâmico, macro e PDF)" }

# ---------------------------------------------------------------- 6. atalhos
Etapa 6 "Atalhos (Área de Trabalho e Menu Iniciar)"
$icone = Join-Path $Pasta "instalador\bot_genesys.ico"
$pyw = Join-Path $Pasta ".venv\Scripts\pythonw.exe"
$shell = New-Object -ComObject WScript.Shell
function Atalho($caminho, $alvo, $argumentos, $descricao) {
    $a = $shell.CreateShortcut($caminho)
    $a.TargetPath = $alvo
    $a.Arguments = $argumentos
    $a.WorkingDirectory = $Pasta
    $a.Description = $descricao
    if (Test-Path $icone) { $a.IconLocation = $icone }
    $a.Save()
}
$menu = Join-Path ([Environment]::GetFolderPath("Programs")) "Bot Genesys"
New-Item -ItemType Directory -Force -Path $menu | Out-Null
$app = "`"" + (Join-Path $Pasta "bot_genesys.py") + "`""
Atalho (Join-Path ([Environment]::GetFolderPath("Desktop")) "Bot Genesys.lnk") $pyw $app "Bot Genesys $versao"
Atalho (Join-Path $menu "Bot Genesys.lnk") $pyw $app "Bot Genesys $versao"
Atalho (Join-Path $menu "Verificar sistema.lnk") (Join-Path $Pasta "diagnostico.bat") "" "Diagnóstico do Bot Genesys"
Atalho (Join-Path $menu "Testes automáticos.lnk") (Join-Path $Pasta "testar.bat") "" "Testes do Bot Genesys"
Atalho (Join-Path $menu "Pasta do Bot Genesys.lnk") $Pasta "" "Pasta do programa"
Ok "Área de Trabalho: Bot Genesys   |   Menu Iniciar: pasta Bot Genesys"

# ---------------------------------------------------------------- 7. verificação
Etapa 7 "Verificação do sistema (diagnóstico)"
$saida = & $VenvPy (Join-Path $Pasta "bot_genesys.py") --diagnostico 2>&1
$saida | Add-Content -Path $Log -Encoding UTF8
$resultado = ($saida | Select-String -Pattern "^Resultado:" | Select-Object -First 1)
if ($resultado) { Ok ($resultado.ToString().Replace("Resultado: ", "")) }
$saida | Select-String -Pattern "^\s+[✗⚠]" | ForEach-Object { Aviso $_.ToString().Trim() }

Escrever ""
Escrever "==============================================================" "Green"
Escrever "   Pronto! Abra pelo atalho 'Bot Genesys' na Área de Trabalho." "Green"
Escrever "   Registro da instalação: logs\instalacao.log" "Green"
Escrever "==============================================================" "Green"
if (-not $SemPerguntas -and (Perguntar "Abrir o Bot Genesys agora?")) { Start-Process -FilePath $pyw -ArgumentList $app -WorkingDirectory $Pasta }
