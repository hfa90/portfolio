# -*- coding: utf-8 -*-
"""Gera o pacote para instalar o Bot Genesys em OUTRO computador: BotGenesys_<versão>.zip
Leva só o programa (+ exemplos e testes). NÃO leva: seus roteiros, planilhas, logs, imagens gravadas,
configurações, agendamentos, perfil do Chrome, .venv e as cópias de versões.
Uso: .venv\\Scripts\\python instalador\\empacotar.py  (o .zip fica na pasta do programa)"""
import os
import sys
import zipfile

PASTA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PASTA)

import versoes  # noqa: E402

EXTRAS = ["manifesto.json", "exemplo_roteiro.json", "exemplo_chamados.csv"]
PASTAS = ["instalador", "testes", "exemplos"]
IGNORAR = ("__pycache__", ".pyc", "~$", "saida")


def arquivos():
    nomes = versoes.arquivos_programa(PASTA) + [n for n in EXTRAS if os.path.exists(os.path.join(PASTA, n))]
    for sub in PASTAS:
        for raiz, dirs, arqs in os.walk(os.path.join(PASTA, sub)):
            dirs[:] = [d for d in dirs if not any(i in d for i in IGNORAR)]
            for a in arqs:
                if not any(i in a for i in IGNORAR):
                    nomes.append(os.path.relpath(os.path.join(raiz, a), PASTA).replace(os.sep, "/"))
    return sorted(set(nomes))


def empacotar(destino=None):
    from versao import VERSAO
    destino = destino or os.path.join(PASTA, f"BotGenesys_{VERSAO}.zip")
    lista = arquivos()
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for n in lista:
            z.write(os.path.join(PASTA, *n.split("/")), f"BotGenesys/{n}")
        z.writestr("BotGenesys/LEIA-ME.txt",
                   f"Bot Genesys {VERSAO}\r\n\r\n1. Extraia esta pasta (ex.: Documentos\\BotGenesys).\r\n"
                   "2. Clique duas vezes em instalar.bat.\r\n"
                   "   O instalador instala o Python (se faltar), as bibliotecas, cria os atalhos e verifica tudo.\r\n"
                   "3. Abra pelo atalho 'Bot Genesys' na Área de Trabalho.\r\n")
    return destino, len(lista)


if __name__ == "__main__":
    caminho, n = empacotar(sys.argv[1] if len(sys.argv) > 1 else None)
    print(f"Pacote criado: {caminho} ({n} arquivos)")
