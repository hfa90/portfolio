# -*- coding: utf-8 -*-
"""
CATÁLOGO DE PASSOS do Bot Genesys — cada tipo de passo é definido AQUI, num lugar só:
nome, ícone, campos do formulário, dica, texto do resumo (lista de passos), validação do formulário
e características (usa a tela? pode tentar de novo?).

Para criar um tipo de passo novo: acrescente um Passo(...) em CATALOGO e escreva como ele executa no motor.
Os testes (testar.bat) conferem que todo tipo do catálogo funciona na tela e no motor.

Campos: (chave, rótulo, tipo, padrão, opções)
  tipo: "str", "int", "float", "bool", "choice" (opções = lista), "text" (várias linhas),
        "pos" (posição X/Y na tela), "img" (imagem de referência), "arq" (arquivo),
        "formula" (valor/fórmula do Excel, com o botão ƒx da lista de funções)
"""
import os

BOTOES = ["esquerdo", "direito", "meio"]
SEGURAR = ["nenhuma", "ctrl", "shift", "ctrl+shift", "alt"]
NAVEGADORES = {"chrome.exe"}


class Passo:
    __slots__ = ("tipo", "nome", "icone", "campos", "dica", "resumo", "validar", "tela", "retentavel")

    def __init__(self, tipo, nome, icone, campos, dica="", resumo=None, validar=None, tela=False, retentavel=False):
        self.tipo = tipo
        self.nome = nome              # aparece na lista "Ação" do formulário
        self.icone = icone            # aparece na lista de passos
        self.campos = campos          # formulário
        self.dica = dica              # texto de ajuda abaixo do formulário
        self.resumo = resumo          # função(passo) -> texto da coluna "Detalhes"
        self.validar = validar        # função(passo, ctx) -> None ou (título, mensagem de erro)
        self.tela = tela              # usa mouse/teclado/tela (não roda com o Excel/Chrome escondidos)
        self.retentavel = retentavel  # pode tentar de novo se falhar (opção "tentativas")


# --------------------------------------------------------------------------- #
# Utilidades usadas pelos resumos e pelo motor
# --------------------------------------------------------------------------- #
def pixels_rolagem(s):
    """Pixels do passo de rolagem (+ desce). Converte roteiros antigos que usavam 'quantidade' (cliques da roda)."""
    if s.get("pixels") not in (None, ""):
        return int(float(s["pixels"]))
    return -int(float(s.get("quantidade", -3))) * 100


def outro_programa(passo):
    """Nome do programa (ex.: 'excel.exe') se o passo foi gravado fora do Chrome; senão ''."""
    j = passo.get("janela") if isinstance(passo, dict) else None
    prog = (j or {}).get("processo", "") if isinstance(j, dict) else ""
    return prog if prog and prog not in NAVEGADORES else ""


def _vazio(d, campo):
    return not str(d.get(campo, "")).strip()


# --------------------------------------------------------------------------- #
# Resumos (coluna "Detalhes" da lista de passos)
# --------------------------------------------------------------------------- #
def _celula(alvo):
    return (f"{alvo['aba']}!{alvo['celula']}" if alvo.get("aba") else str(alvo.get("celula", ""))) if alvo else ""


def _segurar(s):
    seg = s.get("segurar") or "nenhuma"
    return "" if seg == "nenhuma" else f"  + segurando {seg.upper()}"


def _r_clique(s):
    txt = f"({s.get('x')}, {s.get('y')})  {s.get('botao', 'esquerdo')}  x{s.get('cliques', 1)}"
    alvo = s.get("alvo") or {}
    if alvo.get("texto") or alvo.get("rotulo"):
        txt += f"  [{(alvo.get('texto') or alvo.get('rotulo'))[:30]}]"
    elif alvo.get("tag"):
        txt += f"  [{alvo['tag']}]"
    if s.get("alvo_excel"):
        txt += f"  [célula {_celula(s['alvo_excel'])}]"
    elif s.get("alvo_uia"):
        txt += f"  [{_elemento(s['alvo_uia'])}]"
    return txt + _segurar(s)


def _elemento(a):
    tipo = {"ButtonControl": "botão", "EditControl": "campo", "MenuItemControl": "menu", "TabItemControl": "aba",
            "ListItemControl": "item", "TreeItemControl": "item", "CheckBoxControl": "caixa",
            "RadioButtonControl": "opção", "ComboBoxControl": "lista", "HyperlinkControl": "link",
            "SplitButtonControl": "botão"}.get(a.get("tipo_nome", ""), "elemento")
    return f'{tipo} "{(a.get("nome") or a.get("automation_id") or "?")[:30]}"'


def _r_arrastar(s):
    txt = f"({s.get('x')}, {s.get('y')}) → ({s.get('x2')}, {s.get('y2')})  {s.get('botao', 'esquerdo')}"
    if s.get("alvo_excel") or s.get("alvo_excel_fim"):
        txt += f"  [{_celula(s.get('alvo_excel')) or '?'} → {_celula(s.get('alvo_excel_fim')) or '?'}]"
    return txt + _segurar(s)


def _r_digitar(s):
    if s.get("senha"):
        txt = "•••••• (senha)"
    else:
        v = s.get("texto", "").replace("\n", " ⏎ ")
        txt = f"\"{v[:45]}{'…' if len(v) > 45 else ''}\""
    if s.get("enter"):
        txt += "  + Enter"
    return txt


def _r_tecla(s):
    txt = s.get("teclas", "")
    if int(s.get("repetir", 1)) > 1:
        txt += f"  x{s.get('repetir')}"
    return txt


def _r_aguardar(s):
    txt = f"{s.get('metodo', 'automático')}, até {s.get('timeout')} s"
    if s.get("seletor"):
        txt += f", elemento {s.get('seletor')}"
    return txt


def _r_imagem(s):
    return f"{os.path.basename(s.get('imagem', ''))}  (prec. {s.get('confianca')})"


def _r_rolar(s):
    px = pixels_rolagem(s)
    txt = f"{'↓ desce' if px > 0 else '↑ sobe'} {abs(px)} px"
    if s.get("alvo_y") not in (None, ""):
        txt += f" (até {s['alvo_y']} px{' na área ' + s['seletor'] if s.get('seletor') else ''})"
    if s.get("x") or s.get("y"):
        txt += f" em ({s.get('x')}, {s.get('y')})"
    origem = {"roda": "roda do mouse", "touchpad": "touchpad", "pagina": "lido da página"}.get(s.get("origem"))
    if origem:
        txt += f"  · {origem}"
    return txt


def _r_ler_pagina(s):
    txt = f"{s.get('seletor') or 'página inteira'} → {{{s.get('variavel', '')}}}"
    if s.get("regex"):
        txt += f"  (padrão {s['regex']})"
    return txt


def _r_excel_abrir(s):
    txt = os.path.basename(str(s.get("arquivo", ""))) + (f" [{s['aba']}]" if s.get("aba") else "")
    if s.get("visivel"):
        txt += "  (visível)"
    return txt


def _r_excel_dinamica(s):
    partes = [f"linhas: {s['linhas']}" if s.get("linhas") else "",
              f"colunas: {s['colunas']}" if s.get("colunas") else "",
              f"{s.get('funcao', 'soma')} de {s['valores']}" if s.get("valores") else "",
              f"filtro: {s['filtros']}" if s.get("filtros") else ""]
    return f"{s.get('nome', '')} em {s.get('destino', '')}  ({'; '.join(p for p in partes if p)})"


def _r_excel_salvar(s):
    return ((os.path.basename(str(s.get("arquivo") or "")) or "mesmo arquivo")
            + (f"  [{s['formato']}]" if s.get("formato") not in (None, "", "mesmo") else "")
            + ("  + fechar" if s.get("fechar") else ""))


# --------------------------------------------------------------------------- #
# Validações do formulário. ctx: existe(caminho), parse_teclas(texto), separar_ref(ref), expandir_teste(texto)
# --------------------------------------------------------------------------- #
def _v_clique(d, ctx):
    if (d["x"], d["y"]) == (0, 0):
        return "Posição", "Capture a posição (F8) antes. O canto (0,0) é a parada de emergência."
    if d.get("conferir") and (not d.get("imagem") or not ctx.existe(d["imagem"])):
        return "Imagem", "Para 'Conferir pela imagem' capture uma imagem de referência."
    return None


def _v_arrastar(d, ctx):
    if (d["x"], d["y"]) == (0, 0):
        return "Posição", "Capture a posição inicial (F8). O canto (0,0) é a parada de emergência."
    if (int(d.get("x2", 0)), int(d.get("y2", 0))) == (d["x"], d["y"]):
        return "Arrastar", "O ponto onde soltar precisa ser diferente do ponto inicial."
    return None


def _v_variavel(d, ctx):
    if _vazio(d, "variavel"):
        return "Variável", "Informe o nome da variável onde guardar o valor (ex.: numero_chamado)."
    return None


def _v_celula(d, ctx):
    try:
        ctx.separar_ref(ctx.expandir_teste(d["celula"]))
    except ValueError as e:
        return "Célula", str(e)
    return None


def _v_excel_ler(d, ctx):
    return _v_variavel(d, ctx) or _v_celula(d, ctx)


def _v_excel_grafico(d, ctx):
    if _vazio(d, "dados"):
        return "Gráfico", "Informe os dados do gráfico (intervalo ou nome da tabela dinâmica)."
    return None


def _v_excel_dinamica(d, ctx):
    if _vazio(d, "valores"):
        return "Tabela dinâmica", "Informe pelo menos uma coluna em 'Valores'."
    return None


def _v_excel_abrir(d, ctx):
    if _vazio(d, "arquivo"):
        return "Planilha", "Escolha o arquivo da planilha."
    return None


def _v_rolar(d, ctx):
    if str(d.get("alvo_y", "")).strip():
        try:
            d["alvo_y"] = int(float(str(d["alvo_y"]).replace(",", ".")))
        except ValueError:
            return "Rolar", "A posição exata deve ser um número de pixels (ou ficar vazia)."
    return None


def _v_tecla(d, ctx):
    try:
        ctx.parse_teclas(d["teclas"])
    except ValueError as e:
        return "Tecla inválida", str(e)
    return None


def _v_imagem(d, ctx):
    if not d["imagem"] or not ctx.existe(d["imagem"]):
        return "Imagem", "Capture ou escolha uma imagem válida."
    if not 0.3 <= d["confianca"] <= 1.0:
        return "Precisão", "A precisão deve ficar entre 0.3 e 1.0."
    return None


# --------------------------------------------------------------------------- #
# O CATÁLOGO (a ordem é a da lista "Ação" do formulário)
# --------------------------------------------------------------------------- #
CATALOGO = [
    Passo("abrir_chrome", "Abrir Chrome", "◉", [
        ("url", "Endereço (URL)", "str", "https://", None),
        ("maximizar", "Maximizar janela", "bool", True, None),
        ("controle", "Modo controlado (detecta carregamento exato)", "bool", True, None),
        ("aguardar", "Aguardar a página carregar toda", "bool", True, None),
        ("espera", "Espera mínima (s)", "float", 1.0, None),
    ], dica="Abre uma nova janela do Chrome na URL. Maximizar mantém as posições iguais. "
            "O 'modo controlado' usa um perfil próprio do bot (pasta chrome_perfil_bot) que "
            "permite saber exatamente quando a página terminou de carregar. Na 1ª vez faça "
            "login no sistema de chamados nessa janela; o login fica salvo.",
          resumo=lambda s: s.get("url", "")),

    Passo("clique", "Clique do mouse", "➤", [
        ("pos", "Posição na tela", "pos", (0, 0), None),
        ("botao", "Botão", "choice", "esquerdo", BOTOES),
        ("cliques", "Nº de cliques", "choice", "1", ["1", "2", "3"]),
        ("segurar", "Segurar tecla (Ctrl+clique, Shift+clique)", "choice", "nenhuma", SEGURAR),
        ("aguardar", "Aguardar página carregar depois", "bool", False, None),
        ("conferir", "Conferir pela imagem (corrige se mudar de lugar)", "bool", False, None),
        ("imagem", "Imagem de referência", "img", "", None),
    ], dica="Coloque a seta do mouse exatamente no ponto (campo, botão...) e aperte F8. "
            "Use 'Mostrar ponto' para conferir onde o bot vai clicar. Com 'Conferir pela imagem' o bot "
            "procura o recorte perto do ponto e corrige o clique se o elemento tiver mudado de lugar "
            "(a gravação já guarda esse recorte automaticamente). Clique gravado numa CÉLULA do Excel "
            "guarda a célula (ex.: Dados!B5): na execução o bot acha a célula na tela, mesmo rolada ou com outro zoom.",
          resumo=_r_clique, validar=_v_clique, tela=True),

    Passo("arrastar", "Arrastar (mouse)", "⇲", [
        ("pos", "Apertar em (início)", "pos", (0, 0), None),
        ("x2", "Soltar em X (px)", "int", 0, None),
        ("y2", "Soltar em Y (px)", "int", 0, None),
        ("botao", "Botão", "choice", "esquerdo", BOTOES),
        ("segurar", "Segurar tecla", "choice", "nenhuma", SEGURAR),
        ("duracao", "Duração do movimento (s)", "float", 0.6, None),
        ("aguardar", "Aguardar página carregar depois", "bool", False, None),
    ], dica="Aperta o botão no início, leva o mouse até o ponto final e solta: selecionar um intervalo de células, "
            "a alça de preencher do Excel, mover um gráfico ou arquivo, selecionar texto. A gravação cria este passo "
            "sozinha quando você arrasta. No Excel guarda as células de início e fim e as acha na tela na execução.",
          resumo=_r_arrastar, validar=_v_arrastar, tela=True),

    Passo("digitar", "Digitar texto", "✎", [
        ("texto", "Texto", "text", "", None),
        ("senha", "Senha / texto secreto (oculta e criptografa)", "bool", False, None),
        ("limpar", "Limpar campo antes (Ctrl+A)", "bool", False, None),
        ("enter", "Apertar Enter no final", "bool", False, None),
    ], dica="Clique no campo antes (passo de Clique). Aceita acentos e várias linhas. "
            "Variáveis: {data}  {hora}  {datahora} e, com planilha CSV, {NomeDaColuna}",
          resumo=_r_digitar, tela=True),

    Passo("tecla", "Tecla / atalho", "⌨", [
        ("teclas", "Tecla ou atalho", "str", "tab", None),
        ("repetir", "Repetir (vezes)", "int", 1, None),
    ], dica="Exemplos: enter, tab, esc, f5, space, backspace, delete, up, down, "
            "ctrl+t, ctrl+l, ctrl+shift+i, alt+tab, win+up",
          resumo=_r_tecla, validar=_v_tecla, tela=True),

    Passo("esperar", "Esperar", "⏱", [
        ("segundos", "Segundos", "float", 1.0, None),
    ], dica="Pausa fixa. Útil depois de abrir páginas ou enviar formulários.",
          resumo=lambda s: f"{s.get('segundos')} s"),

    Passo("aguardar_carregar", "Aguardar página carregar", "⟳", [
        ("metodo", "Como detectar", "choice", "automático", ["automático", "chrome", "visual"]),
        ("seletor", "Esperar elemento CSS (opcional)", "str", "", None),
        ("estavel", "Tempo parado p/ considerar pronto (s)", "float", 1.5, None),
        ("timeout", "Desistir depois de (s)", "float", 60.0, None),
    ], dica="Espera o navegador carregar todos os elementos. 'chrome': lê a página "
            "(documento completo, imagens, fontes e rede parada) - precisa do Chrome aberto "
            "em modo controlado. 'visual': espera a tela parar de mudar (funciona com "
            "qualquer Chrome). 'automático': usa chrome se der, senão visual. "
            "Elemento CSS opcional, ex.: #titulo, button[type=submit], .form-chamado",
          resumo=_r_aguardar, retentavel=True),

    Passo("clicar_imagem", "Clicar na imagem", "▣", [
        ("imagem", "Imagem", "img", "", None),
        ("confianca", "Precisão (0.5 a 1.0)", "float", 0.85, None),
        ("timeout", "Procurar por até (s)", "float", 10.0, None),
        ("botao", "Botão", "choice", "esquerdo", BOTOES),
        ("cliques", "Nº de cliques", "choice", "1", ["1", "2", "3"]),
        ("offset_x", "Deslocar X (px)", "int", 0, None),
        ("offset_y", "Deslocar Y (px)", "int", 0, None),
        ("aguardar", "Aguardar página carregar depois", "bool", False, None),
    ], dica="Recorte o botão/elemento com 'Capturar da tela'. O bot procura essa imagem "
            "na tela e clica no centro dela (+ deslocamento). Funciona mesmo se a "
            "página mudar de lugar.",
          resumo=_r_imagem, validar=_v_imagem, tela=True, retentavel=True),

    Passo("esperar_imagem", "Esperar imagem aparecer", "◫", [
        ("imagem", "Imagem", "img", "", None),
        ("confianca", "Precisão (0.5 a 1.0)", "float", 0.85, None),
        ("timeout", "Esperar até (s)", "float", 30.0, None),
    ], dica="O bot fica esperando até a imagem aparecer na tela (ex.: página carregou, "
            "mensagem 'Chamado aberto'). Se não aparecer no tempo, o bot para com erro.",
          resumo=_r_imagem, validar=_v_imagem, tela=True, retentavel=True),

    Passo("rolar", "Rolar página", "⇅", [
        ("pixels", "Rolar (pixels: + desce, - sobe)", "int", 300, None),
        ("pos", "Mouse sobre (0,0 = onde estiver)", "pos", (0, 0), None),
        ("alvo_y", "Posição exata na página (px, opcional)", "str", "", None),
        ("seletor", "Área rolável (CSS, opcional)", "str", "", None),
    ], dica="Rola a página. Com o Chrome em modo controlado e 'Posição exata' preenchida, o bot leva a "
            "página (ou a área rolável) exatamente para essa posição. Sem isso, gira a roda do mouse o "
            "equivalente aos pixels, com o mouse sobre o ponto indicado. A gravação preenche tudo sozinha "
            "(roda do mouse ou touchpad).",
          resumo=_r_rolar, validar=_v_rolar, tela=True),

    Passo("ler_pagina", "Ler da página", "⌕", [
        ("variavel", "Guardar em (nome da variável)", "str", "numero_chamado", None),
        ("seletor", "Elemento (CSS; vazio = página inteira)", "str", "", None),
        ("como", "Ler", "choice", "texto", ["texto", "valor do campo", "html"]),
        ("regex", "Padrão (opcional), ex.: (INC\\d+)", "str", "", None),
        ("timeout", "Esperar até (s)", "float", 15.0, None),
    ], dica="Lê um valor da página do Chrome controlado e guarda numa variável, ex.: o número do chamado "
            "depois de enviar. Use depois como {numero_chamado} em textos, no Excel ou na coluna de mesmo "
            "nome da planilha. O padrão (regex) pega só um trecho: (INC\\d+) pega 'INC0012345'.",
          resumo=_r_ler_pagina, validar=_v_variavel, retentavel=True),

    Passo("excel_abrir", "Excel: abrir planilha", "▦", [
        ("arquivo", "Planilha", "arq", "", None),
        ("aba", "Aba (vazio = a primeira/ativa)", "str", "", None),
        ("visivel", "Mostrar o Excel (senão roda invisível)", "bool", False, None),
        ("somente_leitura", "Somente leitura", "bool", False, None),
    ], dica="Abre a planilha numa cópia invisível do Excel (não mexe no Excel que você estiver usando). "
            "Se ela já estiver aberta no seu Excel, o bot usa essa janela. Sem o Excel instalado, usa "
            "openpyxl (sem macros/atualizar dados).",
          resumo=_r_excel_abrir, validar=_v_excel_abrir),

    Passo("excel_ler", "Excel: ler célula", "▦", [
        ("celula", "Célula ou intervalo (ex.: B2, Dados!A1:C10)", "str", "A1", None),
        ("variavel", "Guardar em (nome da variável)", "str", "valor", None),
    ], dica="Lê uma célula (ou intervalo) e guarda numa variável, ex.: {total}. "
            "Pode usar {linha_planilha} para a linha do chamado atual.",
          resumo=lambda s: f"{s.get('celula')} → {{{s.get('variavel', '')}}}", validar=_v_excel_ler),

    Passo("excel_escrever", "Excel: escrever célula", "▦", [
        ("celula", "Célula (ex.: D{linha_planilha}, Resumo!B3)", "str", "A1", None),
        ("valor", "Valor ou fórmula (aceita {variáveis})", "formula", "", None),
        ("idioma", "Idioma da fórmula", "choice", "automático", ["automático", "português", "inglês"]),
    ], dica="Escreve valor ou fórmula, em português (=SE(G2=\"\";\"\";G2-F2)) ou inglês (=IF(G2=\"\",\"\",G2-F2)): "
            "o idioma é detectado sozinho e funciona com o Excel em qualquer idioma. Botão ƒx = lista de "
            "funções. Num intervalo (ex.: H2:H{ultima_linha}) a fórmula é preenchida para baixo, ajustando as "
            "linhas. Variáveis: colunas da planilha, valores lidos, {data}, {proxima_linha}...",
          resumo=lambda s: f"{s.get('celula')} = \"{str(s.get('valor', ''))[:50]}\"", validar=_v_celula),

    Passo("excel_copiar", "Excel: copiar intervalo", "▦", [
        ("origem", "Copiar de (ex.: Dados!A1:F50)", "str", "", None),
        ("destino", "Colar em (ex.: Relatório!A2)", "str", "", None),
        ("so_valores", "Só os valores (sem formatação)", "bool", True, None),
    ], dica="Copia um intervalo para outro lugar (pode ser outra aba). 'Só os valores' cola sem fórmulas. "
            "Dica: origem = destino com 'só os valores' congela o resultado de uma fórmula (ex.: =AGORA()).",
          resumo=lambda s: f"{s.get('origem')} → {s.get('destino')}"
                           f"{'  (só valores)' if s.get('so_valores', True) else ''}"),

    Passo("excel_ultima_linha", "Excel: última linha preenchida", "▦", [
        ("coluna", "Coluna", "str", "A", None),
        ("aba", "Aba (vazio = a aba aberta)", "str", "", None),
        ("variavel", "Guardar em (também cria {proxima_linha})", "str", "ultima_linha", None),
    ], dica="Descobre a última linha preenchida da coluna e guarda em {ultima_linha}; "
            "{proxima_linha} é a seguinte, para inserir um registro novo (ex.: A{proxima_linha}).",
          resumo=lambda s: f"coluna {s.get('coluna', 'A')}{' da aba ' + s['aba'] if s.get('aba') else ''} → "
                           f"{{{s.get('variavel') or 'ultima_linha'}}}, {{proxima_linha}}"),

    Passo("excel_dinamica", "Excel: tabela dinâmica", "▦", [
        ("nome", "Nome da tabela dinâmica", "str", "TabelaDinamica1", None),
        ("origem", "Dados (ex.: Chamados!A1 = região inteira)", "str", "Dados!A1", None),
        ("destino", "Onde criar (ex.: Painel!A3)", "str", "Painel!A3", None),
        ("linhas", "Linhas (colunas separadas por ;)", "str", "", None),
        ("colunas", "Colunas (separadas por ;)", "str", "", None),
        ("valores", "Valores (separadas por ;)", "str", "", None),
        ("funcao", "Resumir valores por", "choice", "soma", ["soma", "contagem", "média", "máximo", "mínimo"]),
        ("filtros", "Filtros (separados por ;)", "str", "", None),
    ], dica="Cria a tabela dinâmica com os dados atuais (se já existir com o mesmo nome, é recriada). "
            "Origem com uma célula só (ex.: Chamados!A1) pega a tabela inteira, mesmo que cresça. "
            "Linhas/Colunas/Valores/Filtros são os nomes das colunas do cabeçalho. Precisa do Excel.",
          resumo=_r_excel_dinamica, validar=_v_excel_dinamica),

    Passo("excel_grafico", "Excel: gráfico", "▤", [
        ("nome", "Nome do gráfico", "str", "Grafico1", None),
        ("dados", "Dados: intervalo (Aba!A3:C8) ou nome da tabela dinâmica", "str", "", None),
        ("destino", "Onde colocar (canto superior esquerdo, ex.: Painel!H4)", "str", "Painel!H4", None),
        ("tipo_grafico", "Tipo", "choice", "colunas", ["colunas", "colunas empilhadas", "barras",
                                                       "barras empilhadas", "linhas", "pizza", "rosca", "área"]),
        ("titulo", "Título", "str", "", None),
        ("largura", "Largura (pontos)", "int", 480, None),
        ("altura", "Altura (pontos)", "int", 290, None),
    ], dica="Cria (ou recria, se já existir com o mesmo nome) um gráfico. Dados = intervalo com a 1ª coluna "
            "como categorias e a 1ª linha como nomes das séries, ou o NOME de uma tabela dinâmica (vira um "
            "gráfico dinâmico, que acompanha os filtros). Gráficos feitos sobre fórmulas se atualizam "
            "sozinhos quando os dados mudam.",
          resumo=lambda s: f"{s.get('tipo_grafico', 'colunas')} de {s.get('dados', '')} em {s.get('destino', '')}"
                           + (f"  \"{s['titulo']}\"" if s.get("titulo") else ""),
          validar=_v_excel_grafico),

    Passo("excel_macro", "Excel: rodar macro", "▦", [
        ("macro", "Nome da macro (ex.: Modulo1.GerarRelatorio)", "str", "", None),
        ("argumentos", "Argumentos (separe com ;)", "str", "", None),
        ("variavel", "Guardar o retorno em (opcional)", "str", "", None),
    ], dica="Roda uma macro VBA da planilha aberta (precisa do Excel). Ex.: Modulo1.Atualizar ou só Atualizar.",
          resumo=lambda s: s.get("macro", "") + (f"({s['argumentos']})" if s.get("argumentos") else "")),

    Passo("excel_atualizar", "Excel: atualizar / recalcular", "▦", [
        ("acao", "O que fazer", "choice", "atualizar tudo", ["atualizar tudo", "só recalcular fórmulas"]),
    ], dica="Atualizar tudo = 'Dados > Atualizar tudo' (consultas, conexões, tabelas dinâmicas) e espera "
            "terminar. Recalcular = recalcula todas as fórmulas.",
          resumo=lambda s: s.get("acao", "atualizar tudo")),

    Passo("excel_salvar", "Excel: salvar / exportar", "▦", [
        ("arquivo", "Salvar como (vazio = o mesmo arquivo)", "arq", "", None),
        ("formato", "Formato", "choice", "mesmo", ["mesmo", "xlsx", "xlsm", "pdf", "csv"]),
        ("aba", "Aba (para PDF/CSV; vazio = a aberta)", "str", "", None),
        ("fechar", "Fechar depois de salvar", "bool", True, None),
    ], dica="Salva a planilha. Em PDF/CSV salva a aba atual. No nome pode usar {data_arquivo} e "
            "{hora_arquivo}, ex.: relatorios/chamados_{data_arquivo}.pdf",
          resumo=_r_excel_salvar),

    Passo("excel_fechar", "Excel: fechar", "▦", [
        ("salvar", "Salvar antes de fechar", "bool", False, None),
    ], dica="Fecha a planilha (e o Excel invisível do bot).",
          resumo=lambda s: "salvando" if s.get("salvar") else "sem salvar"),
]

# --------------------------------------------------------------------------- #
# Arquivos e Windows (sem mouse/teclado: também em segundo plano)
# --------------------------------------------------------------------------- #
CONFLITOS = ["manter os dois", "substituir", "pular", "parar com erro"]
_DICA_CAMINHO = ("Caminhos: completos (C:\\Pasta\\arq.xlsx), relativos à pasta do bot, com ~ (sua pasta de usuário, ex.: "
                 "~\\Downloads), curingas (*.pdf) e {variáveis} ({data_arquivo}, colunas da planilha...).")


def _obrigatorio(*campos):
    nomes = {"origem": "a origem", "destino": "o destino", "arquivo": "o arquivo", "novo_nome": "o novo nome",
             "arquivos": "os arquivos", "pasta": "a pasta", "padrao": "o arquivo a esperar", "alvo": "o que abrir",
             "comando": "o comando"}

    def validar(d, ctx):
        for c in campos:
            if _vazio(d, c):
                return "Campo obrigatório", f"Informe {nomes.get(c, c)}."
        return None
    return validar


def _base(p):
    return os.path.basename(str(p or "").rstrip("\\/")) or str(p or "")


CATALOGO += [
    Passo("arq_copiar", "Arquivos: copiar", "⧉", [
        ("origem", "Copiar (arquivo ou curinga, ex.: ~\\Downloads\\*.pdf)", "str", "", None),
        ("destino", "Para (pasta, ou caminho com o novo nome)", "str", "", None),
        ("conflito", "Se já existir", "choice", "manter os dois", CONFLITOS),
        ("variavel", "Guardar o caminho final em", "str", "arquivo", None),
    ], dica="Copia um ou vários arquivos. Destino terminado em \\ (ou uma pasta que já existe) = copia para dentro "
            "da pasta, que é criada se não existir. 'Manter os dois' cria 'nome (2).ext'. " + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('origem', '')} → {s.get('destino', '')}", validar=_obrigatorio("origem", "destino")),

    Passo("arq_mover", "Arquivos: mover", "➜", [
        ("origem", "Mover (arquivo ou curinga)", "str", "", None),
        ("destino", "Para (pasta, ou caminho com o novo nome)", "str", "", None),
        ("conflito", "Se já existir", "choice", "manter os dois", CONFLITOS),
        ("variavel", "Guardar o caminho final em", "str", "arquivo", None),
    ], dica="Move (recorta e cola) arquivos. Ex.: mover o relatório baixado para Relatórios\\{data_arquivo}\\. "
            + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('origem', '')} → {s.get('destino', '')}", validar=_obrigatorio("origem", "destino")),

    Passo("arq_renomear", "Arquivos: renomear", "✎", [
        ("arquivo", "Arquivo", "str", "{arquivo}", None),
        ("novo_nome", "Novo nome (sem extensão = mantém a extensão)", "str", "", None),
        ("conflito", "Se já existir", "choice", "manter os dois", CONFLITOS),
        ("variavel", "Guardar o caminho novo em", "str", "arquivo", None),
    ], dica="Renomeia UM arquivo na mesma pasta. Ex.: novo nome = Chamados_{data_arquivo}. " + _DICA_CAMINHO,
          resumo=lambda s: f"{_base(s.get('arquivo'))} → {s.get('novo_nome', '')}",
          validar=_obrigatorio("arquivo", "novo_nome")),

    Passo("arq_excluir", "Arquivos: excluir", "✖", [
        ("arquivos", "Arquivo(s) (aceita curinga, ex.: temp\\*.csv)", "str", "", None),
        ("lixeira", "Mandar para a Lixeira (dá para recuperar)", "bool", True, None),
        ("maximo", "No máximo (segurança)", "int", 50, None),
    ], dica="Exclui arquivos (nunca pastas). Por segurança vai para a Lixeira e recusa apagar mais que o máximo de "
            "uma vez — se o curinga pegar arquivos demais, o roteiro para em vez de apagar. " + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('arquivos', '')}{'  (Lixeira)' if s.get('lixeira', True) else '  (DE VEZ)'}",
          validar=_obrigatorio("arquivos")),

    Passo("arq_pasta", "Arquivos: criar pasta", "▢", [
        ("pasta", "Pasta (cria as que faltarem)", "str", "", None),
        ("variavel", "Guardar o caminho em", "str", "pasta", None),
    ], dica="Cria a pasta (e as de cima, se faltarem). Se já existir, não faz nada. Ex.: Relatórios\\{data_arquivo}. "
            + _DICA_CAMINHO,
          resumo=lambda s: s.get("pasta", ""), validar=_obrigatorio("pasta")),

    Passo("arq_esperar", "Arquivos: esperar arquivo aparecer", "⌛", [
        ("padrao", "Arquivo (ex.: ~\\Downloads\\*.xlsx)", "str", "~\\Downloads\\*", None),
        ("so_novos", "Só arquivos novos (que aparecerem depois deste passo começar)", "bool", True, None),
        ("timeout", "Esperar até (s)", "float", 120.0, None),
        ("variavel", "Guardar o caminho em", "str", "arquivo", None),
    ], dica="Espera um arquivo aparecer E terminar de ser gravado (ignora .crdownload/.tmp de downloads em andamento). "
            "Use depois de clicar em 'Baixar' no Chrome: o caminho fica em {arquivo} para mover, renomear ou abrir no "
            "Excel. " + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('padrao', '')}  (até {s.get('timeout', 120)} s) → {{{s.get('variavel') or 'arquivo'}}}",
          validar=_obrigatorio("padrao")),

    Passo("arq_listar", "Arquivos: listar pasta", "☰", [
        ("pasta", "Pasta", "str", "", None),
        ("padrao", "Quais arquivos (ex.: *.xlsx)", "str", "*", None),
        ("subpastas", "Incluir subpastas", "bool", False, None),
        ("ordem", "Ordem", "choice", "mais novo primeiro", ["mais novo primeiro", "mais antigo primeiro", "nome"]),
        ("variavel", "Guardar em (o primeiro da lista)", "str", "arquivo", None),
    ], dica="Lista os arquivos da pasta. {arquivo} = o primeiro (com 'mais novo primeiro' = o último baixado), "
            "{arquivo_quantidade} = quantos e {arquivo_lista} = todos, separados por ;. " + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('pasta', '')}\\{s.get('padrao', '*')}  ({s.get('ordem', 'mais novo primeiro')})",
          validar=_obrigatorio("pasta")),

    Passo("arq_zip", "Arquivos: compactar / extrair zip", "⊞", [
        ("acao", "O que fazer", "choice", "compactar", ["compactar", "extrair"]),
        ("origem", "Origem (arquivo, pasta ou curinga / o .zip)", "str", "", None),
        ("destino", "Destino (o .zip / a pasta)", "str", "", None),
        ("variavel", "Guardar o caminho em", "str", "arquivo", None),
    ], dica="Compactar: um arquivo, uma pasta inteira ou um curinga viram um .zip. Extrair: o .zip vai para a pasta. "
            + _DICA_CAMINHO,
          resumo=lambda s: f"{s.get('acao', 'compactar')}: {s.get('origem', '')} → {s.get('destino', '')}",
          validar=_obrigatorio("origem", "destino")),

    Passo("win_abrir", "Windows: abrir arquivo, programa ou site", "▶", [
        ("alvo", "Abrir (arquivo, pasta, programa .exe ou https://...)", "str", "", None),
        ("argumentos", "Argumentos do programa (opcional)", "str", "", None),
        ("espera", "Esperar depois (s)", "float", 2.0, None),
    ], dica="Abre como se você desse dois cliques: arquivo no programa padrão (ex.: {arquivo} no Excel), pasta no "
            "Explorador, programa ou site. " + _DICA_CAMINHO,
          resumo=lambda s: s.get("alvo", "") + (f" {s['argumentos']}" if s.get("argumentos") else ""),
          validar=_obrigatorio("alvo")),

    Passo("win_area", "Windows: área de transferência", "⎘", [
        ("acao", "O que fazer", "choice", "copiar texto para ela", ["copiar texto para ela", "ler para variável"]),
        ("texto", "Texto a copiar (aceita {variáveis} e várias linhas)", "text", "", None),
        ("variavel", "Guardar o que estiver nela em", "str", "copiado", None),
    ], dica="Copiar: põe o texto na área de transferência (depois um passo Tecla ctrl+v cola em qualquer programa). "
            "Ler: guarda o que você ou um programa copiou (Ctrl+C) numa variável, ex.: {copiado}.",
          resumo=lambda s: (f"ler → {{{s.get('variavel') or 'copiado'}}}" if s.get("acao") == "ler para variável"
                            else f"copiar \"{str(s.get('texto', '')).replace(chr(10), ' ⏎ ')[:45]}\"")),

    Passo("win_comando", "Windows: rodar comando", "›", [
        ("comando", "Comando", "text", "", None),
        ("shell", "Rodar no", "choice", "cmd", ["cmd", "powershell"]),
        ("pasta", "Na pasta (opcional)", "str", "", None),
        ("esperar", "Esperar terminar", "bool", True, None),
        ("timeout", "Desistir depois de (s)", "float", 300.0, None),
        ("variavel", "Guardar a saída em", "str", "saida", None),
        ("parar_se_erro", "Parar o roteiro se o comando der erro", "bool", True, None),
    ], dica="Roda um comando do Windows (cmd) ou PowerShell, ou um .bat/.ps1/.py. A saída fica em {saida}. "
            "Ex.: robocopy, um script seu, ou powershell para algo que não tenha passo pronto.",
          resumo=lambda s: f"[{s.get('shell', 'cmd')}] {str(s.get('comando', '')).splitlines()[0][:60] if s.get('comando') else ''}",
          validar=_obrigatorio("comando")),
]


# --------------------------------------------------------------------------- #
# Fluxo: condições, repetições, erros (blocos que abrem e fecham)
# --------------------------------------------------------------------------- #
OPERADORES = ["é igual a", "é diferente de", "contém", "não contém", "começa com", "termina com",
              "é maior que", "é menor que", "é maior ou igual a", "é menor ou igual a", "está vazio", "não está vazio"]
_NEGAR = ("negar", "Inverter (SE NÃO ...)", "bool", False, None)
_DICA_BLOCO = (" Todo 'Se' termina num 'Fim do se' (o bot cria os dois juntos); os passos entre eles só rodam se a "
               "condição for verdadeira. Um 'Senão' no meio separa o que fazer quando ela for falsa.")


CONTINUAR_QUANDO = ["eu clicar em Continuar (ou F2)", "aparecer na página do Chrome", "aparecer na tela (OCR)"]


def _nao(s):
    return "NÃO " if s.get("negar") else ""


def _r_comparar(s):
    op = s.get("operador") or "é igual a"
    return f"{s.get('valor1', '')} {op}" + ("" if op in ("está vazio", "não está vazio") else f" {s.get('valor2', '')}")


def _v_repetir(d, ctx):
    if d.get("modo") == "para cada item da lista" and _vazio(d, "lista"):
        return "Repetir", "Informe a lista (ex.: {arquivo_lista} ou itens separados por ;)."
    if d.get("modo") == "vezes" and _vazio(d, "vezes"):
        return "Repetir", "Informe quantas vezes."
    return None


def _r_repetir(s):
    modo = s.get("modo") or "vezes"
    if modo == "para cada item da lista":
        return f"para cada item de {s.get('lista', '')}  → {{item}}"
    if modo == "enquanto (comparar valores)":
        return f"enquanto {_r_comparar(s)}"
    return f"{s.get('vezes', '')} vezes  → {{{s.get('variavel') or 'volta'}}}"


CATALOGO += [
    Passo("se_valor", "Se: comparar valores", "◇", [
        ("valor1", "Valor (aceita {variáveis})", "str", "{valor}", None),
        ("operador", "Condição", "choice", "é igual a", OPERADORES),
        ("valor2", "Com (aceita {variáveis})", "str", "", None),
    ], dica="Compara como uma pessoa: números como números (1.234,56 = 1234.56), datas dd/mm/aaaa como datas, "
            "textos sem diferenciar maiúsculas. Ex.: {total} é maior que 1000; {status} contém Fechado." + _DICA_BLOCO,
          resumo=lambda s: "se " + _r_comparar(s)),

    Passo("se_imagem", "Se: imagem aparece na tela", "◇", [
        ("imagem", "Imagem", "img", "", None),
        ("confianca", "Precisão (0.5 a 1.0)", "float", 0.85, None),
        ("espera", "Esperar até (s)", "float", 3.0, None),
        _NEGAR,
    ], dica="Verdadeiro se a imagem aparecer na tela dentro do tempo (ex.: uma mensagem de erro, um pop-up, o "
            "botão 'Próxima página'). Não dá erro se não aparecer: só segue pelo 'Senão'." + _DICA_BLOCO,
          resumo=lambda s: f"se {_nao(s)}aparecer {os.path.basename(s.get('imagem', ''))} (até {s.get('espera', 3)} s)",
          validar=lambda d, ctx: None if d.get("imagem") and ctx.existe(d["imagem"]) else
          ("Imagem", "Capture ou escolha a imagem da condição."), tela=True),

    Passo("se_arquivo", "Se: arquivo existe", "◇", [
        ("padrao", "Arquivo (aceita * e {variáveis})", "str", "", None),
        ("espera", "Esperar até (s)", "float", 0.0, None),
        _NEGAR,
    ], dica="Verdadeiro se existir algum arquivo com esse nome/curinga. Ex.: se NÃO existir Relatórios\\{data_arquivo}.pdf, "
            "gerar o relatório." + _DICA_BLOCO,
          resumo=lambda s: f"se {_nao(s)}existir {s.get('padrao', '')}", validar=_obrigatorio("padrao")),

    Passo("se_pagina", "Se: texto/elemento na página (Chrome)", "◇", [
        ("texto", "Texto (vazio = só ver se o elemento existe)", "str", "", None),
        ("seletor", "Elemento CSS (vazio = página inteira)", "str", "", None),
        ("espera", "Esperar até (s)", "float", 3.0, None),
        _NEGAR,
    ], dica="Lê a página do Chrome controlado: verdadeiro se o texto aparecer (sem diferenciar maiúsculas) ou se o "
            "elemento existir. Ex.: se a página tiver 'Chamado criado com sucesso'." + _DICA_BLOCO,
          resumo=lambda s: f"se {_nao(s)}a página tiver " + (f"\"{s['texto']}\"" if s.get("texto") else "")
          + (f" em {s['seletor']}" if s.get("seletor") else ""),
          validar=lambda d, ctx: None if (str(d.get("texto", "")).strip() or str(d.get("seletor", "")).strip()) else
          ("Condição", "Informe o texto ou o elemento CSS.")),

    Passo("se_janela", "Se: janela aberta", "◇", [
        ("titulo", "Título da janela contém", "str", "", None),
        ("espera", "Esperar até (s)", "float", 0.0, None),
        _NEGAR,
    ], dica="Verdadeiro se houver uma janela aberta cujo título contenha o texto (ex.: 'Salvar como', "
            "'Microsoft Excel', o nome de um sistema)." + _DICA_BLOCO,
          resumo=lambda s: f"se {_nao(s)}houver janela \"{s.get('titulo', '')}\"", validar=_obrigatorio("titulo")),

    Passo("senao", "Senão", "├", [], dica="Dentro de um 'Se': os passos daqui até o 'Fim do se' rodam quando a "
                                          "condição for FALSA.", resumo=lambda s: ""),
    Passo("fim_se", "Fim do se", "└", [], dica="Fecha o bloco 'Se'.", resumo=lambda s: ""),

    Passo("repetir", "Repetir", "↻", [
        ("modo", "Repetir", "choice", "vezes", ["vezes", "para cada item da lista", "enquanto (comparar valores)"]),
        ("vezes", "Quantas vezes (aceita {variáveis})", "str", "3", None),
        ("lista", "Lista (ex.: {arquivo_lista})", "str", "", None),
        ("separador", "Separador da lista", "str", ";", None),
        ("valor1", "Enquanto: valor", "str", "", None),
        ("operador", "Enquanto: condição", "choice", "é diferente de", OPERADORES),
        ("valor2", "Enquanto: com", "str", "", None),
        ("variavel", "Número da volta em", "str", "volta", None),
        ("maximo", "No máximo (voltas, segurança)", "int", 1000, None),
    ], dica="Repete os passos até o 'Fim do repetir': N vezes, para cada item de uma lista (o item fica em {item}; "
            "ex.: cada arquivo de {arquivo_lista}) ou enquanto uma comparação for verdadeira. {volta} = número da volta. "
            "O máximo evita repetir para sempre. Use 'Sair da repetição' dentro de um 'Se' para parar antes.",
          resumo=_r_repetir, validar=_v_repetir),
    Passo("fim_repetir", "Fim do repetir", "└", [], dica="Fecha o bloco 'Repetir' (volta para o início dele).",
          resumo=lambda s: ""),
    Passo("sair_repeticao", "Sair da repetição", "⤴", [], dica="Sai do 'Repetir' mais próximo e segue depois do "
                                                             "'Fim do repetir'. Normalmente dentro de um 'Se'.",
          resumo=lambda s: ""),

    Passo("tentar", "Tentar", "⚑", [], dica="Se algum passo daqui até o 'Se der erro' falhar, o roteiro NÃO para: vai "
                                           "para o 'Se der erro' (a mensagem fica em {erro}). Bom para pop-ups que "
                                           "às vezes aparecem, sistemas instáveis, itens que podem não existir.",
          resumo=lambda s: ""),
    Passo("se_der_erro", "Se der erro", "⚠", [], dica="Dentro de um 'Tentar': o que fazer quando der erro. {erro} tem a "
                                                    "mensagem. Sem erro, estes passos são pulados.",
          resumo=lambda s: "→ {erro}"),
    Passo("fim_tentar", "Fim do tentar", "└", [], dica="Fecha o bloco 'Tentar'.", resumo=lambda s: ""),

    Passo("parar_roteiro", "Parar o roteiro", "■", [
        ("resultado", "Terminar como", "choice", "sucesso", ["sucesso", "erro"]),
        ("mensagem", "Mensagem (aceita {variáveis})", "str", "", None),
    ], dica="Termina a execução aqui. 'Sucesso' encerra tudo como concluído (inclusive as próximas linhas da "
            "planilha); 'erro' conta como erro deste item (com 'continuar se der erro', a planilha segue).",
          resumo=lambda s: f"{s.get('resultado', 'sucesso')}" + (f": {s['mensagem']}" if s.get("mensagem") else "")),

    Passo("definir_variavel", "Definir variável", "≔", [
        ("nome", "Variável", "str", "contador", None),
        ("operacao", "Operação", "choice", "definir", ["definir", "somar", "subtrair", "juntar ao texto",
                                                      "codificar para link (URL)"]),
        ("valor", "Valor (aceita {variáveis})", "str", "", None),
    ], dica="Cria ou muda uma variável para usar em outros passos. Ex.: contador somar 1; total somar {valor}; "
            "nome = Chamado_{numero_chamado}. 'Codificar para link' prepara um texto para ir dentro de um endereço "
            "(espaços, acentos e quebras de linha), ex.: corpo de e-mail no link do Gmail.",
          resumo=lambda s: f"{{{s.get('nome', '')}}} {({'definir': '=', 'somar': '+=', 'subtrair': '-='}).get(s.get('operacao', 'definir'), '&=')} "
                           f"{s.get('valor', '')}",
          validar=_obrigatorio("nome")),

    Passo("aguardar_usuario", "Pausar: esperar você", "✋", [
        ("mensagem", "O que você precisa fazer (aparece no cartão)", "text", "", None),
        ("continuar", "Continuar quando", "choice", CONTINUAR_QUANDO[0], CONTINUAR_QUANDO),
        ("texto", "Texto que deve aparecer (opcional)", "str", "", None),
        ("seletor", "Chrome: seletor CSS que deve aparecer (opcional)", "str", "", None),
        ("timeout", "Esperar no máximo (s; 0 = sem limite)", "float", 0.0, None),
        ("se_acabar", "Se o tempo acabar", "choice", "dar erro", ["dar erro", "seguir"]),
    ], dica="O robô para e mostra um cartão com a mensagem e os botões Continuar e Parar (F2 também continua). "
            "Ex.: fazer login, resolver um captcha, conferir algo antes de enviar. Com 'aparecer na página' ou "
            "'aparecer na tela' ele continua sozinho quando o texto/elemento surgir (ex.: a caixa de entrada depois "
            "do login).",
          resumo=lambda s: f"\"{str(s.get('mensagem', '')).splitlines()[0][:50] if s.get('mensagem') else ''}\""
                           + ("" if str(s.get("continuar", "")).startswith("eu") else
                              f"  → continua quando {s.get('seletor') or s.get('texto') or '?'} aparecer")
                           + (f"  (até {s['timeout']:.0f} s)" if float(s.get("timeout") or 0) > 0 else "")),

    Passo("executar_roteiro", "Executar outro roteiro", "⇪", [
        ("arquivo", "Roteiro (.json)", "arq", "", None),
    ], dica="Roda outro roteiro salvo, como um pedaço deste (ex.: 'login.json' usado por vários roteiros). As "
            "variáveis são as mesmas nos dois.",
          resumo=lambda s: _base(s.get("arquivo")), validar=_obrigatorio("arquivo")),
]


# --------------------------------------------------------------------------- #
# Texto da tela (OCR do Windows)
# --------------------------------------------------------------------------- #
REGIOES_OCR = ["tela inteira", "janela da frente", "área (posição + largura e altura)", "arquivo de imagem"]
_DICA_OCR = (" Usa o leitor de texto que já vem no Windows 10/11 (leva 1 a 3 s por leitura). Funciona em qualquer "
             "programa — até em imagens, PDFs abertos e sistemas antigos.")


def _regiao_txt(s):
    r = s.get("regiao") or "tela inteira"
    if r.startswith("área"):
        return f"área ({s.get('x')}, {s.get('y')}) {s.get('largura')}x{s.get('altura')}"
    if r.startswith("arquivo"):
        return f"arquivo {s.get('arquivo') or '?'}"
    return r


CATALOGO += [
    Passo("ler_tela", "Ler texto da tela (OCR)", "⌕", [
        ("regiao", "Onde ler", "choice", "janela da frente", REGIOES_OCR),
        ("pos", "Área: canto superior esquerdo (F8)", "pos", (0, 0), None),
        ("largura", "Área: largura (px)", "int", 400, None),
        ("altura", "Área: altura (px)", "int", 120, None),
        ("arquivo", "Arquivo de imagem (png, jpg, bmp, tif; aceita {variáveis})", "arq", "", None),
        ("regex", "Padrão (opcional), ex.: (INC\\d+)", "str", "", None),
        ("idioma", "Idioma do texto", "choice", "pt-BR", ["pt-BR", "en-US"]),
        ("timeout", "Esperar o padrão aparecer até (s)", "float", 0.0, None),
        ("variavel", "Guardar em", "str", "texto_tela", None),
    ], dica="Lê o texto que está na tela e guarda numa variável, ex.: o número do protocolo que um sistema desktop "
            "mostra. Com padrão (regex) pega só o trecho, ex.: (\\d{6}) = 6 dígitos." + _DICA_OCR,
          resumo=lambda s: f"{_regiao_txt(s)} → {{{s.get('variavel') or 'texto_tela'}}}"
                           + (f"  (padrão {s['regex']})" if s.get("regex") else ""),
          validar=_obrigatorio("variavel"), tela=True, retentavel=True),

    Passo("clicar_texto", "Clicar no texto da tela (OCR)", "⌖", [
        ("texto", "Texto (uma ou mais palavras; aceita {variáveis})", "str", "", None),
        ("ocorrencia", "Qual ocorrência (1 = a primeira, de cima para baixo)", "int", 1, None),
        ("regiao", "Onde procurar", "choice", "janela da frente", REGIOES_OCR[:2]),
        ("botao", "Botão", "choice", "esquerdo", BOTOES),
        ("cliques", "Nº de cliques", "choice", "1", ["1", "2", "3"]),
        ("offset_x", "Deslocar X (px)", "int", 0, None),
        ("offset_y", "Deslocar Y (px)", "int", 0, None),
        ("idioma", "Idioma do texto", "choice", "pt-BR", ["pt-BR", "en-US"]),
        ("timeout", "Procurar por até (s)", "float", 10.0, None),
        ("aguardar", "Aguardar página carregar depois", "bool", False, None),
    ], dica="Acha um texto na tela e clica nele — ex.: o botão 'Confirmar' de um sistema em que nada mais "
            "funciona, ou o nome de um cliente numa lista. Sem diferenciar maiúsculas e acentos." + _DICA_OCR,
          resumo=lambda s: f"\"{s.get('texto', '')}\"" + (f" (ocorrência {s['ocorrencia']})"
                                                         if int(s.get("ocorrencia") or 1) > 1 else "")
          + f"  {s.get('botao', 'esquerdo')} x{s.get('cliques', 1)}",
          validar=_obrigatorio("texto"), tela=True, retentavel=True),

    Passo("se_texto_tela", "Se: texto aparece na tela (OCR)", "◇", [
        ("texto", "Texto (aceita {variáveis})", "str", "", None),
        ("regiao", "Onde procurar", "choice", "janela da frente", REGIOES_OCR[:2]),
        ("idioma", "Idioma do texto", "choice", "pt-BR", ["pt-BR", "en-US"]),
        ("espera", "Esperar até (s)", "float", 3.0, None),
        _NEGAR,
    ], dica="Verdadeiro se o texto aparecer na tela (ex.: 'Erro', 'Sessão expirada', 'Gravado com sucesso') em "
            "qualquer programa." + _DICA_OCR + _DICA_BLOCO,
          resumo=lambda s: f"se {_nao(s)}aparecer \"{s.get('texto', '')}\" na {s.get('regiao', 'janela da frente')}",
          validar=_obrigatorio("texto"), tela=True),
]


# --------------------------------------------------------------------------- #
# E-mail e notificações (não usam a tela: funcionam também em segundo plano)
# --------------------------------------------------------------------------- #
VIAS_EMAIL = ["Outlook do computador", "SMTP (Gmail, Office 365...)"]
ACOES_OUTLOOK = ["enviar", "abrir para eu revisar", "salvar como rascunho"]
SEGURANCAS_SMTP = ["STARTTLS (porta 587)", "SSL (porta 465)", "nenhuma"]
QUAIS_EMAILS = ["só os que chegarem a partir de agora", "não lidos", "o mais recente (lido ou não)"]
SE_NAO_ACHAR = ["dar erro", "seguir com as variáveis vazias"]
CANAIS = ["Windows (aviso na tela)", "Telegram", "Microsoft Teams", "Slack", "Discord", "Webhook (outro)"]


def _v_email(d, ctx):
    if d.get("acao", "enviar") == "enviar" and not any(str(d.get(k) or "").strip() for k in ("para", "cc", "cco")):
        return "Falta o destinatário", "Informe pelo menos um endereço em Para, Cc ou Cco."
    if str(d.get("via", "")).startswith("SMTP") and not str(d.get("smtp_usuario") or "").strip():
        return "Falta o usuário SMTP", "Para enviar por SMTP informe o usuário (o seu e-mail) e a senha."
    return None


def _v_notificar(d, ctx):
    canal = d.get("canal", "")
    if not str(d.get("mensagem") or "").strip():
        return "Falta a mensagem", "Escreva o texto da notificação."
    if not canal.startswith("Windows") and not str(d.get("chave") or "").strip():
        return "Falta o token/endereço", ("Telegram: o token do seu bot (do @BotFather). Teams, Slack, Discord: o "
                                          "endereço do webhook do canal.")
    if canal == "Telegram" and not str(d.get("chat_id") or "").strip():
        return "Falta o chat_id", "Informe o chat_id do Telegram (veja a dica do passo)."
    return None


CATALOGO += [
    Passo("email_enviar", "E-mail: enviar", "✉", [
        ("via", "Enviar por", "choice", VIAS_EMAIL[0], VIAS_EMAIL),
        ("para", "Para (separe com ;)", "str", "", None),
        ("cc", "Cc", "str", "", None),
        ("cco", "Cco (cópia oculta)", "str", "", None),
        ("assunto", "Assunto", "str", "", None),
        ("corpo", "Mensagem (aceita {variáveis})", "text", "", None),
        ("html", "A mensagem é HTML", "bool", False, None),
        ("anexos", "Anexos (separe com ; e aceita *.pdf)", "arq", "", None),
        ("acao", "Outlook: o que fazer", "choice", ACOES_OUTLOOK[0], ACOES_OUTLOOK),
        ("conta", "Outlook: enviar pela conta (opcional)", "str", "", None),
        ("smtp_usuario", "SMTP: usuário (seu e-mail)", "str", "", None),
        ("smtp_senha", "SMTP: senha (guardada criptografada)", "segredo", "", None),
        ("smtp_servidor", "SMTP: servidor (vazio = descobre pelo e-mail)", "str", "", None),
        ("smtp_porta", "SMTP: porta", "int", 587, None),
        ("smtp_seguranca", "SMTP: segurança", "choice", SEGURANCAS_SMTP[0], SEGURANCAS_SMTP),
    ], dica="Pelo Outlook do computador usa a conta que já está aberta (sem senha). Por SMTP: no Gmail use uma "
            "'senha de app' (Conta Google > Segurança > Senhas de app); a senha fica criptografada pelo Windows no "
            "roteiro. Ex.: assunto 'Relatório {data}' com anexo relatorios\\*.pdf. Não usa a tela.",
          resumo=lambda s: f"{'Outlook' if str(s.get('via', '')).startswith('Outlook') else 'SMTP'} → "
                           f"{s.get('para') or s.get('cc') or s.get('cco') or '?'}: \"{str(s.get('assunto', ''))[:40]}\""
                           + ("  + anexos" if s.get("anexos") else "")
                           + (f"  ({s.get('acao')})" if str(s.get("via", "")).startswith("Outlook")
                              and s.get("acao", "enviar") != "enviar" else ""),
          validar=_v_email, retentavel=True),

    Passo("email_esperar", "E-mail: esperar / ler (Outlook)", "✉", [
        ("pasta", "Pasta do Outlook (vazio = Caixa de Entrada)", "str", "", None),
        ("quais", "Quais e-mails", "choice", QUAIS_EMAILS[0], QUAIS_EMAILS),
        ("remetente", "Remetente contém (opcional; separe com ;)", "str", "", None),
        ("assunto", "Assunto contém (opcional)", "str", "", None),
        ("contem", "Texto contém (opcional)", "str", "", None),
        ("com_anexo", "Só com anexo", "bool", False, None),
        ("timeout", "Esperar chegar até (s; 0 = só olhar agora)", "float", 300.0, None),
        ("salvar_anexos", "Salvar anexos na pasta (opcional)", "str", "", None),
        ("filtro_anexos", "Só anexos com (ex.: .xlsx; *.pdf)", "str", "", None),
        ("marcar_lido", "Marcar como lido", "bool", True, None),
        ("mover_para", "Depois mover para a pasta (opcional)", "str", "", None),
        ("se_nao_achar", "Se não chegar", "choice", SE_NAO_ACHAR[0], SE_NAO_ACHAR),
        ("variavel", "Prefixo das variáveis", "str", "email", None),
    ], dica="Espera chegar (ou pega) um e-mail no Outlook do computador e guarda: {email_assunto} "
            "{email_remetente} {email_corpo} {email_data} {email_anexos} (caminhos separados por ;) e "
            "{email_qtd_anexos}. Ex.: esperar o e-mail 'Base diária' com anexo .xlsx, salvar em Downloads\\base e "
            "processar a planilha. Com 'seguir com as variáveis vazias', use 'Se: comparar' com {email_assunto}.",
          resumo=lambda s: "Outlook" + (f" [{s['pasta']}]" if s.get("pasta") else "")
                           + (f" de {s['remetente']}" if s.get("remetente") else "")
                           + (f" \"{s['assunto']}\"" if s.get("assunto") else "")
                           + f"  ({s.get('quais', '')[:22]}, até {s.get('timeout', 300)} s)"
                           + (f"  → anexos em {s['salvar_anexos']}" if s.get("salvar_anexos") else ""),
          retentavel=True),

    Passo("notificar", "Notificar (Windows, Telegram, Teams...)", "🔔", [
        ("canal", "Onde", "choice", CANAIS[0], CANAIS),
        ("titulo", "Título", "str", "Bot Genesys", None),
        ("mensagem", "Mensagem (aceita {variáveis}, ex.: {erro})", "text", "", None),
        ("chave", "Token do bot (Telegram) ou endereço do webhook — criptografado", "segredo", "", None),
        ("chat_id", "Telegram: chat_id", "str", "", None),
        ("falhar", "Se a notificação falhar, parar o roteiro", "bool", False, None),
    ], dica="Avisa no canto da tela do Windows ou no celular. Telegram: crie um bot com o @BotFather (dá o token), "
            "mande uma mensagem para ele e abra api.telegram.org/bot<TOKEN>/getUpdates para ver o chat_id. Teams: "
            "no canal, 'Fluxos de trabalho' > 'Postar em um canal quando uma solicitação de webhook for recebida' "
            "(dá o endereço). Slack/Discord: crie um 'Incoming Webhook'. Dentro de 'Se der erro', mande {erro}.",
          resumo=lambda s: f"{s.get('canal', '')}: \"{str(s.get('mensagem', '')).splitlines()[0][:50] if s.get('mensagem') else ''}\"",
          validar=_v_notificar, retentavel=True),
]


# --------------------------------------------------------------------------- #
# IA (Claude): perguntar e clicar pelo que se vê
# --------------------------------------------------------------------------- #
INCLUIR_IA = ["nada (só o texto)", "tela inteira", "janela da frente", "arquivo de imagem"]
FORMATOS_IA = ["texto", "número", "sim ou não", "JSON"]
_DICA_IA = (" Usa a IA configurada em IA › Configurar (chave da API da Anthropic; cada uso custa centavos). "
            "Não mande senhas nem dados que não possam sair da empresa.")

CATALOGO += [
    Passo("ia_perguntar", "IA: perguntar / extrair", "✦", [
        ("pergunta", "Pergunta (aceita {variáveis})", "text", "", None),
        ("incluir", "Mostrar para a IA", "choice", INCLUIR_IA[0], INCLUIR_IA),
        ("arquivo", "Arquivo de imagem (se escolheu arquivo)", "arq", "", None),
        ("formato", "Formato da resposta", "choice", FORMATOS_IA[0], FORMATOS_IA),
        ("variavel", "Guardar em", "str", "resposta", None),
    ], dica="Ex.: 'Este e-mail é reclamação, dúvida ou elogio? {email_corpo}' (texto); 'Qual o valor total da "
            "nota nesta imagem?' (número, com arquivo de imagem); 'A tela mostra uma mensagem de erro?' (sim ou não, "
            "com a janela da frente); 'Extraia nome, CPF e data deste texto: {texto_tela}' (JSON). Use a resposta "
            "com 'Se: comparar' ou nos próximos passos." + _DICA_IA,
          resumo=lambda s: f"\"{str(s.get('pergunta', '')).splitlines()[0][:50] if s.get('pergunta') else ''}\""
                           + (f" + {s.get('incluir')}" if not str(s.get("incluir", "nada")).startswith("nada") else "")
                           + f" → {{{s.get('variavel') or 'resposta'}}} ({s.get('formato', 'texto')})",
          validar=lambda d, ctx: ("Falta a pergunta", "Escreva o que a IA deve responder.")
          if not str(d.get("pergunta") or "").strip() else None, retentavel=True),

    Passo("ia_clicar", "IA: clicar no que eu descrever", "✦", [
        ("descricao_alvo", "O que clicar (ex.: botão azul 'Salvar' no rodapé)", "str", "", None),
        ("regiao", "Onde procurar", "choice", "janela da frente", ["janela da frente", "tela inteira"]),
        ("botao", "Botão", "choice", "esquerdo", BOTOES),
        ("cliques", "Nº de cliques", "choice", "1", ["1", "2", "3"]),
        ("timeout", "Tentar por até (s)", "float", 20.0, None),
        ("aguardar", "Aguardar página carregar depois", "bool", False, None),
    ], dica="A IA olha a tela e clica no elemento descrito — para telas que mudam de layout, ícones sem texto ou "
            "quando nem o elemento nem o texto funcionam. Mais lento (3 a 10 s) que os outros cliques: use quando "
            "eles não servirem." + _DICA_IA,
          resumo=lambda s: f"\"{s.get('descricao_alvo', '')}\" na {s.get('regiao', 'janela da frente')}  "
                           f"{s.get('botao', 'esquerdo')} x{s.get('cliques', 1)}",
          validar=lambda d, ctx: ("Falta a descrição", "Descreva o que clicar.")
          if not str(d.get("descricao_alvo") or "").strip() else None, tela=True, retentavel=True),
]


# --------------------------------------------------------------------------- #
# Anexos e pop-ups (passos "à prova de surpresa")
# --------------------------------------------------------------------------- #
ONDE_POPUP = ["aviso do Chrome (alerta/confirmação da página)", "janela do Windows"]
ACOES_POPUP = ["OK / aceitar", "Cancelar / não", "fechar", "clicar no botão com o texto"]
DEPOIS_POPUP = ["registrar e seguir", "parar o roteiro com erro"]

CATALOGO += [
    Passo("chrome_anexar", "Chrome: anexar arquivo (sem a janela Abrir)", "📎", [
        ("arquivos", "Arquivo(s) (separe com ;  aceita *.pdf e {variáveis})", "arq", "", None),
        ("seletor", "Campo de upload (vazio = descobrir sozinho)", "str", "", None),
        ("conferir", "Esperar o nome do arquivo aparecer na página", "bool", True, None),
        ("timeout", "Esperar até (s)", "float", 60.0, None),
    ], dica="Entrega o arquivo direto ao site (Gmail, formulários, portais), como se você escolhesse na janela "
            "'Abrir' — sem abrir essa janela, sem clicar no clipe e sem digitar caminho. Use com o formulário de "
            "envio já aberto (ex.: depois da 'Nova mensagem' no Gmail). Confere se o nome do arquivo apareceu. "
            "Funciona também em segundo plano. Precisa do Chrome em modo controlado.",
          resumo=lambda s: f"{s.get('arquivos', '')}" + ("  + conferir" if s.get("conferir", True) else ""),
          validar=_obrigatorio("arquivos"), retentavel=True),

    Passo("win_escolher_arquivo", "Windows: escolher arquivo na janela Abrir/Salvar", "🗁", [
        ("arquivo", "Arquivo (caminho; aceita {variáveis})", "arq", "", None),
        ("titulo", "Título da janela contém (opcional)", "str", "", None),
        ("timeout", "Esperar a janela abrir até (s)", "float", 20.0, None),
    ], dica="Logo depois do clique que abre a janela 'Abrir' ou 'Salvar como' do Windows (em qualquer programa): "
            "espera ela aparecer, escreve o caminho no campo Nome, confere e confirma — e espera a janela fechar. "
            "Nada de digitar às cegas antes da janela abrir. Em sites no Chrome prefira 'Chrome: anexar arquivo'.",
          resumo=lambda s: f"{s.get('arquivo', '')}" + (f"  [janela '{s['titulo']}']" if s.get("titulo") else ""),
          validar=_obrigatorio("arquivo"), retentavel=True),

    Passo("vigiar_popup", "Vigiar pop-up (durante o roteiro)", "🛡", [
        ("onde", "Onde", "choice", ONDE_POPUP[0], ONDE_POPUP),
        ("texto", "Quando o aviso tiver o texto (vazio = qualquer)", "str", "", None),
        ("acao", "Responder", "choice", ACOES_POPUP[0], ACOES_POPUP),
        ("botao", "Texto do botão (se escolheu clicar no botão)", "str", "", None),
        ("depois", "Depois de responder", "choice", DEPOIS_POPUP[0], DEPOIS_POPUP),
    ], dica="Regra que vale do ponto em que aparece até o fim da execução: sempre que surgir o aviso, o robô "
            "responde sozinho (no meio de qualquer passo ou espera) e anota no log. Ex.: aviso do Chrome 'esqueceu "
            "de anexar' → Cancelar e parar com erro; janela do Windows 'Deseja substituir' → clicar em 'Sim'; "
            "'sessão expirada' → OK. Coloque no início do roteiro. Sem regra, um aviso do Chrome que trave a página "
            "para o roteiro com a mensagem dele (em vez de seguir às cegas).",
          resumo=lambda s: f"{'Chrome' if str(s.get('onde', '')).startswith('aviso') else 'Windows'}: "
                           f"\"{s.get('texto') or 'qualquer'}\" → "
                           + (f"botão '{s.get('botao')}'" if str(s.get("acao", "")).startswith("clicar")
                              else s.get("acao", "OK"))
                           + ("  e PARAR" if str(s.get("depois", "")).startswith("parar") else "")),
]


# --------------------------------------------------------------------------- #
# Visões derivadas do catálogo (usadas pelo motor e pela tela)
# --------------------------------------------------------------------------- #
POR_TIPO = {p.tipo: p for p in CATALOGO}
TIPOS = {p.tipo: p.nome for p in CATALOGO}
TIPO_POR_NOME = {p.nome: p.tipo for p in CATALOGO}
ICONES = {p.tipo: p.icone for p in CATALOGO}
FIELDS = {p.tipo: p.campos for p in CATALOGO}
DICAS = {p.tipo: p.dica for p in CATALOGO if p.dica}
PRECISA_TELA = {p.tipo for p in CATALOGO if p.tela}
RETENTAVEIS = {p.tipo for p in CATALOGO if p.retentavel}
CAMPOS_SEGREDO = {p.tipo: [c[0] for c in p.campos if c[2] == "segredo"] for p in CATALOGO
                  if any(c[2] == "segredo" for c in p.campos)}
SUFIXO_PROTEGIDO = "_protegido"


def guardar_segredos(passo, proteger):
    """Cópia do passo para SALVAR: senhas/tokens (campos 'segredo') viram <campo>_protegido criptografado."""
    p = dict(passo)
    for k in CAMPOS_SEGREDO.get(p.get("tipo"), ()):
        if p.get(k):
            p[k + SUFIXO_PROTEGIDO] = proteger(str(p.pop(k)))
        else:
            p.pop(k, None)
    return p


def abrir_segredos(passo, abrir):
    """Ao CARREGAR: <campo>_protegido volta a ser o valor (no próprio passo). Devolve os campos que falharam."""
    falhas = []
    for k in [k for k in passo if k.endswith(SUFIXO_PROTEGIDO) and k != "texto" + SUFIXO_PROTEGIDO]:
        try:
            passo[k[:-len(SUFIXO_PROTEGIDO)]] = abrir(passo.pop(k))
        except Exception:
            passo[k[:-len(SUFIXO_PROTEGIDO)]] = ""
            falhas.append(k[:-len(SUFIXO_PROTEGIDO)])
    return falhas


def resumo(s):
    """Texto da coluna 'Detalhes' da lista de passos."""
    t = s.get("tipo")
    p = POR_TIPO.get(t)
    txt = p.resumo(s) if p and p.resumo else ""
    if t in ("clique", "clicar_imagem", "arrastar") and s.get("aguardar"):
        txt += "  + aguardar carregar"
    if t == "clique" and s.get("conferir"):
        txt += "  + conferir imagem"
    desc = s.get("descricao", "").strip()
    prog = outro_programa(s) if t in PRECISA_TELA else ""
    if prog:
        txt += f"  · no {prog.removesuffix('.exe').upper()}"
    return f"{desc}  —  {txt}" if desc else txt


def validar(d, ctx):
    """Validação do formulário do passo. Devolve None (ok) ou (título, mensagem)."""
    p = POR_TIPO.get(d.get("tipo"))
    return p.validar(d, ctx) if p and p.validar else None
